import { useState, useEffect } from 'react';
import { Box, Typography, IconButton, Hidden, Grid, LinearProgress } from '@mui/material';
import NavigateBeforeIcon from '@mui/icons-material/NavigateBefore';
import { useHistory } from 'react-router';
import { MFSubmitButton, MFTextField } from '../../lib/formik';
import { Formik } from 'formik';
import PersonOutlineOutlinedIcon from '@mui/icons-material/PersonOutlineOutlined';
import {
  AddAifApproverRequestBody,
  AifApprover,
  FundManager,
} from '../../redux-store/types/api-types';
import { useDispatch } from 'react-redux';
import {
  addAifApprover,
  AifApproverAccess,
  getAIFApproverById,
  getAmcApproverAccess,
  UpdateAifApprover,
} from '../../redux-store/actions/userManagement';
import { aifApproverSchema } from '../../utils/schema';
import { Location } from 'history';
import { CountryCodesDropDown } from '../commonComponents';

const initialValues: AddAifApproverRequestBody = {
  name: '',
  email: '',
  countryNameAndCode: 'India: +91',
  countryCode: '+91',
  phone: '',
  panNumber: '',
  pincode: '',
  buildingNo: '',
  streetName: '',
  city: '',
  state: '',
  country: '',
  isActive: true,
};

export default function AddAIFApprover({
  location,
}: {
  location: Location<{ aifApproverId: number }>;
}): JSX.Element {
  const { aifApproverId } = location.state || {};
  const history = useHistory();
  const dispatch = useDispatch();
  const [formikValues, setFormikValues] = useState<AddAifApproverRequestBody | null>();
  const [accessForEditAdd, setAccessForEditAdd] = useState(false);

  const [aifApproverDetails, setAifApproverDetails] = useState(initialValues);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    let isComponentAlive = true;
    (async function () {
      try {
        setLoading(true);
        const { amcApproverAccess } = (await dispatch(
          getAmcApproverAccess()
        )) as unknown as AifApproverAccess;
        if (aifApproverId) {
          const getAifApproverDetails = (await dispatch(
            getAIFApproverById(aifApproverId)
          )) as unknown as FundManager;
          const { pincode, buildingNo, streetName, city, state, country, panNumber, id, isActive } =
            getAifApproverDetails;
          const {
            firstName: name,
            phone,
            email,
            countryCode,
            countryNameAndCode,
          } = getAifApproverDetails.user;
          setAifApproverDetails({
            ...aifApproverDetails,
            name,
            phone,
            email,
            pincode,
            buildingNo,
            streetName,
            city,
            state,
            country,
            panNumber,
            id,
            isActive,
            countryNameAndCode: countryNameAndCode ? countryNameAndCode : 'India: +91',
            countryCode: countryCode ? countryCode : '+91',
          });
        }
        if (!isComponentAlive) return;
        setAccessForEditAdd(amcApproverAccess);
        setLoading(false);
      } catch (e) {
        console.error((e as Error).message);
      } finally {
        if (isComponentAlive) {
          setLoading(false);
        }
      }
    })();

    return () => {
      isComponentAlive = false;
    };
  }, []);

  // useEffect(() => {
  //   let isComponentActive = true;
  //   (async function () {
  //     try {
  //       if (!formikValues) return;
  //       if (!aifApprovers) {
  //         await dispatch(addAifApprover(formikValues));
  //       } else {
  //         await dispatch(UpdateAifApprover(id, formikValues));
  //       }

  //       if (!isComponentActive) return;
  //       history.push('checker');
  //     } catch (e) {
  //       console.error((e as Error).message);
  //     }
  //   })();
  //   return () => {
  //     isComponentActive = false;
  //   };
  // }, [formikValues]);

  const onSubmit = async (values: AddAifApproverRequestBody) => {
    try {
      if (!aifApproverId) {
        await dispatch(
          addAifApprover({
            ...values,
            countryCode: values.countryNameAndCode?.split(':')[1].trim(),
          })
        );
        history.push('checker');
      } else {
        await dispatch(
          UpdateAifApprover(aifApproverId, {
            ...values,
            countryCode: values.countryNameAndCode?.split(':')[1].trim(),
          })
        );
        history.push('checker-details', { aifApproverId });
      }
    } catch (e) {
      console.error((e as Error).message);
    }
    //setFormikValues({ ...values, countryCode: values.countryNameAndCode?.split(':')[1].trim() });
  };

  return (
    <>
      <Formik
        initialValues={aifApproverDetails}
        onSubmit={onSubmit}
        enableReinitialize={true}
        validationSchema={aifApproverSchema}>
        {({ handleSubmit, values }) => (
          <Box
            sx={{
              bgcolor: 'white',
              boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.05)',
              borderRadius: '10px',
              py: { xs: 2, sm: 5 },
              pl: { xs: 0, sm: 5 },
              mt: { xs: 2, sm: 5 },
            }}
            component="form"
            noValidate
            onSubmit={handleSubmit}>
            <Hidden smUp={true}>
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <IconButton
                  sx={{ height: 'fit-content', p: 0 }}
                  onClick={() =>
                    aifApproverId
                      ? history.push('checker-details', { aifApproverId: values.id })
                      : history.push('checker')
                  }>
                  <NavigateBeforeIcon fontSize="medium" sx={{ color: 'common.black' }} />
                </IconButton>
                <Typography
                  sx={{
                    fontSize: 20,
                    fontWeight: 600,
                    color: '#1C2D47',
                  }}>
                  Back
                </Typography>
              </Box>
              <Box
                sx={{
                  display: 'flex',
                  alignItems: 'center',
                  my: 2,
                  py: 2,
                  pl: { xs: 3, sm: 0 },
                  color: 'primary.main',
                  bgcolor: 'rgba(238, 244, 251, 0.5)',
                }}>
                <PersonOutlineOutlinedIcon fontSize="large" />
                <Typography
                  sx={{
                    fontSize: 20,
                    fontWeight: 600,
                    pl: 1,
                  }}>
                  User Management
                </Typography>
              </Box>
            </Hidden>
            <Box sx={{ display: 'flex', alignItems: 'center' }}>
              <Hidden only="xs">
                <IconButton
                  sx={{ height: 'fit-content', p: 0 }}
                  onClick={() =>
                    aifApproverId
                      ? history.push('checker-details', { aifApproverId: values.id })
                      : history.push('checker')
                  }>
                  <NavigateBeforeIcon fontSize="medium" sx={{ color: 'common.black' }} />
                </IconButton>
              </Hidden>
              <Typography
                sx={{
                  fontSize: 20,
                  fontWeight: 600,
                  color: '#1C2D47',
                  pl: { xs: 3, sm: 0 },
                }}>
                {aifApproverId ? 'Checker' : 'Onboarding Checker'}
              </Typography>
            </Box>
            {loading ? (
              <LinearProgress />
            ) : (
              <>
                <Grid container rowSpacing={1} columnSpacing={4} px={4} pt={3}>
                  <Grid item xs={12} sm={6} md={4}>
                    <MFTextField
                      name="name"
                      label="Name *"
                      placeholder="Enter Name"
                      disabled={!accessForEditAdd}
                    />
                  </Grid>
                  <Grid item xs={12} sm={6} md={4}>
                    <MFTextField
                      name="email"
                      label="Email Id *"
                      placeholder="Enter Email Id"
                      disabled={!accessForEditAdd}
                    />
                  </Grid>
                  <Grid item xs={12} sm={6} md={4}>
                    <MFTextField
                      name="phone"
                      label="Mobile Number *"
                      placeholder="Enter Mobile Number"
                      // startAdornment={
                      //   <CountryCodesDropDown
                      //     name={`countryNameAndCode`}
                      //     value={values.countryNameAndCode}
                      //   />
                      // }
                      disabled={!accessForEditAdd}
                    />
                  </Grid>
                  <Grid item xs={12} sm={6} md={4}>
                    <MFTextField
                      name="pincode"
                      label="Pincode"
                      placeholder="Enter Pincode"
                      disabled={!accessForEditAdd}
                    />
                  </Grid>
                  <Grid item xs={12} sm={6} md={4}>
                    <MFTextField
                      name="buildingNo"
                      label="Building Number"
                      placeholder="Enter Building Number"
                      disabled={!accessForEditAdd}
                    />
                  </Grid>
                  <Grid item xs={12} sm={6} md={4}>
                    <MFTextField
                      name="streetName"
                      label="Street Name"
                      placeholder="Enter Street Name"
                      disabled={!accessForEditAdd}
                    />
                  </Grid>
                  <Grid item xs={12} sm={6} md={4}>
                    <MFTextField
                      name="state"
                      label="State"
                      placeholder="Enter State"
                      disabled={!accessForEditAdd}
                    />
                  </Grid>
                  <Grid item xs={12} sm={6} md={4}>
                    <MFTextField
                      name="city"
                      label="City"
                      placeholder="Enter City"
                      disabled={!accessForEditAdd}
                    />
                  </Grid>
                  <Grid item xs={12} sm={6} md={4}>
                    <MFTextField
                      name="country"
                      label="Country"
                      placeholder="Enter Country"
                      disabled={!accessForEditAdd}
                    />
                  </Grid>
                </Grid>
                {accessForEditAdd && (
                  <Box sx={{ width: '100%', maxWidth: '350px', mx: 'auto', mt: 3 }}>
                    <MFSubmitButton label="Save" />
                  </Box>
                )}
              </>
            )}
          </Box>
        )}
      </Formik>
    </>
  );
}
