import {
  Box,
  Checkbox,
  FormControl,
  FormControlLabel,
  FormGroup,
  Stack,
  Typography,
} from '@mui/material';
import { Form, Formik } from 'formik';
import { useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import { useSnackbar } from 'notistack';
import {
  getInvestorReports,
  getReportSelectionList,
} from '../../redux-store/actions/investorReports';
import {
  downloadMultipleFiles,
  formatDate,
  replaceLetterOWithW,
} from '../../utils/utilityFunctions';
import { ReportSectionContainer, ReportsRightLayout } from './index';
import { TextDatePicker } from '../onboarding/DatePickerWithTextFeild';
import FormMultiSelect from '../../lib/formik/FormMultiSelect';
import { MFSubmitButton } from '../../lib/formik';
import { validationSchemaClientStatement } from '../../utils/schema';
import { Location } from 'history';
import { useHistory } from 'react-router';
import {
  getInvestorData,
  getRMDashBoardMetrics,
  getRmRedirectionLink,
} from '../../redux-store/actions/userManagement';
import {
  InvestorDetailEntity,
  RmDashboardType,
  RmRedirectionLinkType,
} from '../../redux-store/types/api-types';
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider, DatePicker } from "@mui/x-date-pickers";
import dayjs from "dayjs";
import { reportData } from '../Reports/report-utils';
import { ColumnType } from '../DataTable';

const ClientStatement = ({
  location }: {
    location: Location<{ investorId: string; investorName: string }>
  }) => {
  const dispatch = useDispatch();
  const [reportSelection, setReportSelection] = useState<any>();
  const { enqueueSnackbar } = useSnackbar();
  const { investorId, investorName } = location?.state || { investorId: '', investorName: '' };
  const history = useHistory();
  const currentDate = dayjs();
  const [loading, setLoading] = useState<boolean>(false);
  const [dates, setDates] = useState<string>(dayjs(currentDate).format("YYYY-MM-DD"));
  const [dashBoardMetricsData, setDashBoardMetricsData] = useState<RmDashboardType | null>(null);
  const [investorData, setInvestorData] = useState<InvestorDetailEntity | null>(null);
  const [investorOptions, setInvestorOptions] = useState<any>([""]);
  const options = [{ invName: investorData?.I_InvName }, { invId: investorData?.OClientID }]
  const options2 = [
    {
      header: 'Investor Name',
      value: (row: InvestorDetailEntity) => row.I_InvName,
    },]

  console.log("inv name", investorId)
  console.log("OPTions", options)
  useEffect(() => {
    let isComponentAlive = true;
    (async function () {
      try {
        const reportSelectionList = (await dispatch(getReportSelectionList())) as unknown as any[];
        const transformedRes = reportSelectionList.map((obj: any) => {
          return {
            label: obj.Name,
            value: obj.ID,
          };
        });
        if (!isComponentAlive) return;
        setReportSelection(transformedRes);
      } catch (e) {
        console.error((e as Error).message);
      }
    })();
    return () => {
      isComponentAlive = false;
    };
  }, []);

  // useEffect(() => {
  //   let isComponentActive = true;
  //   setInvestorOptions(investorData);
  //   (async function () {
  //     try {
  //       // setLoading(true);
  //       const response = (await dispatch(getRMDashBoardMetrics())) as RmDashboardType;
  //       if (!isComponentActive) {
  //         return;
  //       }
  //       setInvestorData(response);
  //       // setInvestorOptions(response.investorDetail)
  //       // setLoading(false);
  //     } catch (e) {
  //       // setLoading(false);
  //       console.log((e as Error).message);
  //     }
  //   })();
  //   return () => {
  //     isComponentActive = false;
  //   };

  // }, []);
  // console.log("inv detail", setInvestorData)
  useEffect(() => {
    // setInvestorData(investorData)

    if (!investorId) {
      let isComponentActive = true;
      setDashBoardMetricsData(null);
      (async function () {
        try {
          // setLoading(true);
          const response = (await dispatch(getRMDashBoardMetrics())) as RmDashboardType;
          if (!isComponentActive) {
            return;
          }
          setDashBoardMetricsData(response);
          setInvestorOptions(investorData?.I_InvName)
          // setLoading(false);
        } catch (e) {
          // setLoading(false);
          console.log((e as Error).message);
        }
      })();
      return () => {
        isComponentActive = false;
      };
    }
  }, [])
  const onSubmit = async (values: any) => {
    try {
      const { reportOptions, date, redeemedSchemesFlg, transactionHistoryFlg } = values;
      const formattedDate = `${new Date(date).getDate().toString().padStart(2, '0')}/${(new Date(date)?.getMonth() + 1).toString().padStart(2, '0')}/${new Date(date).getFullYear()}`;
      console.log("formattedDate", formattedDate)
      const allIdValue = reportSelection.find(
        (option: { label: string; value: string }) => option.label.toLowerCase() === 'all'
      ).value;
      if (investorId) {
        setLoading(true)
        const res = await dispatch(
          getInvestorReports({
            // clientId: [replaceLetterOWithW(investorId) || ''],
            clientId: [investorId || ''],
            toDate: formattedDate,
            reportName: 'ClientStatement',
            reportConfig: {
              redeemedSchemesFlg: redeemedSchemesFlg.toString(),
              transactionHistoryFlg: transactionHistoryFlg.toString(),
              reportOptions:
                reportOptions.indexOf(allIdValue) !== -1 ? [allIdValue] : reportOptions,
            },
          })
        );
        setLoading(false)
        downloadMultipleFiles(res);
        enqueueSnackbar('File(s) downloaded successfully.', {
          variant: 'success',
          autoHideDuration: 3000,
        });
      }
      setDates(dayjs(currentDate).format("YYYY-MM-DD"));
    } catch (e) {
      console.error((e as Error).message);
    }
  };
  console.log("investor report", options2)
  return (
    <>
      <ReportsRightLayout>
        <Typography
          sx={{
            color: 'text.secondary',
            fontSize: '16px',
            fontWeight: 500,
            lineHeight: '19px',
            letterSpacing: '0.06em',
            textTransform: 'uppercase',
            display: ['none', 'none', 'block'],
          }}>
          Client Statement
        </Typography>
        <Formik
          validationSchema={validationSchemaClientStatement}
          initialValues={{
            reportOptions: [],
            date: new Date(),
            redeemedSchemesFlg: 1,
            transactionHistoryFlg: 0,
          }}
          onSubmit={onSubmit}>
          {({
            values,
            setFieldValue,
          }: {
            values: {
              reportOptions: number[];
              date: any;
              redeemedSchemesFlg: number;
              transactionHistoryFlg: number;
            };
            setFieldValue: (
              field: string,
              value: any,
              shouldValidate?: boolean | undefined
            ) => void;
          }) => (
            <Form>
              <ReportSectionContainer>
                <Stack>
                  {/* <TextDatePicker
                    label={'You are requesting client statement'}
                    inputLabelStyles={{
                      fontSize: '14px',
                      fontWeight: 400,
                      lineHeight: '22px',
                      letterSpacing: '0.01em',
                    }}
                    placeholder={'Enter Net worth as on Date'}
                    name={`date`}
                    applyLabelStyles={true}
                  /> */}
                  <LocalizationProvider dateAdapter={AdapterDayjs}>

                    <DatePicker
                      label="You are requesting client statement"
                      format="DD-MM-YYYY"
                      value={dayjs(dates)}
                      maxDate={dayjs(currentDate)}

                      onChange={(date: any) => {
                        setDates(date.format("YYYY-MM-DD"))
                        setFieldValue('date', date)
                      }
                      }
                    />

                  </LocalizationProvider>
                </Stack>
              </ReportSectionContainer>
              <ReportSectionContainer>
                <Stack>
                  <Typography
                    sx={{
                      fontSize: '14px',
                      fontWeight: 400,
                      lineHeight: '22px',
                      letterSpacing: '0.01em',
                    }}>
                    Report Selection
                  </Typography>
                  <FormMultiSelect
                    name={'reportOptions'}
                    onChange={(e) => {
                      const value = e.target.value as Array<number>;
                      const allIdValue: number = reportSelection.find(
                        (option: { label: string; value: string }) =>
                          option.label.toLowerCase() === 'all'
                      ).value;
                      if (
                        value.length < values.reportOptions.length &&
                        value.indexOf(allIdValue) !== -1
                      ) {
                        value.splice(value.indexOf(allIdValue), 1);
                        setFieldValue('reportOptions', value);
                      } else if (value.indexOf(allIdValue) !== -1) {
                        setFieldValue(
                          'reportOptions',
                          reportSelection.map((each: any) => each.value)
                        );
                      } else if (
                        value.length === reportSelection.length - 1 &&
                        values.reportOptions.indexOf(allIdValue) === -1
                      ) {
                        setFieldValue('reportOptions', [...value, allIdValue]);
                      } else if (
                        value.indexOf(allIdValue) === -1 &&
                        values.reportOptions.indexOf(allIdValue) !== -1
                      ) {
                        setFieldValue('reportOptions', []);
                      } else {
                        setFieldValue('reportOptions', value);
                      }
                    }}
                    options={reportSelection}
                    placeholder={'Select here'}
                  />

                  <Stack>
                    <FormControl component="fieldset">
                      <FormGroup aria-label="position">
                        <FormControlLabel
                          value={Boolean(values.redeemedSchemesFlg)}
                          checked={Boolean(values.redeemedSchemesFlg)}
                          onChange={(_, checked) => {
                            setFieldValue('redeemedSchemesFlg', Number(checked));
                          }}
                          control={<Checkbox />}
                          label="Redeemed Schemes"
                          labelPlacement="end"
                        />
                        <FormControlLabel
                          value={Boolean(values.transactionHistoryFlg)}
                          checked={Boolean(values.transactionHistoryFlg)}
                          onChange={(_, checked) => {
                            setFieldValue('transactionHistoryFlg', Number(checked));
                          }}
                          control={<Checkbox />}
                          label="Transaction History (since inception)"
                          labelPlacement="end"
                        />
                      </FormGroup>
                    </FormControl>
                  </Stack>
                </Stack>
              </ReportSectionContainer>
              <Stack justifyContent="center" alignItems="center" sx={{ m: 2 }}>
                <MFSubmitButton label="Download" loadingEnable={loading} />
              </Stack>
            </Form>
          )}
        </Formik>
      </ReportsRightLayout>
    </>
  );
};

export default ClientStatement;
