import React from 'react';
import {
  Button,
  FormControl,
  FormControlLabel,
  FormHelperText,
  FormLabel,
  IconButton,
  Radio,
  RadioGroup,
  TextField,
  Drawer,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  InputLabel,
  Input,
  InputAdornment,
  Typography,
  Checkbox,
} from '@mui/material';
import { Box } from '@mui/system';
import { useEffect, useMemo, useState } from 'react';
import CancelOutlinedIcon from '@mui/icons-material/CancelOutlined';
import { ReportFilterType, RMType } from '../../redux-store/types/api-types';
import {
  applicationTypes,
  filterApplicationStatusTypes,
  filterApplicationTypes,
  getFromDate,
} from './report-utils';
import { FundProps } from '../../redux-store/types/funds';
import { Distributor, getRMsList } from '../../redux-store/actions';
import { LocalizationProvider, MobileDatePicker } from '@mui/lab';
import AdapterDateFns from '@mui/lab/AdapterDateFns';
import KeyboardArrowRightSharpIcon from '@mui/icons-material/KeyboardArrowRightSharp';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import SearchSharpIcon from '@mui/icons-material/SearchSharp';
import { useDebounce } from '../../utils/useDebounce';
import { useDispatch } from 'react-redux';

type FiltersDropDownProps = {
  filters: ReportFilterType;
  anchorEl: boolean;
  onFiltersChange: (value: ReportFilterType) => void;
  handleClose: () => void;
  funds?: FundProps[];
  distributors?: Distributor[];
  rmsList: RMType[];
};

const AccordionFilter = ({
  filterName = '',
  children,
  expanded,
  handleChange,
}: {
  filterName: string;
  children: JSX.Element;
  expanded: boolean;
  handleChange: (
    event: React.SyntheticEvent<Element, Event>,
    expanded: boolean,
    filterName: string
  ) => void;
}): JSX.Element => {
  return (
    <Accordion
      sx={{
        '&.MuiAccordion-root': {
          boxShadow: 'none',
        },
      }}
      expanded={expanded}
      onChange={(event, expanded) => handleChange(event, expanded, filterName)}>
      <AccordionSummary
        expandIcon={<ExpandMoreIcon />}
        aria-controls="panel1a-content"
        id="panel1a-header">
        <FormLabel component="legend">{filterName}</FormLabel>
      </AccordionSummary>
      <AccordionDetails>{children}</AccordionDetails>
    </Accordion>
  );
};

export const FilterDatePicker = ({
  value,
  onChange,
  placeholder = '',
  errorText = '',
}: {
  value: Date;
  onChange: (date: Date | null) => void;
  placeholder: string;
  errorText?: string;
}): JSX.Element => {
  return (
    <LocalizationProvider dateAdapter={AdapterDateFns}>
      <FormControl variant="outlined" fullWidth>
        <MobileDatePicker
          components={{ OpenPickerIcon: KeyboardArrowRightSharpIcon }}
          value={value}
          maxDate={new Date()}
          inputFormat="dd/MM/yyyy"
          onChange={onChange}
          renderInput={(params: any) => (
            <TextField
              fullWidth
              id="date-picker"
              placeholder={placeholder}
              {...params}
              sx={{
                '& .MuiInputBase-root': {
                  height: '44px',
                },
              }}
            />
          )}
          disableCloseOnSelect={false}
          showToolbar={false}
        />
        {errorText && (
          <FormHelperText error sx={{ marginLeft: 'unset' }}>
            {errorText}
          </FormHelperText>
        )}
      </FormControl>
    </LocalizationProvider>
  );
};

export const initialFilters: ReportFilterType = {
  from: getFromDate(),
  to: new Date().toISOString(),
  investorType: 'all',
  distributorId: null,
  schemeId: '',
  planId: '',
  rmId: '',
  downloadFile: false,
  status: '',
  supportRmId: '',
};

const SearchComponent = ({
  search,
  setSearch,
}: {
  search: string;
  setSearch: React.Dispatch<React.SetStateAction<string>>;
}): JSX.Element => {
  return (
    <FormControl variant="standard" sx={{ display: 'block' }}>
      <InputLabel
        htmlFor="input-with-icon-adornment"
        sx={{ '&.Mui-focused': { color: 'text.primary' } }}>
        Search
      </InputLabel>
      <Input
        id="input-with-icon-adornment"
        value={search}
        autoComplete={'off'}
        onChange={({ target: { value } }) => setSearch(value)}
        endAdornment={
          <InputAdornment position="end">
            <IconButton>
              <SearchSharpIcon sx={{ color: 'primary.main' }} />
            </IconButton>
          </InputAdornment>
        }
      />
    </FormControl>
  );
};

export const FilterDropdown = ({
  filters,
  anchorEl,
  onFiltersChange,
  handleClose,
  // funds = [],
  distributors = [],
  rmsList = [],
}: FiltersDropDownProps): JSX.Element => {
  const dispatch = useDispatch();
  const [rmSearchLoading, setRmLoading] = useState(false);
  const [rmList, setRmList] = useState<RMType[]>([]);
  const [modalState, setModalState] = useState(initialFilters);
  const [distributorSearch, setDistributorSearch] = useState('');
  const [filterExpanded, setExpanded] = useState<boolean | string>(false);
  const [rmSearch, setSearch] = useState('');
  const debounceSearchString = useDebounce(rmSearch, 500);
  // const plans = funds
  //   .map((fund) =>
  //     fund.plans
  //       .filter((plan) => plan.isActive)
  //       .map((plan) => ({ ...plan, schemeName: fund.schemeName }))
  //   )
  //   .flat();

  useEffect(() => {
    if (anchorEl) {
      setRmList(rmsList);
    }
    return () => {
      setExpanded(false);
      setSearch('');
      setDistributorSearch('');
    };
  }, [anchorEl]);

  useEffect(() => {
    let isComponentActive = true;
    (async function () {
      setRmLoading(true);
      const res = (await dispatch(getRMsList({ name: rmSearch }))) as unknown as RMType[];
      if (!isComponentActive) return;
      setRmList(res);
      setRmLoading(false);
    })();
    return () => {
      isComponentActive = false;
    };
  }, [debounceSearchString]);

  useEffect(() => {
    setModalState(filters);
  }, [filters, anchorEl]);

  const _handleModalState = () => {
    handleClose();
    setModalState(initialFilters);
  };

  const _handleApplyFilters = () => {
    onFiltersChange(modalState);
    _handleModalState();
  };

  const _handleClearFilters = () => {
    onFiltersChange(initialFilters);
    handleClose();
  };

  const _handleSelection = (item: string | number, key: string) => {
    if (key === 'status') {
      const index = (modalState[key] as string[]).indexOf(item as string);
      if (index === -1) {
        setModalState({
          ...modalState,
          [key]: [...((modalState[key] as string[]) || []), item] as string[],
        });
      } else {
        setModalState({
          ...modalState,
          [key]: (modalState[key] as string[]).filter((status: any) => status != (item as string)),
        });
      }
    } else {
      setModalState({
        ...modalState,
        [key]: item,
      });
    }
  };

  const handleAccordionExpanded = (
    event: React.SyntheticEvent<Element, Event>,
    isExpanded: boolean,
    panel: string
  ) => {
    setExpanded(isExpanded ? panel : false);
  };

  const rmListFilter = useMemo(() => {
    return (
      <>
        <SearchComponent search={rmSearch} setSearch={setSearch} />
        {rmSearchLoading ? (
          <Typography>{'Loading...'}</Typography>
        ) : (
          <Box sx={{ mt: 2 }}>
            {rmList.length ? (
              <RadioGroup aria-label="RM Name" defaultValue="" name="RM Name">
                {rmList
                  .filter((x: RMType) => x?.roleType === 'amc_rm')
                  .map((rm: RMType) => (
                    <FormControlLabel
                      key={rm.id}
                      value={rm.id}
                      onChange={() => _handleSelection(rm.id, 'rmId')}
                      control={
                        <Radio
                          size="small"
                          checked={rm.id.toString() === modalState.rmId?.toString()}
                        />
                      }
                      label={rm.name || ''}
                      title={rm.name || ''}
                    />
                  ))}
              </RadioGroup>
            ) : (
              <Typography>{'No Results found'}</Typography>
            )}
          </Box>
        )}
      </>
    );
  }, [rmList, rmSearchLoading, rmSearch, modalState]);
  const supportRmListFilter = useMemo(() => {
    return (
      <>
        <SearchComponent search={rmSearch} setSearch={setSearch} />
        {rmSearchLoading ? (
          <Typography>{'Loading...'}</Typography>
        ) : (
          <Box sx={{ mt: 2 }}>
            {rmList.length ? (
              <RadioGroup aria-label="RM Name" defaultValue="" name="RM Name">
                {rmList
                  .filter((x: RMType) => x.roleType === 'support_rm')
                  .map((rm: RMType) => (
                    <FormControlLabel
                      key={rm.id}
                      value={rm.id}
                      onChange={() => _handleSelection(rm.id, 'supportRmId')}
                      control={
                        <Radio
                          size="small"
                          checked={rm.id.toString() === modalState.supportRmId?.toString()}
                        />
                      }
                      label={rm?.name || ''}
                      title={rm?.name || ''}
                    />
                  ))}
              </RadioGroup>
            ) : (
              <Typography>{'No Results found'}</Typography>
            )}
          </Box>
        )}
      </>
    );
  }, [rmList, rmSearchLoading, rmSearch, modalState]);

  const distributorFilter = useMemo(() => {
    const filteredDistributors = distributorSearch
      ? distributors.filter((distributor) =>
        distributor.name.trim().toLowerCase().includes(distributorSearch.trim().toLowerCase())
      )
      : distributors;
    return (
      <>
        <SearchComponent search={distributorSearch} setSearch={setDistributorSearch} />
        {filteredDistributors.length ? (
          <Box sx={{ mt: 2 }}>
            <RadioGroup aria-label="Distributor Name" defaultValue="" name="Distributor Name">
              {filteredDistributors.map((distributor: Distributor) => (
                <FormControlLabel
                  key={distributor.id}
                  value={distributor.id}
                  onChange={() => _handleSelection(distributor.id, 'distributorId')}
                  control={
                    <Radio
                      size="small"
                      checked={distributor.id.toString() === modalState.distributorId?.toString()}
                    />
                  }
                  label={distributor.name}
                  title={distributor.name}
                />
              ))}
            </RadioGroup>
          </Box>
        ) : (
          <Typography>{'No Results found'}</Typography>
        )}
      </>
    );
  }, [distributorSearch, distributors, modalState]);

  return (
    <Box>
      <Drawer anchor={'right'} open={anchorEl} onClose={_handleModalState}>
        <FormControl
          component="fieldset"
          sx={{
            width: '100%',
            position: 'relative',
            p: { xs: 1, sm: 2 },
            pb: 0,
            '.MuiFormLabel-root ': { color: 'primary.main', fontWeight: 600, mb: 0.5 },
            '.MuiFormControlLabel-root': {
              ml: '-2px',
              mb: 0.75,
              width: '100%',
              alignItems: 'flex-start',
              '.MuiTypography-root': {
                color: 'text.primary',
                fontWeight: 500,
                fontSize: 14,
                overflow: { xs: 'unset', md: 'hidden' },
                whiteSpace: { xs: 'unset', md: 'nowrap' },
                textOverflow: { xs: 'unset', md: 'ellipsis' },
                wordBreak: { xs: 'break-word', md: 'unset' },
              },
              '.MuiRadio-root,.MuiCheckbox-root ,.Mui-checked': { color: 'text.primary' },
              '.MuiRadio-root,.MuiCheckbox-root ': { p: 0, mr: 0.5 },
            },
            '.MuiAccordionDetails-root': {
              paddingTop: 0,
            },
            '.MuiAccordionSummary-content.Mui-expanded': {
              marginBottom: '10px',
            },
          }}>
          <Box>
            <IconButton sx={{ float: 'right', p: 0 }} onClick={_handleModalState}>
              <CancelOutlinedIcon sx={{ color: '#EA5167' }} fontSize="large" />
            </IconButton>
          </Box>
          <Box>
            <AccordionFilter
              filterName={'Status'}
              expanded={filterExpanded === 'Status'}
              handleChange={(e, expanded, filterName) =>
                handleAccordionExpanded(e, expanded, filterName)
              }>
              <RadioGroup aria-label="status" defaultValue="" name="status">
                {filterApplicationStatusTypes.map((type: { key: string; value: string }) => (
                  <FormControlLabel
                    key={type.key}
                    value={type.key}
                    onChange={() => _handleSelection(type.key, 'status')}
                    control={
                      <Checkbox size="small" checked={modalState.status.includes(type.key)} />
                    }
                    label={type.value}
                    title={type.value}
                  />
                ))}
              </RadioGroup>
            </AccordionFilter>

            <AccordionFilter
              filterName={'RM'}
              expanded={filterExpanded === 'RM'}
              handleChange={(e, expanded, filterName) =>
                handleAccordionExpanded(e, expanded, filterName)
              }>
              {rmListFilter}
            </AccordionFilter>
            <AccordionFilter
              filterName={'Support RM'}
              expanded={filterExpanded === 'Support RM'}
              handleChange={(e, expanded, filterName) =>
                handleAccordionExpanded(e, expanded, filterName)
              }>
              {supportRmListFilter}
            </AccordionFilter>
            {/* <AccordionFilter
              filterName={'Distributor Name'}
              expanded={filterExpanded === 'Distributor Name'}
              handleChange={(e, expanded, filterName) =>
                handleAccordionExpanded(e, expanded, filterName)
              }>
              {distributorFilter}
            </AccordionFilter>
            <AccordionFilter
              filterName={'Investor Type'}
              expanded={filterExpanded === 'Investor Type'}
              handleChange={(e, expanded, filterName) =>
                handleAccordionExpanded(e, expanded, filterName)
              }>
              <RadioGroup aria-label="Investor Type" defaultValue="" name="Investor Type">
                {filterApplicationTypes.map((type: { key: string; value: string }) => (
                  <FormControlLabel
                    key={type.key}
                    value={type.key}
                    onChange={() => _handleSelection(type.key, 'investorType')}
                    control={<Radio size="small" checked={type.key === modalState.investorType} />}
                    label={type.value}
                    title={type.value}
                  />
                ))}
              </RadioGroup>
            </AccordionFilter>
            <AccordionFilter
              filterName={'Scheme'}
              expanded={filterExpanded === 'Scheme'}
              handleChange={(e, expanded, filterName) =>
                handleAccordionExpanded(e, expanded, filterName)
              }>
              <RadioGroup aria-label="scheme" defaultValue="" name="scheme">
                {funds.map((fund: FundProps) => (
                  <FormControlLabel
                    key={fund.id}
                    value={fund.id}
                    onChange={() => _handleSelection(fund.id, 'schemeId')}
                    control={<Radio size="small" checked={fund.id === modalState.schemeId} />}
                    label={fund.schemeName}
                    title={fund.schemeName}
                  />
                ))}
              </RadioGroup>
            </AccordionFilter>
            <AccordionFilter
              filterName={'Plan'}
              expanded={filterExpanded === 'Plan'}
              handleChange={(e, expanded, filterName) =>
                handleAccordionExpanded(e, expanded, filterName)
              }>
              <RadioGroup aria-label="plan" defaultValue="" name="plan">
                {plans.map((plan) => (
                  <FormControlLabel
                    key={plan.id}
                    value={plan.id}
                    onChange={() => _handleSelection(plan.id, 'planId')}
                    control={<Radio size="small" checked={plan.id === modalState.planId} />}
                    label={plan.schemeName + `${'-'}` + plan.planDescription}
                    title={plan.schemeName + `${'-'}` + plan.planDescription}
                  />
                ))}
              </RadioGroup>
            </AccordionFilter> */}
          </Box>
          <Box
            sx={{
              display: 'flex',
              justifyContent: 'center',
              mb: 2,
              mt: 2,
              '& .MuiButton-root': {
                fontSize: 16,
                mx: 1,
                px: 3.5,
                py: 0.5,
              },
            }}>
            <Button
              type="submit"
              sx={{
                color: 'common.white',
                '&, :hover': { bgcolor: 'primary.main' },
              }}
              onClick={_handleApplyFilters}>
              Apply Filters
            </Button>
            <Button
              type="reset"
              sx={{
                color: 'text.primary',
                border: '1px solid #1F4173',
                '&, :hover': { bgcolor: 'common.white' },
              }}
              onClick={_handleClearFilters}>
              Clear Filters
            </Button>
          </Box>
        </FormControl>
      </Drawer>
    </Box>
  );
};
