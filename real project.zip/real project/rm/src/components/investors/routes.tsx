import { CommonLayout } from '../commonComponents';
import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Redirect, Route, Switch, useHistory, useRouteMatch, Router } from 'react-router';
import AdditionalKYCDetails from './additionalKYCDetails';
import BankDetails from './bankDetails';
import { InvestorDetailsLayout } from './components';
import ContactDetails from './contactDetails';
import ContributorDetails from './personalDetails';
import DistributorDetails from './rmDetails';
import DocumentDetails from './documentDetails';
import Fatca from './fatca';
import InvestmentPaymentDetails from './investmentPaymentDetails';
import NomineeDetails from './nomineeDetails';
import { getApplicationDetails } from '../../redux-store/actions/application';
import { ApplicationProps } from '../../redux-store/types/api-types';
import { Location } from 'history';
import { RootStateType } from '../../redux-store/reducers';
import { USER_ROLES } from '../../utils/constant';
import RelatedPerson from './relatedPerson';
import LoginRequireRoute from '../../routes/LoginRequireRoute';
import riskProfile from './riskProfileDetails';
import riskProfilee from './servicePreferenceDetails';
import ServicePreference from './servicePreferenceDetails';
import InvestmentPreference from './investmentPreferenceDetails';

export const Routes = ({
  id,
  applicant1ReferenceId,
}: {
  id: string;
  applicant1ReferenceId?: string;
  applicationType?: string;
}): JSX.Element => {
  const history = useHistory();
  const dispatch = useDispatch();
  const { path } = useRouteMatch();

  const {
    auth: { role },
    application: { application: _application },
    investor: { token = '' },
  } = useSelector((store: RootStateType) => store);

  const { applicationNumber } = _application || {};

  useEffect(() => {
    async function fetchApplication() {
      try {
        if (role === USER_ROLES.INVESTOR && !token) {
          history.push(`/investment-details/${applicant1ReferenceId}/investor-login`);
          return;
        }
        if (id) {
          (await dispatch(getApplicationDetails(id))) as unknown as ApplicationProps;
        } else {
          history.push('/');
          console.error('No application id found');
        }
      } catch (e) {
        console.error((e as Error).message);
      }
    }
    // if (application === null) {
    fetchApplication();
    // }
  }, []);

  return (
    <InvestorDetailsLayout
      applicationId={id}
      applicant1ReferenceId={applicant1ReferenceId}
      applicationNumber={applicationNumber || ''}>
      <Router history={history}>
        <Switch>
          <Route
            exact
            path={path}
            render={() => (
              <Redirect
                to={{
                  pathname: `${path}/rm-details`,
                  state: { id, applicant1ReferenceId },
                }}
                from={location.pathname}
              />
            )}
          />
          <Route path={`${path}/rm-details`} component={DistributorDetails} />
          <Route path={`${path}/personal-details`} component={ContributorDetails} />
          <Route path={`${path}/related-person-details`} component={RelatedPerson} />
          <Route path={`${path}/contact-details`} component={ContactDetails} />
          <Route path={`${path}/additional-KYC-details`} component={AdditionalKYCDetails} />
          <Route path={`${path}/fatca`} component={Fatca} />
          <Route path={`${path}/nominee-details`} component={NomineeDetails} />
          <Route path={`${path}/risk-profiles`} component={riskProfile} />
          <Route path={`${path}/service-preference`} component={ServicePreference} />
          <Route path={`${path}/investment-preference`} component={InvestmentPreference} />
          <Route path={`${path}/bank-details`} component={BankDetails} />
          <Route path={`${path}/document-details`} component={DocumentDetails} />
          <LoginRequireRoute path="*" />
        </Switch>
      </Router>
    </InvestorDetailsLayout>
  );
};

const ApplicationRoutes = ({
  location,
}: {
  location: Location<{ id: string; applicant1ReferenceId?: string; applicationType?: string }>;
}): JSX.Element => {
  const { id = '', applicant1ReferenceId = '', applicationType = '' } = location.state || {};
  return (
    <CommonLayout>
      <Routes
        id={id}
        applicant1ReferenceId={applicant1ReferenceId}
        applicationType={applicationType}
      />
    </CommonLayout>
  );
};

export default ApplicationRoutes;
