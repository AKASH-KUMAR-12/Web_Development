/* eslint-disable @typescript-eslint/explicit-module-boundary-types */
import { ArrowDropDown, Close } from '@mui/icons-material';
import { TabContext, TabList, TabPanel } from '@mui/lab';
import { Box, Button, Grid, IconButton, Skeleton, Stack, Tab, Typography,Link, Breadcrumbs } from '@mui/material';
import { Location } from 'history';
import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { formatToIndianCurrency } from '../../utils/utilityFunctions';
import { CommonLayout, FilterDrawer } from '../commonComponents';
import FilterPortal from './filter-portal';
import ProductDebt from './product-debt';
import ProductEquity from './product-equity';
import ProductOverview from './product-overview';
import SchemeDetails from './product-scheme-details';
import TransactionDetails from './product-transaction-details';
import DashboardLayout from './dashboard-layout';
import { useHistory } from 'react-router';
import { NavigateNext as NavigateNextIcon } from '@mui/icons-material';

export function ProductTopSection({
  marketValue,
  investedValue,
  gainLoss,
  isLoading,
  xirr,
}: {
  marketValue?: number;
  investedValue?: number;
  gainLoss?: number;
  isLoading?: boolean;
  xirr?: number | null;
}) {
  
  const valueConverter = useSelector((state:any)=> state.valueConverter)
  return (
    <Box
      sx={{
        background: ' #FFFFFF',
        boxShadow: '0px 4px 28px 2px rgba(0, 0, 0, 0.08)',
        borderRadius: '5px',
        mb: 7,
        py: 2.5,
        px: [2, 2, 5, 7],
      }}>
      <Grid container spacing={2}>
        <Grid item xs={12} sm={6} md={3}>
          <Typography sx={{ fontSize: [12, 12, 13, 16], lineHeight: '19px', color: '#22242C' }}>
            Current Market Value
          </Typography>
          {isLoading ? (
            <Skeleton />
          ) : (
            <Typography
              sx={{
                fontSize: [16, 16, 16, 20],
                lineHeight: '24px',
                color: '#000',
                fontWeight: 700,
              }}>
              {marketValue ? `${formatToIndianCurrency(marketValue,valueConverter)}` : 'NA'}
            </Typography>
          )}
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Typography sx={{ fontSize: [12, 12, 13, 16], lineHeight: '19px', color: '#22242C' }}>
            Invested Value
          </Typography>
          {isLoading ? (
            <Skeleton />
          ) : (
            <Typography
              sx={{
                fontSize: [16, 16, 16, 20],
                lineHeight: '24px',
                color: '#000',
                fontWeight: 700,
              }}>
              {investedValue ? `${formatToIndianCurrency(investedValue,valueConverter)}` : 'NA'}
            </Typography>
          )}
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <Typography sx={{ fontSize: [12, 12, 13, 16], lineHeight: '19px', color: '#22242C' }}>
            Gain/Loss
          </Typography>
          {isLoading ? (
            <Skeleton />
          ) : (
            <Typography
              sx={{
                fontSize: [16, 16, 16, 20],
                lineHeight: '24px',
                color: '#000',
                fontWeight: 700,
              }}>
              {gainLoss ? `${formatToIndianCurrency(gainLoss,valueConverter)}` : 'NA'}
            </Typography>
          )}
        </Grid>
        {xirr !== null ? (
          <Grid item xs={12} sm={6} md={3}>
            <Typography sx={{ fontSize: [12, 12, 13, 16], lineHeight: '19px', color: '#22242C' }}>
              XIRR
            </Typography>
            {isLoading ? (
              <Skeleton />
            ) : (
              <Typography
                sx={{
                  fontSize: [16, 16, 16, 20],
                  lineHeight: '24px',
                  color: xirr && xirr < 0 ? '#DC3636' : '#9FD8BE',
                  fontWeight: 700,
                }}>
                {xirr ? `${xirr}%` : 'NA'}
              </Typography>
            )}
          </Grid>
        ) : null}
      </Grid>
    </Box>
  );
}

const defaultFilters = {};

export default function ProductDetails({
  location,
}: {
  location: Location<{ investorId: string; investorName: string }>;
}): JSX.Element {
  const { investorId, investorName } = location?.state || { investorId: '', investorName: '' };
  const history = useHistory();
  const [value, setValue] = useState<string>('overview');
  const [assetTypes, setAssetTypes] = useState<string[]>([]);
  const [filterElementLoading, setFilterElementLoading] = useState<boolean>(true);
  const [filterMenuAnchorEl, setFilterMenuAnchorEl] = useState<null | HTMLElement>(null);
  const filterMenuOpen = Boolean(filterMenuAnchorEl);
  const [selectedFilters, setSelectedFilters] =
    useState<{ [key: string]: string[] }>(defaultFilters);
  const handleChange = (event: React.SyntheticEvent, newValue: string) => {
    setValue(newValue);
  };
  const [viewAllSelectedFilters, setViewAllSelectedFilters] = useState(false);
  let filtersSelected = ([] as string[]).concat(...Object.values(selectedFilters));
  filtersSelected =
    filtersSelected.length > 3 && !viewAllSelectedFilters
      ? filtersSelected.slice(0, 3)
      : filtersSelected;
  useEffect(() => {
    setTimeout(() => setFilterElementLoading(false), 1);
  }, []);
  useEffect(() => {
    setSelectedFilters(defaultFilters);
  }, [value]);

  const selectedFilterElements = (
    <Box
      sx={{
        bgcolor: 'common.white',
        boxShadow: '0px 4px 28px 2px rgba(0, 0, 0, 0.08)',
        borderRadius: '5px',
        mb: 7,
        display: 'flex',
        flex: 1,
        justifyContent: 'space-between',
        p: 2,
        width: '100%',
      }}>
      <Stack
        direction="row"
        alignItems="center"
        sx={{ flex: 1, flexWrap: 'wrap', gap: 1 }}
        spacing={1}>
        {filtersSelected.map((each) => (
          <Box
            key={each}
            sx={{
              background: '#D9D9D9',
              p: '6px 8px',
              borderRadius: '9px',
              display: 'flex',
              cursor: 'pointer',
            }}>
            <Typography sx={{ color: '#323232' }}>{each}</Typography>
            <Close
              sx={{ color: '#6D6868', width: 16, ml: 1 }}
              onClick={() => {
                const updatedFilters = { ...selectedFilters };
                Object.keys(updatedFilters).map((eachSection) => {
                  if (selectedFilters?.[eachSection]?.includes(each)) {
                    updatedFilters[eachSection] = selectedFilters?.[eachSection].filter(
                      (val) => val !== each
                    );
                  } else {
                    updatedFilters[eachSection] = selectedFilters?.[eachSection];
                  }
                });
                setSelectedFilters(updatedFilters);
              }}
            />
          </Box>
        ))}
      </Stack>
      {([] as string[]).concat(...Object.values(selectedFilters)).length > 3 && (
        <Button
          endIcon={<ArrowDropDown />}
          sx={{
            fontSize: 14,
            lineHeight: '16px',
            color: '#4E5056',
            fontWeight: 500,
            padding: '4px 22px',
            boxShadow: '1px 1px 3px rgba(0, 0, 0, 0.15)',
            border: '1px solid #0BAAE7',
            borderRadius: '5px',
            height: 'fit-content',
          }}
          onClick={() => setViewAllSelectedFilters(!viewAllSelectedFilters)}>
          {viewAllSelectedFilters ? 'View Less' : ' View all'}
        </Button>
      )}
    </Box>
  );
  const breadcrumbs = location.pathname.includes('/product')
  ? [
      <Typography key="1" sx={{ color: '#BBB5B5 !important' }}>
        Products
      </Typography>,
      <Typography key="2" color="text.primary">
        {location.pathname.includes('/mutual-fund')
          ? 'Mutual Fund'
          : location.pathname.includes('/direct-equity')
          ? 'Direct Equity'
          : location.pathname.includes('/pms')
          ? 'PMS'
          : location.pathname.includes('/aif')
          ? 'AIF'
          : null}
      </Typography>,
    ]
  : [
      investorId ? (
        <Link
          key="2"
          sx={{ cursor: 'pointer', textDecoration: 'none' }}
          onClick={() => history.push('/investor', { investorId, investorName })}>
          {investorName}
        </Link>
      ) : null,
      location.pathname.includes('mutual-fund') ||
      location.pathname.includes('direct-equity') ||
      location.pathname.includes('pms') ||
      location.pathname.includes('aif') ? (
        <Typography key="3" color="text.primary">
          {location.pathname.includes('mutual-fund')
            ? 'Mutual Fund'
            : location.pathname.includes('direct-equity')
            ? 'Direct Equity'
            : location.pathname.includes('/pms')
            ? 'PMS'
            : location.pathname.includes('/aif')
            ? 'AIF'
            : null}
        </Typography>
      ) : null,
    ];

  return (
    <>
      {
        // *** Filter Disabled for the time being
        /* {!filterElementLoading && (
        <FilterPortal>
          <Box sx={{ display: 'flex' }}>
            <IconButton onClick={(e) => setFilterMenuAnchorEl(e.currentTarget)}>
              <img src="/images/filter.svg" alt="filter" />
            </IconButton>
          </Box>
          <FilterDrawer
            selectedFilters={selectedFilters}
            setSelectedFilters={setSelectedFilters}
            open={filterMenuOpen}
            anchorEl={filterMenuAnchorEl}
            onClose={() => setFilterMenuAnchorEl(null)}
          />
        </FilterPortal>
      ) */
      }
      <CommonLayout>
        {/* <DashboardLayout 
        // location={location}
      //  location={investorName}
      
        >    */}
        <Box>
         <Box
        sx={{
          background: '#EEF9F4',
          borderRadius: '16px',
          px: 3,
          py: 1.5,
          mb: 2.5,
        }}>
      <Breadcrumbs
        separator={<NavigateNextIcon fontSize="small" />}
        aria-label="breadcrumb"
        sx={{
          '& .MuiTypography-root': {
            fontSize: 20,
            lineHeight: '23px',
            fontWeight: 500,
            color: '#BBB5B5',
            '&.MuiTypography-body1': { color: '#22242C' },
          },
          '& .MuiBreadcrumbs-separator': {
            '& .MuiSvgIcon-root': { color: 'rgba(0,0,0,0.6)' },
            '&:last-of-type': {
              background: 'red',
              '& .MuiSvgIcon-root': { color: '#22242C' },
            },
          },
        }}>
        {breadcrumbs}
      </Breadcrumbs>
      </Box>
          <Box
            sx={{
              width: '100%',
              '& .MuiTabPanel-root': { py: 4, px: 0 },
              '& .MuiTab-root': {
                color: '#A1A2A2',
                opacity: 0.8,
                fontSize: 17,
                lineHeight: '24px',
                textTransform: 'capitalize',
                px: { xs: 2, md: 3, lg: 5 },
                '&.Mui-selected': {
                  color: '#4B81B1',
                },
              },
              '& .MuiTabs-indicator': {
                height: 3,
                background: '#4B81B1',
              },
            }}>
            <TabContext value={value}>
              <Box>
                <TabList
                  onChange={handleChange}
                  aria-label="product tabs"
                  variant="scrollable"
                  scrollButtons="auto">
                  <Tab label="Overview" value="overview" />
                  {assetTypes.includes('equity') && <Tab label="Equity" value="equity" />}
                  {assetTypes.includes('hybrid') && <Tab label="Hybrid" value="hybrid" />}
                  {assetTypes.includes('debt') && <Tab label="Debt" value="debt" />}
                  <Tab label="Scheme Details" value="scheme-details" />
                  <Tab label="Transaction Details" value="transaction-details" />
                </TabList>
              </Box>
              <TabPanel value="overview">
                <>
                  {filtersSelected.length ? selectedFilterElements : null}
                  <ProductOverview
                    investorId={investorId}
                    selectedFilters={selectedFilters}
                    setAssetTypes={setAssetTypes}
                  />
                </>
              </TabPanel>
              <TabPanel value="equity">
                <>
                  {filtersSelected.length ? selectedFilterElements : null}
                  <ProductEquity investorId={investorId} selectedFilters={selectedFilters} />
                </>
              </TabPanel>
              <TabPanel value="hybrid">
                <>
                  {filtersSelected.length ? selectedFilterElements : null}
                  <ProductEquity
                    investorId={investorId}
                    selectedFilters={selectedFilters}
                    forHybrid={true}
                  />
                </>
              </TabPanel>
              <TabPanel value="debt">
                <>
                  {filtersSelected.length ? selectedFilterElements : null}
                  <ProductDebt investorId={investorId} selectedFilters={selectedFilters} />
                </>
              </TabPanel>
              <TabPanel value="scheme-details">
                <>
                  {filtersSelected.length ? selectedFilterElements : null}
                  <SchemeDetails investorId={investorId} selectedFilters={selectedFilters} />
                </>
              </TabPanel>
              <TabPanel value="transaction-details">
                <>
                  {filtersSelected.length ? selectedFilterElements : null}
                  <TransactionDetails investorId={investorId} selectedFilters={selectedFilters} />
                </>
              </TabPanel>
            </TabContext>
          </Box>
          </Box>
        {/* </DashboardLayout> */}
      </CommonLayout>
    </>
  );
}
