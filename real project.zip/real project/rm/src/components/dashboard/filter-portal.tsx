import { ReactNode } from 'react';
import { createPortal } from 'react-dom';
export default function FilterPortal({ children }: { children: ReactNode }): JSX.Element | null {
  const domNode = document.getElementById('filter-container');
  return domNode ? createPortal(children, domNode) : null;
}
