/* eslint-disable @typescript-eslint/explicit-module-boundary-types */
import { ArrowDropDown, Close } from '@mui/icons-material';
import { TabContext, TabList, TabPanel } from '@mui/lab';
import { Box, Button, Stack, Tab, Typography } from '@mui/material';
import { Location } from 'history';
import React, { useEffect, useState } from 'react';
import { CommonLayout } from '../../commonComponents';
import DashboardLayout from '../dashboard-layout';
import { PageUnderConstructionIcon } from '../../customSVGs';
// import PMSOverview from './overview';
// import SchemeDetails from './scheme-details';
// import TransactionDetails from './transaction-details';

export default function Bonds({
  location,
}: {
  location: Location<{ investorId: string; investorName: string }>;
}): JSX.Element {
  const [value, setValue] = useState('1');
  const { investorId } = location.state || { investorId: '' };
  const [filterElementLoading, setFilterElementLoading] = useState<boolean>(true);
  const [filterMenuAnchorEl, setFilterMenuAnchorEl] = useState<null | HTMLElement>(null);
  const filterMenuOpen = Boolean(filterMenuAnchorEl);
  const [selectedFilters, setSelectedFilters] = useState<{ [key: string]: string[] }>({});
  const handleChange = (event: React.SyntheticEvent, newValue: string) => {
    setValue(newValue);
  };

  const [viewAllSelectedFilters, setViewAllSelectedFilters] = useState(false);
  let filtersSelected = ([] as string[]).concat(...Object.values(selectedFilters));
  filtersSelected =
    filtersSelected.length > 3 && !viewAllSelectedFilters
      ? filtersSelected.slice(0, 3)
      : filtersSelected;
  useEffect(() => {
    setTimeout(() => setFilterElementLoading(false), 1);
  }, []);
  useEffect(() => {
    setSelectedFilters({});
  }, [value]);

  const selectedFilterElements = (
    <Box
      sx={{
        bgcolor: 'common.white',
        boxShadow: '0px 4px 28px 2px rgba(0, 0, 0, 0.08)',
        borderRadius: '5px',
        mb: 7,
        display: 'flex',
        flex: 1,
        justifyContent: 'space-between',
        p: 2,
        width: '100%',
      }}>
      <Stack
        direction="row"
        alignItems="center"
        sx={{ flex: 1, flexWrap: 'wrap', gap: 1 }}
        spacing={1}>
        {filtersSelected.map((each) => (
          <Box
            key={each}
            sx={{
              background: '#D9D9D9',
              p: '6px 8px',
              borderRadius: '9px',
              display: 'flex',
              cursor: 'pointer',
            }}>
            <Typography sx={{ color: '#323232' }}>{each}</Typography>
            <Close
              sx={{ color: '#6D6868', width: 16, ml: 1 }}
              onClick={() => {
                const updatedFilters = { ...selectedFilters };
                Object.keys(updatedFilters).map((eachSection) => {
                  if (selectedFilters?.[eachSection]?.includes(each)) {
                    updatedFilters[eachSection] = selectedFilters?.[eachSection].filter(
                      (val) => val !== each
                    );
                  } else {
                    updatedFilters[eachSection] = selectedFilters?.[eachSection];
                  }
                });
                setSelectedFilters(updatedFilters);
              }}
            />
          </Box>
        ))}
      </Stack>
      {([] as string[]).concat(...Object.values(selectedFilters)).length > 3 && (
        <Button
          endIcon={<ArrowDropDown />}
          sx={{
            fontSize: 14,
            lineHeight: '16px',
            color: '#4E5056',
            fontWeight: 500,
            padding: '4px 22px',
            boxShadow: '1px 1px 3px rgba(0, 0, 0, 0.15)',
            border: '1px solid #0BAAE7',
            borderRadius: '5px',
            height: 'fit-content',
          }}
          onClick={() => setViewAllSelectedFilters(!viewAllSelectedFilters)}>
          {viewAllSelectedFilters ? 'View Less' : ' View all'}
        </Button>
      )}
    </Box>
  );

  return (
    <>
      {
        // *** Filter Disabled for the time being
        /* {!filterElementLoading && (
        <FilterPortal>
          <Box sx={{ display: 'flex' }}>
            <IconButton onClick={(e) => setFilterMenuAnchorEl(e.currentTarget)}>
              <img src="/images/filter.svg" alt="filter" />
            </IconButton>
          </Box>
          <FilterDrawer
            selectedFilters={selectedFilters}
            setSelectedFilters={setSelectedFilters}
            open={filterMenuOpen}
            anchorEl={filterMenuAnchorEl}
            onClose={() => setFilterMenuAnchorEl(null)}
          />
        </FilterPortal>
      ) */
      }

      <CommonLayout>
        <DashboardLayout location={location}>
          <Box
            sx={{
              width: '100%',
              '& .MuiTabPanel-root': { py: 4, px: 0 },
              '& .MuiTab-root': {
                color: '#A1A2A2',
                opacity: 0.8,
                fontSize: 17,
                lineHeight: '24px',
                textTransform: 'capitalize',
                px: { xs: 2, md: 3, lg: 5 },
                '&.Mui-selected': {
                  color: '#4B81B1',
                },
              },
              '& .MuiTabs-indicator': {
                height: 3,
                background: '#4B81B1',
              },
            }}>
            <TabContext value={value}>
            <Box
        sx={{
          background: ' #FFFFFF',
          boxShadow: '0px 4px 28px 2px rgba(0, 0, 0, 0.08)',
          borderRadius: '5px',
          mb: 7,
          mt: 10
        }}>
             <Box
          sx={{
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            px: 5,
            py: 5,
          }}>
            <PageUnderConstructionIcon/>
          <Typography
            sx={{
              color: '#22242C',
              opacity: 0.8,
              fontSize: 25,
              lineHeight: '19px',
              fontWeight: 800,
              mt: 8
            }}>
            Page Under Development
          </Typography>
        </Box>
            </Box>
              {/* <Box>
                <TabList
                  onChange={handleChange}
                  aria-label="product tabs"
                  variant="scrollable"
                  scrollButtons="auto">
                  <Tab label="Overview" value="1" />
                  <Tab label="Scheme Details" value="2" />
                  <Tab label="Transaction Details" value="3" />
                </TabList>
              </Box> */}
              {/* <TabPanel value="1">
                <>{filtersSelected.length ? selectedFilterElements : null}</>
                <PMSOverview investorId={investorId} />
              </TabPanel>
              <TabPanel value="2">
                <>{filtersSelected.length ? selectedFilterElements : null}</>
                <SchemeDetails investorId={investorId} />
              </TabPanel>
              <TabPanel value="3">
                <>{filtersSelected.length ? selectedFilterElements : null}</>
                <TransactionDetails investorId={investorId} />
              </TabPanel> */}
            </TabContext>
          </Box>
        </DashboardLayout>
      </CommonLayout>
    </>
  );
}
