import "./styles.css";

export function TransactionAssetClassTab ({investorId, schemes}:{investorId:string, schemes:any}) {
return (
    <div
      className="fundCardContainer  homeContainer"
      style={{ padding: 15, alignItems: "center" }}
    >
      <div style={{ height: "100%" }}>
        {/*
          src={fundDetail.ImageURL}
          style={{ height: 60, width: 60 }}
          alt=""
        /> */}
      </div>
      <div style={{ marginLeft: 20, paddingTop: 5 }}>
        {/* <div>{fundDetail.Sub_AssetclassName}</div>
        <div className="fundCatdesc">{fundDetail.Descripti}</div> */}
        <div>{schemes}</div>
        <div className="fundCatdesc">Asset class description</div>
      </div>
    </div>
)
}