import { Location } from 'history';
import {
  Box,
  Breadcrumbs,
  Grid,
  Typography, Button, Stack, Tab, Divider
} from '@mui/material';
import { TabContext, TabList, TabPanel } from '@mui/lab';
import { CommonLayout, AmountUnit } from '../commonComponents';
import NavigateNextIcon from '@mui/icons-material/NavigateNext';
import SaveAltRoundedIcon from '@mui/icons-material/SaveAltRounded';
import { useEffect, useState } from 'react';
// import TabComponent from './tabs'
import { TransactionAssetClassTab } from './transaction-tabs';
import SubFundCategory from './sub-fund-category';
import SchemeDetail from './scheme-detail';

export default function InvestorTransactions({
  location,
}: {
  location: Location<{ investorId: string; investorName: string }>;
}): JSX.Element {

  const [value, setValue] = useState<string>("equity");
  const [open, setOpen] = useState<boolean>(false);
  const [arrSubAsset, setArrSubAsset] = useState<any>([]);
  const [itemSelected, setItemSelected] = useState({});
  const [itemIndexSelected, setIndexItemSelected] = useState(0);
  const [viewSubList, setViewSubList] = useState(false);
  const [viewSchemeDetails, setViewSchemeDetails] = useState<boolean>(false);
  const { investorId, investorName } = location?.state || { investorId: '', investorName: '' };
  const [openModal, setOpenModal] = useState(false);

  const handleModalOpen = () => setOpenModal(true);
  const handleModalClose = () => setOpenModal(false);

  const handleChange = (event: any, value: any) => {
    setValue(value);
  };

  const toggleDrawer = () => {
    setOpen(!open);
  };

  useEffect(() => {
    const fetchData = async () => {
      window.scrollTo({
        top: 0,
        behavior: "smooth",
      });
      await handleFundCategoryChange("Equity");
    };

    fetchData();
  }, []);

  useEffect(() => {
    handleFundCategoryChange(value);
  }, [value]);

  const handleFundCategoryChange = async (type: any) => {
    if (type == "equity") setArrSubAsset(['equity'])
    if (type == "debt") setArrSubAsset(['debt'])
    if (type == "hybrid") setArrSubAsset(['hybrid'])
    if (type == "liquid") setArrSubAsset(['liquid'])
    // const response = await props.getSubAssetSchemeClasses(type);
    // if (response.hasOwnProperty("sub_asset_classes")) {
    //   setArrSubAsset(response.sub_asset_classes);
    // } else {
    //   alert(response.error);
    // }
  };

  const breadcrumbs = [
    <Typography key="1" sx={{ color: '#BBB5B5 !important' }}>
      {investorName}
    </Typography>,
    <Typography key="2" color="text.primary">
      Transactions
    </Typography>,
  ];

  const handleClick = (item: any, index: any) => () => {
    setViewSubList(true);
    setItemSelected(item);
    setIndexItemSelected(index);
  };

  const fundCategories = [
    { title: "Equity" },
    { title: "Debt" },
    { title: "Hybrid" },
    { title: "Liquid" },
  ];

  const handleSetViewSchemeDetails = (val: boolean) => {
    setViewSchemeDetails(val);
  }


  return (
    <div>

      <CommonLayout>
        <>

          <Box
            sx={{
              background: '#EEF9F4',
              borderRadius: '16px',
              px: 3,
              py: 1.5,
              mb: 2.5,
            }}>
            <Breadcrumbs
              separator={<NavigateNextIcon fontSize="small" />}
              aria-label="breadcrumb"
              sx={{
                '& .MuiTypography-root': {
                  fontSize: 20,
                  lineHeight: '23px',
                  fontWeight: 500,
                  color: '#BBB5B5',
                  '&.MuiTypography-body1': { color: '#22242C' },
                },
                '& .MuiBreadcrumbs-separator': {
                  '& .MuiSvgIcon-root': { color: 'rgba(0,0,0,0.6)' },
                  '&:last-of-type': {
                    background: 'red',
                    '& .MuiSvgIcon-root': { color: '#22242C' },
                  },
                },
              }}>
              {breadcrumbs}
            </Breadcrumbs>
          </Box>
          <Box
            sx={{
              mb: 3
            }}>
            <AmountUnit />
            <Button
              onClick={() => window.print()}

              sx={{
                marginLeft: '20px',
                height: '27px',
                color: 'white',
                fontSize: '13px',
                cursor: 'pointer',
                borderRadius: '5px',
                bgcolor: '#4990F0',
                '&:hover': { backgroundColor: '#639FF0' },
              }}>Download   PDF <SaveAltRoundedIcon sx={{ fontSize: '20px', marginLeft: '8px' }} /></Button>
          </Box>
          <Box
            sx={{
              bgcolor: 'common.white',
              boxShadow: '0px 4px 28px 2px rgba(0, 0, 0, 0.08)',
              borderRadius: '5px',
              py: 2,
            }}>
            {!viewSubList && !viewSchemeDetails && <Grid container>
              <Box
                sx={{
                  width: '100%',
                  '& .MuiTabPanel-root': { py: 2, px: 0 },
                  '& .MuiTab-root': {
                    color: '#A1A2A2',
                    opacity: 0.8,
                    fontSize: 17,
                    lineHeight: '24px',
                    textTransform: 'capitalize',
                    px: { xs: 2, md: 3, lg: 5 },
                    '&.Mui-selected': {
                      color: '#4B81B1',
                    },
                  },
                  '& .MuiTabs-indicator': {
                    height: 3,
                    background: '#4B81B1',
                  },
                }}>
                <TabContext value={value}>
                  <Box sx={{ px: 3 }}>
                    <TabList
                      onChange={handleChange}
                      aria-label="product tabs"
                      variant="scrollable"
                      scrollButtons="auto">
                      <Tab label="Equity" value="equity" />
                      <Tab label="Debt" value="debt" />
                      <Tab label="Hybrid" value="hybrid" />
                      <Tab label="Liquid" value="liquid" />
                    </TabList>
                  </Box>
                  <Divider />
                  <Box sx={{ px: 3 }}>
                    <TabPanel value="equity">
                      <>
                        {arrSubAsset.map((ele: any, index: number) => (
                          <div
                            key={index}
                            style={{ cursor: "pointer" }}
                            onClick={handleClick(ele, index)}
                          >
                            <TransactionAssetClassTab investorId={investorId} schemes={ele} />
                          </div>
                        )
                        )}
                      </>
                    </TabPanel>
                    <TabPanel value="debt">
                      <>
                        {arrSubAsset.map((ele: any, index: number) => (
                          <div
                            key={index}
                            style={{ cursor: "pointer" }}
                            onClick={handleClick(ele, index)}
                          >
                            <TransactionAssetClassTab investorId={investorId} schemes={ele} />
                          </div>
                        )
                        )}
                      </>
                    </TabPanel>
                    <TabPanel value="hybrid">
                      <>
                        {arrSubAsset.map((ele: any, index: number) => (
                          <div
                            key={index}
                            style={{ cursor: "pointer" }}
                            onClick={handleClick(ele, index)}
                          >
                            <TransactionAssetClassTab investorId={investorId} schemes={ele} />
                          </div>
                        )
                        )}
                      </>
                    </TabPanel>
                    <TabPanel value="liquid">
                      <>
                        {arrSubAsset.map((ele: any, index: number) => (
                          <div
                            key={index}
                            style={{ cursor: "pointer" }}
                            onClick={handleClick(ele, index)}
                          >
                            <TransactionAssetClassTab investorId={investorId} schemes={ele} />
                          </div>
                        )
                        )}
                      </>
                    </TabPanel>
                  </Box>
                </TabContext>
              </Box>
              {/* <TabComponent
                value={value}
                tabsArray={fundCategories}
                handleChange={handleChange}
                // position={false}
              >
                  <div>
                    {arrSubAsset.map((ele, index) => (
                      <div
                        key={index}
                        style={{ cursor: "pointer" }}
                        onClick={handleClick(ele, index)}
                      >
                        <FundCatCard
                          fundDetail={ele}
                          close={toggleDrawer}
                        />
                      </div>
                    ))}
                  </div>
              </TabComponent> */}

            </Grid>
            }
            {viewSubList && !viewSchemeDetails && <Grid container >
              <SubFundCategory
                handleBackClick={() => {
                  setViewSubList(false);
                }
                }
                handleModalOpen={handleModalOpen}
                handleModalClose={handleModalClose}
                openModal={openModal}
                setViewSubList={setViewSubList}
                handleSetViewSchemeDetails={handleSetViewSchemeDetails}
              />
            </Grid>
            }
            {viewSchemeDetails && <Grid container >
              <SchemeDetail
                handleBackClick={() => {
                  setViewSubList(true);
                  setViewSchemeDetails(false);
                }
                }
                handleSetViewSchemeDetails={handleSetViewSchemeDetails}
              />
            </Grid>}
          </Box>
        </>
      </CommonLayout>
    </div>
  );
}
