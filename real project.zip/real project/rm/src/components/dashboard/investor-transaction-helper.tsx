import { Box, Button, Divider, Switch, Typography } from "@mui/material";
import Checkbox from '@mui/material/Checkbox';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import "./styles.css";
import { formatToIndianCurrency } from "../../utils/utilityFunctions";
import { CloseIcon, DeleteIcon } from "../customSVGs";
import { useState } from "react";

export function SubFundCategoryCard(
  { onSchemeSelection, schemeId, OnSchemeDeSelection, handleSetViewSchemeDetails }:
    {
      onSchemeSelection: (schemeId: string) => void;
      schemeId: string;
      OnSchemeDeSelection: (schemeId: string) => void;
      handleSetViewSchemeDetails: (val: boolean) => void;
    }
) {

  const handleSchemeCheckboxChange = (e: any) => {
    if (e.target.checked == true) {
      onSchemeSelection(schemeId);
    }
    else {
      OnSchemeDeSelection(schemeId);
    }
  }
  return (
    <div>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', cursor: 'pointer', my: 2.5 }}>
        <Box sx={{ width: '10%' }}>
          <Checkbox sx={{ color: '#337FC9', mx: 1.5 }} onChange={handleSchemeCheckboxChange} />
        </Box>
        <Box sx={{ marginRight: 15, display: 'flex', flexDirection: 'column', width: "23%" }}>
          <Typography sx={{ fontSize: 14, fontWeight: 500, mb: 0.5 }}>
            Canara Robeco Bluechip Equity
          </Typography>
          <Box sx={{ display: 'flex' }}>
            {/* {!!fundItem.AssetClassName && ( */}
            <Bubble text={"Equity"} />
            {/* )} */}
            {/* {!!fundItem.Sub_AssetclassName && ( */}
            <Bubble text={"Large-Cap"} />
            {/* )} */}
            {/* {!!plan && <Bubble text={plan} />}
          {subPlan.length !== 0 && <Bubble text={subPlan} />}
          {!!subPlan&&!!fundItem.Dividendfrequency && ( */}
            <Bubble text={"Growth"} />
            {/* )} */}
          </Box>
        </Box>
        <Box sx={{ width: "15%" }}>
          <Typography sx={{ fontSize: 14, color: '#5a7c82' }}>AUM</Typography>
          <Typography sx={{ fontSize: 16 }}>
            {/* {fundItem.Aum === "0" || !fundItem.Aum
            ? "NA"
            : `₹${currencyConverter(fundItem.Aum)}`} */}
            {formatToIndianCurrency(100000000, 1)}
          </Typography>
        </Box>

        <Box sx={{ width: "17%", display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
          <Typography sx={{ fontSize: 14, color: '#5a7c82' }}>Category Avg Returns</Typography>
          <Typography sx={{ fontSize: 16, color: "rgb(30, 163, 98)" }}>
            {/* {fundItem.Aum === "0" || !fundItem.Aum
            ? "NA"
            : `₹${currencyConverter(fundItem.Aum)}`} */}
            10.86%
          </Typography>
        </Box>

        <Box sx={{ width: "15%", display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
          <Typography sx={{ fontSize: 14, color: '#5a7c82' }}>Returns</Typography>
          <Typography sx={{ fontSize: 16, color: "rgb(30, 163, 98)" }}>
            {/* {fundItem.Aum === "0" || !fundItem.Aum
            ? "NA"
            : `₹${currencyConverter(fundItem.Aum)}`} */}
            14.07%
          </Typography>
        </Box>
        <Box sx={{ width: '8%' }}>
          <ArrowForwardIosIcon onClick={() => { handleSetViewSchemeDetails(true); }} sx={{ borderRadius: 1, backgroundColor: '#337FC9', color: '#ffffff', p: 0.2, mx: 1.5 }} />
        </Box>
      </Box>

    </div>
  )
}

export function Bubble(props: { text: string }) {
  return (
    <div className="bubbleDiv">
      <div className="bubbleText">
        {props.text}
      </div>
    </div>
  );
}

export function RecommendedSchemesModal({ handleModalClose, selectedSchemes, OnSchemeDeSelection }: { handleModalClose: () => void; selectedSchemes: { schemeId: string; }[]; OnSchemeDeSelection: (schemeId: string) => void; }) {
  return (
    <Box>
      <Box sx={{ mb: 3, px: 3, display: 'flex', justifyContent: 'space-between' }}>
        <Typography sx={{ fontSize: 16, fontWeight: 500 }}>
          Recommended Schemes
        </Typography>
        <Box onClick={handleModalClose} sx={{ cursor: 'pointer' }}>
          <CloseIcon />
        </Box>
      </Box>
      <Divider />
      {
        selectedSchemes.map((val, index) => {
          return (
            <Box sx={{ px: 2, mb: 6 }} key={index}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', cursor: 'pointer', my: 2.5 }}>
                <Box sx={{ marginRight: 15, display: 'flex', flexDirection: 'column', width: "23%" }}>
                  <Typography sx={{ fontSize: 14, fontWeight: 500, mb: 0.5 }}>
                    Canara Robeco Bluechip Equity
                  </Typography>
                  <Box sx={{ display: 'flex' }}>
                    {/* {!!fundItem.AssetClassName && ( */}
                    <Bubble text={"Equity"} />
                    {/* )} */}
                    {/* {!!fundItem.Sub_AssetclassName && ( */}
                    <Bubble text={"Large-Cap"} />
                    {/* )} */}
                    {/* {!!plan && <Bubble text={plan} />}
          {subPlan.length !== 0 && <Bubble text={subPlan} />}
          {!!subPlan&&!!fundItem.Dividendfrequency && ( */}
                    <Bubble text={"Growth"} />
                    {/* )} */}
                  </Box>
                </Box>
                <Box sx={{ width: "16%", display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                  <Typography sx={{ fontSize: 14, color: '#5a7c82' }}>Returns</Typography>
                  <Typography sx={{ fontSize: 16, color: "rgb(30, 163, 98)" }}>
                    {/* {fundItem.Aum === "0" || !fundItem.Aum
            ? "NA"
            : `₹${currencyConverter(fundItem.Aum)}`} */}
                    14.07%
                  </Typography>
                </Box>
                <Box sx={{ width: "21%", display: 'flex', flexDirection: 'column', alignItems: "center" }}>
                  <Typography sx={{ fontSize: 14, color: '#5a7c82', mb: 0.5 }}>Investment Amount</Typography>
                  <input className='investmentAmount' placeholder="Enter Amount">
                  </input>
                </Box>
                <Box sx={{ width: "23%", display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <Typography
                    sx={{
                      color: '#22242C',
                      opacity: 0.8,
                      fontSize: 14,
                    }}>
                    SIP
                  </Typography>
                  <Switch
                    // checked={selectedAssetsType === 'assetClass'}
                    // onChange={(_, checked) =>
                    //   setSelectedAssetsType(checked ? 'assetClass' : 'product')
                    // }
                    sx={{
                      p: 0,
                      mx: 2,
                      height: 20,
                      width: 48,
                      '& .MuiSwitch-track': {
                        background: '#4990F0',
                        opacity: 1,
                        borderRadius: '12px',
                      },
                      '& .MuiSwitch-thumb': { border: '1px solid #E1D8D8' },
                      '& .MuiSwitch-switchBase': {
                        p: 0,
                        '&.Mui-checked': {
                          color: '#fff',
                          transform: 'translateX(32px)',
                          '& + .MuiSwitch-track': {
                            backgroundColor: '#4990F0',
                            opacity: 1,
                          },
                        },
                      },
                    }}
                  />
                  <Typography
                    sx={{
                      color: '#22242C',
                      opacity: 0.8,
                      fontSize: 14
                    }}>
                    Lumpsum
                  </Typography>
                </Box>
                <Box sx={{ width: "7%" }}>
                  <div onClick={() => { OnSchemeDeSelection(val.schemeId); }}><DeleteIcon /></div>
                </Box>
              </Box>
            </Box>
          )
        })
      }
      <Box sx={{ width: '100%', display: 'flex', justifyContent: 'center' }}>
        <Button
          sx={{
            height: '40px',
            color: 'white',
            fontSize: '16px',
            fontWeight: 400,
            cursor: 'pointer',
            borderRadius: '5px',
            bgcolor: '#337FC9',
            width: '50%',
            '&:hover': { backgroundColor: '#337FC9' },
          }}
        >Recommend</Button>
      </Box>
    </Box>
  )
}

