import React from 'react';
import {
  Button,
  FormControl,
  FormControlLabel,
  FormHelperText,
  FormLabel,
  IconButton,
  RadioGroup,
  TextField,
  Drawer,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  InputLabel,
  Input,
  InputAdornment,
  Checkbox,
  Typography,
  Radio,
} from '@mui/material';
import { Box } from '@mui/system';
import { useEffect, useMemo, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { RootStateType } from '../../redux-store/reducers';
import CancelOutlinedIcon from '@mui/icons-material/CancelOutlined';
import { ApplicationFilterType, RMType } from '../../redux-store/types/api-types';
import { filterApplicationTypes, ModeOfHoldingTypes } from '../../utils/constant';
import { Distributor, getRMsList } from '../../redux-store/actions';
import { LocalizationProvider, MobileDatePicker } from '@mui/lab';
import AdapterDateFns from '@mui/lab/AdapterDateFns';
import KeyboardArrowRightSharpIcon from '@mui/icons-material/KeyboardArrowRightSharp';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import SearchSharpIcon from '@mui/icons-material/SearchSharp';
import { Form, Formik } from 'formik';
import { MFTextField } from '../../lib/formik';
import { Search } from '@mui/icons-material';

type FiltersDropDownProps = {
  filters: ApplicationFilterType;
  anchorEl: boolean;
  onFiltersChange: (value: ApplicationFilterType) => void;
  handleClose: () => void;
  distributors?: Distributor[];
  loader?: boolean;
};

const AccordionFilter = ({
  filterName = '',
  children,
  expanded,
  handleChange,
}: {
  filterName: string;
  children: JSX.Element;
  expanded: boolean;
  handleChange: (
    event: React.SyntheticEvent<Element, Event>,
    expanded: boolean,
    filterName: string
  ) => void;
}): JSX.Element => {
  return (
    <Accordion
      sx={{
        '&.MuiAccordion-root': {
          boxShadow: 'none',
        },
      }}
      expanded={expanded}
      onChange={(event, expanded) => handleChange(event, expanded, filterName)}>
      <AccordionSummary
        expandIcon={<ExpandMoreIcon />}
        aria-controls="panel1a-content"
        id="panel1a-header">
        <FormLabel component="legend">{filterName}</FormLabel>
      </AccordionSummary>
      <AccordionDetails>{children}</AccordionDetails>
    </Accordion>
  );
};

export const FilterDatePicker = ({
  value,
  onChange,
  placeholder = '',
  errorText = '',
}: {
  value: Date;
  onChange: (date: Date | null) => void;
  placeholder: string;
  errorText?: string;
}): JSX.Element => {
  return (
    <LocalizationProvider dateAdapter={AdapterDateFns}>
      <FormControl variant="outlined" fullWidth>
        <MobileDatePicker
          components={{ OpenPickerIcon: KeyboardArrowRightSharpIcon }}
          value={value}
          maxDate={new Date()}
          inputFormat="dd/MM/yyyy"
          onChange={onChange}
          renderInput={(params: any) => (
            <TextField
              fullWidth
              id="date-picker"
              placeholder={placeholder}
              {...params}
              sx={{
                '& .MuiInputBase-root': {
                  height: '44px',
                },
              }}
            />
          )}
          disableCloseOnSelect={false}
          showToolbar={false}
        />
        {errorText && (
          <FormHelperText error sx={{ marginLeft: 'unset' }}>
            {errorText}
          </FormHelperText>
        )}
      </FormControl>
    </LocalizationProvider>
  );
};

const Inival = (role: string) => {
  return {
    applicationType: [],
    modeOfHolding: [],
    status: [],
    distributorId: [],
    applicationSentBack: null,
  };
};

export const initialFilters = (
  role: string,
  storeStatus: string,
  storeApplicationType: string,
  storeModeOfHolding: string,
  storeDistributorId: string
): ApplicationFilterType => {
  return {
    applicationType: storeApplicationType ? storeApplicationType.split(',') : [],
    modeOfHolding: storeModeOfHolding ? storeModeOfHolding.split(',') : [],
    status: storeStatus ? storeStatus.split(',') : [],
    distributorId: storeDistributorId ? storeDistributorId.split(',') : [],
  };
};

const SearchComponent = ({
  search,
  setSearch,
}: {
  search: string;
  setSearch: React.Dispatch<React.SetStateAction<string>>;
}): JSX.Element => {
  return (
    <FormControl variant="standard" sx={{ display: 'block' }}>
      <InputLabel
        htmlFor="input-with-icon-adornment"
        sx={{ '&.Mui-focused': { color: 'text.primary' } }}>
        Search
      </InputLabel>
      <Input
        id="input-with-icon-adornment"
        value={search}
        autoComplete={'off'}
        onChange={({ target: { value } }) => setSearch(value)}
        endAdornment={
          <InputAdornment position="end">
            <IconButton>
              <SearchSharpIcon sx={{ color: 'primary.main' }} />
            </IconButton>
          </InputAdornment>
        }
      />
    </FormControl>
  );
};

export const FilterDropdown = ({
  filters,
  anchorEl,
  onFiltersChange,
  distributors = [],
  handleClose,
  loader,
}: FiltersDropDownProps): JSX.Element => {
  const [distributorSearch, setDistributorSearch] = useState('');
  const {
    page,
    status: storeStatus,
    applicationType: storeApplicationType,
    modeOfHolding: storeModeOfHolding,
    distributorId: storeDistributorId,
  } = useSelector((store: RootStateType) => store.paramsObj);
  const [filterExpanded, setExpanded] = useState<boolean | string>(false);
  const { role } = useSelector((store: RootStateType) => store.auth);
  const [modalState, setModalState] = useState(
    initialFilters(role, storeStatus, storeApplicationType, storeModeOfHolding, storeDistributorId)
  );
  const [searchfilter, setSearchfilter] = useState<string>('');
  const [fetchData, setFetchData] = useState<boolean>(true);
  const [changeRadio, setChangeRadio] = useState()
  useEffect(() => {
    setModalState(filters);
  }, [filters, anchorEl]);

  const handleChangeRadio = (e: any) => {
    setChangeRadio(e.target.value)
  };

  const _handleModalState = () => {
    handleClose();
    setModalState(
      initialFilters(
        role,
        storeStatus,
        storeApplicationType,
        storeModeOfHolding,
        storeDistributorId
      )
    );
  };

  const _handleApplyFilters = () => {
    onFiltersChange(modalState);
    _handleModalState();
  };

  const filterApplicationStatusTypes = [
    { key: 'large-cap', value: 'Large Cap' },
    { key: 'mid-cap', value: 'Mid Cap' },
    { key: 'small-cap', value: 'Small Cap' },
  ];
  const filterApplicationSectorTypes = [
    { key: 'chemicals', value: 'Chemicals' },
    { key: 'financial', value: 'Financial' },
    { key: 'communication', value: 'Communication' },
    { key: 'automobile', value: 'Automobile' },
  ];
  const filterApplicationSecuritynamesTypes = [
    { key: 'security', value: 'Security 1' },
  ];
  const filterApplicationAccountTypes = [
    { key: 'family', value: 'Overall Family' },
    { key: 'client', value: 'Client' },
  ];

  const _handleClearFilters = () => {
    onFiltersChange(Inival(role));
    handleClose();
  };

  const _handleSelection = (item: string[] | string | number, key: string | any) => {
    const index = (modalState[key] as string[]).indexOf(item as string);
    if (index === -1) {
      setModalState({
        ...modalState,
        [key]: [...((modalState[key] as string[]) || []), item] as string[],
      });
    } else {
      setModalState({
        ...modalState,
        [key]: (modalState[key] as string[]).filter((status: any) => status != (item as string)),
      });
    }
  };

  const handleAccordionExpanded = (
    event: React.SyntheticEvent<Element, Event>,
    isExpanded: boolean,
    panel: string
  ) => {
    setExpanded(isExpanded ? panel : false);
  };

  const distributorFilter = useMemo(() => {
    const filteredDistributors = distributorSearch
      ? distributors.filter((distributor) =>
        distributor.name.trim().toLowerCase().includes(distributorSearch.trim().toLowerCase())
      )
      : distributors;
    return (
      <>
        <SearchComponent search={distributorSearch} setSearch={setDistributorSearch} />
        {loader ? (
          <Typography>{'Loading...'}</Typography>
        ) : (
          <>
            {filteredDistributors.length ? (
              <Box sx={{ mt: 2 }}>
                <RadioGroup aria-label="Distributor Name" defaultValue="" name="Distributor Name">
                  {filteredDistributors.map((distributor: Distributor) => (
                    <FormControlLabel
                      key={distributor.id}
                      value={distributor.id.toString()}
                      onChange={() => _handleSelection(distributor.id, 'distributorId')}
                      control={
                        <Checkbox
                          size="small"
                          checked={modalState.distributorId
                            .map((dis) => dis.toString())
                            .includes(distributor.id.toString())}
                        />
                      }
                      label={distributor.name}
                      title={distributor.name}
                    />
                  ))}
                </RadioGroup>
              </Box>
            ) : (
              <Typography>{'No Results found'}</Typography>
            )}
          </>
        )}
      </>
    );
  }, [distributorSearch, distributors, loader, modalState]);

  return (
    <Box>
      <Drawer anchor={'right'} open={anchorEl} onClose={_handleModalState}>
        <FormControl
          component="fieldset"
          sx={{
            width: '100%',
            position: 'relative',
            p: { xs: 1, sm: 2 },
            pb: 0,
            '.MuiFormLabel-root ': { color: 'primary.main', fontWeight: 600, mb: 0.5 },
            '.MuiFormControlLabel-root': {
              ml: '-2px',
              mb: 0.75,
              width: '100%',
              alignItems: 'flex-start',
              '.MuiTypography-root': {
                color: 'text.primary',
                fontWeight: 500,
                fontSize: 14,
                overflow: { xs: 'unset', md: 'hidden' },
                whiteSpace: { xs: 'unset', md: 'nowrap' },
                textOverflow: { xs: 'unset', md: 'ellipsis' },
                wordBreak: { xs: 'break-word', md: 'unset' },
              },
              '.MuiRadio-root,.MuiCheckbox-root ,.Mui-checked': { color: 'text.primary' },
              '.MuiRadio-root,.MuiCheckbox-root ': { p: 0, mr: 0.5 },
            },
            '.MuiAccordionDetails-root': {
              paddingTop: 0,
            },
            '.MuiAccordionSummary-content.Mui-expanded': {
              marginBottom: '10px',
            },
          }}>
          <Box>
            <IconButton sx={{ float: 'right', p: 0 }} onClick={_handleModalState}>
              <CancelOutlinedIcon sx={{ color: '#EA5167' }} fontSize="large" />
            </IconButton>
          </Box>
          <Formik
            initialValues={{}}
            onSubmit={() => {
              setFetchData(true);
            }}>
            <Form>
              <Box
                sx={{
                  display: 'flex',
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                }}>
                <Box
                  sx={{ display: 'flex', flexDirection: 'row', gap: 4, alignItems: 'center' }}>

                  <MFTextField
                    placeholder={'Search'}
                    name={'SecurityName'}
                    value={searchfilter}
                    onChange={(e) => {
                      setSearchfilter(e.target.value);
                    }}
                    endAdornment={<Search sx={{ pr: 0.5, color: '#000000', opacity: 0.4 }} />}
                    sx={{
                      width: { md: '10rem', lg: '15rem' },
                      '& .MuiInputBase-root': {
                        fontSize: { md: 10, lg: 12 },
                        border: '0 !important',
                        boxShadow: '0px 2px 4px rgba(0, 0, 0, 0.15)',
                        ':hover': {
                          border: 0,
                          boxShadow: '0px 2px 4px rgba(0, 0, 0, 0.15)',
                        },
                      },
                    }}
                  />

                </Box>
              </Box>
            </Form>
          </Formik>
          <Box>
            <AccordionFilter
              filterName={'Market Capitalization'}
              expanded={filterExpanded === 'Market Capitalization'}
              handleChange={(e, expanded, filterName) =>
                handleAccordionExpanded(e, expanded, filterName)
              }>
              <RadioGroup aria-label="status" defaultValue="" name="status">
                {filterApplicationStatusTypes
                  .filter((obj) => {
                    if (role === 'amcapprover') {
                      return (
                        !['draft', 'draft_send_back'].includes(obj.key) &&
                        obj.key !== 'sent_to_poa_approver'
                      );
                    }
                    if (role === 'poaapprover') {
                      return !['draft', 'draft_send_back'].includes(obj.key);
                    }
                    return obj;
                  })
                  .map((type: { key: string; value: string }) => (
                    <FormControlLabel
                      key={type.key}
                      value={type.key}
                      onChange={() => _handleSelection(type.key, 'status')}
                      control={
                        <Checkbox size="small" checked={modalState.status.includes(type.key)} />
                      }
                      label={type.value}
                      title={type.value}
                    />
                  ))}
              </RadioGroup>
            </AccordionFilter>

            {/* <AccordionFilter
              filterName={'Distributor Name'}
              expanded={filterExpanded === 'Distributor Name'}
              handleChange={(e, expanded, filterName) =>
                handleAccordionExpanded(e, expanded, filterName)
              }>
              {distributorFilter}
            </AccordionFilter> */}

            <AccordionFilter
              filterName={'Sector'}
              expanded={filterExpanded === 'Sector'}
              handleChange={(e, expanded, filterName) =>
                handleAccordionExpanded(e, expanded, filterName)
              }>
              <RadioGroup aria-label="modeOfHolding" defaultValue="" name="modeOfHolding">
                {filterApplicationSectorTypes.map((type: { key: string; value: string }) => (
                  <FormControlLabel
                    key={type.key}
                    value={type.key}
                    onChange={() => _handleSelection(type.key, 'modeOfHolding')}
                    control={
                      <Checkbox
                        size="small"
                        checked={modalState.modeOfHolding.includes(type.key)}
                      />
                    }
                    label={type.value}
                    title={type.value}
                  />
                ))}
              </RadioGroup>
            </AccordionFilter>
            <AccordionFilter
              filterName={'Security Name'}
              expanded={filterExpanded === 'Security Name'}
              handleChange={(e, expanded, filterName) =>
                handleAccordionExpanded(e, expanded, filterName)
              }>
              <RadioGroup aria-label="applicationType" defaultValue="" name="applicationType">
                {filterApplicationSecuritynamesTypes.map((type: { key: string; value: string }) => (
                  <FormControlLabel
                    key={type.key}
                    value={type.key}
                    onChange={() => _handleSelection(type.key, 'applicationType')}
                    control={
                      <Checkbox
                        size="small"
                        checked={modalState.applicationType.includes(type.key)}
                      />
                    }
                    label={type.value}
                    title={type.value}
                  />
                ))}
              </RadioGroup>
            </AccordionFilter>
            <AccordionFilter
              filterName={'Account Type'}
              expanded={filterExpanded === 'Account Type'}
              handleChange={(e, expanded, filterName) =>
                handleAccordionExpanded(e, expanded, filterName)
              }>
              <RadioGroup aria-label="modeOfHolding" defaultValue="" name="modeOfHolding">
                {filterApplicationAccountTypes.map((type: { key: string; value: string }) => (
                  <FormControlLabel
                    key={type.key}
                    value={type.key}
                    onClick={() => handleChangeRadio}
                    control={
                      <Radio
                        size="small"
                      // checked={modalState.modeOfHolding.includes(type.key)}
                      />
                    }
                    label={type.value}
                    title={type.value}
                  />
                ))}
              </RadioGroup>
            </AccordionFilter>
          </Box>
          <Box
            sx={{
              display: 'flex',
              justifyContent: 'center',
              mb: 2,
              mt: 2,
              '& .MuiButton-root': {
                fontSize: 16,
                mx: 1,
                px: 3.5,
                py: 0.5,
              },
            }}>
            <Button
              type="submit"
              sx={{
                color: 'common.white',
                '&, :hover': { bgcolor: 'primary.main' },
              }}
              onClick={_handleApplyFilters}>
              Apply Filters
            </Button>
            <Button
              type="reset"
              sx={{
                color: 'text.primary',
                border: '1px solid #1F4173',
                '&, :hover': { bgcolor: 'common.white' },
              }}
              onClick={_handleClearFilters}>
              Clear Filters
            </Button>
          </Box>
        </FormControl>
      </Drawer>
    </Box>
  );
};
