import { Box, Button, Divider, Modal, Tab, Typography } from "@mui/material";
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';
import { TabContext, TabList, TabPanel } from '@mui/lab';
import "./styles.css";
import { useEffect, useState } from "react";
import { Bubble, RecommendedSchemesModal, SubFundCategoryCard } from "./investor-transaction-helper";
import { formatToIndianCurrency } from "../../utils/utilityFunctions";
import Highcharts from 'highcharts';
import { HighchartsReact } from 'highcharts-react-official';
import { formatLongDate } from "../../utils/date";
import {
    DirectEquityOverviewType,
} from '../../redux-store/types/api-types';
import LinearProgress from "@material-ui/core/LinearProgress";
import { withStyles } from "@material-ui/core/styles";
import { useDispatch } from "react-redux";
import { getInvestorData } from "../../redux-store/actions/userManagement";
import { TopHoldingButtons, YearSelecter } from "../commonComponents";
// import FundApiGraph from "./area-chart";



const BorderLinearProgress = withStyles({
    root: {
        height: 10,
        backgroundColor: '#e4e4e4',
        borderRadius: 20,
    },
    bar: {
        borderRadius: 20,
        backgroundColor: '#337FC9',
    },
})(LinearProgress);

export default function SchemeDetail({
    handleBackClick,
    handleSetViewSchemeDetails,
    investorId,
    scheme_details
}: {
    handleBackClick: () => void;
    handleSetViewSchemeDetails: (val: boolean) => void;
    investorId?: string;
    scheme_details?: any;
}) {
    const [overviewData, setOverviewData] = useState<DirectEquityOverviewType | null>(null);
    const [isDebtOrLiq, setIsDebtOrLiq] = useState<boolean>(false);
    const [yearTabSelected, setYearTabSelected] = useState<any>();
    const [categoryReturn, setCategoryReturn] = useState<any>();
    const [schemeReturn, setSchemeReturn] = useState<any>();
    const [holdingType, setHoldingType] = useState<string>('Equity');
    const [holdingValue, setHoldingValue] = useState<string>('Sectors');
    const [holdingRoutes, setHoldingRoutes] = useState<any>([
        { key: "Sectors", title: "Sectors" },
        { key: "Companies", title: "Companies" },
    ]);
    const [topHoldingData, setTopHoldingData] = useState<any>([
        {
            "sector": "Financial Services",
            "Weighting": 33.25836,
            "type": "Equity"
        },
        {
            "sector": "Technology",
            "Weighting": 11.78882,
            "type": "Equity"
        },
    ])
    const [assetClassName, setAssetClassName] = useState<any>("Liquid");
    const portfolioPerformance = overviewData?.portfolioData;
    const [arrReturnArray, setArrReturnArray] = useState<any>([]);
    const portfolioPerformaceGraphOptions = {
        chart: {
            type: 'area',
            // scrollablePlotArea: {
            //   minWidth: 600,
            //   scrollPositionX: 1,
            // },
        },
        title: {
            text: '',
        },
        credits: false,
        xAxis: {
            // type: 'datetime',
            categories: portfolioPerformance?.map(
                (each: { DT: string }) =>
                    formatLongDate(each.DT).split(' ')[1].substring(0, 3) +
                    ' ' +
                    formatLongDate(each.DT).split(' ')[2]
            ),
            labels: {
                autoRotation: false,
                overflow: 'justify',
            },
        },
        yAxis: {
            title: {
                text: 'Return',
            },
            labels: {
                // formatter: function (): string {
                //   return '<span>' + (this as any).value + ' %</span>';
                // },
                format: '{text} %',
            },
            visible: false
        },
        tooltip: {
            valueSuffix: ' %',
            shared: true,
        },
        legend: {
            align: 'center',
            verticalAlign: 'top',
            enabled: false,
        },
        plotOptions: {
            line: {
                lineWidth: 2,
                states: {
                    hover: {
                        lineWidth: 3,
                    },
                },
                marker: {
                    enabled: false,
                },
            },
        },
        series: [
            {
                name: 'Portfolio',
                color: '#337FC9',
                opacity: '0.5',
                outerHeight: '200px',
                data: portfolioPerformance?.map((each: { Rtn: any; }) => each.Rtn),
                connectEnds: false,
                connectNulls: true,
                crisp: true,
            },
            // {
            //   name: 'Sensex',
            //   color: '#F4C10E',
            //   data: portfolioPerformance?.map((each) => 0),
            // },
            // {
            //   name: 'Nifty',
            //   color: '#730EF4',
            //   data: portfolioPerformance?.map((each) => 0),
            // },
        ],
        navigation: {
            menuItemStyle: {
                fontSize: '8px',
            },
        },
    };
    const dispatch = useDispatch();
    useEffect(() => {
        let isComponentActive = true;
        setOverviewData(null);
        (async function () {
            try {
                const response = (await dispatch(
                    getInvestorData({
                        productLevel: 'DIRECT EQUITIES',
                        filters: {
                            customers: investorId ? [investorId] : [],
                        },
                        required: ['overview'],
                    })
                )) as unknown as DirectEquityOverviewType;
                if (!isComponentActive) {
                    return;
                }
                setOverviewData(response);
            } catch (e) {
                console.log((e as Error).message);
            }
        })();
        return () => {
            isComponentActive = false;
        };
    }, [location.pathname]);

    const years = [
        {
            text: isDebtOrLiq ? "1M" : "1Y",
        },
        {
            text: isDebtOrLiq ? "3M" : "3Y",
        },
        {
            text: isDebtOrLiq ? "6M" : "5Y",
        },
        {
            text: isDebtOrLiq ? "1Y" : "7Y",
        },
        {
            text: isDebtOrLiq ? "3Y" : "10Y",
        },
    ];

    const scheme_details_ = {
        "header": {
            "SchemeName": "Canara Robeco Bluechip Equity",
            "Sub_AssetClassname": "Large-Cap",
            "AssetClassName": "Equity",
            "Productcode_RTA": "101LCGP",
            "TailWindRec": "Y",
            "Growthoption": 1,
            "DividendReinvestment": 2,
            "DividendPayout": 2,
            "Dividendfrequency": null,
            "RiskMapping": 5,
            "SchemeCode_RTA": "101LCGP",
            "SN_NAV": 46.39,
            "Nav_Date": "03/10/2023",
            "Aum": "100897361000",
            "ExpenseRatio": "1.71000",
            "ExitLoad": 1,
            "AmcID": 22,
            "MinimumPurchaseAmount": 5000,
            "MaximumPurchaseAmount": 0,
            "SIPFLAG": "Y",
            "AMC": "Canara Robeco Asset Management Co. Ltd.",
            "img": "https://d3b6oys4j48anl.cloudfront.net/Assets/canara.jpg"
        },
        "insight": {
            "FscbiIndianRiskLevel": "Very High Risk"
        },
        "top_holdings": {
            "company_wise": [
                {
                    "name": "HDFC Bank Ltd",
                    "Weighting": 9.60378,
                    "type": "Equity"
                },
                {
                    "name": "ICICI Bank Ltd",
                    "Weighting": 8.24851,
                    "type": "Equity"
                },
                {
                    "name": "Infosys Ltd",
                    "Weighting": 6.42931,
                    "type": "Equity"
                },
                {
                    "name": "Reliance Industries Ltd",
                    "Weighting": 6.19837,
                    "type": "Equity"
                },
                {
                    "name": "Larsen & Toubro Ltd",
                    "Weighting": 4.49583,
                    "type": "Equity"
                },
                {
                    "name": "ITC Ltd",
                    "Weighting": 3.42095,
                    "type": "Equity"
                },
                {
                    "name": "Tata Consultancy Services Ltd Shs Dematerialised",
                    "Weighting": 3.33689,
                    "type": "Equity"
                },
                {
                    "name": "Bajaj Finance Ltd",
                    "Weighting": 3.3078,
                    "type": "Equity"
                },
                {
                    "name": "Bharti Airtel Ltd",
                    "Weighting": 3.20018,
                    "type": "Equity"
                },
                {
                    "name": "Axis Bank Ltd",
                    "Weighting": 3.1012,
                    "type": "Equity"
                },
                {
                    "name": "UltraTech Cement Ltd",
                    "Weighting": 2.68216,
                    "type": "Equity"
                },
                {
                    "name": "State Bank of India",
                    "Weighting": 2.67052,
                    "type": "Equity"
                },
                {
                    "name": "Hindustan Unilever Ltd",
                    "Weighting": 2.522,
                    "type": "Equity"
                },
                {
                    "name": "Sun Pharmaceuticals Industries Ltd",
                    "Weighting": 2.22491,
                    "type": "Equity"
                },
                {
                    "name": "NTPC Ltd Shs Dematerialised",
                    "Weighting": 2.18341,
                    "type": "Equity"
                },
                {
                    "name": "Maruti Suzuki India Ltd",
                    "Weighting": 2.09599,
                    "type": "Equity"
                },
                {
                    "name": "Kotak Mahindra Bank Ltd",
                    "Weighting": 1.91524,
                    "type": "Equity"
                },
                {
                    "name": "Tata Motors Ltd",
                    "Weighting": 1.77207,
                    "type": "Equity"
                },
                {
                    "name": "HCL Technologies Ltd",
                    "Weighting": 1.52418,
                    "type": "Equity"
                },
                {
                    "name": "Titan Co Ltd",
                    "Weighting": 1.49904,
                    "type": "Equity"
                },
                {
                    "name": "Cholamandalam Investment and Finance Co Ltd",
                    "Weighting": 1.46539,
                    "type": "Equity"
                },
                {
                    "name": "Mahindra & Mahindra Ltd",
                    "Weighting": 1.3506,
                    "type": "Equity"
                },
                {
                    "name": "IndusInd Bank Ltd",
                    "Weighting": 1.3454,
                    "type": "Equity"
                },
                {
                    "name": "Bharat Electronics Ltd",
                    "Weighting": 1.32675,
                    "type": "Equity"
                },
                {
                    "name": "Max Healthcare Institute Ltd Ordinary Shares",
                    "Weighting": 1.25842,
                    "type": "Equity"
                },
                {
                    "name": "United Spirits Ltd Shs Dematerialised",
                    "Weighting": 1.24324,
                    "type": "Equity"
                },
                {
                    "name": "Siemens Ltd",
                    "Weighting": 1.22955,
                    "type": "Equity"
                },
                {
                    "name": "ABB India Ltd",
                    "Weighting": 1.18335,
                    "type": "Equity"
                },
                {
                    "name": "InterGlobe Aviation Ltd",
                    "Weighting": 1.18213,
                    "type": "Equity"
                },
                {
                    "name": "Bajaj Auto Ltd",
                    "Weighting": 1.06317,
                    "type": "Equity"
                },
                {
                    "name": "Page Industries Ltd",
                    "Weighting": 1.01436,
                    "type": "Equity"
                },
                {
                    "name": "SBI Life Insurance Company Limited",
                    "Weighting": 0.99922,
                    "type": "Equity"
                },
                {
                    "name": "Dr Reddy's Laboratories Ltd",
                    "Weighting": 0.97265,
                    "type": "Equity"
                },
                {
                    "name": "PI Industries Ltd",
                    "Weighting": 0.93563,
                    "type": "Equity"
                },
                {
                    "name": "Abbott India Ltd",
                    "Weighting": 0.9288,
                    "type": "Equity"
                },
                {
                    "name": "Sona BLW Precision Forgings Ltd",
                    "Weighting": 0.85594,
                    "type": "Equity"
                },
                {
                    "name": "Tata Steel Ltd",
                    "Weighting": 0.82829,
                    "type": "Equity"
                },
                {
                    "name": "Avenue Supermarts Ltd",
                    "Weighting": 0.76917,
                    "type": "Equity"
                },
                {
                    "name": "Indian Hotels Co Ltd",
                    "Weighting": 0.64659,
                    "type": "Equity"
                },
                {
                    "name": "Tata Consumer Products Ltd",
                    "Weighting": 0.60889,
                    "type": "Equity"
                },
                {
                    "name": "Jio Financial Services Ltd",
                    "Weighting": 0.6013,
                    "type": "Equity"
                },
                {
                    "name": "Coforge Ltd",
                    "Weighting": 0.49844,
                    "type": "Equity"
                },
                {
                    "name": "Hindalco Industries Ltd",
                    "Weighting": 0.37372,
                    "type": "Equity"
                }
            ],
            "sector_wise": [
                {
                    "sector": "Financial Services",
                    "Weighting": 33.25836,
                    "type": "Equity"
                },
                {
                    "sector": "Technology",
                    "Weighting": 11.78882,
                    "type": "Equity"
                },
                {
                    "sector": "Consumer Cyclical",
                    "Weighting": 10.29776,
                    "type": "Equity"
                },
                {
                    "sector": "Industrials",
                    "Weighting": 9.41761,
                    "type": "Equity"
                },
                {
                    "sector": "Consumer Defensive",
                    "Weighting": 8.56425,
                    "type": "Equity"
                },
                {
                    "sector": "Energy",
                    "Weighting": 6.19837,
                    "type": "Equity"
                },
                {
                    "sector": "Healthcare",
                    "Weighting": 5.38478,
                    "type": "Equity"
                },
                {
                    "sector": "Basic Materials",
                    "Weighting": 4.8198,
                    "type": "Equity"
                },
                {
                    "sector": "Communication Services",
                    "Weighting": 3.20018,
                    "type": "Equity"
                },
                {
                    "sector": "Utilities",
                    "Weighting": 2.18341,
                    "type": "Equity"
                }
            ],
            "equity_per": 95.11,
            "debt_per": 4.89,
            "debt_holders": [
                {
                    "CashEquivalent": "4.88664",
                    "Corporate": "0.00000",
                    "Government": "0.00000",
                    "Municipal": "0.00000",
                    "Securitized": "0.00000"
                }
            ],
            "debt_ratings": [
                {
                    "AA": null,
                    "AAA": null,
                    "B": null,
                    "BB": null,
                    "BBB": null
                }
            ],
            "db_category_returns": [],
            "portfolio_aggregates": [],
            "credit_ratings": [
                {
                    "WEIGHTING": 100.0001,
                    "NAME": "Cash"
                }
            ]
        },
        "fund_management": [
            {
                "FUND_NAME": "Canara Robeco Asset Management Co. Ltd.",
                "FUND_MANAGER": "Shridatta Bhandwaldar"
            },
            {
                "FUND_NAME": "Canara Robeco Asset Management Co. Ltd.",
                "FUND_MANAGER": "Vishal Mishra"
            }
        ],
        "growth_options": [
            {
                "Plan": "GROWTH   ",
                "FSCBIDistributionFrequency": 46.39,
                "FSCBIFundStandardName": "Canara Robeco Bluechip Equity",
                "FscbiDistributionStatus": "GROWTH",
                "FscbiMStarId": "F00000J3Q8",
                "SchId": 1174
            },
            {
                "Plan": "DIVIDEND   Annually",
                "FSCBIDistributionFrequency": 23.69,
                "FSCBIFundStandardName": "Canara Robeco Bluechip Equity",
                "FscbiDistributionStatus": "DIVIDEND",
                "FscbiMStarId": "F00000J3Q9",
                "SchId": 1175
            }
        ],
        "exit_load": [
            {
                "Unit": "Percentage",
                "BreakpointUnit": "Years",
                "LowBreakpoint": "0",
                "HighBreakpoint": "1",
                "Value": 1
            },
            {
                "Unit": "Percentage",
                "BreakpointUnit": "Years",
                "LowBreakpoint": "1",
                "HighBreakpoint": "LifeTime",
                "Value": 0
            }
        ]
    }

    const performanceTabSelected = (value: any) => {
        const { header } = scheme_details_;
        const assetClassName =
            !!header && header.AssetClassName && header.AssetClassName;
        const schReturns =
            assetClassName === "Debt" || assetClassName === "Liquid"
                ? value === "1Y" || value === "5Y" || value === "3Y"
                    ? `Sch_Return${value.replace(/[^0-9]/g, "")}Yr`
                    : `Sch_Return${value.replace(/[^0-9]/g, "")}Mth`
                : `Sch_Return${value.replace(/[^0-9]/g, "")}Yr`;

        const catReturns =
            assetClassName === "Debt" || assetClassName === "Liquid"
                ? value === "1Y" || value === "5Y" || value === "3Y"
                    ? `Cat_Return${value.replace(/[^0-9]/g, "")}yr`
                    : `Cat_Return${value.replace(/[^0-9]/g, "")}Mth`
                : `Cat_Return${value.replace(/[^0-9]/g, "")}yr`;
        const schemReturn = 14.79095;

        // arrReturnArray.filter((value: any) =>
        //     Object.keys(value).includes(schReturns)
        // )[0][schReturns];
        const catReturn = 14.79095
        // assetClassName === "Debt" || assetClassName === "Liquid"
        //     ? ""
        //     : arrReturnArray.filter((value: any) =>
        //         Object.keys(value).includes(catReturns)
        //     )[0][catReturns];
        setYearTabSelected(value);
        setCategoryReturn(catReturn);
        setSchemeReturn(schemReturn);
    };

    const changeValue = (label: string) => () => {
        if (label === "Equity") {
            setHoldingType(label);
            setHoldingValue("Sectors");
            setHoldingRoutes([
                { key: "Sectors", title: "Sectors" },
                { key: "Companies", title: "Companies" },
            ]);
        } else if (label === "Debt") {
            let routes = [
                { key: "Holdings", title: "Debt Holdings" },
                { key: "CreditRatings", title: "Debt Credit Ratings" },
            ];
            routes =
                assetClassName === "Liquid" ||
                    assetClassName === "Debt"
                    ? [
                        ...routes,
                        { key: "portfolio_aggregates", title: "Portfolio Aggregates" },
                    ]
                    : routes;
            setHoldingType(label);
            setHoldingValue("Debt Holdings");
            setHoldingRoutes(routes);
        }
    };

    const handleHoldingValueChange = (event: any, value: any) => {
        setHoldingValue(value);
    };

    return (
        <div style={{ width: "100%" }}>

            <Box
                sx={{
                    width: '100%',
                    '& .MuiTabPanel-root': { py: 2, px: 0 },
                    '& .MuiTab-root': {
                        color: '#A1A2A2',
                        opacity: 0.8,
                        fontSize: 17,
                        lineHeight: '24px',
                        textTransform: 'capitalize',
                        px: { xs: 2, md: 3, lg: 5 },
                        '&.Mui-selected': {
                            color: '#4B81B1',
                        },
                    },
                    '& .MuiTabs-indicator': {
                        height: 3,
                        background: '#4B81B1',
                    },
                }}>
                <Box sx={{ px: 3, display: 'flex', alignItems: 'center', width: '100%', mb: 2 }}>

                    <ArrowBackIosIcon sx={{ cursor: 'pointer' }}
                        onClick={() => { handleSetViewSchemeDetails(false) }}
                    />
                    <Box sx={{ display: 'flex', alignItems: 'center', mx: 3, width: '80%' }}>
                        <div style={{ marginLeft: 16, marginRight: 16 }}>
                            <Typography sx={{ fontSize: 18, fontWeight: 500 }}>Title</Typography>
                        </div>
                        <Box sx={{ display: 'flex' }}>
                            {/* {!!fundItem.AssetClassName && ( */}
                            <Bubble text={"Equity"} />
                            {/* )} */}
                            {/* {!!fundItem.Sub_AssetclassName && ( */}
                            <Bubble text={"Large-Cap"} />
                            {/* )} */}
                            {/* {!!plan && <Bubble text={plan} />}
          {subPlan.length !== 0 && <Bubble text={subPlan} />}
          {!!subPlan&&!!fundItem.Dividendfrequency && ( */}
                            <Bubble text={"Growth"} />
                            {/* )} */}
                        </Box>
                    </Box>

                    <Button
                        sx={{
                            marginLeft: '20px',
                            height: '27px',
                            color: 'white',
                            fontSize: '13px',
                            cursor: 'pointer',
                            borderRadius: '5px',
                            bgcolor: '#337FC9',
                            '&:hover': { backgroundColor: '#337FC9' },
                        }}
                    // onClick={handleModalOpen}
                    >Recommend</Button>
                </Box>

                <Divider />

                <Box sx={{ px: 3 }}>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', cursor: 'pointer', my: 2.5 }}>
                        <Box sx={{ width: "23%", display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                            <Typography sx={{ fontSize: 14, color: '#5a7c82' }}>NAV as on 13/07/2023</Typography>
                            <Typography sx={{ fontSize: 16, color: "rgb(30, 163, 98)" }}>
                                {/* {fundItem.Aum === "0" || !fundItem.Aum
            ? "NA"
            : `₹${currencyConverter(fundItem.Aum)}`} */}
                                45.7
                            </Typography>
                        </Box>
                        <Box sx={{ width: "23%", display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                            <Typography sx={{ fontSize: 14, color: '#5a7c82' }}>AUM</Typography>
                            <Typography sx={{ fontSize: 16, color: "rgb(30, 163, 98)" }}>
                                {/* {fundItem.Aum === "0" || !fundItem.Aum
            ? "NA"
            : `₹${currencyConverter(fundItem.Aum)}`} */}
                                {formatToIndianCurrency(100000000, 1)}
                            </Typography>
                        </Box>

                        <Box sx={{ width: "23%", display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                            <Typography sx={{ fontSize: 14, color: '#5a7c82' }}>Category Avg Returns</Typography>
                            <Typography sx={{ fontSize: 16, color: "rgb(30, 163, 98)" }}>
                                {/* {fundItem.Aum === "0" || !fundItem.Aum
            ? "NA"
            : `₹${currencyConverter(fundItem.Aum)}`} */}
                                10.86%
                            </Typography>
                        </Box>

                        <Box sx={{ width: "23%", display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                            <Typography sx={{ fontSize: 14, color: '#5a7c82' }}>Returns</Typography>
                            <Typography sx={{ fontSize: 16, color: "rgb(30, 163, 98)" }}>
                                {/* {fundItem.Aum === "0" || !fundItem.Aum
            ? "NA"
            : `₹${currencyConverter(fundItem.Aum)}`} */}
                                10.86%
                            </Typography>
                        </Box>
                    </Box>
                </Box>

                <Box sx={{ width: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>

                    {/* Performance Analysis Graph */}
                    <Box
                        sx={{
                            display: 'flex',
                            // alignItems: 'center',
                            justifyContent: 'space-between',
                            flexDirection: 'column',
                            border: '1px solid black',
                            borderRadius: '10px',
                            width: '90%'
                        }}>
                        <Box sx={{
                            width: '100%', bgcolor: '#337FC9', px: 4, py: 1,
                            borderRadius: '10px 10px 0px 0px'
                        }}>
                            <Typography
                                sx={{
                                    color: 'white',

                                    fontSize: 16,
                                    lineHeight: '19px',
                                    fontWeight: 600,
                                    flex: 1,
                                }}>
                                Portfolio Performance
                            </Typography>
                        </Box>
                        <Box sx={{
                            borderRadius: '10px', py: 2

                        }}>
                            <HighchartsReact highcharts={Highcharts} options={portfolioPerformaceGraphOptions} />

                            <div className="fundPerformanceDataDiv">
                                <div key="Category Return">
                                    <div className="catText">Category Return</div>
                                    <div className="getStarted">
                                        {Number(200 || 0).toFixed(2)}%
                                    </div>
                                </div>

                                <div className="fundPerFormanceDiv">
                                    {years.map((ele, index) => (
                                        <YearSelecter
                                            text={ele.text}
                                            marginH={2}
                                            paddingV={4}
                                            key={index}
                                            onPress={() => performanceTabSelected(ele.text)}
                                            isSelected={yearTabSelected === ele.text}
                                        />
                                    ))}
                                </div>

                                <div key="Category Return">
                                    <div className="catText">Scheme Return</div>
                                    <div className="getStarted">
                                        {Number(200 || 0).toFixed(2)}%
                                    </div>
                                </div>
                            </div>

                            {/* <div
                                className="spaceBetween"
                                style={{ paddingTop: 20, marginLeft: 15, marginRight: 15 }}
                            >
                                {[
                                    { label: "Category Return", value: 200 },
                                    { label: "Scheme Return", value: 200 },
                                ].map((ele) => (
                                    <div key={ele.label}>
                                        <div className="catText">{ele.label} </div>
                                        <div className="getStarted">
                                            {Number(ele.value || 0).toFixed(2)}%
                                        </div>
                                    </div>
                                ))}
                            </div> */}

                        </Box>
                    </Box>

                    {/* Bottom 2 cards Box */}
                    <Box sx={{ width: '90%', display: 'flex', justifyContent: 'space-between', mt: 2 }}>

                        {/* Fund Manager */}
                        <Box
                            sx={{
                                display: 'flex',
                                // alignItems: 'center',
                                // justifyContent: 'center',
                                flexDirection: 'column',
                                border: '1px solid black',
                                borderRadius: '10px',
                                width: '45%'
                            }}>
                            <Box sx={{
                                width: '100%', bgcolor: '#337FC9', px: 4, py: 1,
                                borderRadius: '10px 10px 0px 0px'
                            }}>
                                <Typography
                                    sx={{
                                        color: 'white',

                                        fontSize: 16,
                                        lineHeight: '19px',
                                        fontWeight: 600,
                                        flex: 1,
                                    }}>
                                    Fund Manager
                                </Typography>
                            </Box>

                            <Box sx={{ p: 2 }}>
                                <div>
                                    <Typography sx={{ fontSize: "14px", fontWeight: 400 }} >Sridatta Bharadwaj</Typography>
                                    <Typography sx={{ fontSize: "11px" }}>oct 2019 - {<span style={{ fontWeight: 500 }}>present</span>}</Typography>
                                </div>
                            </Box>
                        </Box>

                        {/* Top Holdings */}
                        <Box
                            sx={{
                                display: 'flex',
                                // alignItems: 'center',
                                justifyContent: 'space-between',
                                flexDirection: 'column',
                                border: '1px solid black',
                                borderRadius: '10px',
                                width: '45%'
                            }}>
                            <Box sx={{
                                width: '100%', bgcolor: '#337FC9', px: 4, py: 1,
                                borderRadius: '10px 10px 0px 0px'
                            }}>
                                <Typography
                                    sx={{
                                        color: 'white',

                                        fontSize: 16,
                                        lineHeight: '19px',
                                        fontWeight: 600,
                                        flex: 1,
                                    }}>
                                    Top Holdings
                                </Typography>
                            </Box>

                            <Box sx={{ width: "100%", display: 'flex', justifyContent: 'center', flexDirection: 'column', alignItems: 'center' }}>
                                <div className="spaceBetween top-holding-btn">
                                    {[
                                        {
                                            text: "Equity",
                                            percent: "40",
                                            holdingType: "equity_per",
                                        },
                                        { text: "Debt", percent: "60", holdingType: "debt_per" },
                                    ].map((ele, ind) => (
                                        !!scheme_details_.top_holdings && !!scheme_details_.top_holdings.equity_per && (
                                            <TopHoldingButtons
                                                label={ele.text}
                                                selected={holdingType}
                                                onPress={changeValue(ele.text)}
                                                percentage={scheme_details_.top_holdings.equity_per}
                                                style={{ width: "30%" }}
                                            />
                                        )
                                    ))}
                                </div>

                                <TabContext value={holdingValue}>
                                    <Box sx={{ px: 1 }}>
                                        <TabList
                                            onChange={handleHoldingValueChange}
                                            aria-label="product tabs"
                                            variant="scrollable"
                                            scrollButtons="auto">
                                            <Tab label="Sectors" value="Sectors" />
                                            <Tab label="Companies" value="Companies" />
                                        </TabList>
                                    </Box>
                                    <Divider />

                                    <Box sx={{ px: 1, width: '100%' }}>
                                        <TabPanel value="Sectors">
                                            <>
                                                {topHoldingData.map((ele: any) => (
                                                    <div
                                                        style={{
                                                            display: "flex",
                                                            flexDirection: "column",
                                                            marginTop: 10,
                                                            width: '100%',
                                                            padding: "0 10px",
                                                        }}
                                                        key={ele.name}
                                                    >
                                                        <Typography sx={{ fontSize: "14px", fontWeight: 400 }}>{ele.sector || ele.name}</Typography>
                                                        <div className="homeContainer">
                                                            <BorderLinearProgress
                                                                // className={classes.margin}
                                                                style={{ marginTop: 4, width: "85%" }}
                                                                variant="determinate"
                                                                color="secondary"
                                                                value={parseFloat(ele.Weighting || 0)}
                                                            />
                                                            <Typography style={{ marginLeft: 15, color: "gray" }}>
                                                                {parseFloat(ele.Weighting || 0).toFixed(2) + "%"}
                                                            </Typography>
                                                        </div>
                                                    </div>
                                                ))}
                                            </>
                                        </TabPanel>
                                        <TabPanel value="Companies">
                                            <>
                                            </>
                                        </TabPanel>
                                    </Box>

                                </TabContext>
                            </Box>
                        </Box>

                    </Box>


                </Box>


            </Box>
        </div>
    )
}