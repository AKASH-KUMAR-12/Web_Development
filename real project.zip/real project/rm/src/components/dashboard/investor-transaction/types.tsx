export interface ErrorType {
    errorInvestmentAmount: boolean,
    errorInvestementAmountMsg: string,
    errorFrequency: boolean,
    errorFrequencyMsg: string,
    errorInstalmentAmount: boolean,
    errorInstalmentAmountMsg: string,
    errorNoOfInstalment: boolean,
    errorNoOfInstalmentMsg: string,
    errorSIPDay: boolean,
    errorSIPDayMsg: string,
    errorFirstOrderToday: boolean;
    errorMessageFirstOrderToday: string;
    errorMandate: boolean;
    errorMessageMandate: string
}

export interface RedemptionErrorType {
    errorRedemptionValue: boolean,
    errorRedemptionValueMsg: string,
}

export interface SwitchErrorType {
    errorSwitchValue: boolean,
    errorSchemeValue: boolean,
    errorSwitchValueMsg: string,
    errorSchemeValueMsg: string,
    errorAstId: boolean,
    errorMessageAstId: string
}
export interface SWP_STPErrorType {
    errorSWPAmount: boolean,
    errorSWPAmountMsg: string,
    errorSWPNoOfInstalment: boolean,
    errorSWPNoOfInstalmentMsg: string,
    errorSWPDay: boolean,
    errorSWPDayMsg: string,
    errorSTPAmount: boolean,
    errorSTPAmountMsg: string,
    errorSchemeValue: boolean,
    errorSchemeValueMsg: string,
    errorSTPNoOfInstalment: boolean,
    errorSTPNoOfInstalmentMsg: string,
    errorSTPDay: boolean,
    errorSTPDayMsg: string,
    errorToSchemeID: boolean,
    errorToSchemeIDMsg: string,
    errorFrequency: boolean,
    errorFrequencyMsg: string,
    errorFirstOrderToday: boolean,
    errorMessageFirstOrderToday: string,
    errorMandate: boolean,
    errorMessageMandate: string,
    errorAstId: boolean,
    errorMessageAstId: string
}

export interface HoldingSchemeData {
    schemeCategory: string,
    schemeName: string,
    schemeID: number,
    bubbleTag: string[],
    xirr: number,
    switchMode: boolean,
    accountSelected: string,
    frequencySelected: string,
    folio: string,
    AmcID: number,
    AccountID: string,
    SCh: string,
    MinimumPurchaseAmount: number,
    MaximumPurchaseAmount: number,
    currentValue: number,
    Units: number,
    Growthoption: number,
    DividendReinvestment: number,
    firstOrderToday: string,
    mandate: string
}

export interface HoldingSIPLumpsumSelectedData {
    schemeCategory: string,
    schemeName: string,
    schemeID: number,
    bubbleTag: string[],
    xirr: number,
    switchMode: boolean,
    accountSelected: string,
    frequencySelected: string | null,
    folio: string,
    AmcID: number,
    AccountID: string,
    SCh: string,
    instalmentAmt: number | null,
    investmentAmt: number | null,
    noOfInstalments: number | null,
    sipDay: string,
    MinimumPurchaseAmount: number,
    MaximumPurchaseAmount: number
    datePicker: any,
    Growthoption: number,
    DividendReinvestment: number,
    firstOrderToday: string,
    mandate: string
}
export interface SwitchValue {
    value: string;
    type: string;
}

export interface HoldingSWPSTPSeletedData {
    schemeCategory: string,
    schemeName: string,
    schemeID: number,
    bubbleTag: string[],
    xirr: number,
    switchMode: boolean,
    accountSelected: string,
    frequencySelected: string,
    folio: string,
    AmcID: number,
    AccountID: string,
    SCh: string,
    MinimumPurchaseAmount: number,
    MaximumPurchaseAmount: number,
    currentValue: number,
    Units: number,
    transactionType: string,
    SWPAmount: string,
    SWPinstallment: string,
    STPinstallment: string,
    STPAmount: string,
    newSchemeSch: string,
    switchValue: SwitchValue,
    ToSchemeName: string,
    ToschemeID: string,
    SIPDate: string,
    STPFrequency: string,
    SWPFrequency: string,
    firstOrderToday: string,
    mandate: string
}

export interface selectedFrequencyValidationData {
    Productcode_RTA: string,
    SIPFREQUENCY: string | null,
    SIPDATES: string,
    SIPMINIMUMINSTALLMENTAMOUNT: string,
    SIPMAXIMUMINSTALLMENTAMOUNT: string,
    SIPMINIMUMINSTALLMENTNUMBERS: string,
    SIPMAXIMUMINSTALLMENTNUMBERS: string,
    SCHEMEISIN: string,
    SIPMINIMUMGAP: string,
    IPMAXIMUMGAP: string,
    SIPMULTIPLIERAMOUNT: string
}