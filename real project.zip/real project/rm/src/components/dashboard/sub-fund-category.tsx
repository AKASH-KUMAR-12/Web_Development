import { Box, Button, Divider, Modal, Tab, Typography } from "@mui/material";
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';
import { TabContext, TabList, TabPanel } from '@mui/lab';
import "./styles.css";
import { useState } from "react";
import { RecommendedSchemesModal, SubFundCategoryCard } from "./investor-transaction-helper";
export default function SubFundCategory({
  handleBackClick,
  handleModalOpen,
  handleModalClose,
  openModal,
  setViewSubList,
  handleSetViewSchemeDetails
}: {
  handleBackClick: () => void;
  handleModalOpen: () => void;
  handleModalClose: () => void;
  openModal: boolean;
  setViewSubList: (viewSubList: boolean) => void;
  handleSetViewSchemeDetails: (val: boolean) => void;
}) {

  const [value, setValue] = useState<string>("largeCap");

  const handleChange = (event: any, value: any) => {
    setValue(value);
  };
  const [schemeList, setSchemeList] = useState<{ schemeId: string; }[]>([{ schemeId: "1" }, { schemeId: "2" }, { schemeId: "3" }]);
  const [selectedSchemes, setSelectedSchemes] = useState<{ schemeId: string; }[]>([]);

  const _getSchemsList = async (subAssetName: any) => {
    // const { routes, index } = this.state;
    // const assetClass = routes[index].mainTitle;
    // const response = await this.props.getSchemeList(subAssetName);
    // //this.setState({ schemsList: [] });
    // if (response.hasOwnProperty("sub_asset_classes")) {
    //   this.setState({
    //     schemsList: response.sub_asset_classes,
    //     arrSchemeList: this.state.schemsList,
    //     selected:
    //       assetClass === "Debt" || assetClass === "Liquid" ? "6M" : "5Y",
    //   });
    // } else {
    //   alert(response.error);
    // }
  };

  const OnSchemeSelection = (schemeId: string) => {
    const scheme = { schemeId: schemeId };
    const schemeList = [...selectedSchemes, scheme];
    setSelectedSchemes(schemeList);
  }

  const OnSchemeDeSelection = (schemeId: string) => {
    const schemeList = selectedSchemes.filter((val) => val.schemeId != schemeId);
    setSelectedSchemes(schemeList);
  }

  return (
    <div style={{ width: "100%" }}>

      <Box
        sx={{
          width: '100%',
          '& .MuiTabPanel-root': { py: 2, px: 0 },
          '& .MuiTab-root': {
            color: '#A1A2A2',
            opacity: 0.8,
            fontSize: 17,
            lineHeight: '24px',
            textTransform: 'capitalize',
            px: { xs: 2, md: 3, lg: 5 },
            '&.Mui-selected': {
              color: '#4B81B1',
            },
          },
          '& .MuiTabs-indicator': {
            height: 3,
            background: '#4B81B1',
          },
        }}>
        <Box sx={{ px: 3, display: 'flex', alignItems: 'center', width: '100%', mb: 3 }}>

          <ArrowBackIosIcon sx={{ cursor: 'pointer' }} onClick={() => { setViewSubList(false) }} />
          <Box sx={{ display: 'flex', alignItems: 'center', mx: 3, width: '80%' }}>
            <img
              src=""
              style={{ width: 60, height: 60 }}
              alt=""
            />
            <div className="line"></div>
            <div style={{ marginLeft: 20, paddingTop: 5 }}>
              <div>Title</div>
              <div className="fundCatdesc">Asset class description</div>
            </div>
          </Box>

          <Button
            sx={{
              marginLeft: '20px',
              height: '27px',
              color: 'white',
              fontSize: '13px',
              cursor: 'pointer',
              borderRadius: '5px',
              bgcolor: '#337FC9',
              '&:hover': { backgroundColor: '#337FC9' },
            }}
            onClick={handleModalOpen}
          >Transaction</Button>
        </Box>
        <Divider />
        <TabContext value={value}>
          <Box sx={{ px: 3 }}>
            <TabList
              onChange={handleChange}
              aria-label="product tabs"
              variant="scrollable"
              scrollButtons="auto"
              sx={{
                '& .MuiTabList-flexContainer': {
                  fontSize: "5px"
                },
                // '& .MuiTabs-indicator':{
                //   height: '2px'
                // }
              }}>
              <Tab label="Large Cap" value="largeCap"
              // style={{fontSize:'15px'}} 
              />
              <Tab label="Flexi Cap" value="flexiCap"
              // style={{fontSize:'15px'}}
              />
              <Tab label="Large & Mid Cap" value="largeMidCap"
              // style={{fontSize:'15px'}}
              />
              <Tab label="Mid Cap" value="midCap"
              // style={{fontSize:'15px'}}
              />
              <Tab label="Small Cap" value="smallCap"
              // style={{fontSize:'15px'}}
              />
            </TabList>
          </Box>
          <Divider />
          <Box sx={{ px: 3 }}>
            <TabPanel value="largeCap">
              <>
                {schemeList.map((val) => {
                  return (
                    <><SubFundCategoryCard onSchemeSelection={OnSchemeSelection} schemeId={val.schemeId} OnSchemeDeSelection={OnSchemeDeSelection} handleSetViewSchemeDetails={handleSetViewSchemeDetails} />
                      <Divider /></>
                  )
                })}
              </>
            </TabPanel>
          </Box>
        </TabContext>
      </Box>
      {/* <div className="fundCatView">
          <div>
            
            <div className="divider" />
          </div> */}
      {/* 
          <TabComponent
            value={selectedFund.title}
            tabsArray={routes}
            handleChange={this.activeTabChanged}
            position={false}
          >
            <div
              className="fundPerFormanceDiv"
              style={{
                margin: 20,
                marginLeft: 180,
                marginRight: 180,
              }}
            >
              {years.map((ele, index) => (
                <YearSelecter
                  key={index}
                  marginH={10}
                  paddingV={8}
                  text={ele.text}
                  onPress={() => this.performanceTabSelected(ele.text)}
                  isSelected={this.state.selected === ele.text}
                />
              ))}
            </div>

            {data.map((ele, index) => (
              <div style={{ paddingTop: 10 }}>
                <SubFundCategoryCard
                  key={index}
                  // name="ICICI Prudential"
                  // twRec={true}
                  // marketvalue={"25000.00"}
                  // returns={"25"}
                  fundItem={ele}
                  selectedValue={this.state.selected}
                  openSchDetailModal={this.openSchDetailModal}
                />
                {index < data.length - 1 && <div className="divider" />}
              </div>
            ))}
          </TabComponent> */}
      {/* </div> */}
      {/* {this.state.visible && (
          <SchemeInfoModel
            item={item}
            visible={visible}
            sch_visible={visible}
            invest={true}
            closeModal={this.closeModal}
            handleClick={() => this.toggleDrawer(INVEST)}
            scheme_details={this.props.scheme_details}
            showInvest={true}
          />
        )}
        {this.state.openModal && (
          <Drawer
            anchor="right"
            open={this.state.openModal}
            onClose={() => this.toggleDrawer("")}
          >
            {this.renderModals(this.state.modalType)}
          </Drawer>
        )}

         <IncompleteDialog
          visibleDialog={show_popup}
          closeDialog={this.closePopup}
          history={this.props.history}
         />         */}

      <Modal
        open={openModal}
        // onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          width: 1000,
          bgcolor: 'background.paper',
          borderRadius: '16px',
          boxShadow: 24,
          border: 'none',
          py: 3
        }}>
          <RecommendedSchemesModal handleModalClose={handleModalClose} selectedSchemes={selectedSchemes} OnSchemeDeSelection={OnSchemeDeSelection} />
        </Box>
      </Modal>
    </div>
  )
}