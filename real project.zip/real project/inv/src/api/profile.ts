import { _request } from './requests';

export async function profileRequest(userId: string = '123456789'): Promise<any> {
  return _request({
    method: 'GET',
    relativeUrl: `/profile/getProfileDetails/${userId}`,
  });
}
