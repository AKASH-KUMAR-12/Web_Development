import { GetAccountType, GetAssetClassesType, GetCategoryAverage, GetMandateIds, GetMasters, GetRecommendationValidations, GetRecommendedSchemes, GetSchemeDetailsType, GetSchemeListType, GetSchemeNav, GetSubAssetClassesType, OrdersDataType, getBSESchemeCodeResponseType, getFolioList, getPortfolioType, getRecommendationPayload, redeemValidationResponse } from '../components/transactionModule/transaction.context';

import { _request } from './requests';


export async function get_assest_classes () : Promise<GetAssetClassesType> {

        return _request({
          method: 'GET',
          relativeUrl: `/transaction/get_assest_classes`,

          

      });

    };
    export type PortfolioBodyType = {
      // clientId: string;
      date: string;
    }
    export type FolioListBodyType ={
      AMC: number;
    }

    export type redeemValidationPayload = {
      AccNo:number,
      SchId:number
  }

  export type updateViewFlagPayload = {
    clientId: string
}

export type OrdersBodyType = {
  rmID: number
}

export type getBSESchemeCodePayloadType = {
  TrType: string;
  Amount: string;
  Growthoption: number;
  DividendReinvestment: number;
  RTACODE: string;
}
  
    export async function get_Portfolio( body: PortfolioBodyType) : Promise<getPortfolioType> {

      return _request({
        relativeUrl: `/transaction/portfolio`,
        method: 'POST',
        body

    });
  };
  export async function get_folioList( body: FolioListBodyType): Promise<getFolioList>  {

    return _request({
      relativeUrl: `/transaction/folioList`,
      method: 'POST',
      body

  });
};

export async function get_sub_asset_classes ( asset: any): Promise<GetSubAssetClassesType>{
    return _request({
      method: 'GET',
          relativeUrl: `/transaction/get_sub_asset_classes/${asset}`,

         

      });

    };

    export async function redeem_validation(requestOptions: redeemValidationPayload): Promise<redeemValidationResponse> {

      return _request({
          method: 'POST',
          relativeUrl: `/transaction/redemption_validation`,
          body: { ...requestOptions },
      });
  };

  export async function update_view_flag(requestOptions: updateViewFlagPayload): Promise<any> {

    return _request({
        method: 'POST',
        relativeUrl: `/transaction/update_recommendation`,
        body: { ...requestOptions },
    });
};


export async function get_scheme_list (asset_id: any): Promise<GetSchemeListType>{

    return _request({

       relativeUrl: `/transaction/get_scheme_list/${asset_id}`,

        method: 'GET',

    });

  };

export async function get_scheme_details(schemeId: any) : Promise<GetSchemeDetailsType> {

    return _request({

        relativeUrl: `/transaction/get_scheme_details/${schemeId}`,

        method: 'GET',

    });

  };

  export type CategoryAverageOptions = {
    schemaId: number,
    marketValue: false
  };

export async function get_category_average ( requestOptions: CategoryAverageOptions,) : Promise<GetCategoryAverage> {

    return _request({
        relativeUrl: `/transaction/category_average`,
        method: 'POST',
        body: {...requestOptions},

    });

  };

export async function get_scheme_nav (schemeId: any) : Promise<GetSchemeNav>  {

    return _request({
        relativeUrl: `/transaction/get_scheme_nav/${schemeId}`,
        method: 'GET',
    });

  };
export type RecommendedSchemesOptions={
  rmId: number,
  clientId: string
}
  export async function get_recommended_schemes ( requestOptions: RecommendedSchemesOptions) : Promise<GetRecommendedSchemes> {

    return _request({
        relativeUrl: `/transaction/get_recommended_schemes`,
        method: 'POST',
        body: {...requestOptions},

    });

  };

  export type SchemeBodyType = {
    AstId: string;
    AmcId: string;
  }
  
  export interface SchemeType {
    Sch_ID: string;
    Sch_Desc: string;
    Productcode_RTA: string;
    ErrorCode: string;
    SwitchFLAG: string,
    SWPFlag: string,
    STPFLAG: string,
    SIPFLAG: string
  }
  
  export interface GetSchemeType {
    schemes: [SchemeType[]];
  }

  export async function get_switch_schemes ( requestOptions: SchemeBodyType) : Promise<GetSchemeType> {

    return _request({
        relativeUrl: `/transaction/get_switch_schemes`,
        method: 'POST',
        body: {...requestOptions},

    });

  };
 

  export async function get_recommendation_validations ( payload: getRecommendationPayload) : Promise<GetRecommendationValidations> {

    return _request({
        relativeUrl: `/transaction/get_recommendation_validations`,
        method: 'POST',
        body: payload,

    });

  };
  export type AccountTypeOptions={
    rmID: number,
  
  }
  export async function get_account_type ( requestOptions:AccountTypeOptions) : Promise<GetAccountType> {

    return _request({
        relativeUrl: `/transaction/get_account_type`,
        method: 'POST',
        body: {...requestOptions},

    });

  };
  export async function get_masters () : Promise<GetMasters> {

    return _request({
        relativeUrl: `/transaction/get-masters`,
        method: 'GET',

    });

  };

  
  export async function get_client_mandateIds () : Promise<GetMandateIds> {

    return _request({
        relativeUrl: `/transaction/get_client_mandateIds`,
        method: 'GET',

    });

  };
  export async function get_orders_data (body: OrdersBodyType) : Promise<OrdersDataType> {

    return _request({
        relativeUrl: `/transaction/orders`,
        method: 'POST',
        body
    });

  };

  export const get_bse_code = (body: getBSESchemeCodePayloadType): Promise<getBSESchemeCodeResponseType> => {

    return _request({
      relativeUrl: `/transaction/get_bse_code`,
      method: 'POST',
      body: { ...body }
    });
  }

  export const create_transaction = (requestOptions: any): Promise<any> => {

    return _request({
      relativeUrl: `/transaction/create_transaction`,
      method: 'POST',
      body: { ...requestOptions }
    });
  }