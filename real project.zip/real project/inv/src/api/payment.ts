import { GetCartType, GetPofileDataType, GetUserDetailsType, InsertTansactionOTP, deleteCartResponse, placeOrderResponse, redeemValidationResponse, registerMandateResponse } from '../components/payment/payment.context'

import { _request } from './requests';

export type tansactionOTPPayload = {
    ihno: any,
    totalAmount: number,
    schemeDesc: any,
    type: string
}

export type placeOrderPayload = {
    orders: ordersPlaceOrder[]
}

export type registerMandatePayload = {
    AC_TYPE: string,
    AccountNO: string,
    Amount: string,
    BankName: string,
    IFSC_CODE: string,
    is_encrypted: boolean,
    mandate_type: string
}

export type ordersPlaceOrder = {
    order_id: string,
    type: string
}

export type deleteCartPayload = {
    type: string,
    IHNO: number
}

export type redeemValidationPayload = {
    AccNo:number,
    SchId:number
}

export async function get_cart(): Promise<GetCartType> {

    return _request({
        method: 'GET',
        relativeUrl: `/transaction/get_cart`,
    });
};

export async function get_profile_data(): Promise<GetPofileDataType> {

    return _request({
        method: 'GET',
        relativeUrl: `/profile/get_profile_data`,
    });
};

export async function get_user_details(): Promise<GetUserDetailsType> {

    return _request({
        method: 'GET',
        relativeUrl: `/profile/get_user_details`,
    });
};

export async function insert_tansaction_otp(requestOptions: tansactionOTPPayload): Promise<InsertTansactionOTP> {

    return _request({
        method: 'POST',
        relativeUrl: `/transaction/insert-tansaction-otp`,
        body: { ...requestOptions },
    });
};

export async function place_order(requestOptions: placeOrderPayload): Promise<placeOrderResponse> {

    return _request({
        method: 'POST',
        relativeUrl: `/transaction/place-order`,
        body: { ...requestOptions },
    });
};

export async function register_mandate(requestOptions: registerMandatePayload): Promise<registerMandateResponse> {

    return _request({
        method: 'POST',
        relativeUrl: `/transaction/register_mandate`,
        body: { ...requestOptions },
    });
};

export async function delete_cart(requestOptions: deleteCartPayload): Promise<deleteCartResponse> {

    return _request({
        method: 'POST',
        relativeUrl: `/transaction/delete_cart`,
        body: { ...requestOptions },
    });
};

export async function redeem_validation(requestOptions: redeemValidationPayload): Promise<redeemValidationResponse> {

    return _request({
        method: 'POST',
        relativeUrl: `/transaction/redemption_validation`,
        body: { ...requestOptions },
    });
};