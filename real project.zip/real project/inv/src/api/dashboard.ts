import { _request } from './requests';

export async function getPortfolioDetailsRequest(body:any) {
  return _request({
    method: 'POST',
    relativeUrl: '/dashboard/getDashboardMetrics',
    body: body

  });
}
