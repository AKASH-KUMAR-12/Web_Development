import { downloadFile, downloadMultipleFiles } from './../lib/helper';
import { _request } from './requests';

export async function getReportsOptions(): Promise<any> {
  return _request({ method: 'GET', relativeUrl: '/reports/getReportList' });
}

export type ClientStatementRequestOptions = {
  clientId: string[];
  level: string;
  date: string;
  redeemedSchemesFlg: string;
  transactionHistoryFlg: string;
  reportOptions: number[];
};

export async function getClientStatementReportRequest(
  requestOptions: ClientStatementRequestOptions,
): Promise<any> {
  return _request({
    method: 'POST',
    additionalHeaders: { responseType: 'arraybuffer' },
    relativeUrl: '/reports/get_client_statement',
    body: { ...requestOptions },
  }).then((res) => downloadMultipleFiles(res));
}

export type TransactionStatementRequestOptions = {
  clientId: string[];
  fromDate: string;
  toDate: string;
};

export async function getTransactionStatementReportRequest(
  requestOptions: TransactionStatementRequestOptions,
): Promise<any> {
  return _request({
    method: 'POST',
    additionalHeaders: { responseType: 'arraybuffer' },
    relativeUrl: '/reports/get_transaction_statement',
    body: { ...requestOptions },
  }).then((res) => downloadMultipleFiles(res));
}

export type PortfolioSummaryRequestOptions = {
  clientId: string[];
  toDate: string;
};

export async function getPortfolioSummaryReportRequest(
  requestOptions: PortfolioSummaryRequestOptions,
): Promise<any> {
  return _request({
    method: 'POST',
    additionalHeaders: { responseType: 'arraybuffer' },
    relativeUrl: '/reports/get_portfolio_summary',
    body: { ...requestOptions },
  }).then((res) => downloadMultipleFiles(res));
}

export type CGStatementRequestOptions = {
  clientId: string[];
  fromDate: string;
  toDate: string;
  fileType: string;
};

export async function getCGStatementReportRequest(
  requestOptions: CGStatementRequestOptions,
) {
  return _request({
    method: 'POST',
    relativeUrl: '/reports/get_cg_report',
    body: { ...requestOptions },
  }).then((res: any) => {
    return downloadMultipleFiles(JSON.parse(res).report);
  });
}
