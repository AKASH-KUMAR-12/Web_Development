import { combineReducers } from 'redux';

import uiReducer, { UIState } from './ui-reducer';

export interface RootStateType {
  ui: UIState;
}

export const rootReducer = combineReducers({
  ui: uiReducer,
});

export type RootState = ReturnType<typeof rootReducer>;
