import cryptoJs from 'crypto-js';
import ReactGA from 'react-ga4';

const GA_ENABLED = import.meta.env.VITE_GA_ENABLED === 'true';

export const formatDate = (dt: string) => {
  if (!dt) return '';
  const x = new Date(dt);
  if (isNaN(x.getTime())) return '';
  return x
    .toLocaleDateString('en-IN', { month: '2-digit', day: '2-digit', year: '2-digit' })
    .replaceAll('/', '-');
};

export const capitalizeFirstLetter = (string: string) => {
  return string.charAt(0).toUpperCase() + string.slice(1).toLocaleLowerCase();
};

export const browserName = (function detectBrowser() {
  const userAgent = navigator.userAgent;

  if (userAgent.match(/chrome|chromium|crios/i)) {
    return 'chrome';
  }
  if (userAgent.match(/firefox|fxios/i)) {
    return 'firefox';
  }
  if (userAgent.match(/safari/i)) {
    return 'safari';
  }
  if (userAgent.match(/opr\//i)) {
    return 'opera';
  }
  if (userAgent.match(/edg/i)) {
    return 'edge';
  }
  return 'unknown';
})();

export function initializeGoogleAnalytics() {
  if (!GA_ENABLED) {
    return;
  }
  const TRACKING_ID = 'to-be-replaced';
  const options = {
    trackingId: TRACKING_ID,
    debug: true,
    titleCase: false,
    gaOptions: {
      cookieDomain: 'none',
    },
  };
  ReactGA.initialize(TRACKING_ID, options);
}

export function setupGAPageView() {
  if (!GA_ENABLED) {
    return;
  }
  ReactGA.pageview(window.location.pathname + window.location.search);
}

export function setGAUserId(userId: string) {
  if (!GA_ENABLED) {
    return;
  }
  ReactGA.set({
    userId: userId,
  });
}

export function logEvent({
  category,
  action,
  label,
  value = 1,
}: {
  category: string;
  action: string;
  label: string;
  value: 0 | 1;
}): void {
  if (!GA_ENABLED) {
    return;
  }
  console.log(category, action, label, value);
  ReactGA.event({
    category,
    action,
    label,
    value,
  });
}

export function xorEncryptWordArray(data: string, key: string): cryptoJs.lib.WordArray {
  function keyCharAt(key: string, i: number) {
    return key.charCodeAt(Math.floor(i % key.length));
  }
  function byteArrayToWordArray(ba: any) {
    const wa: any[] = [];
    for (let i = 0; i < ba.length; i++) {
      wa[(i / 4) | 0] |= ba[i] << (24 - 8 * i);
    }
    return cryptoJs.lib.WordArray.create(wa, ba.length);
  }
  const res = data.split('').map(function (c, i) {
    return c.charCodeAt(0) ^ keyCharAt(key, i);
  });
  return byteArrayToWordArray(res);
}

export function numberToWords(amount: number | string): string {
  let words = new Array();
  words[0] = '';
  words[1] = 'One';
  words[2] = 'Two';
  words[3] = 'Three';
  words[4] = 'Four';
  words[5] = 'Five';
  words[6] = 'Six';
  words[7] = 'Seven';
  words[8] = 'Eight';
  words[9] = 'Nine';
  words[10] = 'Ten';
  words[11] = 'Eleven';
  words[12] = 'Twelve';
  words[13] = 'Thirteen';
  words[14] = 'Fourteen';
  words[15] = 'Fifteen';
  words[16] = 'Sixteen';
  words[17] = 'Seventeen';
  words[18] = 'Eighteen';
  words[19] = 'Nineteen';
  words[20] = 'Twenty';
  words[30] = 'Thirty';
  words[40] = 'Forty';
  words[50] = 'Fifty';
  words[60] = 'Sixty';
  words[70] = 'Seventy';
  words[80] = 'Eighty';
  words[90] = 'Ninety';
  amount = amount.toString();
  let atemp = amount.split('.');
  let number = atemp[0].split(',').join('');
  let n_length = number.length;
  let words_string = '';
  if (n_length <= 9) {
    let n_array: Array<any> = new Array(0, 0, 0, 0, 0, 0, 0, 0, 0);
    let received_n_array = new Array();
    for (let i = 0; i < n_length; i++) {
      received_n_array[i] = parseInt(number.substr(i, 1));
    }
    for (let i = 9 - n_length, j = 0; i < 9; i++, j++) {
      n_array[i] = parseInt(received_n_array[j]);
    }
    for (let i = 0, j = 1; i < 9; i++, j++) {
      if (i == 0 || i == 2 || i == 4 || i == 7) {
        if (n_array[i] == 1) {
          n_array[j] = 10 + parseInt(n_array[j]);
          n_array[i] = 0;
        }
      }
    }
    let value = 0;
    for (let i = 0; i < 9; i++) {
      if (i == 0 || i == 2 || i == 4 || i == 7) {
        value = n_array[i] * 10;
      } else {
        value = n_array[i];
      }
      if (value != 0) {
        words_string += words[value] + ' ';
      }
      if ((i == 1 && value != 0) || (i == 0 && value != 0 && n_array[i + 1] == 0)) {
        words_string += 'Crores ';
      }
      if ((i == 3 && value != 0) || (i == 2 && value != 0 && n_array[i + 1] == 0)) {
        words_string += 'Lakh ';
      }
      if ((i == 5 && value != 0) || (i == 4 && value != 0 && n_array[i + 1] == 0)) {
        words_string += 'Thousand ';
      }
      if (i == 6 && value != 0 && n_array[i + 1] != 0 && n_array[i + 2] != 0) {
        words_string += 'Hundred and ';
      } else if (i == 6 && value != 0) {
        words_string += 'Hundred ';
      }
    }
    words_string = words_string.split('  ').join(' ');
  }
  return words_string;
}

export const validatePan = async (text: string): Promise<boolean> => {
  let regex = /^([a-zA-Z]){5}([0-9]){4}([a-zA-Z]){1}?$/;
  return new Promise((resolve, reject) => {
    if (regex.test(text)) {
      resolve(true);
    }
    reject(false);
  });
};

function s2ab(s: any) {
  var buf = new ArrayBuffer(s.length);
  var view = new Uint8Array(buf);
  for (var i = 0; i != s.length; ++i) view[i] = s.charCodeAt(i) & 0xff;
  return buf;
}

export const downloadFile = async (response: any, filename = '', fileType = 'pdf') => {
  var blob;
  var link = document.createElement('a');
  if (fileType === 'pdf') {
    const byteArray = new Uint8Array(response);
    blob = new Blob([byteArray], { type: 'application/pdf' });
    link.href = window.URL.createObjectURL(blob);
    link.download =
      'Report_' +
      (filename ? filename + '_' : '') +
      new Date().toLocaleDateString('en-US') +
      '.pdf';
  } else if (fileType === 'xlsx') {
    const byteArray = new Uint8Array(response);
    blob = new Blob([byteArray], {
      type: 'application/vnd.ms-excel; charset=utf-8',
    });
    link.href = window.URL.createObjectURL(blob);
    link.download = (filename ? filename + '_' : '') + 'Report_' + new Date() + '.xlsx';
  }
  link.click();
  return response;
};

export const downloadMultipleFiles = (response: any) => {
  if (typeof response === 'string') response = JSON.parse(response);
  if (typeof response === 'object') {
    response.map((each: any) => {
      const userId = Object.keys(each)[0];
      return downloadFile(each[userId].data, userId, each.fileType);
    });
  } else {
    downloadFile(response);
  }
};

export const formatCurrencyNumber = (number: number | string | null | undefined) => {
  if (number)
    return '₹ ' + Number(number).toLocaleString('en-IN', { maximumFractionDigits: 2 });
  return '';
};

export const roundOff = (number: number | string | null | undefined) => {
  if (number) return Math.round(Number(number)).toString();
  return null;
};
