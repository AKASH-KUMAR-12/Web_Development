export const READY_TO_SUBMIT = 'READY_TO_SUBMIT';
export const SUBMITTING = 'SUBMITTING';
