import { Close as CloseIcon } from '@mui/icons-material';
import { AlertColor } from '@mui/lab';
import { IconButton, Slide } from '@mui/material';
import { SnackbarKey, useSnackbar, VariantType } from 'notistack';
import React, { createContext, useCallback, useContext, useState } from 'react';
import { sections } from '../Sidebar/sidebar.responsive';
import { useNavigate } from 'react-router';

interface RootState {
  selectedFamilyMembers: string[];
  setSelectedFamilyMembers: React.Dispatch<React.SetStateAction<string[]>>;
  showToast(message: string, type: AlertColor, hideDuration?: number): void;
  showToastForNewRecommendation(message: string, type: AlertColor, hideDuration?: number): void;
  showSidebar: boolean;
  setShowSidebar: React.Dispatch<React.SetStateAction<boolean>>;
  showContactRMDialog: boolean;
  setShowContactRMDialog: React.Dispatch<React.SetStateAction<boolean>>;
  selectedPagesSection:
    | {
        name: string;
        options: { label: string; icon: JSX.Element; path: string }[];
      }
    | undefined;
  setSelectedPagesSection: React.Dispatch<
    React.SetStateAction<
      | {
          name: string;
          options: { label: string; icon: JSX.Element; path: string }[];
        }
      | undefined
    >
  >;
  resetSelectedFamilyMembers(): void;
}

const RootContext = createContext<RootState>({
  selectedFamilyMembers: [],
  setSelectedFamilyMembers: () => {},
  showSidebar: false,
  setShowSidebar: () => {},
  showContactRMDialog: false,
  setShowContactRMDialog: () => {},
  showToast: () => {},
  showToastForNewRecommendation: () => {},
  selectedPagesSection: sections.profile,
  setSelectedPagesSection: () => {},
  resetSelectedFamilyMembers: () => {},
});

export const useRootContext = () => {
  return useContext(RootContext);
};

function RootContextProvider({ children }: { children: React.ReactElement }) {
  const isMobileBreakpoint = window.innerWidth < 900;
  const [selectedFamilyMembers, setSelectedFamilyMembers] = useState(['overall-family']);
  const [showSidebar, setShowSidebar] = useState(isMobileBreakpoint ? false : true);
  const [selectedPagesSection, setSelectedPagesSection] = useState<
    | {
        name: string;
        options: { label: string; icon: JSX.Element; path: string }[];
      }
    | undefined
  >();
  const [showContactRMDialog, setShowContactRMDialog] = useState<boolean>(false);
  const [snackIdToDelete, setSnackIdToDelete] = useState<SnackbarKey>();
  const { enqueueSnackbar, closeSnackbar } = useSnackbar();
  const navigate = useNavigate();

  const showToast = useCallback(
    (message: string, variant: VariantType, hideDuration?: number) => {
      enqueueSnackbar(message, {
        action: (snackbarId: SnackbarKey) => (
          <IconButton
            key="close"
            aria-label="close"
            color="inherit"
            onClick={() => closeSnackbar(snackbarId)}
          >
            <CloseIcon />
          </IconButton>
        ),
        anchorOrigin: { vertical: 'top', horizontal: 'right' },
        TransitionComponent: (props) => <Slide {...props} direction="down" />,
        variant,
        autoHideDuration: hideDuration || 2000,
      });
    },
    [enqueueSnackbar],
  );

  const showToastForNewRecommendation = useCallback(
    (message: string, variant: VariantType, hideDuration?: number) => {
      enqueueSnackbar(message, {
        // action: (snackbarId: SnackbarKey) => (
        //   <IconButton
        //     key="close"
        //     aria-label="close"
        //     color="inherit"
        //     onClick={() => closeSnackbar(snackbarId)}
        //   >
        //     <CloseIcon />
        //   </IconButton>
        // ),
        anchorOrigin: { vertical: 'top', horizontal: 'center' },
        TransitionComponent: (props) => <Slide {...props} direction="down" />,
        variant,
        autoHideDuration: hideDuration || 4000,
        SnackbarProps: {
          onClick: () => {
            navigate('/invest' , { state: {tab: "recommend"}});
            closeSnackbar(snackIdToDelete);
          },
        }
      });
    },
    [enqueueSnackbar],
  );

  const resetSelectedFamilyMembers = () => {
    setSelectedFamilyMembers(['overall-family']);
  };

  return (
    <RootContext.Provider
      value={{
        selectedFamilyMembers,
        setSelectedFamilyMembers,
        showToast,
        showToastForNewRecommendation,
        showSidebar,
        setShowSidebar,
        showContactRMDialog,
        setShowContactRMDialog,
        selectedPagesSection,
        setSelectedPagesSection,
        resetSelectedFamilyMembers,
      }}
    >
      {children}
    </RootContext.Provider>
  );
}

export default RootContextProvider;
