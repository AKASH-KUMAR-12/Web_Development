import * as React from 'react';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogTitle from '@mui/material/DialogTitle';
import useMediaQuery from '@mui/material/useMediaQuery';
import { useTheme } from '@mui/material/styles';
import { useLoginContext } from '../login/data/login.context';
import { useNavigate } from 'react-router';
import LogoutIcon from '@mui/icons-material/Logout';


export default function logoutAlert({open,handleClose}:{open:boolean,handleClose:any}) {
  const { logout } = useLoginContext();
  const navigate = useNavigate();

  const handleCloseLogoutAlert = () => {
    handleClose(false);
  };

  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down('md'));
  return (
    <React.Fragment>
      <Dialog sx={{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",marginBlock:"auto",marginInline:{xs:"5rem",sm:"auto"},height:{xs:"11rem",sm:"20rem"},borderRadius:{xs:"2rem"}, "& .MuiDialog-container": {
            "& .MuiPaper-root": {
              maxWidth: "800px",
              pt:{xs:0,sm:3},pl:{xs:0,sm:7},pb:{xs:0,sm:5},pr:{xs:0,sm:7} ,
             
            },
          }}}
         fullScreen={fullScreen}
         open={open}
         onClose={handleCloseLogoutAlert}
         aria-labelledby="responsive-dialog-title"
      >
        <LogoutIcon fontSize='large' sx={{marginInline:"auto",marginTop:{xs:"1rem",sm:"1rem"}}}/>
        <DialogTitle id="responsive-dialog-title" sx={{fontSize:{xs:12,sm:20}}}>
          {"Are you sure you want to Log Out?"}
        </DialogTitle>
        
        <DialogActions sx={{display:"flex",justifyContent:"center",alignItems:"center",}}>
          <Button 
          sx={{
            background:"transparent",
            p:{xs:"0.2rem 0.5rem",sm:"0.2rem 1rem"},
            fontSize:{xs:12,sm:14},
            mr:"1rem",
            borderRadius:"10px",
            color:"#123991",
            border:"1px solid #123991",
            '&:hover': {
          color: 'white',
          border:"1px solid white",
          backgroundColor: '#123991',
          },
          }}
          onClick={()=>{
            logout()
            navigate('/login')
            }}  >
            Yes, Logout
          </Button>
          <Button 
          sx={{
            background:"#123991",
            p:{xs:"0.2rem 0.5rem",sm:"0.2rem 1rem"},
            fontSize:{xs:12,sm:14},
            color:"white",
            borderRadius:"10px",
            border:"1px solid white",
            '&:hover': {
          color: '#123991',
          border:"1px solid #123991",
          backgroundColor: 'transparent',
          
          },
          }}
          onClick={handleClose}>Cancel</Button>
        </DialogActions>
      </Dialog>
    </React.Fragment>
  );
}