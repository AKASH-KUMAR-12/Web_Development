import { ChevronLeft, Close } from '@mui/icons-material';
import { Box, CardMedia, Divider, Stack, Typography } from '@mui/material';
import { Fragment, ReactElement, useEffect, useState } from 'react';
import { NavLink } from '../common';
import { useRootContext } from '../data/root.context';
import { useLoginContext } from '../login/data/login.context';
import LogoutAlert from './LogoutAlert';
import AdditionalKYCIcon from '../profile/icons/additional-kyc';
import BankDetailsIcon from '../profile/icons/bank-details';
import ContactDetailsIcon from '../profile/icons/contact-details';
import DocumentsIcon from '../profile/icons/documents';
import FatcaDeclarationIcon from '../profile/icons/fatca-declaration';
import NomineeDetailsIcon from '../profile/icons/nominee-details';
import PersonDetailsIcon from '../profile/icons/person-details';
import PersonalInfoIcon from '../profile/icons/personal-info';
import UpdatePasswordIcon from '../profile/icons/update-password';
import CGStatementIcon from '../reports/icons/cg-statement';
import ClientStatementIcon from '../reports/icons/client-statement';
import PortfolioSummaryIcon from '../reports/icons/portfolio-summary';
import TransactionStatementIcon from '../reports/icons/transaction-statement';
import ContactRmDialog from '../contact-rm-dialog/contact-rm-dialog';

export const sections = {
  profile: {
    name: 'Profile',
    options: [
      {
        label: 'Personal Information',
        icon: <PersonalInfoIcon />,
        path: '/profile/personal-information',
      },
      {
        label: 'Details of Related Person',
        icon: <PersonDetailsIcon />,
        path: '/profile/nominee',
      },
      {
        label: 'Contact Details',
        icon: <ContactDetailsIcon />,
        path: '/profile/contact-details',
      },
      {
        label: 'Additional KYC',
        icon: <AdditionalKYCIcon />,
        path: '/profile/additional-kyc',
      },
      {
        label: 'Nominee Details',
        icon: <NomineeDetailsIcon />,
        path: '/profile/nominee-details',
      },
      {
        label: 'FATCA Declaration',
        icon: <FatcaDeclarationIcon />,
        path: '/profile/fatca-declaration',
      },
      {
        label: 'Bank Details',
        icon: <BankDetailsIcon />,
        path: '/profile/bank-details',
      },
      // {
      //   label: 'Documents',
      //   icon: <DocumentsIcon />,
      //   path: '/profile/documents',
      // },
      // {
      //   label: 'Update Password',
      //   icon: <UpdatePasswordIcon />,
      //   path: '/profile/update-password',
      // },
    ],
  },
  reports: {
    name: 'Reports',
    options: [
      {
        label: 'Client Statement',
        icon: <ClientStatementIcon />,
        path: '/reports/client-statement',
      },
      {
        label: 'Transaction Statement',
        icon: <TransactionStatementIcon />,
        path: '/reports/transaction-statement',
      },
      {
        label: 'Portfolio Summary',
        icon: <PortfolioSummaryIcon />,
        path: '/reports/portfolio-summary',
      },
      {
        label: 'CG Statement',
        icon: <CGStatementIcon />,
        path: '/reports/cg-statement',
      },
    ],
  },
};

export default function SideNavResponsive() {
  const {
    setShowSidebar,
    showContactRMDialog,
    setShowContactRMDialog,
    selectedPagesSection: selectedSection,
    setSelectedPagesSection: setSelectedSection,
  } = useRootContext();
  const [mainMenuVisible, setMainMenuVisible] = useState(selectedSection === undefined);
  const { userDetails: user, logout } = useLoginContext();

  const [open, setOpen] = useState(false);
  const handleOpenLogoutAlert = () => {
    setOpen(true);
  };

  const handleCloseLogoutAlert = () => {
    setOpen(false);
  };
  const handleOpenContactRmDialog = () => {
    setShowContactRMDialog(true);
  };
  const handleCloseContactRmDialog = () => {
    setShowContactRMDialog(false);
  };

  return (
    <>
      <Box
        sx={{
          width: '100vw',
          height: '100vh',
          overflow: 'hidden',
          position: 'relative',
        }}
      >
        <Box
          className={'sidenav'}
          sx={{
            position: 'absolute',
            top: '0',
            left: '0',
            width: '100%',
            transform: mainMenuVisible ? 'translateX(0)' : 'translateX(-100%)',
            transition: 'transform 0.3s ease-in-out',
          }}
        >
          <Box
            sx={{
              background:
                'url("/images/menu-bg-mobile.svg") local no-repeat right top, #163869',
              width: '100%',
              height: '100vh',
              position: 'relative',
              pt: 4,
              px: 3,
            }}
          >
            <Box
              onClick={() => setShowSidebar(false)}
              sx={{
                width: '34px',
                height: '34px',
                border: '1px solid rgba(255, 255, 255, 0.19)',
                borderRadius: '10px',
                display: 'grid',
                placeItems: 'center',
              }}
            >
              <Close
                sx={{
                  color: 'primary.light',
                }}
              />
            </Box>
            <Stack alignItems="center" sx={{ p: 3 }}>
              <CardMedia
                component="img"
                alt="avatar"
                src="/images/avatar.svg"
                sx={{ width: '60px' }}
              />
              <Typography
                sx={{
                  fontSize: '24px',
                  fontWeight: 600,
                  color: 'primary.light',
                  pt: 1.5,
                }}
              >
                {user?.name || ''}
              </Typography>
            </Stack>
          </Box>
          <Box
            sx={{
              bgcolor: 'primary.light',
              position: 'absolute',
              top: '220px',
              borderTopRightRadius: 40,
              borderTopLeftRadius: 40,
              width: '100%',
              overflow: 'auto',
              height: 'calc(100vh - 220px)',
              p: 4.5,
            }}
          >
            <NavLink
              to={'/dashboard'}
              onClick={() => {
                setShowSidebar(false);
                setSelectedSection(undefined);
              }}
            >
              <Stack direction="row" alignItems="center" spacing={2}>
                <CardMedia
                  component="img"
                  src="/images/dashboard-mobile.svg"
                  alt="dashboard"
                  sx={{ width: 34 }}
                />
                <Typography sx={{ color: 'text.secondary', fontWeight: 500 }}>
                  Dashboard
                </Typography>
              </Stack>
            </NavLink>
            <Divider sx={{ my: 2 }} />
            <NavLink
              to={'/invest'}
              onClick={() => {
                setShowSidebar(false);
                setSelectedSection(undefined);
              }}
            >
              <Stack direction="row" alignItems="center" spacing={2}>
                <CardMedia
                  component="img"
                  src='/images/invest_icon.svg'
                  alt="invest"
                  sx={{ width: 34 }}
                />
                <Typography sx={{ color: 'text.secondary', fontWeight: 500 }}>
                  Invest
                </Typography>
              </Stack>
            </NavLink>
            <Divider sx={{ my: 2 }} />
            <Stack
              direction="row"
              onClick={() => {
                setMainMenuVisible(false);
                setSelectedSection(sections.reports);
              }}
              alignItems="center"
              spacing={2}
            >
              <CardMedia
                component="img"
                src="/images/reports-mobile.svg"
                alt="Reports"
                sx={{ width: 34 }}
              />
              <Typography sx={{ color: 'text.secondary', fontWeight: 500 }}>
                Reports
              </Typography>
            </Stack>
            <Divider sx={{ my: 2 }} />
            <Stack
              direction="row"
              onClick={() => {
                setMainMenuVisible(false);
                setSelectedSection(sections.profile);
              }}
              alignItems="center"
              spacing={2}
            >
              <CardMedia
                component="img"
                src="/images/profile-mobile.svg"
                alt="Profile"
                sx={{ width: 34 }}
              />
              <Typography sx={{ color: 'text.secondary', fontWeight: 500 }}>
                Profile
              </Typography>
            </Stack>
            <Divider sx={{ my: 2 }} />
            {/* <Stack
              direction="row"
              onClick={() => setShowContactRMDialog(true)}
              alignItems="center"
              spacing={2}
            >
              <CardMedia
                component="img"
                src="/images/contact-rm-mobile.svg"
                alt="ContactRM"
                sx={{ width: 34 }}
              />
              <Typography sx={{ color: 'text.secondary', fontWeight: 500 }}>
                Contact RM
              </Typography>
            </Stack> 
            <Divider sx={{ my: 2 }} /> */}
             <NavLink
              to={'#'}
              onClick={() => {
                handleOpenContactRmDialog()
              }}
            >
              <Stack direction="row" alignItems="center" spacing={2}>
                <CardMedia
                  component="img"
                  src="/images/contact_rm.svg"
                  alt="contact rm "
                  sx={{ width: 34 }}
                />
                <Typography sx={{ color: 'text.secondary', fontWeight: 500 }}>
                  Contact RM
                </Typography>
              </Stack>
            </NavLink>
            <Divider sx={{ my: 2 }} />
            <NavLink
              to="#"
              onClick={() => {
                handleOpenLogoutAlert()
              }}
            >
              <Stack direction="row" alignItems="center" spacing={2}>
                <CardMedia
                  component="img"
                  src="/images/logout-mobile.svg"
                  alt="logout"
                  sx={{ width: 34 }}
                />
                <Typography sx={{ fontWeight: 500 }}>Logout</Typography>
              </Stack>
            </NavLink>
            <LogoutAlert
              open={open}
              handleClose={handleCloseLogoutAlert}
            />
             <ContactRmDialog
             width={true}
        open={showContactRMDialog}
        handleClose={handleCloseContactRmDialog}
      />
          </Box>
        </Box>
        <Box
          className="sidenav-subsection"
          sx={{
            position: 'absolute',
            top: '0',
            left: '0',
            width: '100%',
            transition: 'transform 0.3s ease-in-out',
            opacity: '1',
            transform: mainMenuVisible ? 'translateX(100%)' : 'translateX(0)',
          }}
        >
          <Box
            sx={{
              background:
                'url("/images/menu-bg-mobile.svg") local no-repeat right top, #163869',
              width: '100%',
              height: '100vh',
              position: 'relative',
              pt: 4,
              px: 3,
            }}
          >
            <Box
              onClick={() => setMainMenuVisible(true)}
              sx={{
                width: '34px',
                height: '34px',
                border: '1px solid rgba(255, 255, 255, 0.19)',
                borderRadius: '10px',
                display: 'grid',
                placeItems: 'center',
              }}
            >
              <ChevronLeft
                sx={{
                  color: 'primary.light',
                }}
              />
            </Box>
            <Stack alignItems="center" sx={{ p: 1 }}>
              <Typography
                sx={{
                  fontSize: '24px',
                  fontWeight: 600,
                  color: 'primary.light',
                  pt: 1.5,
                }}
              >
                {selectedSection?.name}
              </Typography>
            </Stack>
          </Box>
          <Box
            sx={{
              bgcolor: 'primary.light',
              position: 'absolute',
              top: '150px',
              borderTopRightRadius: 40,
              borderTopLeftRadius: 40,
              width: '100%',
              height: 'calc(100vh - 150px)',
              overflow: 'auto',
              p: 4.5,
            }}
          >
            {selectedSection?.options.map((option, index) => (
              <Fragment key={option.path}>
                <NavLink
                  to={option.path || ''}
                  sx={{
                    color: 'text.primary',
                  }}
                  onClick={() => {
                    setShowSidebar(false);
                  }}
                >
                  {option?.icon}
                  {option.label}
                </NavLink>
                {index < selectedSection?.options.length - 1 && (
                  <Divider sx={{ my: 2 }} />
                )}
              </Fragment>
            ))}
          </Box>
        </Box>

      </Box>
    </>
  );
}
