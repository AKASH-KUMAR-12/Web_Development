import { Box, CardMedia, Grid, Stack, styled, Typography, useTheme } from '@mui/material';
import MuiLinearProgress, {
  linearProgressClasses,
  LinearProgressProps,
} from '@mui/material/LinearProgress';
import { BoxProps } from '@mui/system';
import { useState } from 'react';

import { formatCurrencyNumber, roundOff } from '../../lib/helper';
import { useRootContext } from '../data/root.context';
import Debt from '../login/icons/debt';
import DirectEquity from '../login/icons/direct-equity';
import MutualFunds from '../login/icons/mutual-funds';
import { useDashboardContext } from './data/dashboard.context';
import Alternatives from './icons/alternatives';
import BgCircle from './icons/bg-cicle';

const InvestmentCard = styled(Box)(({ theme }) => ({
  background: theme.palette.primary.light,
  padding: theme.spacing(3.2, 2.5),
  //height: '6em',
  boxShadow: theme.shadows[24],
  borderRadius: 10,
  margin: theme.spacing(2, 0),
  display: 'flex',
  flexDirection: 'row',
  alignItems: 'center',
  position: 'relative',
  justifyContent: 'space-between',
  '& .bg-circle-small': {
    width: '4em',
    height: '6rem',
  },
  [theme.breakpoints.down('md')]: {
    flexDirection: 'column-reverse',
    padding: theme.spacing(2.5),
  },
}));

const TextInImage = styled(Typography)(({ theme }) => ({
  fontSize: 20,
  letterSpacing: '0.01em',
  lineHeight: '25px',
  [theme.breakpoints.up('xl')]: {
    fontSize: 22,
  },
  [theme.breakpoints.down('lg')]: {
    fontSize: 16,
  },
}));

const LabelHeadText = styled(Typography)(({ theme }) => ({
  fontSize: 13,
  letterSpacing: '0.01em',
  color: theme.palette.text.secondaryDark,
  [theme.breakpoints.down('lg')]: {
    fontSize: 11,
  },
}));

const LabelBodyText = styled(Typography)(({ theme }) => ({
  fontSize: 16,
  fontWeight: 600,
  color: theme.palette.text.primaryDark,
  [theme.breakpoints.up('xl')]: {
    fontSize: 20,
  },
  [theme.breakpoints.down('lg')]: {
    fontSize: 13,
  },
}));

const LinearProgressBar = styled(MuiLinearProgress)(({ theme }) => ({
  height: '1em',
  borderRadius: 5,
  boxShadow: '0px 2px 2px rgba(0, 0, 0, 0.1)',
  [`&.${linearProgressClasses.colorPrimary}`]: {
    backgroundColor: theme.palette.grey[theme.palette.mode === 'light' ? 200 : 800],
  },
  [`& .${linearProgressClasses.bar}`]: {
    borderRadius: 5,
    backgroundColor: theme.palette.mode === 'light' ? '#1a90ff' : '#308fe8',
  },
}));

const InvestmentsProgressBarLabel = styled(Box)(
  (props: BoxProps & { value: number }) => ({
    width: '100%',
    height: '1em',
    display: 'flex',
    justifyContent: 'flex-end',
    alignItems: 'flex-start',
    position: 'absolute',
    top: 0,
    transform: `translateX(${Math.round(props.value) - 100}%)`,
    right: props.value > 9 ? '3px' : '-20px',
    '& span': {
      fontSize: '12px',
      color: props.value > 9 ? 'white' : 'black',
    },
  }),
);

const InvestmentValues = styled(Stack)(({ theme }) => ({
  flexDirection: 'row',
  borderLeft: '1px solid',
  borderRight: '1px solid',
  borderColor: theme.palette.text.disabledLight,
  paddingLeft: 20,
  paddingRight: 20,
  marginRight: 22,
  flex: 2,
  justifyContent: 'space-between',
  [theme.breakpoints.between('md', 'lg')]: {
    flex: 3,
  },
  [theme.breakpoints.down('md')]: {
    width: '100%',
    justifyContent: 'unset',
    gap: 12,
    paddingLeft: 0,
    paddingRight: 0,
    marginRight: 0,
    borderRight: 'none',
    borderLeft: 'none',
  },
}));

const InvestmentsProgressBar = ({
  value,
  ...props
}: LinearProgressProps & { value: number }) => {
  return (
    <Box sx={{ position: 'relative' }}>
      <LinearProgressBar value={value} {...props} />
      <InvestmentsProgressBarLabel value={value}>
        <span
        // variant="body2" color="text.secondary"
        >{`${Math.round(value)}%`}</span>
      </InvestmentsProgressBarLabel>
    </Box>
  );
};

const InvestmentsCards = () => {
  const {
    details: { investments: data },
  } = useDashboardContext();
  const { selectedFamilyMembers } = useRootContext();
  const [cardsOpen, setCardsOpen] = useState({
    debt: false,
    equity: false,
    hybrid: false,
    alternatives: false,
  });
  const theme = useTheme();
  const debt = data.find((obj) => obj.assetClass === 'Debt');
  const equity = data.find((obj) => obj.assetClass === 'Equity');
  const hybrid = data.find((obj) => obj.assetClass === 'Hybrid');
  const alternatives = data.find((obj) => obj.assetClass === 'Alternatives');

  return (
    (debt || equity || hybrid || alternatives) && (
    <>
      <Box sx={{ my: 8 }}>
        <Typography
          sx={{
            fontSize: [14, 14, 16, 20],
            fontWeight: 500,
            color: 'text.secondary',
            textTransform: 'uppercase',
            letterSpacing: '0.06em',
          }}
        >
          Investments
        </Typography>
        {
          //! Debt
          debt && (
            <InvestmentCard
              onClick={() => setCardsOpen({ ...cardsOpen, debt: !cardsOpen.debt })}
            >
              <BgCircle
                fillPath={'url(#bg_circle_linear_gradient_blue)'}
                sx={{
                  width: '4em',
                  height: '6rem',
                  display: ['none', 'none', 'block'],
                  position: 'absolute',
                  left: '0px',
                }}
              />
              <Stack
                direction="row"
                alignItems="center"
                spacing={2}
                sx={{
                  flex: 1,
                  display: ['none', 'none', 'flex'],
                }}
              >
                <DirectEquity sx={{ width: '36px', height: '36px' }} />
                <TextInImage>Debt</TextInImage>
              </Stack>
              <InvestmentValues
                sx={{
                  [theme.breakpoints.down('md')]: {
                    maxHeight: cardsOpen.debt ? '100px' : '0px',
                    overflow: 'hidden',
                    transition: 'all 0.3s ease-in-out',
                  },
                }}
              >
                <Box
                  sx={{
                    width: '100%',
                    height: '100%',
                    [theme.breakpoints.down('md')]: {
                      borderTop: '1px solid',
                      borderColor: theme.palette.text.disabledLight,
                      borderLeft: 'none',
                      borderRight: 'none',
                      paddingTop: 2,
                      marginTop: 2,
                    },
                  }}
                >
                  <Grid container>
                    <Grid item xs={5}>
                      <Stack>
                        <LabelHeadText>Net Investment</LabelHeadText>
                        <LabelBodyText>
                          {formatCurrencyNumber(roundOff(debt.investedValue))}
                        </LabelBodyText>
                      </Stack>
                    </Grid>
                    <Grid item xs={5}>
                      <Stack>
                        <LabelHeadText>Current Value</LabelHeadText>
                        <LabelBodyText>
                          {formatCurrencyNumber(roundOff(debt.currentValue))}
                        </LabelBodyText>
                      </Stack>
                    </Grid>
                    <Grid item xs={2}>
                      <Stack>
                        <LabelHeadText>XIRR</LabelHeadText>
                        <LabelBodyText>
                          {debt.xirr && !(selectedFamilyMembers.length > 1)
                            ? debt.xirr + '%'
                            : 'N/A'}
                        </LabelBodyText>
                      </Stack>
                    </Grid>
                  </Grid>
                </Box>
              </InvestmentValues>
              <Box
                sx={{
                  flex: 1.5,
                  width: ['100%', '100%', 'auto'],
                  ml: ['auto', 'auto', 'auto'],
                  mr: ['auto', 'auto', 4],
                }}
              >
                <InvestmentsProgressBar variant="determinate" value={debt.holdPercent} />
              </Box>
              <Stack
                direction="row"
                alignItems="center"
                justifyContent="space-between"
                sx={{ width: '100%', mb: 2, display: ['flex', 'flex', 'none'] }}
              >
                <TextInImage>Debt</TextInImage>
                <Stack direction="row" alignItems="center">
                  <Typography sx={{ color: 'text.primaryDark', mr: 1 }}>₹54L</Typography>
                  <CardMedia component="img" src="/images/up-arrow.svg" alt="arrow" />
                </Stack>
              </Stack>
            </InvestmentCard>
          )
        }
        {
          //! Equity
          equity && (
            <InvestmentCard
              onClick={() => setCardsOpen({ ...cardsOpen, equity: !cardsOpen.equity })}
            >
              <BgCircle
                fillPath={'url(#bg_circle_linear_gradient_purple)'}
                sx={{
                  width: '4em',
                  height: '6rem',
                  display: ['none', 'none', 'block'],
                  position: 'absolute',
                  left: '0px',
                }}
              />
              <Stack
                direction="row"
                alignItems="center"
                spacing={2}
                sx={{
                  display: ['none', 'none', 'flex'],
                  flex: 1,
                }}
              >
                <MutualFunds sx={{ width: '36px', height: '36px' }} />
                <TextInImage>Equity</TextInImage>
              </Stack>
              <InvestmentValues
                sx={{
                  [theme.breakpoints.down('md')]: {
                    maxHeight: cardsOpen.equity ? '100px' : '0px',
                    overflow: 'hidden',
                    transition: 'all 0.3s ease-in-out',
                  },
                }}
              >
                <Box
                  sx={{
                    width: '100%',
                    height: '100%',
                    [theme.breakpoints.down('md')]: {
                      borderTop: '1px solid',
                      borderColor: theme.palette.text.disabledLight,
                      borderLeft: 'none',
                      borderRight: 'none',
                      paddingTop: 2,
                      marginTop: 2,
                    },
                  }}
                >
                  <Grid container>
                    <Grid item xs={5}>
                      <Stack>
                        <LabelHeadText>Net Investment</LabelHeadText>
                        <LabelBodyText>
                          {formatCurrencyNumber(roundOff(equity.investedValue))}
                        </LabelBodyText>
                      </Stack>
                    </Grid>
                    <Grid item xs={5}>
                      <Stack>
                        <LabelHeadText>Current Value</LabelHeadText>
                        <LabelBodyText>
                          {formatCurrencyNumber(roundOff(equity.currentValue))}
                        </LabelBodyText>
                      </Stack>
                    </Grid>
                    <Grid item xs={2}>
                      <Stack>
                        <LabelHeadText>XIRR</LabelHeadText>
                        <LabelBodyText>
                          {equity.xirr && !(selectedFamilyMembers.length > 1)
                            ? equity.xirr + '%'
                            : 'N/A'}
                        </LabelBodyText>
                      </Stack>
                    </Grid>
                  </Grid>
                </Box>
              </InvestmentValues>
              <Box
                sx={{
                  flex: 1.5,
                  width: ['100%', '100%', 'auto'],
                  ml: ['auto', 'auto', 'auto'],
                  mr: ['auto', 'auto', 4],
                }}
              >
                <InvestmentsProgressBar
                  variant="determinate"
                  value={equity.holdPercent}
                  sx={{
                    '& .MuiLinearProgress-bar': {
                      backgroundColor: 'rgba(153, 106, 198, 1)',
                    },
                  }}
                />
              </Box>
              <Stack
                direction="row"
                alignItems="center"
                justifyContent="space-between"
                sx={{ width: '100%', mb: 2, display: ['flex', 'flex', 'none'] }}
              >
                <TextInImage>Equity</TextInImage>
                <Stack direction="row" alignItems="center">
                  <Typography sx={{ color: 'text.primaryDark', mr: 1 }}>₹25L</Typography>
                  <CardMedia component="img" src="/images/down-arrow.svg" alt="arrow" />
                </Stack>
              </Stack>
            </InvestmentCard>
          )
        }
        {
          //! Hybrid
          hybrid && (
            <InvestmentCard
              onClick={() => setCardsOpen({ ...cardsOpen, hybrid: !cardsOpen.hybrid })}
            >
              <BgCircle
                fillPath={'url(#bg_circle_linear_gradient_turquoise)'}
                sx={{
                  width: '4em',
                  height: '6rem',
                  display: ['none', 'none', 'block'],
                  position: 'absolute',
                  left: '0px',
                }}
              />
              <Stack
                direction="row"
                alignItems="center"
                spacing={2}
                sx={{
                  flex: 1,
                  display: ['none', 'none', 'flex'],
                }}
              >
                <Debt
                  sx={{ width: '36px', height: '36px', '& path': { fill: '#32BCD8' } }}
                />
                <TextInImage>Hybrid</TextInImage>
              </Stack>
              <InvestmentValues
                sx={{
                  [theme.breakpoints.down('md')]: {
                    maxHeight: cardsOpen.hybrid ? '100px' : '0px',
                    overflow: 'hidden',
                    transition: 'all 0.3s ease-in-out',
                  },
                }}
              >
                <Box
                  sx={{
                    width: '100%',
                    height: '100%',
                    [theme.breakpoints.down('md')]: {
                      borderTop: '1px solid',
                      borderColor: theme.palette.text.disabledLight,
                      borderLeft: 'none',
                      borderRight: 'none',
                      paddingTop: 2,
                      marginTop: 2,
                    },
                  }}
                >
                  <Grid container>
                    <Grid item xs={5}>
                      <Stack>
                        <LabelHeadText>Net Investment</LabelHeadText>
                        <LabelBodyText>
                          {formatCurrencyNumber(roundOff(hybrid?.investedValue))}
                        </LabelBodyText>
                      </Stack>
                    </Grid>
                    <Grid item xs={5}>
                      <Stack>
                        <LabelHeadText>Current Value</LabelHeadText>
                        <LabelBodyText>
                          {formatCurrencyNumber(roundOff(hybrid.currentValue))}
                        </LabelBodyText>
                      </Stack>
                    </Grid>
                    <Grid item xs={2}>
                      <Stack>
                        <LabelHeadText>XIRR</LabelHeadText>
                        <LabelBodyText>
                          {hybrid.xirr && !(selectedFamilyMembers.length > 1)
                            ? hybrid.xirr + '%'
                            : 'N/A'}
                        </LabelBodyText>
                      </Stack>
                    </Grid>
                  </Grid>
                </Box>
              </InvestmentValues>
              <Box
                sx={{
                  flex: 1.5,
                  width: ['100%', '100%', 'auto'],
                  ml: ['auto', 'auto', 'auto'],
                  mr: ['auto', 'auto', 4],
                }}
              >
                <InvestmentsProgressBar
                  variant="determinate"
                  value={hybrid.holdPercent}
                  sx={{
                    '& .MuiLinearProgress-bar': {
                      backgroundColor: 'rgba(50, 188, 216, 1)',
                    },
                  }}
                />
              </Box>
              <Stack
                direction="row"
                alignItems="center"
                justifyContent="space-between"
                sx={{ width: '100%', mb: 2, display: ['flex', 'flex', 'none'] }}
              >
                <TextInImage>Hybrid</TextInImage>
                <Stack direction="row" alignItems="center">
                  <Typography sx={{ color: 'text.primaryDark', mr: 1 }}>₹25L</Typography>
                  <CardMedia component="img" src="/images/down-arrow.svg" alt="arrow" />
                </Stack>
              </Stack>
            </InvestmentCard>
          )
        }
        {
          //! Alternatives
          alternatives && (
            <InvestmentCard
              onClick={() =>
                setCardsOpen({ ...cardsOpen, alternatives: !cardsOpen.alternatives })
              }
            >
              <BgCircle
                fillPath={'url(#bg_circle_linear_gradient_black)'}
                sx={{
                  width: '4em',
                  height: '6rem',
                  display: ['none', 'none', 'block'],
                  position: 'absolute',
                  left: '0px',
                }}
              />
              <Stack
                direction="row"
                alignItems="center"
                justifyContent={'flex-start'}
                spacing={2}
                sx={{
                  flex: 1,
                  display: ['none', 'none', 'flex'],
                }}
              >
                <Alternatives sx={{ width: '36px', height: '36px' }} />
                <TextInImage>Alternatives</TextInImage>
              </Stack>
              <InvestmentValues
                sx={{
                  [theme.breakpoints.down('md')]: {
                    maxHeight: cardsOpen.alternatives ? '100px' : '0px',
                    overflow: 'hidden',
                    transition: 'all 0.3s ease-in-out',
                  },
                }}
              >
                <Box
                  sx={{
                    width: '100%',
                    height: '100%',
                    [theme.breakpoints.down('md')]: {
                      borderTop: '1px solid',
                      borderColor: theme.palette.text.disabledLight,
                      borderLeft: 'none',
                      borderRight: 'none',
                      paddingTop: 2,
                      marginTop: 2,
                    },
                  }}
                >
                  <Grid container>
                    <Grid item xs={5}>
                      <Stack>
                        <LabelHeadText>Net Investment</LabelHeadText>
                        <LabelBodyText>
                          {formatCurrencyNumber(roundOff(alternatives.investedValue))}
                        </LabelBodyText>
                      </Stack>
                    </Grid>
                    <Grid item xs={5}>
                      <Stack>
                        <LabelHeadText>Current Value</LabelHeadText>
                        <LabelBodyText>
                          {formatCurrencyNumber(roundOff(alternatives.currentValue))}
                        </LabelBodyText>
                      </Stack>
                    </Grid>
                    <Grid item xs={0}>
                      <Stack>
                        <LabelHeadText>XIRR</LabelHeadText>
                        <LabelBodyText>
                          {alternatives.xirr && !(selectedFamilyMembers.length > 1)
                            ? alternatives.xirr + '%'
                            : 'N/A'}
                        </LabelBodyText>
                      </Stack>
                    </Grid>
                  </Grid>
                </Box>
              </InvestmentValues>
              <Box
                sx={{
                  flex: 1.5,
                  width: ['100%', '100%', 'auto'],
                  ml: ['auto', 'auto', 'auto'],
                  mr: ['auto', 'auto', 4],
                }}
              >
                <InvestmentsProgressBar
                  variant="determinate"
                  value={alternatives.holdPercent}
                  sx={{
                    '& .MuiLinearProgress-bar': {
                      backgroundColor: 'rgba(63, 85, 109, 1)',
                    },
                  }}
                />
              </Box>
              <Stack
                direction="row"
                alignItems="center"
                justifyContent="space-between"
                sx={{ width: '100%', mb: 2, display: ['flex', 'flex', 'none'] }}
              >
                <TextInImage>Alternatives</TextInImage>
                <Stack direction="row" alignItems="center">
                  <Typography sx={{ color: 'text.primaryDark', mr: 1 }}>₹25L</Typography>
                  <CardMedia component="img" src="/images/up-arrow.svg" alt="arrow" />
                </Stack>
              </Stack>
            </InvestmentCard>
          )
        }
      </Box>
    </>)
  );
};

export default InvestmentsCards;
