import { ChevronLeft } from '@mui/icons-material';
import { Box, CardMedia, Stack, useTheme } from '@mui/material';
import { useLocation, useNavigate } from 'react-router-dom';
import { useRootContext } from '../data/root.context';
import { useLoginContext } from '../login/data/login.context';
import { sections } from '../Sidebar/sidebar.responsive';

import MultiSelectDropDown from './multiselect.dropdown';

const DashboardResponsiveHeader = () => {
  const { setShowSidebar, setSelectedPagesSection } = useRootContext();
  const { userDetails: user } = useLoginContext();
  const theme = useTheme();
  const location = useLocation();
  const section = Object.values(sections).find((option) =>
    option.options.find((each) => each.path === location.pathname),
  );
  const subSection = section?.options.find((each) => each.path === location.pathname);
  return (
    <>
      <Box
        sx={{
          display: ['flex', 'flex', 'none'],
          bgcolor: 'primary.light',
          pl: 2,
          pr: 2,
          py: 1.5,
          justifyContent: 'space-between',
          alignItems: 'center',
          boxShadow: '0px 1px 4px #DEE2EE',
          position: 'fixed',
          width: '100%',
          zIndex: '300',
        }}
      >
        {subSection ? (
          <Box
            sx={{
              display: 'flex',
              gap: '1rem',
              textTransform: 'uppercase',
              color: 'text.primary',
              padding: theme.spacing(1, 0),
            }}
          >
            <ChevronLeft
              onClick={() => {
                setSelectedPagesSection(section);
                setShowSidebar(true);
              }}
            />
            {subSection?.label}
          </Box>
        ) : (
          <>
            <Stack
              direction="row"
              onClick={() => {
                setShowSidebar(true);
              }}
              spacing={2}
            >
              <img src="/images/mobile-menu.svg" alt="Menu" />
              <CardMedia
                component="img"
                src="/images/logo.png"
                alt="logo"
                sx={{ width: '50%' }}
              />
            </Stack>
            {user?.isHead && user?.familyData?.length ? <MultiSelectDropDown /> : null}
          </>
        )}
      </Box>
    </>
  );
};

export default DashboardResponsiveHeader;
