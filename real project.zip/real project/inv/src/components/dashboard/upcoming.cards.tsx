import { Divider, Grid, Stack, styled, Typography } from '@mui/material';
import CountUp from 'react-countup';

const UpcomingTransactionCards = styled(Stack)(({ theme }) => ({
  padding: theme.spacing(3, 6),
  backgroundColor: theme.palette.primary.light,
  borderRadius: 10,
  boxSizing: 'border-box',
  [theme.breakpoints.down('md')]: {
    padding: theme.spacing(2, 3),
  },
}));
const BlueText = styled(Typography)(({ theme }) => ({
  fontSize: 44,
  fontWeight: 700,
  color: theme.palette.text.spinnerText,
  letterSpacing: 2,
  lineHeight: '52px',
  [theme.breakpoints.down('md')]: {
    fontSize: 32,
  },
}));
const LabelText = styled(Typography)(({ theme }) => ({
  fontSize: 14,
  fontWeight: 600,
  color: theme.palette.text.secondary,
  textTransform: 'uppercase',
  letterSpacing: 2,
  lineHeight: '16px',
  [theme.breakpoints.down('md')]: {
    fontSize: 13,
  },
}));
const UpcomingCards = () => {
  return (
    <>
      <Grid container spacing={2}>
        <Grid item sm={12} md={6}>
          <Stack>
            <Typography
              sx={{
                fontSize: [14, 14, 22],
                fontWeight: 500,
                color: 'text.secondary',
                textTransform: 'uppercase',
                letterSpacing: '0.06em',
                mb: 3,
              }}
            >
              Upcoming Transactions
              <span
                style={{
                  fontSize: 12,
                  fontWeight: 400,
                  textTransform: 'capitalize',
                  paddingLeft: 4,
                }}
              >
                (In upcoming 30 days)
              </span>
            </Typography>
            <UpcomingTransactionCards>
              <Stack direction="row" alignItems="center" justifyContent="space-between">
                <Stack alignItems="center" sx={{ gap: [1, 1, 2] }}>
                  <img src="/images/sip.svg" alt="SIP" />
                  <CountUp start={0} end={130} delay={0} enableScrollSpy>
                    {({ countUpRef }) => (
                      <div>
                        <BlueText ref={countUpRef} />
                      </div>
                    )}
                  </CountUp>
                  <LabelText>SIP</LabelText>
                </Stack>
                <Divider orientation="vertical" flexItem />
                <Stack alignItems="center" sx={{ gap: [1, 1, 2] }}>
                  <img src="/images/swp.svg" alt="SWP" />
                  <CountUp start={0} end={120} delay={0} enableScrollSpy>
                    {({ countUpRef }) => (
                      <div>
                        <BlueText ref={countUpRef} />
                      </div>
                    )}
                  </CountUp>
                  <LabelText>SWP</LabelText>
                </Stack>
                <Divider orientation="vertical" flexItem />
                <Stack alignItems="center" sx={{ gap: [1, 1, 2] }}>
                  <img src="/images/stp.svg" alt="STP" />
                  <CountUp start={0} end={82} delay={0} enableScrollSpy>
                    {({ countUpRef }) => (
                      <div>
                        <BlueText ref={countUpRef} />
                      </div>
                    )}
                  </CountUp>
                  <LabelText>STP</LabelText>
                </Stack>
              </Stack>
            </UpcomingTransactionCards>
          </Stack>
        </Grid>
        <Grid item sm={12} md={6}>
          <Stack>
            <Typography
              sx={{
                fontSize: [14, 14, 22],
                fontWeight: 500,
                color: 'text.secondary',
                textTransform: 'uppercase',
                letterSpacing: '0.06em',
                mb: 3,
              }}
            >
              Upcoming MATURITIES
              <span
                style={{
                  fontSize: 12,
                  fontWeight: 400,
                  textTransform: 'capitalize',
                  paddingLeft: 4,
                }}
              >
                (In upcoming 30 days)
              </span>
            </Typography>
            <UpcomingTransactionCards>
              <Stack direction="row" alignItems="center" justifyContent="space-between">
                <Stack alignItems="center" sx={{ gap: [1, 1, 2] }}>
                  <img src="/images/sip.svg" alt="SIP" />
                  <CountUp start={0} end={121} delay={0} enableScrollSpy>
                    {({ countUpRef }) => (
                      <div>
                        <BlueText ref={countUpRef} />
                      </div>
                    )}
                  </CountUp>
                  <LabelText>SIP</LabelText>
                </Stack>
                <Divider orientation="vertical" flexItem />
                <Stack alignItems="center" sx={{ gap: [1, 1, 2] }}>
                  <img src="/images/fmp.svg" alt="FMP" />
                  <CountUp start={0} end={64} delay={0} enableScrollSpy>
                    {({ countUpRef }) => (
                      <div>
                        <BlueText ref={countUpRef} />
                      </div>
                    )}
                  </CountUp>
                  <LabelText>FMP</LabelText>
                </Stack>
                <Divider orientation="vertical" flexItem />
                <Stack alignItems="center" sx={{ gap: [1, 1, 2] }}>
                  <img src="/images/bonds.svg" alt="bonds" />
                  <CountUp start={0} end={32} delay={0} enableScrollSpy>
                    {({ countUpRef }) => (
                      <div>
                        <BlueText ref={countUpRef} />
                      </div>
                    )}
                  </CountUp>
                  <LabelText>BONDS</LabelText>
                </Stack>
              </Stack>
            </UpcomingTransactionCards>
          </Stack>
        </Grid>
      </Grid>
    </>
  );
};

export default UpcomingCards;
