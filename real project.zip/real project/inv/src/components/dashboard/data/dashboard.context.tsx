import { createContext, ReactElement, useContext, useEffect, useState } from 'react';

import { getPortfolioDetailsRequest } from '../../../api/dashboard';
import { useRootContext } from '../../data/root.context';
import { useLoginContext } from '../../login/data/login.context';

type DashboardState = {
  loading: boolean;
  details: {
    portfolio: PortfolioDetails[];
    investments: InvestmentDetails[];
  };
  setHeaderSelected: any;
  headerOption:any;
};

type PortfolioDetailValues = {
  inflowOutflowAmt: number;
  investedValue: number;
  currentValue: number;
  returns: number;
  weightedAvgDays: number;
  xirr: number;
};

type PortfolioDetails = PortfolioDetailValues & {
  asonDate: string;
  familyName: string;
};

type InvestmentDetails = {
  asonDate: string;
  assetClass: string;
  currentValue: number;
  familyName: string;
  holdPercent: number;
  investedValue: number;
  xirr: number;
};

const DashboardContext = createContext<DashboardState>({
  loading: false,
  details: { portfolio: [], investments: [] },
  setHeaderSelected:()=>{},
  headerOption :""
});

export const useDashboardContext = () => {
  return useContext(DashboardContext);
};

const initialPortfolio: PortfolioDetails = {
  investedValue: 0,
  currentValue: 0,
  inflowOutflowAmt: 0,
  asonDate: '',
  familyName: '',
  returns: 0,
  weightedAvgDays: 0,
  xirr: 0,
};

const initialInvestments: InvestmentDetails = {
  asonDate: '',
  assetClass: '',
  currentValue: 0,
  familyName: '',
  holdPercent: 0,
  investedValue: 0,
  xirr: 0,
};

export const DashboardContextProvider = ({ children }: { children: ReactElement }) => {
  const [apiResponse, setApiResponse] = useState<{
    familyPortFolio: PortfolioDetails[];
    individualPortFolio: PortfolioDetails[];
    familyInvestments: InvestmentDetails[];
    individualInvestments: InvestmentDetails[];
    portfolioDetails?: PortfolioDetails[];
    investmentDetails?: InvestmentDetails[];
  }>({
    individualPortFolio: [initialPortfolio],
    familyPortFolio: [initialPortfolio],
    individualInvestments: [initialInvestments],
    familyInvestments: [initialInvestments],
    portfolioDetails: [initialPortfolio],
    investmentDetails: [initialInvestments],
  });
  const [portfolioDetails, setPortfolioDetails] = useState<Array<PortfolioDetails>>([
    initialPortfolio,
  ]);
  const [headerSelected,setHeaderSelected]= useState({})
  const [investmentDetails, setInvestmentDetails] = useState<Array<InvestmentDetails>>(
    [],
  );
  const [loading, setLoading] = useState(false);
  const { selectedFamilyMembers, showToast } = useRootContext();
  const { userDetails: user } = useLoginContext();
  const portfolioKey = user?.isHead === true ? 'individualPortFolio' : 'portfolioDetails';

  useEffect(() => {
    getPortfolioDetails(headerSelected);
  }, [headerSelected]);
console.log("headerSelected",headerSelected)
  useEffect(() => {
    if (
      selectedFamilyMembers[0] === 'overall-family' &&
      user?.isHead === true &&
      user?.familyData?.length
    ) {
      setPortfolioDetails(apiResponse?.familyPortFolio);
      setInvestmentDetails(apiResponse?.familyInvestments);
    } else if (!user?.isHead || !user?.familyData?.length) {
      setPortfolioDetails(apiResponse?.portfolioDetails || []);
      setInvestmentDetails(apiResponse?.investmentDetails || []);
    } else {
      const selectedMembersPortfolio: Array<PortfolioDetails> = selectedFamilyMembers.map(
        (member) => {
          const memberName = user?.familyData?.find(
            (each) => each.clientId === member,
          )?.InvName.split(" ").join("");
          const result = apiResponse?.individualPortFolio.find(
            (portfolio: any) => portfolio?.invName.split(" ").join("") === memberName,
          );
          return result || initialPortfolio;
        },
      );
      let selectedMembersInvestments: Array<InvestmentDetails> = [];
      selectedFamilyMembers.forEach((member) => {
        const memberName = user?.familyData?.find(
          (each) => each.clientId === member,
        )?.InvName.split(" ").join("");
        const investments = apiResponse?.individualInvestments.filter(
          (investment: any) => investment?.invName.split(" ").join("") === memberName,
        );
        selectedMembersInvestments = [...selectedMembersInvestments, ...investments];
      });

      if (selectedMembersPortfolio.length > 1) {
        setPortfolioDetails([
          selectedMembersPortfolio.reduce((acc, curr) => {
            return (Object.keys(curr) as Array<keyof PortfolioDetailValues>).reduce<
              Partial<PortfolioDetails>
            >(
              (val, key) => {
                if (key === 'xirr' || key === 'weightedAvgDays') {
                  return {
                    ...val,
                    [key]: acc[key]
                      ? Math.round(((acc[key] + curr[key]) / 2) * 100) / 100
                      : curr[key],
                  };
                } else {
                  return {
                    ...val,
                    [key]: Math.round(((acc[key] || 0) + curr[key]) * 100) / 100,
                  };
                }
              },
              { ...curr },
            ) as PortfolioDetails;
          }),
        ]);
      } else {
        setPortfolioDetails(selectedMembersPortfolio);
      }
      setInvestmentDetails(selectedMembersInvestments);
    }
  }, [selectedFamilyMembers, apiResponse]);

  useEffect(() => {
    if (
      investmentDetails &&
      investmentDetails?.length > 1 &&
      investmentDetails.some(
        (obj, index) =>
          investmentDetails.findIndex((item) => item.assetClass === obj.assetClass) !==
          index,
      )
    ) {
      const result: InvestmentDetails[] = Object.values(
        investmentDetails.reduce<Record<string, InvestmentDetails>>((acc, cur) => {
          const key = cur.assetClass;
          if (!acc[key]) {
            acc[key] = { ...cur };
          } else {
            acc[key].investedValue =
              Math.round((acc[key].investedValue + cur.investedValue) * 100) / 100;
            acc[key].currentValue =
              Math.round((acc[key].currentValue + cur.currentValue) * 100) / 100;
            acc[key].xirr = acc[key].xirr
              ? Math.round(((acc[key].xirr + cur.xirr) / 2) * 100) / 100
              : cur.xirr;
            acc[key].holdPercent = (acc[key].holdPercent + cur.holdPercent) / 2;
          }
          return acc;
        }, {}),
      );
      setInvestmentDetails(result);
    }
  }, [investmentDetails]);

 const getPortfolioDetails = (body:any) => {
    // setLoading(true);
    return getPortfolioDetailsRequest(body)
      .then((res: any) => setApiResponse(res))
      .catch((e) => {
        showToast(`Error getting details: ${e?.message}`, 'error');
      })
      .finally(() => setLoading(false));
  };

  return (
    <DashboardContext.Provider
      value={{
        loading,
        details: { portfolio: portfolioDetails, investments: investmentDetails },
        setHeaderSelected : setHeaderSelected,
        headerOption : headerSelected
      }}
    >
      {children}
    </DashboardContext.Provider>
  );
};
