import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import { Menu, MenuProps, Stack, styled, Typography, useTheme } from '@mui/material';
import { Form, Formik, useFormikContext } from 'formik';
import { ReactElement, useState } from 'react';

import { useRootContext } from '../data/root.context';
import { useLoginContext } from '../login/data/login.context';
import NestedMultiSelect from './components/nested-multiselect';

const FamilyPortfolio = styled(Stack)(({ theme }) => ({
  backgroundColor: theme.palette.primary.light,
  boxShadow: theme.shadows[24],
  borderRadius: 40,
  padding: theme.spacing(1, 2),
  [theme.breakpoints.down('md')]: {
    backgroundColor: '#F2F4F8',
    boxShadow: 'none',
  },
}));
const HeaderText = styled(Typography)(({ theme }) => ({
  fontSize: 14,
  fontWeight: 400,
  textTransform: 'uppercase',
  letterSpacing: '0.01em',
  padding: theme.spacing(0.6, 2.5),
  cursor: 'pointer',
  display: 'flex',
  alignItems: 'center',
  gap: '1em',
  [theme.breakpoints.down('md')]: {
    whiteSpace: 'nowrap',
    padding: theme.spacing(0.6, 1.5),
  },
}));
const HeaderCaptionText = styled('span')(() => ({
  fontSize: 9,
  color: '#0393FE',
  textTransform: 'capitalize',
  fontWeight: '400',
  lineHeight: '11px',
  letterSpacing: '0.01em',
}));

const StyledMenu = ({
  children,
  onClose,
  ...rest
}: MenuProps & { children: ReactElement }) => {
  const theme = useTheme();
  const { submitForm } = useFormikContext();

  const handleClose = (e: any) => {
    submitForm();
    onClose && onClose(e, 'backdropClick');
  };

  return (
    <Menu
      {...rest}
      onClose={handleClose}
      sx={{
        marginTop: theme.spacing(2),
        '& .MuiMenu-list': {
          margin: theme.spacing(1, 6, 4, 1),
          padding: `${theme.spacing(2, 4)}`,
          [theme.breakpoints.down('md')]: {
            margin: theme.spacing(1),
            padding: `${theme.spacing(1)}`,
          },
        },
      }}
      PaperProps={{
        sx: {
          background: 'primary.light',
          boxShadow: '0px -1px 34px rgba(13, 13, 32, 0.33)',
          borderRadius: '10px',
          fontWeight: '400',
          fontSize: '14px',
          lineHeight: '16px',
          letterSpacing: '0.01em',
          textTransform: 'uppercase',
          color: 'text.primary',
        },
      }}
    >
      {children}
    </Menu>
  );
};

const MultiSelectDropDown = () => {
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const open = Boolean(anchorEl);
  const { familyData: transformedFamilyData, userDetails: user } = useLoginContext();
  const { selectedFamilyMembers, setSelectedFamilyMembers } = useRootContext();
  const handleClose = (event: Event) => {
    event.stopPropagation();
    setAnchorEl(null);
  };
  return (
    <Formik
      initialValues={{
        selectedType: selectedFamilyMembers,
      }}
      enableReinitialize
      onSubmit={({ selectedType }) => {
        setSelectedFamilyMembers(selectedType);
      }}
    >
      <FamilyPortfolio
      sx={{cursor:"pointer"}}
        direction="row"
        justifyContent="space-between"
        alignItems="center"
        onClick={(e) => setAnchorEl(e.currentTarget)}
      >
        <img src="/images/family-group.svg" alt="family group" />
        <HeaderText>
          Family Portfolio
          <HeaderCaptionText>
            {selectedFamilyMembers[0] !== 'overall-family' &&
              selectedFamilyMembers.map((member, index) => {
                const memberName = user?.familyData
                  ?.find((each) => each.clientId === member)
                  ?.InvName.split(' ')[0];
                if (index < 2) {
                  return (
                    memberName + (index < selectedFamilyMembers.length - 1 ? ', ' : '')
                  );
                } else if (index === 2) {
                  return `+ ${selectedFamilyMembers.length - 2}`;
                }
              })}
          </HeaderCaptionText>
        </HeaderText>

        <StyledMenu
          open={open}
          anchorEl={anchorEl}
          transformOrigin={{ horizontal: 'right', vertical: 'top' }}
          anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
          onClose={handleClose}
        >
          <Form>
            <NestedMultiSelect
              allPropertyValue="overall-family"
              allPropertyLabel="Overall Family"
              selectPropertyLabel="Select Family Member"
              name="selectedType"
              options={transformedFamilyData}
            />
          </Form>
        </StyledMenu>
        <ExpandMoreIcon />
      </FamilyPortfolio>
    </Formik>
  );
};

export default MultiSelectDropDown;
