import { Box, Stack, styled, Typography, useTheme, Modal, Tooltip, Badge } from '@mui/material';

// import { NavLink } from '../common';
import { useLoginContext } from '../login/data/login.context';
import MultiSelectDropDown from './multiselect.dropdown';
import ShoppingCartOutlinedIcon from '@mui/icons-material/ShoppingCartOutlined';
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router';
import { usePaymentContext } from '../payment/payment.context';
// import Cart from './cart';


const DashboardNavItem = styled(Typography)(({ theme }) => ({
  border: 'none',
  borderRadius: 50,
  fontSize: 16,
  fontWeight: 400,
  color: theme.palette.text.disabled,
  textTransform: 'uppercase',
  letterSpacing: '0.01em',
  padding: theme.spacing(1, 2),
  cursor: 'not-allowed',
 
  '&.active': {
    cursor: 'pointer',
    // border: '1px solid #0393FE',
    color: '#0293FE !important',
  },
  [theme.breakpoints.up('xs')]: {
    fontSize: 12,
    whiteSpace: 'nowrap',
  },
  [theme.breakpoints.up('sm')]: {
    fontSize: 14,
    whiteSpace: 'nowrap',
  }
}));
const DashboardHeader = ({headerOption,setHeaderOption}:{headerOption:any; setHeaderOption:any}) => {
  const { userDetails: user, cartItemCount, getCartCount } = useLoginContext();
  const [isActive, setIsActive] = useState(false);
  const navigate= useNavigate();
  const theme = useTheme();
  useEffect(() => {     
    const fetchCartCount = async () => {       
      const count = await getCartCount(); 
          };     
      fetchCartCount();   
    }, 
      [getCartCount])



  const handleClick=()=>{
    navigate("/cart",{state:{"value":"New","subValue":"lumpsum"}})
  }
  return (
    <>
      <Stack
        direction="row"
        justifyContent="space-between"
        alignItems="center"
        sx={{ mb: 2}}     
      >
        <Stack
          direction="row"
          spacing={2}
          sx={{
            [theme.breakpoints.down('md')]: {
              width: {xs:'35%',sm:'100%'},
              justifyContent: 'space-around'
            },
          }}
        >
          <Tooltip title="Go Home">
          <DashboardNavItem
          className='active'
            style={headerOption=="Bugle Rock"?{
              cursor: 'pointer',
              border: '1px solid #0393FE',
              color: '#0293FE !important',
            }:{}}
            onClick={() => {navigate('/dashboard',{state:{"headerOption":"Bugle Rock"}}),setHeaderOption("Bugle Rock")}}
          >
            {/* O3 Wealth */}
            Bugle Rock
          </DashboardNavItem>
          </Tooltip>
         <DashboardNavItem 
           className='active'
              style={headerOption=="Held Away"?{
                cursor: 'pointer',
                border: '1px solid #0393FE',
                color: '#0293FE !important',
              }:{}}
           onClick={()=>{navigate('/dashboard',{state:{"headerOption":"Held Away"}}),setHeaderOption("Held Away"),setIsActive(!isActive)}} >Held Away</DashboardNavItem>
           
        <DashboardNavItem
           className='active'
              style={headerOption=="Combined"?{
                cursor: 'pointer',
                border: '1px solid #0393FE',
                color: '#0293FE !important',
              }:{}}
                onClick={()=>{navigate('/dashboard',{state:{"headerOption":"Combined"}}),setHeaderOption("Combined")}} >Combined</DashboardNavItem>
                
        </Stack>
       
        <Box sx={{display:'flex', flexDirection:'row',alignItems:'flex-end'}}>
        {location.pathname==="/dashboard"? <Box sx={{ display: ['none', 'none', 'block'] }}>
          {user?.isHead && user?.familyData?.length ? <MultiSelectDropDown /> : null}
        </Box>
        : ''}
        <Tooltip title={'Cart'}>
        <Box sx={{ml:3}} >
        <Badge
      badgeContent={cartItemCount}
      color="error"
      overlap="circular"
      sx={{ marginRight: '10px', cursor: 'pointer' }}
    >
          <ShoppingCartOutlinedIcon sx={{color:'#34A9FE', fontSize:'40px', padding:'2px', bgcolor:'white' ,boxShadow:'0px 0px 20px #dfdfdf',borderRadius:'8px', cursor:'pointer'}}
          onClick={handleClick}/>
          </Badge>
        </Box>
        </Tooltip>
        </Box>
      </Stack>
    </>
  );
};

export default DashboardHeader;
