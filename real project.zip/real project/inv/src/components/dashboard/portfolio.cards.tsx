import { Box, Divider, Grid, Stack, styled, Typography } from '@mui/material';

import { formatCurrencyNumber, roundOff } from '../../lib/helper';
import { useRootContext } from '../data/root.context';
import { useLoginContext } from '../login/data/login.context';
import { useDashboardContext } from './data/dashboard.context';
import { useEffect, useState } from 'react';
import pic from '../../images/3d.png'

export const FadingDivider = styled(Divider)((props) => ({
  border: 'none',
  borderWidth: 0,
  height: props?.orientation === 'vertical' ? 'auto' : '1.5px !important',
  width: props?.orientation === 'vertical' ? '1.5px' : '100%',
  margin: props.orientation === 'vertical' ? '0 10px' : '10px 0',
  position: 'relative',
  background:
    props?.orientation === 'vertical'
      ? '-webkit-linear-gradient(bottom, rgba(200,200,200,0) 0%,rgba(200,200,200,0) 5%,rgba(200,200,200,0.3) 50%,rgba(200,200,200,0) 95%,rgba(200,200,200,0) 100%)'
      : '-webkit-linear-gradient(left, rgba(200,200,200,0) 0%,rgba(200,200,200,0) 5%,rgba(200,200,200,0.65) 50%,rgba(200,200,200,0) 95%,rgba(200,200,200,0) 100%)',
}));

const PortfolioValueCard = styled(Box)(({ theme }) => ({
  // padding: theme.spacing(5),
  background: 'linear-gradient(282.88deg, #59CDE9 4.07%, #0A2A88 78.45%)',
  border: '2px solid rgba(255, 255, 255, 0.6)',
  borderRadius: 20,
  boxSizing: 'border-box',
  // width: 668,
  minHeight: 275,
  position: 'relative',
  [theme.breakpoints.down('md')]: {
    boxShadow: '0px 4px 14px rgba(12, 28, 77, 0.2)',
  },
}));
const PortfolioValueLeftSectionContainer = styled(Grid)(({ theme }) => ({
  padding: theme.spacing(5, 0, 5, 5),
  [theme.breakpoints.between('md', 'lg')]: {
    padding: theme.spacing(3, 0, 3, 3),
  },
  [theme.breakpoints.down('md')]: {
    padding: theme.spacing(2.5, 0, 3, 4),
  },
}));
const PortfolioValueRightSectionContainer = styled(Grid)(({ theme }) => ({
  color: 'white',
  display: 'flex',
  flexDirection: 'column',
  gap: theme.spacing(3),
  padding: theme.spacing(5, 5, 5, 0),
  [theme.breakpoints.between('md', 'lg')]: {
    gap: theme.spacing(1),
  },
  [theme.breakpoints.down('md')]: {
    display: 'none',
  },
}));
const PortfolioMobileRightSectionContainer = styled(Grid)(({ theme }) => ({
  color: 'white',
  display: 'flex',
  flexDirection: 'column',
  gap: theme.spacing(3),
  padding: theme.spacing(3),
  [theme.breakpoints.up('md')]: {
    display: 'none',
  },
}));
const CardOverlay = styled(Box)(({ theme }) => ({
  position: 'absolute',
  top: '174px',
  bottom: 0,
  right: 0,
  left: 0,
  background:
    'linear-gradient(180deg, rgba(89, 205, 233, 0.13) 0%, rgba(89, 205, 233, 0) 100%)',
  borderBottomLeftRadius: 18,
  borderBottomRightRadius: 18,
  [theme.breakpoints.between('md', 'lg')]: {
    top: '144px',
  },
  [theme.breakpoints.down('md')]: {
    top: '110px',
  },
}));
const LabelHeadText = styled(Typography)(({ theme }) => ({
  fontSize: 13,
  letterSpacing: '0.01em',
  color: theme.palette.primary.light,
  [theme.breakpoints.down('lg')]: {
    fontSize: 10,
    whiteSpace: 'nowrap',
  },
}));

const LabelBodyText = styled(Typography)(({ theme }) => ({
  fontSize: 18,
  fontWeight: 500,
  color: theme.palette.primary.light,
  overflow: 'hidden',
  whiteSpace: 'nowrap',
  textOverflow: 'ellipsis',
  '&>div': {
    overflow: 'hidden',
  },
  [theme.breakpoints.between('md', 'lg')]: {
    fontSize: 14,
  },
  [theme.breakpoints.down('md')]: {
    fontSize: 16,
  },
}));

const PortfolioCard = ({headerOption}:{headerOption:any}) => {
  const { userDetails: user } = useLoginContext();
  const { selectedFamilyMembers } = useRootContext();
  const [showImage, setShowImage] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowImage(true);
    }, 1000);
    return () => clearTimeout(timer);
  }, [headerOption]);
  console.log("headerOption",headerOption)

  const isMobileBreakpoint = window.innerWidth < 900;
  const {
    details: { portfolio: data },
    // headerOption,
    setHeaderSelected
  } = useDashboardContext();
  const portfolio = data[0];
const header:any={
  "Bugle Rock": {"HFlag": "1"},
  "Held Away":{"HFlag": "2"},
  "Combined":{"HFlag": "3"},
}

 useEffect(()=>{
  setHeaderSelected(header[headerOption])
 },[headerOption])


  const hours = new Date().getHours();

  return (
    <>
      <Grid container spacing={2} alignItems="center" sx={{ my: {xs:0,sm:3} }}>
        <Grid item md={4} sx={{ display: ['none', 'none', 'block'] }}>
          <Typography
            sx={{
              fontSize: [16, 16, 20, 26],
              color: 'text.secondary',
            }}
          >
            {hours >= 0 && hours < 12
              ? 'Good Morning!'
              : hours === 12
              ? 'Good Noon!'
              : hours > 12 && hours <= 17
              ? 'Good Afternoon!'
              : 'Good Evening!'}
          </Typography>
          <Typography
            sx={{
              fontSize: [20, 20, 30, 40, 42],
              fontWeight: 500,
              whiteSpace: 'nowrap',
              overflow: 'hidden',
              textOverflow: 'ellipsis',
            }}
          >
            {selectedFamilyMembers[0] === 'overall-family' ? (
              user?.familyName
            ) : selectedFamilyMembers.length < 2 ? (
              user?.isHead && user?.familyData?.length ? (
                user?.familyData
                  ?.find((each) => each.clientId === selectedFamilyMembers[0])
                  ?.InvName.split(' ')[0]
              ) : (
                user?.name
              )
            ) : (
              <>{''}</>
            )}
          </Typography>
        </Grid>
        <Grid item xs={12} md={8} sx={{position:"relative"}}>
          <PortfolioValueCard>
            <Grid container>
              <PortfolioValueLeftSectionContainer item xs={12} md={7}>
                <Typography
                  sx={{
                    fontSize: [13, 13, 16, 22],
                    letterSpacing: '0.01em',
                    color: 'text.lightPrimary',
                  }}
                >
                  Portfolio Value
                </Typography>
                <Typography
                  sx={{
                    fontSize: [7, 7, 9, 10],
                    color: 'text.lightPrimary',
                  }}
                >
                  (as on{' '}
                  {new Date(portfolio?.asonDate || new Date()).toLocaleDateString(
                    'en-US',
                    {
                      day: 'numeric',
                      month: 'short',
                      year: 'numeric',
                    },
                  )}
                  )
                </Typography>
                <Typography
                  sx={{
                    fontSize: portfolio?.currentValue == null ?50:[26, 26, 26, 32, 52],
                    fontWeight: 600,
                    color: 'primary.light',
                    my: 2,
                  }}
                >
                  {formatCurrencyNumber(roundOff(portfolio?.currentValue == null ? "0" : portfolio?.currentValue))}
                </Typography>
                {showImage && portfolio?.currentValue==null && <img src={pic} style={{position:"absolute",top:30,right:80}}/>}
                {portfolio?.currentValue &&
                <Stack
                  direction="row"
                  spacing={4}
                  sx={{ pt: [0, 0, 2, 0], mt: [0, 0, 4] }}
                >
                  <Stack
                    sx={{
                      flexDirection: ['row', 'row', 'column'],
                      alignItems: ['center', 'center', 'unset'],
                      gap: [1.5, 1.5, 0.5, 0],
                    }}
                  >
                    <Typography
                      sx={{
                        fontSize: [10, 10, 13],
                        color: 'text.lightPrimary',
                      }}
                    >
                      Gain/Loss
                    </Typography>
                    <Typography
                      sx={{
                        fontSize: [12, 12, 14, 18],
                        fontWeight: 600,
                        color: 'primary.light',
                      }}
                    >
                      <span
                        style={{
                          color: portfolio?.returns?.toString()?.includes('-')
                            ? 'red'
                            : '#8ED8B7',
                          marginRight: 2,
                        }}
                      >
                        {portfolio?.returns?.toString()?.includes('-') ? '- ' : '+ '}
                      </span>
                      {portfolio?.returns?.toString()?.includes('-')
                        ? formatCurrencyNumber(
                            roundOff(portfolio?.returns)?.split('-')[1],
                          )
                        : formatCurrencyNumber(roundOff(portfolio?.returns == null ? "0":portfolio.returns)) || 'N/A'}
                    </Typography>
                  </Stack>
                  <Stack
                    sx={{
                      flexDirection: ['row', 'row', 'column'],
                      alignItems: ['center', 'center', 'unset'],
                      gap: [2, 2, 0.5, 0],
                    }}
                  >
                    <Typography
                      sx={{
                        fontSize: [10, 10, 13],
                        color: 'text.lightPrimary',
                      }}
                    >
                      XIRR
                    </Typography>
                    <Typography
                      sx={{
                        fontSize: [12, 12, 14, 18],
                        fontWeight: 600,
                        color:
                          portfolio?.xirr > 0 && !(selectedFamilyMembers.length > 1)
                            ? 'text.profileGreen'
                            : 'white',
                      }}
                    >
                      {portfolio?.xirr && !(selectedFamilyMembers.length > 1) ? (
                        <>
                          <span
                            style={{
                              color: portfolio?.xirr?.toString()?.includes('-')
                                ? 'red'
                                : '#8ED8B7',
                              marginRight: 2,
                            }}
                          >
                            {portfolio?.xirr?.toString()?.includes('-') ? '- ' : '+ '}
                          </span>
                          {portfolio?.xirr?.toString()?.includes('-')
                            ? portfolio?.xirr.toString()?.split('-')[1] + '%'
                            : portfolio?.xirr + '%' || '0'}
                        </>
                      ) : (
                        '0'
                      )}
                    </Typography>
                  </Stack>
                </Stack>}
              </PortfolioValueLeftSectionContainer>
              <Grid
                item
                xs={12}
                md={1}
                sx={{ height: 'auto', display: 'flex', justifyContent: 'center' }}
                >
                <FadingDivider
                  orientation={isMobileBreakpoint ? 'horizontal' : 'vertical'}
                  flexItem
                  sx={{ height: '100%' }}
                  />
              </Grid>
                  
              <PortfolioValueRightSectionContainer item xs={12} md={4}>
              {portfolio?.currentValue &&
              <>
                <Stack direction="row" alignItems="center" spacing={2}>
                  <img src="/images/invested-value.svg" alt="Invested value" />
                  <Stack>
                    <LabelHeadText>Invested Value</LabelHeadText>
                    <LabelBodyText>
                      {formatCurrencyNumber(roundOff(portfolio?.returns == null ? '0':portfolio.returns))}
                    </LabelBodyText>
                  </Stack>
                </Stack>
                <Stack direction="row" alignItems="center" spacing={2}>
                  <img src="/images/inflow-outflow.svg" alt="Invested value" />
                  <Stack>
                    <LabelHeadText>Inflow - Outflow</LabelHeadText>
                    <LabelBodyText>
                      {formatCurrencyNumber(roundOff(portfolio?.inflowOutflowAmt == 0 ? "0":portfolio.inflowOutflowAmt))}
                    </LabelBodyText>
                  </Stack>
                </Stack>
                <Stack direction="row" alignItems="center" spacing={2}>
                  <img src="/images/avg-days.svg" alt="Invested value" />
                  <Stack>
                    <LabelHeadText>Weighted Avg Days</LabelHeadText>
                    <LabelBodyText>{portfolio?.weightedAvgDays == null ? "0":portfolio?.weightedAvgDays}</LabelBodyText>
                  </Stack>
                </Stack>
                </>
                }
              </PortfolioValueRightSectionContainer>
              <PortfolioMobileRightSectionContainer item xs={12}>
                <Grid container gap={1}>
                  <Grid
                    item
                    xs={5.8}
                    sx={{
                      bgcolor: 'rgba(255, 255, 255, 0.16)',
                      borderRadius: 2,
                      overflow: 'hidden',
                      zIndex: '0',
                      boxSizing: 'border-box',
                    }}
                  >
                    <Box
                      sx={{
                        width: '100%',
                        height: '100%',
                        padding: '1px',
                        position: 'relative',
                        zIndex: -2,
                        background:
                          'linear-gradient(304.19deg, rgba(255, 255, 255, 0.07) 20.89%, #0A8AF2 70.64%, rgba(255, 255, 255, 0) 101.84%)',
                      }}
                    >
                      <Box sx={{ p: 2 }}>
                        <Stack direction="row" alignItems="center" spacing={1}>
                          <img
                            src="/images/invested-value-mob.svg"
                            alt="Invested value"
                          />
                          <LabelHeadText>Invested Value</LabelHeadText>
                        </Stack>
                        <LabelBodyText>
                          {roundOff(portfolio?.investedValue)}
                        </LabelBodyText>
                      </Box>
                      <Box
                        sx={{
                          zIndex: -1,
                          position: 'absolute',
                          top: '1px',
                          left: '1px',
                          bottom: '1px',
                          right: '1px',
                          opacity: 1,
                          borderRadius: '8px',
                          overflow: 'hidden',
                          background:
                            'linear-gradient(282.88deg, #2e74b5 4.07%, #0f358f 78.45%)',
                        }}
                      >
                        <Box
                          sx={{
                            width: '100%',
                            height: '100%',
                            backgroundColor: 'rgba(255,255,255,0.16)',
                          }}
                        ></Box>
                      </Box>
                    </Box>
                  </Grid>
                  <Grid
                    item
                    xs={5.8}
                    sx={{
                      bgcolor: 'rgba(255, 255, 255, 0.16)',
                      borderRadius: 2,
                      boxSizing: 'border-box',
                      overflow: 'hidden',
                      zIndex: '0',
                    }}
                  >
                    <Box
                      sx={{
                        width: '100%',
                        height: '100%',
                        padding: '1px',
                        position: 'relative',
                        zIndex: -2,
                        background:
                          'linear-gradient(269.83deg, rgba(255, 255, 255, 0.07) -6.08%, #26E1F1 43.66%, rgba(255, 255, 255, 0) 106.61%)',
                      }}
                    >
                      <Box sx={{ p: 2 }}>
                        <Stack direction="row" alignItems="center" spacing={1}>
                          <img
                            src="/images/inflow-outflow-mob.svg"
                            alt="Invested value"
                          />
                          <LabelHeadText>Invested Value</LabelHeadText>
                        </Stack>
                        <LabelBodyText>
                          {roundOff(portfolio?.investedValue)}
                        </LabelBodyText>
                      </Box>
                      <Box
                        sx={{
                          zIndex: -1,
                          position: 'absolute',
                          top: '1px',
                          left: '1px',
                          bottom: '1px',
                          right: '1px',
                          opacity: 1,
                          borderRadius: '8px',
                          overflow: 'hidden',
                          background:
                            'linear-gradient(282.88deg, #56c7e5 4.07%, #2d71b3 78.45%)',
                        }}
                      >
                        <Box
                          sx={{
                            width: '100%',
                            height: '100%',
                            backgroundColor: 'rgba(255,255,255,0.16)',
                          }}
                        ></Box>
                      </Box>
                    </Box>
                  </Grid>
                </Grid>
                <Box
                  sx={{
                    bgcolor: 'rgba(255, 255, 255, 0.16)',
                    borderRadius: 10,
                    overflow: 'hidden',
                    zIndex: '0',
                    boxSizing: 'border-box',
                  }}
                >
                  <Box
                    sx={{
                      width: '100%',
                      height: '100%',
                      padding: '1px',
                      position: 'relative',
                      zIndex: -2,
                      background:
                        'linear-gradient(304.19deg, rgba(255, 255, 255, 0.07) 20.89%, #C68CFE 70.64%, rgba(255, 255, 255, 0) 101.84%)',
                    }}
                  >
                    <Box sx={{ p: 0 }}>
                      <Stack
                        direction="row"
                        alignItems="center"
                        justifyContent="center"
                        spacing={1}
                        sx={{
                          bgcolor: 'rgba(255, 255, 255, 0.16)',
                          borderRadius: 10,
                          px: 2,
                          py: 1,
                        }}
                      >
                        <img src="/images/avg-days-mob.svg" alt="Invested value" />
                        <LabelHeadText>Weighted Avg Days</LabelHeadText>
                        <LabelBodyText>{portfolio?.weightedAvgDays}</LabelBodyText>
                      </Stack>
                    </Box>
                    <Box
                      sx={{
                        zIndex: -1,
                        position: 'absolute',
                        top: '1px',
                        left: '1px',
                        bottom: '1px',
                        right: '1px',
                        opacity: 1,
                        borderRadius: 10,
                        overflow: 'hidden',
                        background:
                          'linear-gradient(282.88deg, #56c6e5 4.07%, #0d2f8b 78.45%)',
                      }}
                    >
                      <Box
                        sx={{
                          width: '100%',
                          height: '100%',
                          backgroundColor: 'rgba(255,255,255,0.16)',
                        }}
                      ></Box>
                    </Box>
                  </Box>
                </Box>
              </PortfolioMobileRightSectionContainer>
            </Grid>
            <CardOverlay></CardOverlay>
          </PortfolioValueCard>
        </Grid>
      </Grid>
    </>
  );
};

export default PortfolioCard;
