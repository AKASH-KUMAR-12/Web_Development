import { Box, LinearProgress, styled } from '@mui/material';

import DashboardHeader from './dashboard.header';
import DashboardResponsiveHeader from './dashboard.responsive.header';
import { useDashboardContext } from './data/dashboard.context';
import InvestmentsCards from './investments.cards';
import PortfolioCard from './portfolio.cards';
import UpcomingCards from './upcoming.cards';
import { useEffect, useState } from 'react';
import { useLocation } from 'react-router';

const MainLayout = styled(Box)(({ theme }) => ({
  width: '90%',
  margin: 'auto',
  boxSizing: 'border-box',
  padding: theme.spacing(4, 1),
  [theme.breakpoints.down('md')]: {
    width: '100%',
    margin: 'unset',
  },
}));


const Dashboard = () => {
  const location = useLocation();
  const [headerSelected,setHeaderSelected]=useState<String>(location?.state?.headerOption);
  const { loading } = useDashboardContext();
  if (loading) {
    return <LinearProgress />;
  }

  return (
    <>
      <MainLayout>
        <DashboardHeader 
        headerOption={headerSelected} 
        setHeaderOption={setHeaderSelected} 
        />
        <PortfolioCard headerOption={headerSelected}/>
        <InvestmentsCards/>
        {/* <UpcomingCards /> */}
      </MainLayout>
    </>
  );
};

export default Dashboard;
