import { SvgIcon, SvgIconProps } from '@mui/material';
import React from 'react';

const BgCircle = ({ fillPath, ...props }: SvgIconProps & { fillPath?: string }) => {
  return (
    <SvgIcon
      {...props}
      className="bg-circle-small"
      width="96"
      height="108"
      viewBox="0 0 96 108"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      {/* <mask
        id="mask0_2728_3056"
        style={{ maskType: 'alpha' }}
        maskUnits="userSpaceOnUse"
        x="0"
        y="0"
        width="96"
        height="108"
      >
        <rect width="96" height="108" rx="10" fill="#D9D9D9" />
      </mask>
      <g mask="url(#mask0_2728_3056)">
        <path
          d="M92.7032 48.6006C89.6646 13.4763 58.7249 -12.5366 23.6006 -9.49802C-11.5238 -6.45947 -37.5366 24.4803 -34.4981 59.6046C-31.4595 94.7289 -0.519791 120.742 34.6045 117.703C69.7288 114.665 95.7417 83.7249 92.7032 48.6006ZM-11.1546 57.5852C-12.0782 46.9083 -8.72263 36.3019 -1.82607 28.0991C5.07049 19.8963 14.9431 14.7691 25.62 13.8455C36.2968 12.9219 46.9033 16.2774 55.106 23.174C63.3088 30.0705 68.436 39.9432 69.3596 50.62C70.2833 61.2969 66.9277 71.9034 60.0312 80.1061C53.1346 88.3089 43.262 93.4361 32.5851 94.3597C21.9083 95.2833 11.3018 91.9278 3.09903 85.0312C-5.10374 78.1347 -10.2309 68.262 -11.1546 57.5852Z"
          fill={fillPath ? fillPath : 'url(#bg_circle_linear_gradient_blue)'}
          fillOpacity="0.06"
        />
      </g> */}
      <path
        xmlns="http://www.w3.org/2000/svg"
        d="M92.7032 48.6006C89.6646 13.4763 58.7249 -12.5366 23.6006 -9.49802C-11.5238 -6.45947 -37.5366 24.4803 -34.4981 59.6046C-31.4595 94.7289 -0.519793 120.742 34.6045 117.703C69.7288 114.665 95.7417 83.7249 92.7032 48.6006ZM-11.1546 57.5852C-12.0782 46.9083 -8.72263 36.3019 -1.82607 28.0991C5.07049 19.8963 14.9431 14.7691 25.62 13.8455C36.2968 12.9219 46.9033 16.2774 55.106 23.174C63.3088 30.0705 68.436 39.9432 69.3596 50.62C70.2833 61.2969 66.9277 71.9034 60.0312 80.1061C53.1346 88.3089 43.262 93.4361 32.5851 94.3597C21.9083 95.2833 11.3018 91.9278 3.09903 85.0312C-5.10375 78.1347 -10.2309 68.262 -11.1546 57.5852Z"
        fill={fillPath ? fillPath : 'url(#bg_circle_linear_gradient_blue)'}
        fillOpacity="0.06"
      />
      <defs>
        <linearGradient
          id="bg_circle_linear_gradient_blue"
          x1="101.5"
          y1="43"
          x2="91.4999"
          y2="-46.5"
          gradientUnits="userSpaceOnUse"
        >
          <stop stopColor="#3597E1" />
          <stop offset="0.421136" stopColor="#3597E1" stopOpacity="0" />
          <stop offset="1" stopColor="white" stopOpacity="0" />
        </linearGradient>
        <linearGradient
          xmlns="http://www.w3.org/2000/svg"
          id="bg_circle_linear_gradient_purple"
          x1="101.5"
          y1="43"
          x2="91.4999"
          y2="-46.5"
          gradientUnits="userSpaceOnUse"
        >
          <stop stopColor="#996AC6" />
          <stop offset="0.421136" stopColor="#996AC6" stopOpacity="0" />
          <stop offset="1" stopColor="white" stopOpacity="0" />
        </linearGradient>
        <linearGradient
          xmlns="http://www.w3.org/2000/svg"
          id="bg_circle_linear_gradient_turquoise"
          x1="101.5"
          y1="43"
          x2="91.4999"
          y2="-46.5"
          gradientUnits="userSpaceOnUse"
        >
          <stop stopColor="#32BCD8" />
          <stop offset="0.421136" stopColor="#3597E1" stopOpacity="0" />
          <stop offset="1" stopColor="white" stopOpacity="0" />
        </linearGradient>
        <linearGradient
          xmlns="http://www.w3.org/2000/svg"
          id="bg_circle_linear_gradient_black"
          x1="101.5"
          y1="43"
          x2="91.4999"
          y2="-46.5"
          gradientUnits="userSpaceOnUse"
        >
          <stop stopColor="#3F556D" />
          <stop offset="0.421136" stopColor="#3F556D" stopOpacity="0" />
          <stop offset="1" stopColor="white" stopOpacity="0" />
        </linearGradient>
      </defs>
    </SvgIcon>
  );
};

export default BgCircle;
