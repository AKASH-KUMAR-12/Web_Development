export const tabMap = [
  {
    label: "New Purchase",
    value: "New",
    trType: "New",
    trType2: "ISIP"
  },
  {
    label: "Additional Purchase",
    value: "Add",
    trType: "Add",
    trType2: "XSIP",
  },
  {
    label: "STP",
    value: "STP",
    trType: "STP",
    trType2: "STP"
  },
  {
    label: "SWP",
    value: "SWP",
    trType: "SWP",
    trType2: "SWP"
  },
  {
    label: "Switch",
    value: "Swt",
    trType: "Swt",
    trType2: "Swt"
  },
  {
    label: "Redemption",
    value: "Red",
    trType: "Red",
    trType2: "Red"
  }
]

export const recommendationStatusMap = [
  'Active',
  'Expired',
  'In Cart',
  'Order Placed', 
  'Order Confirmation Failed',
  'Payment Successfull'
]