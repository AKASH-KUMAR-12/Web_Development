import { Box, Button, Divider, Switch, Tooltip, Typography, Zoom } from "@mui/material";
import Checkbox from '@mui/material/Checkbox';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import "./styles.css";
import { formatToIndianCurrency } from "../utils/utilityFunctions";
import { CloseIcon, DeleteIcon, InvestNowIcon } from "../customSVGs";
import { useState, useEffect } from "react";
import { RecommendationsType, SchemeList } from "./transaction.context";
import Highcharts from 'highcharts';
import { HighchartsReact } from 'highcharts-react-official';
import { AddToCartDrawer } from "./add.to.cart.drawer";
import { withStyles } from "@material-ui/core/styles";
import { _request } from "../../api/requests";


export function SubFundCategoryCard(
  { onSchemeSelection, schemeDetail, OnSchemeDeSelection, handleSetViewSchemeDetails, allocation, selectedSchemes, openModal }:
    {
      onSchemeSelection: (schemeId: number) => void;
      schemeDetail: SchemeList;
      OnSchemeDeSelection: (schemeId: number) => void;
      handleSetViewSchemeDetails: (val: boolean, schemeDetail: SchemeList) => void;
      allocation: boolean;
      selectedSchemes: SchemeList[];
      openModal: boolean;
    }
) {
  type schemeParams = {
    SchemeID: number;
    SchemeName: string;
    Aum: string;
    Sch_Return5Yr: number;
    switchValue: string;
    invAmount: number;
    error: boolean;
    errorMessage: string;
    AssetClassName: string;
    Sub_AssetclassName: string;
    Dividendfrequency: string;
    Growthoption: number;
    Dividendreinvestment: number;
    DividendPayout: number;
    instalments: number;
    SIPDay: string;
    mandate: string;
    frequency: string;
  }
  const [schemeSelected, setSchemeSelected] = useState<boolean>(false);

  const [schemeParams, setSchemeParams] = useState<schemeParams[]>();
  useEffect(() => {
    const schemeParams: any = [];
    selectedSchemes?.map((item) => {
      const swtVal = {
        SchemeID: item.SchemeID,
        SchemeName: item.SchemeName,
        Aum: item.Aum,
        Sch_Return5Yr: item.Sch_Return5Yr,
        switchValue: "Lumpsum",
        invAmount: null,
        error: false,
        errorMessage: "",
        AssetClassName: item.AssetClassName,
        Sub_AssetclassName: item.Sub_AssetclassName,
        Dividendfrequency: item.Dividendfrequency,
        Growthoption: item.Growthoption,
        Dividendreinvestment: item.Dividendreinvestment,
        DividendPayout: item.DividendPayout,
        instalments: null,
        SIPDay: "",
        mandate: "",
        frequency: ""
      }
      schemeParams.push(swtVal);
    })
    setSchemeParams(schemeParams);
  }, [])

  // const OnSchemeDeSelection_ = (scId: number) => {
  //   const schemeList = schemeParams?.filter((val) => val.SchemeID != scId);
  //   setSchemeParams(schemeList);
  //   OnSchemeDeSelection(scId);
  // }
  const handleSubmit = () => {
    invAmountValidation();
  }

  const invAmountValidation = () => {
    const updatedData = schemeParams ? [...schemeParams] : [];
    updatedData?.map((item) => {
      if (item.invAmount == null) {
        item.error = true;
        item.errorMessage = "Amount Can not be empty";
      }
      else if (item.invAmount && item.invAmount < 1000) {
        item.error = true;
        item.errorMessage = "Enter Amount more than 1000";
        // setError(true);
        // setErrorMessage("Enter Amount more the 1000");
      }
      else {
        item.error = false;
      }
    })
    setSchemeParams(updatedData);
  }

  const handleSchemeCheckboxChange = (e: any) => {
    if (e.target.checked == true) {
      onSchemeSelection(schemeDetail.SchemeID);
      setSchemeSelected(true);
    }
    else {
      OnSchemeDeSelection(schemeDetail.SchemeID);
      setSchemeSelected(false);
    }
  }
  const handleAddToCartAnchorsEl = async () => {
    try {
      setAddToCartAnchorsEl(true);
      // setDistributorLoading(false);
    } catch (e) {
      console.error((e as Error).message);
      // setDistributorLoading(false);
    }
  };
  const [addToCartAnchorsEl, setAddToCartAnchorsEl] = useState<boolean>(false);
  
  const handleAddToCartAnchorsElClose = () => {
    setAddToCartAnchorsEl(false);
  };
  useEffect(() => {
    if (!selectedSchemes.includes(schemeDetail)) {
      setSchemeSelected(false);
    }
  }, [openModal])
  const plan =
    schemeDetail.Growthoption === 1
      ? "Growth"
      : schemeDetail.Dividendreinvestment === 1
        ? "Div"
        : schemeDetail.DividendPayout === 1
          ? "Div"
          : "";
  const subPlan =
    schemeDetail.Dividendreinvestment === 1
      ? "Reinvestment"
      : schemeDetail.DividendPayout === 1
        ? "Payout"
        : "";

  const categoryValue = schemeDetail.Cat_Return5yr;
  const selectedValue = schemeDetail.Sch_Return5Yr;

  function roundToTwo(num: number) {
    const num2 = num + "e+2";

    return +(Math.round(Number(num2)) + "e-2");
  }

  const Nanprocessor = function (entry: any) {
    if (entry) {
      return entry;
    } else {
      return 0;
    }
  };
  const InvestNowTooltip = withStyles({
    tooltip: {
      color: "grey",
      fontSize: '13px',
      backgroundColor: "#ffffff",
      height: '20px',
    paddingBottom:'1.5rem',
      border: '0.5px solid grey',
      borderRadius: '8px',
    }
  })(Tooltip);
  return (
    <div>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', cursor: 'pointer', my: 2.5,flexDirection:{xs:"column",sm:"row"} }}>
        {/* <Box sx={{ width: '10%' }}> }}>
        {/* <Box sx={{ width: '10%' }}>
          <Checkbox sx={{ color: '#337FC9', mx: 1.5 }} onChange={handleSchemeCheckboxChange} checked={schemeSelected} />
        </Box> */}
        <Box sx={{ marginRight: {xs:0,sm:3}, ml:{xs:0,sm:"1.5rem"},display: 'flex', flexDirection: 'column', width: {xs:"100%",sm:"65%"} }}>
          <Typography sx={{ fontSize: 14, fontWeight: 500, mb: 0.5 }}>
            {schemeDetail.SchemeName}
          </Typography>
          <Box sx={{ display: 'flex', width: "100%", flexWrap: "wrap",mt:{xs:0,sm:1}}}>
            {!!schemeDetail.AssetClassName && (
              <Bubble text={schemeDetail.AssetClassName} />
            )}
            {!!schemeDetail.Sub_AssetclassName && (
              <Bubble text={schemeDetail.Sub_AssetclassName} />
            )}
            {!!plan && <Bubble text={plan} />}
            {subPlan.length !== 0 && <Bubble text={subPlan} />}
            {!!subPlan && !!schemeDetail.Dividendfrequency && (
              <Bubble text={schemeDetail.Dividendfrequency} />
            )}
          </Box>
        </Box>
        <Box sx={{display:"flex", alignItems: {xs:'flex-start',sm:"center"}, cursor: 'pointer',width:"100%",mt:{xs:"0.5rem",sm:"0rem"},mr:{xs:"1rem",sm:0}}}>
        <Box sx={{ display:"flex",flexDirection:"column",alignItems:"center",width: {xs:"30%",sm:"20%"},pt:{xs:"0.2rem",sm:0}}}>
          <Typography sx={{ fontSize: {xs:11,sm:12.5}, color: '#5a7c82' }}>AUM</Typography>
          <Typography sx={{ fontSize: {xs:11,sm:12.5},mt:1 }}>
            {schemeDetail.Aum === "0" || !schemeDetail.Aum
              ? "NA"
              : formatToIndianCurrency(schemeDetail.Aum, 1)}
          </Typography>
        </Box>

        <Box sx={{ width: {xs:"50%",sm:"35%"}, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
          <Typography sx={{ fontSize: {xs:11,sm:12.5}, color: '#5a7c82' }}>
            {!allocation ? "Category Avg Returns" : "Allocation"}
          </Typography>
          <Typography sx={{ fontSize: {xs:11,sm:12.5}, color: "rgb(30, 163, 98)",mt:1 }}>
            {" "}
            {`${Nanprocessor(roundToTwo(Number(categoryValue)))}%`}
          </Typography>
        </Box>

        <Box sx={{ width: {xs:"25%",sm:"23%"}, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
          <Typography sx={{ fontSize: {xs:11,sm:12.5}, color: '#5a7c82' }}>Returns</Typography>
          <Typography sx={{ fontSize: {xs:11,sm:12.5}, color: "rgb(30, 163, 98)",mt:1 }}>
            {selectedValue === "0" || !selectedValue
              ? "NA"
              : `${Nanprocessor(roundToTwo(Number(selectedValue)))}%`}
          </Typography>
        </Box>
        <InvestNowTooltip title='Add to Cart'  TransitionComponent={Zoom}
  TransitionProps={{ timeout: 200 }}>        
   <Box sx={{ width: '10%',  }} onClick={handleAddToCartAnchorsEl} >
          <InvestNowIcon  />
       
        </Box>
        </InvestNowTooltip>
        {' '}
        {addToCartAnchorsEl && (
          <AddToCartDrawer
          
            anchorEl={addToCartAnchorsEl}
            handleClose={handleAddToCartAnchorsElClose}
            schemeName={schemeDetail?.SchemeName}
            recommendedSchemeData={schemeDetail}
            AmcID={schemeDetail?.AmcID}
          />
        )}
        <Box sx={{ width: '8%' }}>
          <ArrowForwardIosIcon onClick={() => { handleSetViewSchemeDetails(true, schemeDetail); }} sx={{ fontSize: 28, borderRadius: 1, backgroundColor: '#163869', color: '#ffffff', p: 0.2, mx: 1.5 }} />
        </Box>
      </Box>
      </Box>
    </div>
  )
}

export function Bubble(props: { text: string }) {
  return (
    <div className="bubbleDiv">
      <div className="bubbleText">
        {props.text}
      </div>
    </div>
  );
}

function roundToTwo(num: number) {
  const num2 = num + "e+2";

  return +(Math.round(Number(num2)) + "e-2");
}

const Nanprocessor = function (entry: any) {
  if (entry) {
    return entry;
  } else {
    return 0;
  }
};

export function RecommendedSchemesModal({ handleModalClose, selectedSchemes, OnSchemeDeSelection }:
  { handleModalClose: () => void; selectedSchemes: SchemeList[] | undefined; OnSchemeDeSelection: (schemeId: number) => void; }) {
  return (
    <Box>
      <Box sx={{ mb: 3, px: 3, display: 'flex', justifyContent: 'space-between' }}>
        <Typography sx={{ fontSize: 16, fontWeight: 500 }}>
          Recommended Schemes
        </Typography>
        <Box onClick={handleModalClose} sx={{ cursor: 'pointer' }}>
          <CloseIcon />
        </Box>
      </Box>
      <Divider />
      {
        selectedSchemes?.map((val, index) => {
          return (
            <Box sx={{ px: 2, mb: 6 }} key={index}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', cursor: 'pointer', my: 2.5 }}>
                <Box sx={{ marginRight: 15, display: 'flex', flexDirection: 'column', width: "23%" }}>
                  <Typography sx={{ fontSize: 14, fontWeight: 500, mb: 0.5 }}>
                    {val.SchemeName}
                  </Typography>
                  <Box sx={{ display: 'flex', width: "100%", flexWrap: "wrap"}}>
                    {/* {!!fundItem.AssetClassName && ( */}
                    <Bubble text={"Equity"} />
                    {/* )} */}
                    {/* {!!fundItem.Sub_AssetclassName && ( */}
                    <Bubble text={"Large-Cap"} />
                    {/* )} */}
                    {/* {!!plan && <Bubble text={plan} />}
          {subPlan.length !== 0 && <Bubble text={subPlan} />}
          {!!subPlan&&!!fundItem.Dividendfrequency && ( */}
                    <Bubble text={"Growth"} />
                    {/* )} */}
                  </Box>
                </Box>
                <Box sx={{ width: "16%", display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                  <Typography sx={{ fontSize: 14, color: '#5a7c82' }}>Returns</Typography>
                  <Typography sx={{ fontSize: 16, color: "rgb(30, 163, 98)" }}>
                    {val.Aum === "0" || !val.Aum
                      ? "NA"
                      : `${Nanprocessor(roundToTwo(Number(val.Sch_Return5Yr)))}%`}
                  </Typography>
                </Box>
                <Box sx={{ width: "21%", display: 'flex', flexDirection: 'column', alignItems: "center" }}>
                  <Typography sx={{ fontSize: 14, color: '#5a7c82', mb: 0.5 }}>Investment Amount</Typography>
                  <input className='investmentAmount' placeholder="Enter Amount">
                  </input>
                </Box>
                <Box sx={{ width: "23%", display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <Typography
                    sx={{
                      color: '#22242C',
                      opacity: 0.8,
                      fontSize: 14,
                    }}>
                    SIP
                  </Typography>
                  <Switch
                    // checked={selectedAssetsType === 'assetClass'}
                    // onChange={(_, checked) =>
                    //   setSelectedAssetsType(checked ? 'assetClass' : 'product')
                    // }
                    sx={{
                      p: 0,
                      mx: 2,
                      height: 20,
                      width: 48,
                      '& .MuiSwitch-track': {
                        background: '#4990F0',
                        opacity: 1,
                        borderRadius: '12px',
                      },
                      '& .MuiSwitch-thumb': { border: '1px solid #E1D8D8' },
                      '& .MuiSwitch-switchBase': {
                        p: 0,
                        '&.Mui-checked': {
                          color: '#fff',
                          transform: 'translateX(32px)',
                          '& + .MuiSwitch-track': {
                            backgroundColor: '#4990F0',
                            opacity: 1,
                          },
                        },
                      },
                    }}
                  />
                  <Typography
                    sx={{
                      color: '#22242C',
                      opacity: 0.8,
                      fontSize: 14
                    }}>
                    Lumpsum
                  </Typography>
                </Box>
                <Box sx={{ width: "7%" }}>
                  <div onClick={() => { OnSchemeDeSelection(val.SchemeID); }}><DeleteIcon /></div>
                </Box>
              </Box>
            </Box>
          )
        })
      }
      <Box sx={{ width: '100%', display: 'flex', justifyContent: 'center', mt: 4 }}>
        <Button
          sx={{
            height: '40px',
            color: 'white',
            fontSize: '16px',
            fontWeight: 400,
            cursor: 'pointer',
            borderRadius: '5px',
            bgcolor: '#337FC9',
            width: '50%',
            '&:hover': { backgroundColor: '#337FC9' },
          }}
        >Recommend</Button>
      </Box>
    </Box>
  )
}

export function PerformaneAnalysisChart(
  { yearSelected, graphArray, categoryAverageArray }:
    {
      yearSelected: any;
      graphArray: any;
      categoryAverageArray: any;
    }
) {

  const [portfolioPerformanceGraphOption, setPortfolioPerformanceGraphOption] = useState<any>({
    chart: {
      type: "line",
      zoomType: "x",
      resetZoomButton: {
        theme: {
          display: "none",
        },
      },

      height: 200,
    },
    title: {
      text: "",
    },
    legend: {
      enabled: false,
    },
    xAxis: {
      type: "datetime",
      tickInterval: 24 * 60 * 60 * 1000 * 30 * 6,

      dateTimeLabelFormats: {
        day: "%b '%y",
      },
    },

    visible: false,

    series: [
      {
        type: "area",
        data: [],
      },
    ],
  });

  useEffect(() => {
    getInitialValue(graphArray, categoryAverageArray, yearSelected);
  }, [graphArray, yearSelected, categoryAverageArray])

  function getInitialValue(arrResult: any, cvgArr: any, year: any) {
    if (arrResult && arrResult.length > 0) {
      let maxDate: Date | number = new Date();
      maxDate = maxDate.setFullYear(maxDate.getFullYear());
      let minDate: Date | number = new Date();
      let _lableCount = 3;
      let _valueFormmater = "yyyy";
      let _timeInterval: string | number = "";

      switch (year) {
        case "1Y":
          minDate = minDate.setFullYear(minDate.getFullYear() - 1);
          _lableCount = 6;
          _valueFormmater = "MMM yy";
          _timeInterval = 24 * 60 * 60 * 1000 * 20;
          break;
        case "3Y":
          minDate = minDate.setFullYear(minDate.getFullYear() - 3);
          _lableCount = 6;
          _valueFormmater = "MMM yy";
          _timeInterval = 24 * 60 * 60 * 1000 * 30 * 3;
          break;
        case "7Y":
          minDate = minDate.setFullYear(minDate.getFullYear() - 7);
          _lableCount = 3;
          _valueFormmater = "yyyy";
          _timeInterval = 24 * 60 * 60 * 1000 * 30 * 6;
          break;
        case "5Y":
          minDate = minDate.setFullYear(minDate.getFullYear() - 5);
          _lableCount = 3;
          _valueFormmater = "yyyy";
          _timeInterval = 24 * 60 * 60 * 1000 * 30 * 6;
          break;
        case "10Y":
          minDate = minDate.setFullYear(minDate.getFullYear() - 10);
          _lableCount = 3;
          _valueFormmater = "yyyy";
          _timeInterval = 24 * 60 * 60 * 1000 * 30 * 6;
          break;
        case "1M":
          minDate = new Date(
            minDate.setMonth(minDate.getMonth() - 1)
          ).getTime();
          _lableCount = 3;
          _valueFormmater = "yyyy";
          _timeInterval = 24 * 60 * 60 * 1000 * 5;
          break;
        case "3M":
          minDate = new Date(
            minDate.setMonth(minDate.getMonth() - 3)
          ).getTime();
          _lableCount = 3;
          _valueFormmater = "yyyy";
          _timeInterval = 24 * 60 * 60 * 1000 * 20;
          break;

        case "6M":
          minDate = new Date(
            minDate.setMonth(minDate.getMonth() - 6)
          ).getTime();
          _lableCount = 3;
          _valueFormmater = "yyyy";
          _timeInterval = 24 * 60 * 60 * 1000 * 20;
          break;
        default:
          minDate = minDate.setFullYear(minDate.getFullYear() - 1);
          _lableCount = 3;
          _valueFormmater = "yyyy";
          _timeInterval = 24 * 60 * 60 * 1000 * 30 * 6;
          break;
      }

      const result = arrResult.filter(
        (a: any) => new Date(a.x) > minDate && new Date(a.x) < maxDate
      );

      const cvg_result = cvgArr.filter(
        (a: any) => new Date(a.x) > minDate && new Date(a.x) < maxDate
      );
      // var myDate = !!result.length ? result[0].x : "";

      // const map1 = arrResult.map((ele) => new Date(ele.x));

      setPortfolioPerformanceGraphOption(
        {
          series: [
            {
              type: "area",
              name: "NAV",
              threshold: null,
              data: result.map(Object.values),
              color: "#2b4a76",
              lineColor: "#2b4a76",
              fillColor: {
                linearGradient: {
                  x1: 0,
                  y1: 0,
                  x2: 0,
                  y2: 1,
                },
                stops: [
                  [0.21, "#d7e4f4"],
                  [1, "#d7e4f4"],
                ],
              },
            },
            {
              type: "area",
              name: "CVG",
              threshold: null,
              data: cvg_result.map(Object.values),
              color: "#FFA500",
              lineColor: "#FFA500",
              fillColor: {
                linearGradient: {
                  x1: 0,
                  y1: 0,
                  x2: 0,
                  y2: 1,
                },
                stops: [
                  [0.21, "rgba(255, 165, 0,0.5)"],
                  [1, "rgba(255, 165, 0,0.3)"],
                ],
              },
            }
          ],
          credits: {
            enabled: false,
          },

          xAxis: {
            type: "datetime",
            tickInterval: _timeInterval,
            title: {
              text: null,
            },
            dateTimeLabelFormats: {
              day: "%b '%y",
            },
          },
          tooltip: {
            split: false,
            color: "red",

            formatter: function (this: Highcharts.Point): any {
              const formatter = new Intl.NumberFormat("en-IN", {
                style: "currency",
                currency: "INR",
              });

              return (
                // "NAV :" +
                formatter.format(this.y ? this.y : 0) +
                "<br>" +
                new Date(this.x).toLocaleDateString("en-UK", {
                  day: "2-digit",
                  month: "short",
                  year: "numeric",
                }) +
                "</br>"
              );
            },
          },

          caption: {
            text: null,
          },
          title: {
            text: null,
          },
          chart: {
            type: "line",
            zoomType: "x",
            resetZoomButton: {
              theme: {
                display: "none",
              },
            },

            height: 200,
          },

          legend: {
            enabled: false,
          },
          plotOptions: {
            series: {
              marker: {
                enabled: false,
              },
              compare: 'percent',
            },
            area: {
              lineWidth: 1,
            },
          },
          yAxis: {
            min: 0,
            gridLineColor: null,

            title: {
              text: null,
            },
            labels: {
              enabled: false,
            },
          },
        }
      )
    }
  }
  // const portfolioPerformaceGraphOptions = {
  //   chart: {
  //     type: 'area',
  //     // scrollablePlotArea: {
  //     //   minWidth: 600,
  //     //   scrollPositionX: 1,
  //     // },
  //   },
  //   title: {
  //     text: '',
  //   },
  //   credits: false,
  //   xAxis: {
  //     // type: 'datetime',
  //     categories: portfolioPerformance?.map(
  //       (each: { DT: string }) =>
  //         formatLongDate(each.DT).split(' ')[1].substring(0, 3) +
  //         ' ' +
  //         formatLongDate(each.DT).split(' ')[2]
  //     ),
  //     labels: {
  //       autoRotation: false,
  //       overflow: 'justify',
  //     },
  //   },
  //   yAxis: {
  //     title: {
  //       text: 'Return',
  //     },
  //     labels: {
  //       // formatter: function (): string {
  //       //   return '<span>' + (this as any).value + ' %</span>';
  //       // },
  //       format: '{text} %',
  //     },
  //     visible: false
  //   },
  //   tooltip: {
  //     valueSuffix: ' %',
  //     shared: true,
  //   },
  //   legend: {
  //     align: 'center',
  //     verticalAlign: 'top',
  //     enabled: false,
  //   },
  //   plotOptions: {
  //     line: {
  //       lineWidth: 2,
  //       states: {
  //         hover: {
  //           lineWidth: 3,
  //         },
  //       },
  //       marker: {
  //         enabled: false,
  //       },
  //     },
  //   },
  //   series: [
  //     {
  //       name: 'Portfolio',
  //       color: '#337FC9',
  //       opacity: '0.5',
  //       outerHeight: '200px',
  //       data: portfolioPerformance?.map((each: { Rtn: any; }) => each.Rtn),
  //       connectEnds: false,
  //       connectNulls: true,
  //       crisp: true,
  //     },
  //     // {
  //     //   name: 'Sensex',
  //     //   color: '#F4C10E',
  //     //   data: portfolioPerformance?.map((each) => 0),
  //     // },
  //     // {
  //     //   name: 'Nifty',
  //     //   color: '#730EF4',
  //     //   data: portfolioPerformance?.map((each) => 0),
  //     // },
  //   ],
  //   navigation: {
  //     menuItemStyle: {
  //       fontSize: '8px',
  //     },
  //   },
  // };
  return (
    <>
      <HighchartsReact
        highcharts={Highcharts}
        options={portfolioPerformanceGraphOption}
      />
    </>
  )
}

export type bseCodePayload = {
  TrType: string,
  Amount: string,
  Growthoption: number,
  DividendReinvestment: number,
  RTACODE: string
}

export type createTransactionPayload = {
  "StartDate": string,
  "Installments": number,
  "InstallmentsAmt": string,
  "MandateId": string,
  "MandateType": string,
  "FirstOrderToday": string,
  "Frequency": string,
  "AmcId": number,
  "Sch": string,
  "TrType": string,
  "Growthoption": number,
  "DividendReinvestment": number,
  "BSE_SchemeCode": string
}