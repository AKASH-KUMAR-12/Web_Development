import { SubAssetclassName } from "./transaction.context";
import "./styles.css";
import { Zoom } from "@mui/material";

export function TransactionAssetClassTab({ subAssetClassNames }: {subAssetClassNames: SubAssetclassName }) {
  return (
    <div
      className="fundCardContainer  homeContainer"
      style={{ padding: 15, alignItems: "center" }}
    >
      <div style={{ height: "100%" }}>
      <Zoom in={true}><img
          src={subAssetClassNames.ImageURL}
          style={{ height: 60, width: 60 }}
          alt=""
        /></Zoom>
      </div>
      <div style={{ marginLeft: 20, paddingTop: 5 }}>
        <div>{subAssetClassNames.Sub_AssetclassName}</div>
        <div className="fundCatdesc">{subAssetClassNames.Descripti}</div>
      </div>
    </div>
  )
}