import { Box, Button, Divider, Modal, Tab, Typography, Skeleton, FormControl, OutlinedInput, InputAdornment } from "@mui/material";
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';
import { TabContext, TabList, TabPanel } from '@mui/lab';
import "./styles.css";
import { useEffect, useState } from "react";
import { RecommendedSchemesModal, SubFundCategoryCard } from "./investor-transaction-helper";
import { SchemeList, SubAssetClasses, useGetTotalData } from "./transaction.context";
import SearchIcon from '@mui/icons-material/Search';
import { IconButton } from "@mui/material";
import { FilterComponent } from "./Filter";
import FilterListIcon from '@mui/icons-material/FilterList';

export default function Scheme_List({
  handleBackClick,
  selectedSubAssetClass,
  setSelectedSubAssetClass,
  handleSetViewSchemeDetails,
  sub_asset_classes,
  schemeList
}: {
  handleBackClick: () => void;
  selectedSubAssetClass: SubAssetClasses | undefined;
  setSelectedSubAssetClass: any;
  handleSetViewSchemeDetails: (val: boolean, schemeDetail: SchemeList) => void;
  sub_asset_classes: SubAssetClasses[] | undefined;
  schemeList: SchemeList[] | undefined;
}) {

  const routes = sub_asset_classes?.map((item) => ({
    key: item.Sub_AssetclassName,
    title: item.Sub_AssetclassName,
    ID: item.ID,
    mainTitle: item.AssetClassName,
    description: item.Descripti,
    imageUrl: item.ImageURL,
  }));

  const [value, setValue] = useState<string>(selectedSubAssetClass ? selectedSubAssetClass.Sub_AssetclassName : "");


  const { setInitialFilter } = useGetTotalData()
  const [checkedSchemes, setCheckedSchemes] = useState<SchemeList[]>([]);
  const [openModal, setOpenModal] = useState(false);
  // const [open, setOpen] = useState<boolean>(false);
  const { initialFilter } = useGetTotalData();
  // const handleOpen = () => setOpen(true);
  const [totalFilter, setTotalFilter] = useState<any>([]);
  const [filterCount, setFilterCount] = useState<number>(0);
  const [finalCheckedItems, setFinalCheckedItems] = useState<any>([]);

  const handleModalOpen = () => setOpenModal(true);
  const handleModalClose = () => setOpenModal(false);

  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const open = Boolean(anchorEl);

  const handleClickFilter = (event: React.MouseEvent<HTMLButtonElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleChange = (event: any, value: any) => {
    setValue(value);
    setInitialFilter({})
    const temp = sub_asset_classes?.filter((ele) => ele.Sub_AssetclassName == value);
    setSelectedSubAssetClass(temp ? temp[0] : selectedSubAssetClass);
  };
  const OnSchemeSelection = (schemeId: number) => {
    const selectedScheme = schemeList?.filter((val) => val.SchemeID === schemeId);
    selectedScheme ? setCheckedSchemes([...checkedSchemes, selectedScheme[0]]) : "";
  }

  const OnSchemeDeSelection = (schemeId: number) => {
    const schemeList = checkedSchemes.filter((val) => val.SchemeID != schemeId);
    setCheckedSchemes(schemeList);
  }
  const [search, setSearch] = useState<string>('');
  const [filteredAMCName, setFilteredAMCName] = useState<any>([]);

  useEffect(() => {
    if (Object.keys(initialFilter).length == 0) {
      const filtered = schemeList?.filter((item) =>
        Object.values(item).some((value) => String(value).toLowerCase().includes(search.toLowerCase()))
      );
      setFilteredAMCName(filtered)
    }
    else {
      const filtered = totalFilter?.filter((item: any) =>
        Object.values(item).some((value) => String(value).toLowerCase().includes(search.toLowerCase()))
      );
      setFilteredAMCName(filtered)
    }
  }, [search])

  return (
    <Box sx={{ width: "100%", '& .MuiTabPanel-root': { py: 1, px: 1 }, }}>
      <Box style={{ display: "flex", justifyContent: "space-between", alignItems: "center", }}>
        <FormControl sx={{ width: { xs: 180, sm: 225 }, mx: 3, mt: 2 }} variant="outlined">
          <OutlinedInput
            value={search}
            onChange={({ target: { value } }) => {
              setSearch(value);
            }}
            sx={{ '& .MuiOutlinedInput-input': { py: 1, fontSize: { xs: 11, sm: 13 } } }}
            id="search-field"
            placeholder="Search by Scheme Name"
            startAdornment={
              <InputAdornment position="start">
                <SearchIcon fontSize="small" />
              </InputAdornment>
            }
          />
        </FormControl>
        <IconButton onClick={handleClickFilter} sx={{ color: "#0393FE", border: "2px solid #0393FE", borderRadius: "30px", fontSize: { xs: "10px", sm: "15px" }, marginRight: "1rem", height: "2rem", marginTop: "10px", padding: { xs: "0rem 0.5rem", sm: "1rem" } }}>
          <FilterListIcon />
          <span><b>FILTER</b></span> {filterCount!=0?<span style={{marginLeft:'10px',width:'16px', height:'16px',color:'wheat', fontSize:'12px',textAlign:'center', backgroundColor:'red', borderRadius:"50%", display:'flex', alignItems:'center', justifyContent:'center'}}>{filterCount}</span>:""}
        </IconButton>
        {open &&
          <FilterComponent
            open={open}
            anchorEl={anchorEl}
            setAnchorEl={setAnchorEl}
            setSearch={setSearch}
            setFilterState={setTotalFilter}
            page={"Explore"}
            setListData={setFilteredAMCName}
            filteredState={schemeList}
            setFilterCount={setFilterCount}
            setFinalCheckedItems={setFinalCheckedItems}
            finalCheckedItems={finalCheckedItems}
          />}
      </Box>
      <Box
        sx={{
          // width: '100%',
          // '& .MuiTabPanel-root': { py: 0, px: 0 },
          // '& .MuiTab-root': {
          //   color: '#A1A2A2',
          //   opacity: 0.8,
          //   fontSize:{xs:12,sm:17},
          //   lineHeight: '20px',
          //   textTransform: 'capitalize',
          //   border: 'none',
          //   px: { xs: 1, sm: 3 },
          //   m: { xs: 0, sm: 1},
          //   '&.Mui-selected': {
          //     color: '#1EB1F3',
          //     border: 'none',

          //   },
          // },
          // '& .MuiTabs-indicator': {
          //   height: 3,
          //   background: '#1EB1F3',
          // },
        }}>
        {/* Header */}
        <Box sx={{ px: 3, display: 'flex', alignItems: 'center', width: '100%', mb: 3, mt: 2 }}>

          <ArrowBackIosIcon sx={{ cursor: 'pointer' }} onClick={handleBackClick} />
          <Box sx={{ display: 'flex', alignItems: 'center', mx: { xs: 0, sm: 3 }, width: { xs: "100%", sm: '80%' }, }}>
            <img
              src={selectedSubAssetClass?.ImageURL}
              style={{ width: 60, height: 60 }}
              alt=""
            />
            <div className="line"></div>
            <div style={{ marginLeft: 20, paddingTop: 5 }}>
              <div>{selectedSubAssetClass?.Sub_AssetclassName}</div>
              <div className="fundCatdesc">{selectedSubAssetClass?.Descripti}</div>
            </div>
          </Box>

        </Box>
        <Divider />
        {/* Tabs */}
        <TabContext value={value}>
          <Box sx={{ px: { xs: 1, sm: 0 } }}>
            <TabList
              onChange={handleChange}
              aria-label="product tabs"
              variant="scrollable"
              scrollButtons="auto"
              sx={{
                width: '100%',
                '& .MuiTabPanel-root': { py: 0, px: 0 },
                '& .MuiTab-root': {
                  color: '#A1A2A2',
                  opacity: 0.8,
                  fontSize: { xs: 12, sm: 17 },
                  border: 'none',
                  lineHeight: '20px',
                  px: { xs: 1, sm: 3 },
                  m: { xs: 0, sm: 1 },
                  '&.Mui-selected': {
                    color: '#1EB1F3',
                    border: 'none',
                  },
                },
                '& .MuiTabs-indicator': {
                  height: 3,
                  background: '#1EB1F3',
                }
                , '& .MuiTabs-flexContainer': {
                  display: "flex",
                  justifyContent: { xs: "space-between", sm: "flex-start" },
                  width: "100%",
                  mt: { xs: 1, sm: 0 }
                }
              }}>
              {routes?.map((item: any) => {
                return (
                  <Tab label={item.title} value={item.key} key={item.key}
                  // style={{fontSize:'15px'}} 
                  />
                )
              })}

            </TabList>
          </Box>
          <Divider />
          <Box sx={{ px: { xs: 1, sm: 0 } ,height:{xs:"100%",sm:"13.5rem"},overflow:"scroll"}}>
            {routes?.map((item: any, index: number) => {
              return (
                <TabPanel value={item.key} key={item.key}>

                  {filteredAMCName?.sort((a: any, b: any) => a.SchemeName.toLowerCase().localeCompare(b.SchemeName.toLowerCase())).map((val: SchemeList, index: number) => {
                    return (
                      <Box key={index}><SubFundCategoryCard

                        onSchemeSelection={OnSchemeSelection}
                        schemeDetail={val}
                        OnSchemeDeSelection={OnSchemeDeSelection}
                        handleSetViewSchemeDetails={handleSetViewSchemeDetails}
                        allocation={false}
                        selectedSchemes={checkedSchemes}
                        openModal={openModal} />
                        <Divider /></Box>
                    )
                  })}

                </TabPanel>
              )
            })}
          </Box>
        </TabContext>
      </Box>

      <Modal
        open={openModal}
        // onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          width: 1000,
          bgcolor: 'background.paper',
          borderRadius: '16px',
          boxShadow: 24,
          border: 'none',
          py: 3
        }}>
          <RecommendedSchemesModal handleModalClose={handleModalClose} selectedSchemes={checkedSchemes} OnSchemeDeSelection={OnSchemeDeSelection} />
        </Box>
      </Modal>
    </Box>
  )
}