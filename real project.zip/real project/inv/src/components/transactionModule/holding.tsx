import { Box, Typography, Tab, Divider, Skeleton, LinearProgress, Tooltip, FormControl, OutlinedInput, InputAdornment, IconButton, Grow, Collapse } from '@mui/material';
import { TabContext, TabList, TabPanel } from '@mui/lab';
import { useEffect, useState } from 'react';
import SchemeDetail from './scheme-detail';
import { AssetClasses, CategoryAverage, PortfolioType, SchemeDetails, SchemeList, SchemeNav, SubAssetClasses, useGetTotalData } from './transaction.context';
import { Bubble } from './investor-transaction-helper';
import { withStyles } from "@material-ui/core/styles";
import { InvestNowIcon } from '../customSVGs';
import { AddToCartHoldings } from './addToCartDrawerForHoldings';
import { _request } from '../../api/requests';
import FilterListIcon from '@mui/icons-material/FilterList';
import { FilterComponent } from './Filter';
import SearchIcon from '@mui/icons-material/Search';

export default function holding() {

  const [isLoadingschemeDetail, setLoadingSchemeDetail] = useState(false);
  const [isLoadingschemeList, setLoadingSchemeList] = useState(false);
  const [isLoadingSubAsset, setLoadingSubAsset] = useState(false);
  const [isLoadingAsset, setLoadingAsset] = useState(true);
  const [isLoadingSchemeName, setLoadingSchemeName] = useState(true);
  const [isLoadingCatAvg, setLoadingCatAvg] = useState(false);
  const [isLoadingSchemeNav, setLoadingSchemeNav] = useState(false);
  const [value, setValue] = useState<string>("Debt");
  const [itemSelected, setItemSelected] = useState<SubAssetClasses>();
  const [viewSubList, setViewSubList] = useState(false);
  const [viewSchemeDetails, setViewSchemeDetails] = useState<boolean>(false);
  const [currentSchemeDetail, setCurrentSchemeDetail] = useState<SchemeList>();
  const { assetClasses, getAssetClassDetails, portfolioData, getPortfolioData, subAssetClasses, getSubAssetClassDetails, schemesList, getSchemeListDetails, schemeNav, getSchemeNavDetails, categoryAverage, getCategoryAverageDetails, schemeDetails, getSchemeDetails, getAccountTypes } = useGetTotalData();
  const [assetClassesData, setAssetClassesData] = useState<AssetClasses[]>();
  const [subAssetClassesData, setSubAssetClassesData] = useState<SubAssetClasses[]>();
  const [schemeList, setSchemeList] = useState<SchemeList[]>();
  const [portfolioNameData, setPortfolioNameData] = useState<PortfolioType[]>();
  const [schemeDetail, setSchemeDetail] = useState<SchemeDetails>();
  const [categoriesAverage, setCategoriesAverage] = useState<CategoryAverage[]>();
  const [investScheme, setInvestScheme] = useState<PortfolioType>();
  // const [open, setOpen] = useState<boolean>(false);
  const [filteredState, setFilteredState] = useState<any>([]);
  const [portfolioDataState, setPortfolioDataState] = useState<any>([])
  const [schemesNav, setSchemesNav] = useState<SchemeNav[]>();
  const [moreDetails, setMoreDetails] = useState<{ [key: number]: boolean }>({});
  // const [search, setSearch] = useState<string>('');
  const [addToCartAnchorsEl, setAddToCartAnchorsEl] = useState<boolean>(false);
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const [filterCount, setFilterCount] = useState<number>(0);
  const [finalCheckedItems, setFinalCheckedItems] = useState<any>([]);
  const open = Boolean(anchorEl);

  const handleClickFilter = (event: React.MouseEvent<HTMLButtonElement>) => {
    setAnchorEl(event.currentTarget);
  };

  // const handleOpen = () => setOpen(true);

  const handleChange = (event: any, value: any) => {
    setValue(value);
  };
  // const [filteredState, setFilteredState] = useState<any>([]);
  const [search, setSearch] = useState<string>('');
  const { initialFilter } = useGetTotalData();
  const [totalFilter, setTotalFilter] = useState<any>([]);
  const [indexFlag, setIndexFlag] = useState<any>({})
  // for displaying more details 
  const handleDetailsClick = (index: number) => {
    setMoreDetails((lessDetails) => {
      const updatedDetails = { ...lessDetails, [index]: !lessDetails[index] };
      return updatedDetails;

    });
  }
  function roundToTwo(num: number) {
    const num2 = num + "e+2";

    return +(Math.round(Number(num2)) + "e-2");
  }

  const Nanprocessor = function (entry: any) {
    if (entry) {
      return entry;
    } else {
      return 0;
    }
  };

  const handleAddToCartAnchorsEl = async (item: PortfolioType) => {
    try {
      setAddToCartAnchorsEl(true);
      setInvestScheme(item);

    } catch (e) {
      console.error((e as Error).message);

    }
  };

  const handleAddToCartAnchorsElClose = () => {
    setAddToCartAnchorsEl(false);
  };

  const InvestNowTooltip = withStyles({
    tooltip: {
      color: "grey",
      fontSize: '13px',
      backgroundColor: "#ffffff",
      height: '20px',
      paddingBottom: '1.5rem',
      border: '0.5px solid grey',
      borderRadius: '8px',

    }
  })(Tooltip);

  const create_transaction = (requestOptions: any): Promise<any> => {

    return _request({
      relativeUrl: `/transaction/create_transaction`,
      method: 'POST',
      body: { ...requestOptions }
    });
  }

  const get_bse_code = (requestOptions: any): Promise<any> => {

    return _request({
      relativeUrl: `/transaction/get_bse_code`,
      method: 'POST',
      body: { ...requestOptions }
    });
  }

  const dateObj = new Date();
  const month = dateObj.getUTCMonth() + 1;
  const day = dateObj.getUTCDate();
  const year = dateObj.getUTCFullYear();

  const latestDate = month + "/" + day + "/" + year;

  const handleClick = (item: any, index: any) => () => {
    setViewSubList(true);
    setItemSelected(item);
  };

  const handleSetViewSchemeDetails = (val: boolean, schemeDetail: SchemeList | undefined | null) => {
    setViewSchemeDetails(val);
    schemeDetail ? setCurrentSchemeDetail(schemeDetail) : "";
  }
  useEffect(() => {
    if (itemSelected) {
      setLoadingSchemeList(true);
      getSchemeListDetails(itemSelected?.ID)
    }
  }, [itemSelected?.ID])

  useEffect(() => {
    if (currentSchemeDetail) {
      // setLoadingCatAvg(true);
      // setLoadingSchemeDetail(true);
      // setLoadingSchemeNav(true);
      getSchemeDetails(currentSchemeDetail?.productid)
      getCategoryAverageDetails({ schemaId: currentSchemeDetail.productid, marketValue: false })
      getSchemeNavDetails(currentSchemeDetail?.productid)
    }
  }, [currentSchemeDetail?.productid])
  const body = {
    "date": latestDate
    // "date" : "1/4/2024"
  }

  useEffect(() => {
    // setLoadingAsset(true);
    // setLoadingSchemeName(true);
    // setLoadingSubAsset(true);
    getAssetClassDetails();
    getPortfolioData(body);
    // getSchemeDetails();
    // getSchemeNavDetails();
    getSubAssetClassDetails(value);
  }, []);

  useEffect(() => {

    setAssetClassesData(assetClasses);
    setSchemeList(schemesList);
    setSchemesNav(schemeNav);
    setCategoriesAverage(categoryAverage);
    setSchemeDetail(schemeDetails);
    if (assetClasses != undefined && portfolioData != undefined) {
      setLoadingAsset(false);
      setLoadingSchemeName(false);
    }
  }, [assetClasses, portfolioData, categoryAverage, schemeDetail, schemeNav]);

  useEffect(() => {

    (async function () {
      if (portfolioData != undefined) {
        if (Object.keys(initialFilter).length == 0) {
          const filtered: any = portfolioData?.filter((item: any) =>
            Object.values(item).some((value) => String(value).toLowerCase().includes(search.toLowerCase()))
          );
          let response_accountType: any = await getAccountTypes({ rmID: 5 })
          filtered?.map(async (item: any) => {
            let foundValue = response_accountType.find((val: any) => val.AccountId == item.AccountID)
            if (foundValue == undefined) {
              item["HoldingName"] = "NA"
            }
            else {
              item["HoldingName"] = foundValue.BseRegStatus == "Y" ? "Y$" + foundValue.AccountType : "N$" + foundValue.AccountType
            }
          })
          setPortfolioDataState(filtered)

        }
        else {
          const filtered: any = totalFilter?.filter((item: any) =>
            Object.values(item).some((value) => String(value).toLowerCase().includes(search.toLowerCase()))
          );
          let response_accountType: any = await getAccountTypes({ rmID: 5 })
          filtered?.map(async (item: any) => {
            let foundValue = response_accountType.find((val: any) => val.AccountId == item.AccountID)
            if (foundValue == undefined) {
              item["HoldingName"] = "NA"
            }
            else {
              item["HoldingName"] = foundValue.BseRegStatus == "Y" ? "Y$" + foundValue.AccountType : "N$" + foundValue.AccountType
            }
          })
          setPortfolioDataState(filtered)
        }
      }

    })();

  }, [search, portfolioData])


  return (
    <div>
      {(isLoadingAsset || isLoadingSchemeName) ? (
        <LinearProgress sx={{ mt: 2.5 }} />
      ) :
        (<Box
          sx={{
            bgcolor: 'common.white',
            boxShadow: '0px 4px 28px 2px rgba(0, 0, 0, 0.08)',
            borderRadius: '5px',
           
          }}>

          {/* Displays recommendation list / scheme detail */}
          {viewSchemeDetails ?
            //scheme detail
            <div>
              <SchemeDetail
                handleBackClick={() => setViewSchemeDetails(false)}
                handleSetViewSchemeDetails={handleSetViewSchemeDetails}
                // investorId={investorId}
                schemeDetail={schemeDetail}
                schemeData={currentSchemeDetail as unknown as SchemeList}
                categoryAverage={categoryAverage}
                schemeNav={schemeNav}
              />

            </div>

            :
            //Recommendation List
            <Box>
              <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <FormControl sx={{ width: {xs:180,sm:225}, ml: 2, mt: 2 }} variant="outlined">
                  <OutlinedInput
                    value={search}
                    onChange={({ target: { value } }) => {
                      setSearch(value);
                    }}
                    sx={{ '& .MuiOutlinedInput-input': { py: 1, fontSize: {xs:11,sm:13} } }}
                    id="search-field"
                    placeholder="Search by Scheme Name"
                    startAdornment={
                      <InputAdornment position="start">
                        <SearchIcon fontSize="small" />
                      </InputAdornment>
                    }
                  />
                </FormControl>
                <IconButton onClick={handleClickFilter} sx={{ color: "#0393FE", border: "2px solid #0393FE", borderRadius: "30px", fontSize: {xs:"10px",sm:"15px"}, marginRight: "1rem", height: "2rem", marginTop: "10px", padding: {xs:"0rem 0.5rem",sm:"1rem"} }}>
                  <FilterListIcon />
                  <span><b>FILTER</b></span> {filterCount!=0?<span style={{marginLeft:'10px',width:'16px', height:'16px',color:'wheat', fontSize:'12px',textAlign:'center', backgroundColor:'red', borderRadius:"50%", display:'flex', alignItems:'center', justifyContent:'center'}}>{filterCount}</span>:""}
                </IconButton>
                {open &&
                  <FilterComponent
                    open={open}
                    anchorEl={anchorEl}
                    setAnchorEl={setAnchorEl}
                    setSearch={setSearch}
                    setFilterState={setTotalFilter}
                    page={"Holding"}
                    setListData={setPortfolioDataState}
                    filteredState={portfolioData}
                    setFilterCount={setFilterCount}
                    setFinalCheckedItems={setFinalCheckedItems}
                    finalCheckedItems={finalCheckedItems}
                  />}


              </Box>
              <Box sx={{'& .MuiTabPanel-root': { py: 1, px: 1 },}}>
                {isLoadingAsset ? <Skeleton /> :
                  <TabContext value={value} >
                    <Box sx={{
                      width: '100%',
                      '& .MuiTabPanel-root': {
                        py: 2,
                        px: 0
                      },
                      '& .MuiTab-root': {
                        color: '#A1A2A2',
                        opacity: 0.8,
                        fontSize: { xs: 12, sm: 17 },
                        lineHeight: '20px',
                        textTransform: 'capitalize',
                        border: "none",
                        minWidth: {xs:70,sm:80},
                        px: { xs: 0, md: 2, lg: 4 },
                        mx: { xs: 0.5, sm: 2 },
                        '&.Mui-selected': {
                          color: '#1EB1F3',
                          border: 'none'
                        },
                      },
                      '& .MuiTabs-indicator': {
                        height: 3,
                        background: '#1EB1F3',

                      },  '& .MuiTabs-flexContainer': {
                        display: "flex",
                        justifyContent: {xs:"space-between",sm:"flex-start"},
                        width: "100%",
                    }
                    }}>
                      <TabList onChange={handleChange}
                      >
                        {assetClassesData?.map((ele, index) => {
                          return (<Tab label={ele.AssetClassName} value={ele.AssetClassName} key={index} />)
                        })}
                      </TabList>
                    </Box>


                    <Divider />
                    <Box sx={{ height:{xs:"100%",sm:"19.5rem"},overflow:"scroll"}}>
                      {assetClassesData?.map((item: any, index: any) => {
                        return (

                          <TabPanel value={item.AssetClassName} key={index}>
                            {/* {isLoadingSubAsset ? <Skeleton /> : <> */}

                            {portfolioDataState?.filter((scheme: any) => scheme.I_Asset_Class === value).length === 0 ? <Box sx={{ width: '100%', display: 'flex', justifyContent: 'center' }}>
                              <Typography sx={{ fontSize: {xs:14,sm:18}, color: '#5a7c82', p: {xs:1,sm:2},fontWeight:500 }}>No Portfolio available</Typography>
                            </Box> : <>
                              {portfolioDataState?.sort((a: any, b: any) => a.Product.toLowerCase().localeCompare(b.Product.toLowerCase())).filter((scheme: any) => scheme.I_Asset_Class === value) // Filter based on AssetClassName
                                .map((ele: any, index: number) => {
                                  return (
                                    <div
                                      key={index}
                                    // style={{ cursor: "pointer" }}
                                    // onClick={handleClick(ele, index)}
                                    >

                                      <Box onClick={()=>handleDetailsClick(index)}  sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', my: {xs:1,sm:2.5} , cursor:'pointer',flexDirection:{xs:"column",sm:"row"},}}>

                                        <Box sx={{ marginRight: {xs:0,sm:4}, display: 'flex', flexDirection: 'column', width: {xs:"100%",sm:"40%"},ml:{xs:"1rem",sm:"2rem"}}}>
                                          <Typography sx={{ fontSize: {xs:11,sm:12.5}, fontWeight: 600, mb: 0.5 }}>
                                            {ele.Product}
                                          </Typography>
                                          <Box sx={{ display: 'flex', width: "20rem",mt:{xs:0,sm:1}}}>
                                            {!!ele.I_Asset_Class && (
                                              <Bubble text={ele.I_Asset_Class} />
                                            )}
                                            {!!ele.I_AssetClass && (
                                              <Bubble text={ele.I_AssetClass} />
                                            )}
                                            {!!ele.PlanShortName && (
                                              <Bubble text={ele.PlanShortName} />
                                            )}


                                          </Box>
                                        </Box>
                                    
                                        <Box sx={{display:"flex", alignItems: {xs:'flex-start',sm:"center"}, cursor: 'pointer',width:"100%",mt:{xs:"0.5rem",sm:"0rem"},ml:{xs:"1rem",sm:"0rem"}}}>
                                        <Box sx={{  width: {xs:"21%",sm:"25%"}, display: 'flex', flexDirection: 'column', alignItems: 'flex-start',justifyContent:"center"}}>
                                          <Typography sx={{ fontSize: {xs:11,sm:12.5}, color: '#5a7c82' }}>

                                            Invested Amount
                                          </Typography>
                                          <Typography sx={{ fontSize:{xs:11,sm:12.5}, color: "rgb(30, 163, 98)",mt: 1  }}>

                                            {`Rs. ${ele.COST}`}
                                          </Typography>
                                        </Box>
                                        <Box sx={{  width: {xs:"25%",sm:"25%"}, display: 'flex', flexDirection: 'column', alignItems: 'flex-start',justifyContent:"center" }}>
                                          <Typography sx={{ fontSize: {xs:11,sm:12.5}, color: '#5a7c82' }}>

                                            Current Value
                                          </Typography>
                                          <Typography sx={{ fontSize: {xs:11,sm:12.5}, color: "rgb(30, 163, 98)",mt: 1  }}>

                                            {`Rs. ${ele.AUM}`}
                                          </Typography>
                                        </Box>

                                        <Box sx={{ width: {xs:"19%",sm:"21%"}, display: 'flex', flexDirection: 'column', alignItems: 'flex-start',justifyContent:"center"}}>
                                          <Typography sx={{ fontSize: {xs:11,sm:12.5}, color: '#5a7c82' }}>XIRR</Typography>
                                          <Typography sx={{ fontSize: {xs:11,sm:12.5}, color: "rgb(30, 163, 98)",mt: 1  }}>
                                            {Nanprocessor(roundToTwo(Number(ele.FolioXirr)))} %
                                          </Typography>
                                        </Box>
                                        <Box sx={{  width: {xs:"19%",sm:"20%"}, display: 'flex', flexDirection: 'column', alignItems: 'flex-start',justifyContent:"center"}}>
                                          <Typography sx={{ fontSize: {xs:11,sm:12.5}, color: '#5a7c82' }}>Units</Typography>
                                          <Typography sx={{ fontSize: {xs:11,sm:12.5}, color: "rgb(30, 163, 98)",mt: 1  }}>
                                            {ele.Units}
                                          </Typography>
                                        </Box>
                                        <InvestNowTooltip title='Add to Cart'
                                          // TransitionComponent={Zoom}
                                          TransitionProps={{ timeout: 200 }} >
                                          <Box sx={{ width: '10%', cursor: "pointer" }} onClick={() => handleAddToCartAnchorsEl(ele)}
                                          //  onClick={handleAddToCartAnchorsEl} 
                                          >
                                            <InvestNowIcon />
                                          </Box>
                                        </InvestNowTooltip>
                                        {/* <Box sx={{ width: '8%' }}>
                                        <ArrowForwardIosIcon 
                                          onClick={() => handleSetViewSchemeDetails(true, ele)}
                                          sx={{ borderRadius: 1, backgroundColor: '#163869', color: '#ffffff', mx: 1, cursor: 'pointer', }}
                                          style={{padding:".2rem",color:"white",width:"1.8rem",height:"1.8rem"}}
                                           fontSize='small' />
                                      </Box> */}
                                      </Box>


                                      </Box>                                 
                                        <Collapse in={moreDetails[index]} timeout={300}>
                                          <Box sx={{ display: "flex", flexDirection:'row', p:{xs:1,sm:3.5},flexWrap:"wrap"}}>
                                            <Box sx={{ display: 'flex', flexDirection: 'column', width: {xs:'35%',sm:'25%'} }}>
                                              <Typography sx={{ fontSize: {xs:11,sm:12.5}, color: '#5a7c82'}}>Holding Name </Typography>
                                              <Typography sx={{ fontSize: {xs:11,sm:12.5}, display: "flex" }}>
                                                {ele?.HoldingName == "NA" ? "NA" : ele?.HoldingName?.split("$")[1]}
                                              </Typography>
                                            </Box>
                                            <Box sx={{ display: 'flex', flexDirection: 'column', width: {xs:'30%',sm:'15%'} }}>
                                              <Typography sx={{ fontSize: {xs:11,sm:12.5}, color: '#5a7c82' }}>Current NAV </Typography>
                                              <Typography sx={{ fontSize: {xs:11,sm:12.5}, display: "flex" }}>
                                                Rs. {ele.NAVAson}
                                              </Typography>
                                            </Box>
                                            <Box sx={{ display: 'flex', flexDirection: 'column', width: {xs:'30%',sm:'20%'} }}>
                                              <Typography sx={{ fontSize: {xs:11,sm:12.5}, color: '#5a7c82' }}>Gain Amount </Typography>
                                              <Typography sx={{ fontSize: {xs:11,sm:12.5}, display: "flex"}}>
                                                Rs. {ele.UnrealReturns} ({ele.AUM_PERCENTAGE} %)
                                              </Typography>
                                            </Box>
                                            <Box sx={{ display: 'flex', flexDirection: 'column', width: {xs:'30%',sm:'15%'},mt:{xs:"0.5rem",sm:"0rem"} }}>
                                              <Typography sx={{ fontSize: {xs:11,sm:12.5}, color: '#5a7c82'}}>Folio  </Typography>
                                              <Typography sx={{ fontSize: {xs:11,sm:12.5}, display: "flex" }}>
                                                {ele?.I_Accno}
                                              </Typography>
                                            </Box>
                                            <Box sx={{ display: 'flex', flexDirection: 'column',alignItems:"center", width: {xs:'50%',sm:'20%'} ,mt:{xs:"0.5rem",sm:"0rem"}}}>
                                              <Typography sx={{ fontSize: {xs:11,sm:12.5}, color: '#5a7c82'}}>NAV Difference(in %)  </Typography>
                                              <Typography sx={{ fontSize:{xs:11,sm:12.5}, display: "flex" }}>
                                                {ele?.NAVDiff}
                                              </Typography>
                                            </Box>
                                        </Box>
                                      </Collapse>

                                      <Divider />
                                    </div>
                                  )
                                }

                                )}</>}
                          </TabPanel>

                        )
                      })}
                    </Box>


                  </TabContext>}
              </Box>
            </Box>
          }

        </Box>)
      }
      {(addToCartAnchorsEl && investScheme != undefined) && (
        <AddToCartHoldings

          anchorEl={addToCartAnchorsEl}
          handleClose={handleAddToCartAnchorsElClose}
          schemeName={`${investScheme?.Product}`}
          selectedSchemeData={investScheme}
          getBSECode={get_bse_code}
          createTransaction={create_transaction}

        />
      )}
    </div>

  );
}
