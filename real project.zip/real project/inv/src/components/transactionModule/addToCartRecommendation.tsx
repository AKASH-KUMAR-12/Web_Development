import { Backdrop, Box, Button, CardMedia, Checkbox, CircularProgress, Divider, Drawer, FormControl, FormControlLabel, FormLabel, IconButton, InputLabel, MenuItem, Radio, RadioGroup, Select, Tab, TextField, TextFieldProps, Typography } from "@mui/material";
import { JSXElementConstructor, ReactElement, memo, useEffect, useRef, useState } from "react";
import { AddToCartButtons, TopHoldingButtons } from "../commonComponents";
import { CheckBox, CurtainsOutlined } from "@mui/icons-material";
import 'react-datepicker/dist/react-datepicker.css';
import { Masters, RecommendationsType, SchemeList, ValidationForSIP, redeemValidationType, useGetTotalData } from "./transaction.context";
import Scheme_List from "./scheme-list";
import './styles.css';
import { bseCodePayload, createTransactionPayload } from "./investor-transaction-helper";
import { useNavigate } from 'react-router';
import Swal from "sweetalert2";
import { useLoginContext } from "../login/data/login.context";
import { errorStateRedeemInitialData, errorStateSTPInitialData, errorStateSWPInitialData, errorStateSWTInitialData, errorStatesRedeem, errorStatesSTP, errorStatesSWP, errorStatesSWT, frequencyMapping } from "./transactionType";
import DatePicker, { registerLocale } from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import { get_switch_schemes } from "../../api/transaction";
import { CloseIcon } from "../customSVGs";


export const STP_Form = ({ recommendedDate, recommendedSchemeData, handleClose }:
    { recommendedDate: any, recommendedSchemeData: any, handleClose: () => void }) => {

    const { getBSECode, createTransaction } = useGetTotalData();
    const [selectedDate, setSelectedDate] = useState<Date | null>(null);
    const [checked, setChecked] = useState(false);
    const navigate = useNavigate();
    const { getCartCount } = useLoginContext();
    const [schemedata, setSchemeData] = useState<any>(recommendedSchemeData)
    const [newSchemeSch, setNewSchemeSch] = useState<string>("");
    const { schemeData, getSchemeData, getValidationDetails, validation } = useGetTotalData();
    const [schemeValidation, setSchemeValidation] = useState<ValidationForSIP[]>();
    const [selectedFrquencyValidations, SetSelectedFrquencyValidations] = useState<ValidationForSIP | undefined>();
    const [error, setError] = useState<errorStatesSTP>(errorStateSTPInitialData);
    const [loading, setLoading] = useState(false);
    const [loadingForm, setLoadingForm] = useState(true);

    useEffect(() => {
        if (recommendedDate != undefined) {
            setSelectedDate(new Date(recommendedDate))
        }
    }, [])

    useEffect(() => {
        try {
            getSchemeData(
                {
                    "AstId": "1",
                    "AmcId": `${recommendedSchemeData.AmcID}`
                }, 'STPFLAG'
            )
        } catch (error) {
            console.error("Error ", error);
        }
    }, []);

    useEffect(() => {
        setSchemeValidation(validation);
    }, [validation, newSchemeSch, recommendedSchemeData])

    useEffect(() => {
        if (schemeData != undefined) {
            let foundValue: any = schemeData?.find((val: any) => {
                if(val.Sch_Desc == schemedata.ToschemeName && validation?.length!=0) setTimeout(()=>{setLoadingForm(false);},1000)
                return val.Sch_Desc == schemedata.ToschemeName
            })
            setNewSchemeSch(foundValue?.Productcode_RTA)
        }
    }, [schemeData,validation])


    useEffect(() => {
        SetSelectedFrquencyValidations(schemeValidation?.filter((item: any) => item.SIPFREQUENCY === schemedata.Frequency)[0]);
    }, [schemeValidation])


    const changeValidationsOnFrequencyChange = (FrequencyVal: any) => {
        SetSelectedFrquencyValidations(schemeValidation?.filter((item: any) => item.SIPFREQUENCY === FrequencyVal)[0]);
    }

    const isDateDisabled = (date: Date): boolean => {

        const currentDate = new Date();
        currentDate.setHours(0, 0, 0, 0);
        if (date < currentDate) {
            return false;
        }

        let foundValue: any = schemeValidation?.find((val: any) => val.SIPFREQUENCY == schemedata.Frequency);
        let datesArray: any = foundValue?.SIPDATES.split(',');

        if (datesArray.includes(date.getDate().toString())) {
            return true;
        } else {
            return false;
        }
    };

    useEffect(() => {
        try {
            if (newSchemeSch != "") {
                getValidationDetails({ sch: newSchemeSch, TrType: "STP" });
            } else {
                console.log("newSchemeSch is undefined");
            }
        } catch (error) {
            console.error("Error ", error);
        }
    }, [newSchemeSch, recommendedSchemeData]);


    const handleClick = () => {
        if (!validateFormData()) {
            return;
        }
        else {
            setLoading(true);
        }
        let payload: any = {}
        getBSECode({
            "TrType": schemedata.SchemeType,
            "Amount": schemedata?.InvestmentAmount.toString(),
            "Growthoption": schemedata?.Growthoption,
            "DividendReinvestment": schemedata?.Dividendreinvestment,
            "RTACODE": schemedata?.Sch
        }).then(async ({ bse_code }) => {
            let { schemes } = await get_switch_schemes({
                "AstId": "1",
                "AmcId": schemedata?.AmcID.toString()
            })
            let matchedValue: any = schemes[0].find((value: any) => value.Sch_ID.split('~')[0] == schemedata.ToschemeID)
            let response: any = await getBSECode({
                "TrType": "STP",
                "Amount": schemedata?.InvestmentAmount.toString(),
                "Growthoption": schemedata?.Growthoption,
                "DividendReinvestment": schemedata?.Dividendreinvestment,
                "RTACODE": matchedValue?.Productcode_RTA
            })
            payload = {
                "RecId": schemedata?.RecID,
                "AccNo": schemedata?.Folio,
                "AmcId": schemedata?.AmcID,
                "BSE_SchemeCode": bse_code[0][0]?.BSE_ProductCod,
                "DividendReinvestment": schemedata?.Dividendreinvestment,
                "EndDate": "15/08/2026",
                "FirstOrderToday": checked == true ? "Y" : "N",             // need to make this dynamic
                "Frequency": frequencyMapping[schemedata.Frequency],
                "Growthoption": schemedata.Growthoption,
                "Installments": frequencyMapping[schemedata.Frequency] == '1' ? '' : schemedata?.No_of_Installments,
                "InstallmentsAmt": schemedata?.InvestmentAmount.toString(),
                "Sch": schemedata?.Sch,
                "StartDate": schemedata?.SIP_date != null ? schemedata?.SIP_date.slice(0, 10).split("-").reverse().join('/') : new Date().toJSON().slice(0, 10).split("-").reverse().join('/'),
                "ToBSE_SchemeCode": response?.bse_code[0][0]?.BSE_ProductCod,
                "ToSch": matchedValue?.Productcode_RTA,
                "TrType": "STP",
                "TransTypeDate": new Date().toJSON().slice(0, 10).split("-").reverse().join('/')
            }
          
            createTransaction(payload).then((response) => {
                // console.log("response for createTransaction", response)
                if (response.transaction_created != "" && response.transaction_created != null) {
                    getCartCount()
                    handleClose()
                    Swal.fire({
                        title: "Added to cart!",
                        icon: "success",
                        customClass: {
                            confirmButton: 'sweet-alert-button'
                        }
                    }).then(() => {
                        navigate("/cart", { state: { "value": payload.TrType, "subValue": "" } });
                    });
                }
            })
        })
    }

    //This function validates the values entered in the form
    const validateFormData = () => {
        let valid = true;
        setError(errorStateSTPInitialData);
        //To scheme
        if (newSchemeSch === "" || newSchemeSch === undefined) {
            if (newSchemeSch === "" || newSchemeSch === undefined) {
                setError((prevParams) => ({ ...prevParams, errorToSchemeID: true, errorToSchemeIDMsg: "Please select any Scheme" }));
                valid = false;
            }
            else {
                setError((prevParams) => ({ ...prevParams, errorToSchemeID: false, errorToSchemeIDMsg: "Please select any Scheme" }));
            }
            return valid;
        }

        //STP frequency
        if (!(newSchemeSch === "" || newSchemeSch === undefined) && (schemedata.Frequency === "" || schemedata.Frequency === null)) {
            if (schemedata.Frequency === "" || schemedata.Frequency === null) {
                setError((prevParams) => ({ ...prevParams, errorFrequency: true, errorFrequencyMsg: "Frequency can not be empty" }));
                valid = false;
            }
            else {
                setError((prevParams) => ({ ...prevParams, errorFrequency: false, errorFrequencyMsg: "Frequency can not be empty" }));
            }
            return valid;
        }

        if (!(schemedata.Frequency === "" || schemedata.Frequency === null)) {
            //STP amount
            if (schemedata?.InvestmentAmount.toString() === "" || schemedata?.InvestmentAmount.toString() === "0") {
                setError((prevParams) => ({ ...prevParams, errorSTPAmount: true, errorSTPAmountMsg: "Amount can not be empty" }));
                valid = false;
            }
            else if (Number(schemedata?.InvestmentAmount) < Number(selectedFrquencyValidations?.SIPMINIMUMINSTALLMENTAMOUNT) ||
                Number(schemedata?.InvestmentAmount) > Number(selectedFrquencyValidations?.SIPMAXIMUMINSTALLMENTAMOUNT)) {
                setError((prevParams) => ({ ...prevParams, errorSTPAmount: true, errorSTPAmountMsg: `Please enter amount greater than ${selectedFrquencyValidations?.SIPMINIMUMINSTALLMENTAMOUNT} and less than ${selectedFrquencyValidations?.SIPMAXIMUMINSTALLMENTAMOUNT}` }));
                valid = false;
            }
            else {
                setError((prevParams) => ({ ...prevParams, errorSTPAmount: false }));
            }

            // STP installment
            if (schemedata.No_of_Installments.toString() === "" || schemedata.No_of_Installments.toString() === "0") {
                setError((prevParams) => ({ ...prevParams, errorSTPNoOfInstalment: true, errorSTPNoOfInstalmentMsg: "Number of installments can not be empty" }));
                valid = false;
            }
            else if (Number(schemedata.No_of_Installments) < Number(selectedFrquencyValidations?.SIPMINIMUMINSTALLMENTNUMBERS) ||
                Number(schemedata.No_of_Installments) > Number(selectedFrquencyValidations?.SIPMAXIMUMINSTALLMENTNUMBERS)) {
                setError((prevParams) => ({ ...prevParams, errorSTPNoOfInstalment: true, errorSTPNoOfInstalmentMsg: `Please enter number greater than ${selectedFrquencyValidations?.SIPMINIMUMINSTALLMENTNUMBERS} and less than ${selectedFrquencyValidations?.SIPMAXIMUMINSTALLMENTNUMBERS}` }));
                valid = false;
            }
            else {
                setError((prevParams) => ({ ...prevParams, errorSTPNoOfInstalment: false }));
            }

            //STP Day
            if (schemedata?.SIP_date === null || schemedata?.SIP_date === "") {
                setError((prevParams) => ({ ...prevParams, errorSTPDay: true, errorSTPDayMsg: "STP Date can not be empty" }));
                valid = false;
            }
            else {
                setError((prevParams) => ({ ...prevParams, errorSTPDay: false }));
            }
        }
        return valid;
    }

    return (
        <Box sx={{ mx: { xs: 3, sm: 6 } }}>
            <Box sx={{ my: { xs: 0, sm: 1.5 } }}>
                <Typography>To Scheme</Typography>
                <input type="text" disabled className='investmentAmount2 toScheme' value={schemedata.ToschemeName}
                // onChange={(e) => {
                //     let newValue = e.target.value;

                //     newValue = newValue.replace(/[^0-9]/g, '');

                //     if (newValue.length < schemeParams.instalments.toString().length) {
                //         newValue = newValue.slice(0, -1);
                //     }

                //     setSchemeParams({ ...schemeParams, instalments: newValue });
                // }}
                >
                </input>
                {/* {error.errorToSchemeID && <Typography sx={{ fontSize: 10, color: 'red', mb: 0.5 }}> {error.errorToSchemeIDMsg} </Typography>} */}
            </Box>
            {loadingForm?
                <Box sx={{ display: 'flex', justifyContent: "center", alignItems: "center", mt: 5 }}>
                    <CircularProgress />
                </Box> : <>
                    <Box sx={{ my: 1.5 }}>
                        <Typography>Frequency</Typography>
                        <FormControl sx={{ width: '100%' }} >
                            <Select
                                labelId="demo-simple-select-label"
                                id="demo-simple-select"
                                value={schemedata.Frequency}
                                onChange={(e) => {
                                    setSchemeData({ ...schemedata, Frequency: e.target.value })
                                    changeValidationsOnFrequencyChange(e.target.value);
                                }}
                                defaultValue={schemedata.Frequency}
                                inputProps={{ 'aria-label': 'Without label' }}
                            >
                                {schemeValidation?.map((item: any, index: any) => (
                                    <MenuItem key={index} value={item.SIPFREQUENCY}>{item.SIPFREQUENCY}</MenuItem>
                                ))}
                            </Select>
                        </FormControl>
                        {error.errorFrequency && <Typography sx={{ fontSize: 10, color: 'red', mb: 0.5 }}> {error.errorFrequencyMsg} </Typography>}
                    </Box>

                    {schemeValidation?.some((val: any) => val.SIPFREQUENCY == schemedata?.Frequency) &&
                        <>
                            {/* STP Day */}
                            <Box sx={{ my: 1.5 }}>
                                <Typography>STP Day</Typography>
                                <DatePicker
                                    className="custom-datepicker"
                                    // ref={datePickerRef}
                                    selected={selectedDate}
                                    onChange={(date: Date) => {
                                        setSelectedDate(date)
                                        const mapToDoubleDigit = (number: number): string => {
                                            return number < 9 ? `0${number + 1}` : `${number + 1}`;
                                        };
                                        const mapDayToDoubleDigit = (number: any): string => {
                                            return number <= 9 ? `0${number}` : `${number}`;
                                        };
                                        setSchemeData({ ...schemedata, SIP_date: `${date?.getFullYear()}-${mapToDoubleDigit(date?.getMonth())}-${mapDayToDoubleDigit(date?.getDate())}` });
                                    }}
                                    dateFormat="dd-MM-yyyy"
                                    filterDate={isDateDisabled}
                                    placeholderText={'dd-mm-yyyy'}
                                // customInput={<CustomInput />}

                                />
                                {error.errorSTPDay && <Typography sx={{ fontSize: 10, color: 'red', mb: 0.5 }}> {error.errorSTPDayMsg} </Typography>}
                            </Box>

                            {/* No. of installments */}
                            <Box sx={{ my: 1.5 }}>
                                <Typography>No. of Installments</Typography>
                                <input type="text" className='investmentAmount2' value={schemedata.No_of_Installments}
                                    onChange={(e) => {
                                        let newValue = e.target.value;
                                        newValue = newValue.replace(/[^0-9]/g, '')
                                        setSchemeData({ ...schemedata, No_of_Installments: Number(newValue) });
                                    }}
                                >
                                </input>
                                {error.errorSTPNoOfInstalment && <Typography sx={{ fontSize: 10, color: 'red', mb: 0.5 }}> {error.errorSTPNoOfInstalmentMsg} </Typography>}
                            </Box>

                            {/* First Order Today */}
                            <Box sx={{ display: 'flex', flexDirection: 'row', my: 1.5 }}>
                                <Checkbox
                                    checked={checked}
                                    onChange={(e) => { setChecked(!checked) }}
                                    inputProps={{ 'aria-label': 'controlled' }}
                                    sx={{ p: 0, m: 0 }}
                                />
                                <Typography sx={{ mx: 2 }} >First Order Today</Typography>

                            </Box>

                            {/* Amount */}
                            <Box sx={{ my: 1.5 }}>
                                <Typography>Monthly Amount </Typography>
                                <input type="text" className='investmentAmount2' value={schemedata?.InvestmentAmount}
                                    onChange={(e) => {
                                        let newValue = e.target.value;
                                        newValue = newValue.replace(/[^0-9]/g, '');
                                        setSchemeData({ ...schemedata, InvestmentAmount: Number(newValue) });
                                    }}
                                >
                                </input>
                                {error.errorSTPAmount && <Typography sx={{ fontSize: 10, color: 'red', mb: 0.5 }}> {error.errorSTPAmountMsg} </Typography>}
                            </Box>
                        </>}

                    <Box sx={{ display: 'flex', flexDirection: 'column', mt: 3 }}>
                        <i style={{ fontSize: '11px', fontWeight: 500, justifyContent: 'center', width: '70%', margin: '0% 0% 0% 15%' }}>
                            By continuing, I agree with <span style={{ color: 'green' }}> Disclaimers</span> and <span style={{ color: 'green' }}> Terms and Conditions </span> of Kfin Technologies Limited
                        </i>
                        <Button
                            sx={{
                                background: 'linear-gradient(90deg, #36DAE9, #0090FF)',
                                width: '100%',
                                height: "2.5rem",
                                color: '#ffffff',
                                borderRadius: '8px',
                                mt: 3
                            }}
                            onClick={handleClick}
                        >
                            {loading ? <Box sx={{ display: 'flex' }}>
                                <CircularProgress style={{ color: "white" }} size="1.8rem" />
                            </Box> :
                                "Add To Cart"}
                        </Button>
                    </Box></>}
        </Box>

    )
}

export const SWP_Form = ({ recommendedDate, recommendedSchemeData, handleClose }:
    { recommendedDate: any, recommendedSchemeData: any, handleClose: () => void }) => {

    const { getBSECode, createTransaction } = useGetTotalData();
    const [selectedDate, setSelectedDate] = useState<Date | null>(null);
    const [checked, setChecked] = useState(false);
    const { getCartCount } = useLoginContext();
    const navigate = useNavigate();
    const [schemeData, setSchemeData] = useState<any>(recommendedSchemeData)
    const [schemeValidation, setSchemeValidation] = useState<ValidationForSIP[]>();
    const [selectedFrquencyValidations, SetSelectedFrquencyValidations] = useState<ValidationForSIP | undefined>();
    const [error, setError] = useState<errorStatesSWP>(errorStateSWPInitialData);
    const { getValidationDetails, validation } = useGetTotalData();
    const [loading, setLoading] = useState(false);
    const [loadingForm, setLoadingForm] = useState(true);

    useEffect(() => {
        if (recommendedDate != undefined) {
            setSelectedDate(new Date(recommendedDate))
        }
    }, [])

    useEffect(() => {
        if(validation?.length!=0) setTimeout(()=>{setLoadingForm(false)},1000)
        setSchemeValidation(validation);
    }, [validation, recommendedSchemeData])

    useEffect(() => {
        SetSelectedFrquencyValidations(schemeValidation?.filter((item: any) => item.SIPFREQUENCY === schemeData.Frequency)[0]);
    }, [schemeValidation])

    useEffect(() => {
        try {
            if (recommendedSchemeData && recommendedSchemeData.Sch) {
                getValidationDetails({ sch: recommendedSchemeData.Sch, TrType: "SWP" });

            } else {
                console.log("selectedSchemeData or selectedSchemeData.SCh is undefined");
            }
        } catch (error) {
            console.error("Error ", error);
        }
    }, [recommendedSchemeData]);

    const changeValidationsOnFrequencyChange = (FrequencyVal: any) => {
        SetSelectedFrquencyValidations(schemeValidation?.filter((item: any) => item.SIPFREQUENCY === FrequencyVal)[0]);
    }

    const isDateDisabled = (date: Date): boolean => {

        const currentDate = new Date();
        currentDate.setHours(0, 0, 0, 0);
        if (date < currentDate) {
            return false;
        }

        let foundValue: any = schemeValidation?.find((val: any) => val.SIPFREQUENCY == schemeData.Frequency);
        let datesArray: any = foundValue?.SIPDATES.split(',');

        if (datesArray.includes(date.getDate().toString())) {
            return true;
        } else {
            return false;
        }
    };

    const handleClick = (item: any) => {
        if (!validateFormData()) {
            return;
        }
        else {
            setLoading(true);
        }
        let payload: any = {}
        getBSECode({
            "TrType": schemeData.SchemeType,
            "Amount": schemeData?.InvestmentAmount.toString(),
            "Growthoption": schemeData?.Growthoption,
            "DividendReinvestment": schemeData?.Dividendreinvestment,
            "RTACODE": schemeData?.Sch
        }).then(async ({ bse_code }) => {
            payload = {
                "RecId": schemeData?.RecID,
                "AccNo": schemeData?.Folio,
                "AmcId": schemeData?.AmcID,
                "BSE_SchemeCode": bse_code[0][0]?.BSE_ProductCod,
                "EndDate": "05/09/2026",
                "FParFul": "p",
                "FUnsAmt": "a",
                "FirstOrderToday": checked == true ? "Y" : "N",
                "Frequency": frequencyMapping[schemeData.Frequency],
                "Installments": frequencyMapping[schemeData.Frequency] == '1' ? '' : schemeData?.No_of_Installments,
                "InstallmentsAmt": schemeData?.InvestmentAmount,
                "Sch": schemeData?.Sch,
                "StartDate": schemeData?.SIP_date.slice(0, 10).split("-").reverse().join('/'), // SIP_DATE
                "TrType": "SWP",
                "TransTypeDate": new Date().toJSON().slice(0, 10).split("-").reverse().join('/'), // Current date
                "Units": "0"
            }
         
            createTransaction(payload).then((response) => {
                console.log("response for createTransaction", response)
                if (response.transaction_created != "" && response.transaction_created != null) {
                    getCartCount()
                    handleClose()
                    Swal.fire({
                        title: "Added to cart!",
                        icon: "success",
                        customClass: {
                            confirmButton: 'sweet-alert-button'
                        }
                    }).then(() => {
                        navigate("/cart", { state: { "value": payload.TrType, "subValue": "" } });
                    });
                }
            })
        })
    }


    //This function validates the values entered in the form
    const validateFormData = () => {
        let valid = true;
        setError(errorStateSWPInitialData);

        //SWP frequency
        if (schemeData.Frequency === "" || schemeData.Frequency === null) {
            if (schemeData.Frequency === "" || schemeData.Frequency === null) {
                setError((prevParams) => ({ ...prevParams, errorFrequency: true, errorFrequencyMsg: "Frequency can not be empty" }));
                valid = false;
            }
            else {
                setError((prevParams) => ({ ...prevParams, errorFrequency: false, errorFrequencyMsg: "Frequency can not be empty" }));
            }
            return valid;
        }

        if (!(schemeData.Frequency === "" || schemeData.Frequency === null)) {
            //SWP amount
            if (schemeData?.InvestmentAmount.toString() === "" || schemeData?.InvestmentAmount.toString() === "0") {
                setError((prevParams) => ({ ...prevParams, errorSWPAmount: true, errorSWPAmountMsg: "Amount can not be empty" }));
                valid = false;
            }
            else if (Number(schemeData?.InvestmentAmount) < Number(selectedFrquencyValidations?.SIPMINIMUMINSTALLMENTAMOUNT) ||
                Number(schemeData?.InvestmentAmount) > Number(selectedFrquencyValidations?.SIPMAXIMUMINSTALLMENTAMOUNT)) {
                setError((prevParams) => ({ ...prevParams, errorSWPAmount: true, errorSWPAmountMsg: `Please enter amount greater than ${selectedFrquencyValidations?.SIPMINIMUMINSTALLMENTAMOUNT} and less than ${selectedFrquencyValidations?.SIPMAXIMUMINSTALLMENTAMOUNT}` }));
                valid = false;
            }
            else {
                setError((prevParams) => ({ ...prevParams, errorSWPAmount: false }));
            }

            // SWP installment
            if (schemeData.No_of_Installments.toString() === "" || schemeData.No_of_Installments.toString() === "0") {
                setError((prevParams) => ({ ...prevParams, errorSWPNoOfInstalment: true, errorSWPNoOfInstalmentMsg: "Number of installments can not be empty" }));
                valid = false;
            }
            else if (Number(schemeData.No_of_Installments) < Number(selectedFrquencyValidations?.SIPMINIMUMINSTALLMENTNUMBERS) ||
                Number(schemeData.No_of_Installments) > Number(selectedFrquencyValidations?.SIPMAXIMUMINSTALLMENTNUMBERS)) {
                setError((prevParams) => ({ ...prevParams, errorSWPNoOfInstalment: true, errorSWPNoOfInstalmentMsg: `Please enter number greater than ${selectedFrquencyValidations?.SIPMINIMUMINSTALLMENTNUMBERS} and less than ${selectedFrquencyValidations?.SIPMAXIMUMINSTALLMENTNUMBERS}` }));
                valid = false;
            }
            else {
                setError((prevParams) => ({ ...prevParams, errorSWPNoOfInstalment: false }));
            }

            //SWP Day
            if (schemeData?.SIP_date === null || schemeData?.SIP_date === "") {
                setError((prevParams) => ({ ...prevParams, errorSWPDay: true, errorSWPDayMsg: "SWP Date can not be empty" }));
                valid = false;
            }
            else {
                setError((prevParams) => ({ ...prevParams, errorSWPDay: false }));
            }
        }
        return valid;
    }

    return (
        <Box sx={{ mx: { xs: 3, sm: 6 } }}>
             {loadingForm?
                <Box sx={{ display: 'flex', justifyContent: "center", alignItems: "center", mt: 5 }}>
                    <CircularProgress />
                </Box> : <>
            <Box sx={{ my: { xs: 0, sm: 1.5 } }}>
                <Typography>Frequency</Typography>
                <FormControl sx={{ width: '100%' }} >
                    <Select
                        labelId="demo-simple-select-label"
                        id="demo-simple-select"
                        value={schemeData?.Frequency}
                        onChange={(e) => {
                            setSchemeData({ ...schemeData, Frequency: e.target.value })
                            changeValidationsOnFrequencyChange(e.target.value);
                        }}
                        defaultValue={schemeData?.Frequency}
                        inputProps={{ 'aria-label': 'Without label' }}
                    >
                        {schemeValidation?.map((item: any, index: any) => (
                            <MenuItem key={index} value={item.SIPFREQUENCY}>{item.SIPFREQUENCY}</MenuItem>
                        ))}
                    </Select>
                </FormControl>
                {error.errorFrequency && <Typography sx={{ fontSize: 10, color: 'red', mb: 0.5 }}> {error.errorFrequencyMsg} </Typography>}
            </Box>

            {schemeValidation?.some((val: any) => val.SIPFREQUENCY == schemeData?.Frequency) &&
                <>
                    {/* SWP Day */}
                    <Box sx={{ my: 1.5 }}>
                        <Typography>SWP Day</Typography>
                        <DatePicker
                            className="custom-datepicker"
                            // ref={datePickerRef}
                            selected={selectedDate}
                            onChange={(date: Date) => {
                                setSelectedDate(date)
                                const mapToDoubleDigit = (number: number): string => {
                                    return number < 9 ? `0${number + 1}` : `${number + 1}`;
                                };
                                const mapDayToDoubleDigit = (number: any): string => {
                                    return number <= 9 ? `0${number}` : `${number}`;
                                };
                                setSchemeData({ ...schemeData, SIP_date: `${date?.getFullYear()}-${mapToDoubleDigit(date?.getMonth())}-${mapDayToDoubleDigit(date?.getDate())}` });
                            }}
                            dateFormat="dd-MM-yyyy"
                            filterDate={isDateDisabled}
                            placeholderText={'dd-mm-yyyy'}
                        // customInput={<CustomInput />}

                        />
                        {error.errorSWPDay && <Typography sx={{ fontSize: 10, color: 'red', mb: 0.5 }}> {error.errorSWPDayMsg} </Typography>}
                    </Box>

                    {/* No. of installments */}
                    <Box sx={{ my: 1.5 }}>
                        <Typography>No. of Installments</Typography>
                        <input type="text" className='investmentAmount2' value={schemeData.No_of_Installments}
                            onChange={(e) => {
                                let newValue = e.target.value;
                                newValue = newValue.replace(/[^0-9]/g, '')
                                setSchemeData({ ...schemeData, No_of_Installments: Number(newValue) });
                            }}
                        >
                        </input>
                        {error.errorSWPNoOfInstalment && <Typography sx={{ fontSize: 10, color: 'red', mb: 0.5 }}> {error.errorSWPNoOfInstalmentMsg} </Typography>}
                    </Box>

                    {/* First Order Today */}
                    <Box sx={{ display: 'flex', flexDirection: 'row', my: 1.5 }}>
                        <Checkbox
                            checked={checked}
                            onChange={(e) => { setChecked(!checked) }}
                            inputProps={{ 'aria-label': 'controlled' }}
                            sx={{ p: 0, m: 0 }}
                        />
                        <Typography sx={{ mx: 2 }} >First Order Today</Typography>

                    </Box>

                    {/* Amount */}
                    <Box sx={{ my: 1.5 }}>
                        <Typography>Monthly Amount </Typography>
                        <input type="text" className='investmentAmount2' value={schemeData?.InvestmentAmount}
                            onChange={(e) => {
                                let newValue = e.target.value;
                                newValue = newValue.replace(/[^0-9]/g, '');
                                setSchemeData({ ...schemeData, InvestmentAmount: Number(newValue) });
                            }}
                        >
                        </input>
                        {error.errorSWPAmount && <Typography sx={{ fontSize: 10, color: 'red', mb: 0.5 }}> {error.errorSWPAmountMsg} </Typography>}
                    </Box>

                </>}
            <Box sx={{ display: 'flex', flexDirection: 'column', mt: 3 }}>
                <i style={{ fontSize: '11px', fontWeight: 500, justifyContent: 'center', width: '70%', margin: '0% 0% 0% 15%' }}>
                    By continuing, I agree with <span style={{ color: 'green' }}> Disclaimers</span> and <span style={{ color: 'green' }}> Terms and Conditions </span> of Kfin Technologies Limited
                </i>
                <Button
                    sx={{
                        background: 'linear-gradient(90deg, #36DAE9, #0090FF)',
                        width: '100%',
                        height: "2.5rem",
                        color: '#ffffff',
                        borderRadius: '8px',
                        mt: 3
                    }}
                    onClick={handleClick}
                >
                    {loading ? <Box sx={{ display: 'flex' }}>
                        <CircularProgress style={{ color: "white" }} size="1.8rem" />
                    </Box> :
                        "Add To Cart"}
                </Button>
            </Box></>}
        </Box>
    )
}

export const SWT_Form = ({ recommendedDate, recommendedSchemeData, handleClose }:
    { recommendedDate: any, recommendedSchemeData: any, handleClose: () => void }) => {

    const { getBSECode, createTransaction } = useGetTotalData();
    const [selectedDate, setSelectedDate] = useState<Date | null>(null);
    const [checked, setChecked] = useState(false);
    const { getCartCount } = useLoginContext();
    const navigate = useNavigate();
    const [schemedata, setSchemeData] = useState<any>(recommendedSchemeData)
    const { schemeData, getSchemeData, redeemValidation, redemptionValidation } = useGetTotalData();
    const [error, setError] = useState<errorStatesSWT>(errorStateSWTInitialData);
    const [newSchemeSch, setNewSchemeSch] = useState<string>("");
    const [schemeValidation, setSchemeValidation] = useState<redeemValidationType>();
    const [switchValue, setSwitchValue] = useState<any>({ value: (schemedata?.PFFlag == "F" ? schemeValidation?.Amount : (recommendedSchemeData?.InvestmentAmount != null || recommendedSchemeData?.InvestmentAmount != undefined) ? recommendedSchemeData?.InvestmentAmount.toString() : "0"), type: "INR" })
    const [loading, setLoading] = useState(false);

    //To set validation data in local state variable
    useEffect(() => {
        setSchemeValidation(redeemValidation);
        if (schemedata?.PFFlag == "F" && redeemValidation != undefined) {
            setSwitchValue({ value: redeemValidation?.Amount, type: "INR" })
        }
    }, [redeemValidation, recommendedSchemeData])

    //To fetch Validation data
    useEffect(() => {
        try {
            if (recommendedSchemeData && recommendedSchemeData.Sch) {
                redemptionValidation({ AccNo: recommendedSchemeData.Folio, SchId: recommendedSchemeData.SchemeID });
            } else {
                console.log("selectedSchemeData or selectedSchemeData.SCh is undefined");
            }
        } catch (error) {
            console.error("Error ", error);
        }
    }, [recommendedSchemeData]);

    useEffect(() => {
        if (schemeData != undefined) {
            let foundValue: any = schemeData?.find((val: any) => {
                return val.Sch_Desc == schemedata.ToschemeName
            })
            setNewSchemeSch(foundValue?.Productcode_RTA)
        }
    }, [schemeData])

    useEffect(() => {
        try {
            getSchemeData(
                {
                    "AstId": "1",
                    "AmcId": `${recommendedSchemeData.AmcID}`
                }, 'SwitchFLAG'
            )
        } catch (error) {
            console.error("Error ", error);
        }
    }, []);

    const handleClick = () => {
        if (!validateFormData()) {
            return;
        }
        else {
            setLoading(true);
        }
        let payload: any = {}
        getBSECode({
            "TrType": 'Swt',
            "Amount": switchValue?.value.toString(),
            "Growthoption": schemedata?.Growthoption,
            "DividendReinvestment": schemedata?.Dividendreinvestment,
            "RTACODE": schemedata?.Sch
        }).then(async ({ bse_code }) => {
            let { schemes } = await get_switch_schemes({
                "AstId": "1",
                "AmcId": schemedata?.AmcID.toString()
            })
            let matchedValue: any = schemes[0].find((value: any) => value.Sch_ID.split('~')[0] == schemedata.ToschemeID)
            let response: any = await getBSECode({
                "TrType": 'Swt',
                "Amount": switchValue?.value.toString(),
                "Growthoption": schemedata?.Growthoption,
                "DividendReinvestment": schemedata?.Dividendreinvestment,
                "RTACODE": matchedValue?.Productcode_RTA
            })
            payload = {
                "RecId": schemedata?.RecID,
                "AccNo": schemedata?.Folio,
                "AmcId": schemedata?.AmcID,
                "Amount": switchValue?.value,
                "BSE_SchemeCode": bse_code[0][0]?.BSE_ProductCod,
                "DividendReinvestment": schemedata?.Dividendreinvestment,
                "FParFul": schemedata?.PFFlag,
                "FUnsAmt": switchValue?.type == "INR" ? "a" : "u",
                "Growthoption": schemedata?.Growthoption,
                "Sch": schemedata?.Sch,
                "ToBSE_SchemeCode": response?.bse_code[0][0]?.BSE_ProductCod,
                "ToSch": matchedValue?.Productcode_RTA,
                "TrType": "Swt",
                "Units": switchValue?.value
            }
           
            createTransaction(payload).then((response) => {
                // console.log("response for createTransaction", response)
                if (response.transaction_created != "" && response.transaction_created != null) {
                    getCartCount()
                    handleClose()
                    Swal.fire({
                        title: "Added to cart!",
                        icon: "success",
                        customClass: {
                            confirmButton: 'sweet-alert-button'
                        }
                    }).then(() => {
                        navigate("/cart", { state: { "value": payload.TrType, "subValue": "" } });
                    });
                }
            })
        })
    }

    //This function validates the values entered in the form
    const validateFormData = () => {
        let valid = true;
        setError(errorStateSWTInitialData);
        const validationAmount = schemeValidation ? schemeValidation.Amount : schemedata.Aum;
        const validationUnit = schemeValidation ? schemeValidation.Units : schemedata.Units;
        //To scheme
        if (newSchemeSch === "" || newSchemeSch === undefined) {
            if (newSchemeSch === "" || newSchemeSch === undefined) {
                setError((prevParams) => ({ ...prevParams, errorToSchemeID: true, errorToSchemeIDMsg: "Please select any Scheme" }));
                valid = false;
            }
            else {
                setError((prevParams) => ({ ...prevParams, errorToSchemeID: false, errorToSchemeIDMsg: "Please select any Scheme" }));
            }
            return valid;
        }

        //STP frequency
        if (!(newSchemeSch === "" || newSchemeSch === undefined)) {
            if (switchValue.value === "" || switchValue.value === "0") {
                setError((prevParams) => ({ ...prevParams, errorSwitchValue: true, errorSwitchValueMsg: "Amount can not be empty" }));
                valid = false;
            }
            else if (switchValue.value && (schemedata?.PFFlag == "P" && switchValue.type === "INR" && Number(switchValue.value) > validationAmount)) {
                setError((prevParams) => ({ ...prevParams, errorSwitchValue: true, errorSwitchValueMsg: `Switch Amount cannot exceed ${validationAmount}` }));
                valid = false;
            }
            else if (switchValue.value && (schemedata?.PFFlag == "P" && switchValue.type === "Units" && Number(switchValue.value) > validationUnit)) {
                setError((prevParams) => ({ ...prevParams, errorSwitchValue: true, errorSwitchValueMsg: `Switch Amount cannot exceed ${validationUnit} units` }));
                valid = false;
            }
            else {
                setError((prevParams) => ({ ...prevParams, errorSwitchValue: false }));
            }
        }

        return valid;
    }

    return (
        <Box sx={{ mx: { xs: 3, sm: 6 } }}>
            <Box sx={{ my: { xs: 0, sm: 1.5 } }}>
                <Typography>To Scheme</Typography>
                <input type="text" disabled className='investmentAmount2 toScheme' value={schemedata.ToschemeName}
                // onChange={(e) => {
                //     let newValue = e.target.value;

                //     newValue = newValue.replace(/[^0-9]/g, '');

                //     if (newValue.length < schemeParams.instalments.toString().length) {
                //         newValue = newValue.slice(0, -1);
                //     }

                //     setSchemeParams({ ...schemeParams, instalments: newValue });
                // }}
                >
                </input>
                {/* {error.errorToSchemeID && <Typography sx={{ fontSize: 10, color: 'red', mb: 0.5 }}> {error.errorToSchemeIDMsg} </Typography>} */}
            </Box>
            {/* Partial / Full */}
            <Box sx={{ display: "flex", alignItems: 'center', justifyContent: "space-between", width: { xs: 300, sm: 400 } }}>
                <FormLabel id="demo-row-radio-buttons-group-label" sx={{ fontWeight: 500, mt: 3, mb: 1 }}>Switch Type</FormLabel>
                <RadioGroup sx={{ pt: "1rem" }}
                    row
                    aria-labelledby="demo-row-radio-buttons-group-label"
                    name="row-radio-buttons-group"
                    value={schemedata?.PFFlag == "P" ? "Partial" : "Full"}
                    onChange={(e) => {
                        if (e.target.value == "Full" && switchValue.type == "INR") {
                            setSwitchValue({ ...switchValue, value: schemeValidation?.Amount })
                        }
                        else if (e.target.value == "Full" && switchValue.type == "Units") {
                            setSwitchValue({ ...switchValue, value: schemeValidation?.Units })
                        }
                        else {
                            setSwitchValue({ ...switchValue, value: schemedata?.InvestmentAmount })
                        }
                        setSchemeData({ ...schemedata, PFFlag: e.target.value == "Partial" ? "P" : "F" })
                    }}
                >
                    <FormControlLabel value="Partial" control={<Radio />} label="Partial" />
                    <FormControlLabel value="Full" control={<Radio />} label="Full" />
                </RadioGroup>
            </Box>

            <Box sx={{ width: '100%', my: 1.5 }}>
                <Typography>Switch Amount</Typography>
                <input type="text" className='investmentAmount2'
                    value={switchValue.value}
                    disabled={schemedata?.PFFlag == "F" ? true : false}
                    onChange={(e) => {
                        let newValue = e.target.value;
                        newValue = newValue.replace(/[^0-9]/g, '');
                        setSwitchValue({ ...switchValue, value: newValue })
                    }}
                >
                </input>
                {error.errorSwitchValue && <Typography sx={{ fontSize: 10, color: 'red', mb: 0.5 }}> {error.errorSwitchValueMsg} </Typography>}
            </Box>

            <Box sx={{ display: "flex", flexDirection: "column", alignItems: 'flex-start', justifyContent: "space-between", width: { xs: 300, sm: 400 } }}>
                <RadioGroup sx={{ display: "flex", flexDirection: "row", mt: "0.5rem", ml: "0.5rem" }}
                    onChange={(e) => {
                        if (e.target.value == "INR" && schemedata?.PFFlag == "F") {
                            setSwitchValue({ value: schemeValidation?.Amount, type: e.target.value })
                        }
                        else if (e.target.value == "Units" && schemedata?.PFFlag == "F") {
                            setSwitchValue({ value: schemeValidation?.Units, type: e.target.value })
                        }
                        else {
                            setSwitchValue({ value: schemedata?.InvestmentAmount, type: e.target.value })
                        }
                    }}
                    value={switchValue.type}
                >
                    <FormControlLabel value="INR" control={<Radio />} label="INR" />
                    <FormControlLabel value="Units" control={<Radio />} label="Units" />
                </RadioGroup>
            </Box>

            <Box sx={{ display: 'flex', flexDirection: 'column', mt: 3 }}>
                <i style={{ fontSize: '11px', fontWeight: 500, justifyContent: 'center', width: '70%', margin: '0% 0% 0% 15%' }}>
                    By continuing, I agree with <span style={{ color: 'green' }}> Disclaimers</span> and <span style={{ color: 'green' }}> Terms and Conditions </span> of Kfin Technologies Limited
                </i>
                <Button
                    sx={{
                        background: 'linear-gradient(90deg, #36DAE9, #0090FF)',
                        width: '100%',
                        height: "2.5rem",
                        color: '#ffffff',
                        borderRadius: '8px',
                        mt: 3
                    }}
                    onClick={handleClick}
                >
                    {loading ? <Box sx={{ display: 'flex' }}>
                        <CircularProgress style={{ color: "white" }} size="1.8rem" />
                    </Box> :
                        "Add To Cart"}
                </Button>
            </Box>

        </Box>

    )
}

export const Redeemtion_Form = ({ recommendedDate, recommendedSchemeData, handleClose }:
    { recommendedDate: any, recommendedSchemeData: any, handleClose: () => void }) => {

    const { getBSECode, createTransaction } = useGetTotalData();
    const { getCartCount } = useLoginContext();
    const navigate = useNavigate();
    const [schemeData, setSchemeData] = useState<any>(recommendedSchemeData)
    const { redeemValidation, redemptionValidation } = useGetTotalData();
    const [error, setError] = useState<errorStatesRedeem>(errorStateRedeemInitialData);
    const [schemeValidation, setSchemeValidation] = useState<redeemValidationType>();
    const [redemptionType,setRedemptionType]=useState("Partial")
    const [redeemValue, setRedeemValue] = useState<any>({ value: (redemptionType == "Full" ? schemeValidation?.Amount : (recommendedSchemeData?.InvestmentAmount != null || recommendedSchemeData?.InvestmentAmount != undefined) ? recommendedSchemeData?.InvestmentAmount.toString() : "0"), type: "INR" })
    const [loading, setLoading] = useState(false);

    //To set validation data in local state variable
    useEffect(() => {
        setSchemeValidation(redeemValidation);
        if (redemptionType == "Full" && redeemValidation != undefined) {
            setRedeemValue({ value: redeemValidation?.Amount, type: "INR" })
        }
    }, [redeemValidation, recommendedSchemeData])

    useEffect(() => {
        try {
            if (recommendedSchemeData && recommendedSchemeData.Sch) {
                redemptionValidation({ AccNo: recommendedSchemeData.Folio, SchId: recommendedSchemeData.SchemeID });
            } else {
                console.log("selectedSchemeData or selectedSchemeData.SCh is undefined");
            }
        } catch (error) {
            console.error("Error ", error);
        }
    }, [recommendedSchemeData]);

    //This function validates the values entered in the form
    const validateFormData = () => {
        let valid = true;
        setError(errorStateRedeemInitialData);
        const validationAmount = schemeValidation ? schemeValidation.Amount : schemeData.Aum;
        const validationUnit = schemeValidation ? schemeValidation.Units : schemeData.Units;

        if (redeemValue.value === "" || redeemValue.value === "0" || redeemValue.value === undefined || redeemValue.value === 0) {
            setError((prevParams) => ({ ...prevParams, errorRedeemValue: true, errorRedeemValueMsg: "Amount can not be empty" }));
            valid = false;
        }
        else if (redeemValue.value && (redemptionType== "Partial" && redeemValue.type === "INR" && Number(redeemValue.value) > validationAmount)) {
            setError((prevParams) => ({ ...prevParams, errorRedeemValue: true, errorRedeemValueMsg: `Redemption Amount cannot exceed ${validationAmount}` }));
            valid = false;
        }
        else if (redeemValue.value && (redemptionType == "Partial" && redeemValue.type === "Units" && Number(redeemValue.value) > validationUnit)) {
            setError((prevParams) => ({ ...prevParams, errorRedeemValue: true, errorRedeemValueMsg: `Redemption Amount cannot exceed ${validationUnit} units` }));
            valid = false;
        }
        else {
            setError((prevParams) => ({ ...prevParams, errorRedeemValue: false }));
        }

        return valid;
    }


    const handleClick = (item: any) => {
        if (!validateFormData()) {
            return;
        }
        else {
            setLoading(true);
        }
        let payload: any = {}
        getBSECode({
            "TrType": 'Red',
            "Amount": redeemValue.value.toString(),
            "Growthoption": schemeData?.Growthoption,
            "DividendReinvestment": schemeData?.Dividendreinvestment,
            "RTACODE": schemeData?.Sch
        }).then(async ({ bse_code }) => {
            payload = {
                "RecId": schemeData?.RecID,
                "AccNo": schemeData?.Folio,
                "AmcId": schemeData?.AmcID,
                "Amount": redeemValue.value,
                "BSE_Scheme_code": bse_code[0][0]?.BSE_ProductCod,
                "FParFul": schemeData?.PFFlag,
                "FUnsAmt": redeemValue.type == "INR" ? "a" : "u",
                "Sch": schemeData?.Sch,
                "TrType": "Red",
                "Units": redeemValue.value
            }
         
            createTransaction(payload).then((response) => {
                // console.log("response for createTransaction", response)
                if (response.transaction_created != "" && response.transaction_created != null) {
                    getCartCount()
                    handleClose()
                    Swal.fire({
                        title: "Added to cart!",
                        icon: "success",
                        customClass: {
                            confirmButton: 'sweet-alert-button'
                        }
                    }).then(() => {
                        navigate("/cart", { state: { "value": payload.TrType, "subValue": "" } });
                    });
                }
            })
        })
    }

    return (
        <Box sx={{ mx: { xs: 3, sm: 6 } }}>
            <Box sx={{ my: { xs: 0, sm: 1.5 } }}>
                {/* Partial / Full */}
                <Box sx={{ display: "flex", alignItems: 'center', justifyContent: "space-between", width: { xs: 300, sm: 400 } }}>
                    <FormLabel id="demo-row-radio-buttons-group-label" sx={{ fontWeight: 500, mt: 3, mb: 1, mr: 1 }}>Redemption Type</FormLabel>
                    <RadioGroup sx={{ pt: "1rem" }}
                        row
                        aria-labelledby="demo-row-radio-buttons-group-label"
                        name="row-radio-buttons-group"
                        value={redemptionType}
                        onChange={(e) => {
                            if (e.target.value == "Full" && redeemValue.type == "INR") {
                                setRedeemValue({ ...redeemValue, value: schemeValidation?.Amount })
                            }
                            else if (e.target.value == "Full" && redeemValue.type == "Units") {
                                setRedeemValue({ ...redeemValue, value: schemeValidation?.Units })
                            }
                            else {
                                setRedeemValue({ ...redeemValue, value: schemeData?.InvestmentAmount })
                            }
                            setSchemeData({ ...schemeData, PFFlag: e.target.value == "Partial" ? "P" : "F" })
                            setRedemptionType(e.target.value as string)
                        }}
                    >
                        <FormControlLabel value="Partial" control={<Radio />} label="Partial" />
                        <FormControlLabel value="Full" control={<Radio />} label="Full" />
                    </RadioGroup>
                </Box>

                <Box sx={{ my: 1.5 }}>
                    <Typography>Redemption Amount <span style={{color:'grey', fontSize:'0.8rem'}}>(you can redeem upto {redeemValue.type=='INR'?`₹${redeemValue.value}`:`${redeemValue.value} units`})</span></Typography>
                    <input type="text" className='investmentAmount2'
                        value={redeemValue.value}
                        disabled={redemptionType == "Full" ? true : false}
                        onChange={(e) => {
                            let newValue = e.target.value;
                            newValue = newValue.replace(/[^0-9]/g, '');
                            setRedeemValue({ ...redeemValue, value: newValue })
                        }}
                    >
                    </input>
                    {error.errorRedeemValue && <Typography sx={{ fontSize: 10, color: 'red', mb: 0.5 }}> {error.errorRedeemValueMsg} </Typography>}
                </Box>

                <Box sx={{ display: "flex", flexDirection: "column", alignItems: 'flex-start', justifyContent: "space-between", width: { xs: 300, sm: 400 } }}>
                    <RadioGroup sx={{ display: "flex", flexDirection: "row", mt: "0.5rem", ml: "0.5rem" }}

                        onChange={(e) => {
                            if (e.target.value == "INR" && schemeData?.PFFlag == "F") {
                                setRedeemValue({ value: schemeValidation?.Amount, type: e.target.value })
                            }
                            else if (e.target.value == "Units" && schemeData?.PFFlag == "F") {
                                setRedeemValue({ value: schemeValidation?.Units, type: e.target.value })
                            }
                            else {
                                setRedeemValue({ value: schemeData?.InvestmentAmount, type: e.target.value })
                            }
                        }}
                        value={redeemValue.type}
                    >
                        <FormControlLabel value="INR" control={<Radio />} label="INR" />
                        <FormControlLabel value="Units" control={<Radio />} label="Units" />
                    </RadioGroup>
                </Box>
                <Box sx={{ display: 'flex', flexDirection: 'column', mt: 3 }}>
                    <i style={{ fontSize: '11px', fontWeight: 500, justifyContent: 'center', width: '70%', margin: '0% 0% 0% 15%' }}>
                        By continuing, I agree with <span style={{ color: 'green' }}> Disclaimers</span> and <span style={{ color: 'green' }}> Terms and Conditions </span> of Kfin Technologies Limited
                    </i>
                    <Button
                        sx={{
                            background: 'linear-gradient(90deg, #36DAE9, #0090FF)',
                            width: '100%',
                            height: "2.5rem",
                            color: '#ffffff',
                            borderRadius: '8px',
                            mt: 3
                        }}
                        onClick={handleClick}
                    >
                        {loading ? <Box sx={{ display: 'flex' }}>
                            <CircularProgress style={{ color: "white" }} size="1.8rem" />
                        </Box> :
                            "Add To Cart"}
                    </Button>
                </Box>

            </Box>
        </Box>
    )
}


export const AddToCartRecommendation = memo(({
    anchorEl,
    handleClose,
    schemeName,
    recommendedSchemeData,
    recommendedDate,
    tabName,
}: { anchorEl: boolean; handleClose: () => void; schemeName: string, recommendedSchemeData: RecommendationsType, recommendedDate?: string, tabName: string }): JSX.Element => {

    const [modalState, setModalState] = useState(false);

    const _handleModalState = () => {
        handleClose();
        setModalState(modalState);
    };

    return (
        <Box>
            <Drawer anchor={'right'} open={anchorEl} onClose={_handleModalState}  >
                <Box sx={{ width: { xs: "100%", sm: '500px' } }}>

                    <Box sx={{ display: "flex", flexDirection: "row", justifyContent: 'space-between', alignItems: 'flex-end', px: '1rem', py: '1.4rem', position: "sticky", top: 0, zIndex: 10, bgcolor: "white" }}>
                        <Box sx={{ display: 'flex', alignItems: 'center' }}>
                            <span style={{ width: '12px', height: '12px', borderRadius: '50%', marginRight: '0.8rem', backgroundColor: '#1EB1F3' }}></span>
                            <Typography sx={{ fontSize: 18, fontWeight: 500 }}>{schemeName}</Typography>
                        </Box>
                        <Box sx={{ cursor: 'pointer' }} onClick={handleClose} >
                            <CloseIcon />
                        </Box>
                    </Box>
                    <Divider />
                    <Box
                        sx={{
                            width: '100%',
                            '& .MuiTabPanel-root': { py: 2, px: 0 },
                            '& .MuiTab-root': {
                                color: '#0393FE',
                                opacity: 0.8,
                                fontSize: 17,
                                lineHeight: '24px',
                                textTransform: 'capitalize',
                                borderRadius: '30px',
                                border: '2px solid #0393FE',
                                mx: 6,
                                my: 1,
                                width: '30%',
                                display: 'flex',
                                flexDirection: 'row',
                                // backgroundColor:'blue',
                                px: { xs: 2, md: 3, lg: 5 },
                                '&.Mui-selected': {
                                    color: '#ffffff',
                                    background: 'linear-gradient(90deg, #0090FF, #36DAE9)',
                                    border: 'none'
                                },
                            },
                            ' & .MuiTab': { backgroundColor: 'yellow' },
                            '& .MuiTabs-indicator': {
                                height: 3,
                                background: 'transparent',
                            },
                        }}>

                        <Box sx={{ paddingTop: "16px", paddingBottom: "16px" }}>
                            {tabName == "STP" ?
                                <STP_Form
                                    recommendedDate={recommendedDate}
                                    recommendedSchemeData={recommendedSchemeData}
                                    handleClose={_handleModalState}
                                /> :
                                (tabName == "SWP") ?
                                    <SWP_Form
                                        recommendedDate={recommendedDate}
                                        recommendedSchemeData={recommendedSchemeData}
                                        handleClose={_handleModalState}
                                    /> :
                                    (tabName == "Swt") ?
                                        <SWT_Form
                                            recommendedDate={recommendedDate}
                                            recommendedSchemeData={recommendedSchemeData}
                                            handleClose={_handleModalState}
                                        />
                                        :
                                        <Redeemtion_Form
                                            recommendedDate={recommendedDate}
                                            recommendedSchemeData={recommendedSchemeData}
                                            handleClose={_handleModalState}
                                        />
                            }
                        </Box>
                    </Box>
                </Box >
            </Drawer >
        </Box >
    )
})