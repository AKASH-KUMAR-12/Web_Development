import { createContext, ReactElement, useContext, useState } from 'react';
import { get_assest_classes, get_sub_asset_classes, get_scheme_details, get_scheme_list, get_category_average, get_scheme_nav, CategoryAverageOptions, RecommendedSchemesOptions, get_recommended_schemes, get_recommendation_validations, get_masters, get_client_mandateIds, AccountTypeOptions, get_account_type, get_Portfolio,get_folioList, PortfolioBodyType, SchemeType, SchemeBodyType, get_switch_schemes, redeem_validation, redeemValidationPayload, updateViewFlagPayload, update_view_flag, OrdersBodyType, get_orders_data, get_bse_code, getBSESchemeCodePayloadType, create_transaction, FolioListBodyType } from '../../api/transaction';
import { useRootContext } from '../data/root.context';
export type SubAssetclassName = {
  AssetClassName: string;
  Descripti: string;
  ID: number;
  ImageURL: string;
  Sub_AssetclassName: string;
}

export type GetAssetClassesType = {

  asset_classes: AssetClasses[];

}

export type GetMandateIds = {
  mandate: any
}

export type AssetClasses = {

  AssetClassName: string;

}

export type GetSubAssetClassesType = {

  sub_asset_classes: SubAssetClasses[];

}

export type SubAssetClasses = {

  ID: number;

  AssetClassName: string;

  Sub_AssetclassName: string;

  ImageURL: string;

  Descripti: string

}

export type GetSchemeListType = {

  sub_asset_classes: SchemeList[];

}

export type SchemeList = {
  subid: number;
  Assetclass: number;
  AssetClassName: string;
  Subassetclass: number;
  Sub_AssetclassName: string;
  SchemeID: number;
  SchemeName: string;
  AmcID: number;
  Growthoption: number;
  Dividendreinvestment: number;
  DividendPayout: number;
  Dividendfrequency: null;
  MinimumPurchaseAmount: string;
  MaximumPurchaseAmount: string;
  AMC: string;
  Aum: string;
  Units: number;
  TailWindRec: string;
  Cat_Return1yr: string;
  Cat_Return3yr: string;
  Cat_Return5yr: string;
  Cat_Return7yr: string;
  Cat_Return10yr: string;
  Sch_Return1Day: string;
  Sch_Return1Week: string;
  Sch_Return1Mth: string;
  Sch_Return3Mth: string;
  Sch_Return1Yr: string;
  Sch_Return3Yr: string;
  Sch_Return5Yr: string;
  Sch_Return7Yr: string;
  Sch_Return10Yr: string;
  Cat_Return1Mth: string;
  Cat_Return3Mth: string;
  Cat_Return6Mth: string;
  Sch_Return6Mth: string;
  img: string;
  Sch: string;
  RecID: string
  productid: number;
}

export type GetSchemeDetailsType = {
  scheme_details: SchemeDetails;
}
export type SchemeDetails = {
  header: SchemeDetailHeader;
  insight: SchemeDetailInsight;
  top_holdings: SchemeDetailTopHoldings;
  fund_management: SchemeDetailFundManagement[];
  growth_options: SchemeDetailGrowthOptions[];
  exit_load: SchemeDetailExitLoad[];
}
export type SchemeDetailHeader = {
  SchemeName: string;
  Sub_AssetClassname: string;
  AssetClassName: string;
  Productcode_RTA: string;
  TailWindRec: string;
  Growthoption: number;
  DividendReinvestment: number;
  DividendPayout: number;
  Dividendfrequency: null;
  RiskMapping: number;
  SchemeCode_RTA: string;
  SN_NAV: number;
  Nav_Date: string;
  Aum: string;
  ExpenseRatio: string;
  ExitLoad: number;
  AmcID: number;
  MinimumPurchaseAmount: number;
  MaximumPurchaseAmount: number;
  SIPFLAG: string;
  AMC: string;
  img: string
}

export type getFolioList ={
  folio: any
}

export interface FolioList {
  Folio: string;
}

export interface getPortfolioType {
  portfolio_details: [PortfolioType[]]
}

export interface PortfolioType {
  Asondate: Date;
  I_Asset_Class: string;
  I_AssetClass: string;
  I_Fund: number;
  I_Scheme: number;
  I_Accno: number;
  Product: string;
  Growthoption: number;
  DividendReinvestment: number;
  DividendPayout: number;
  AvgPurNAV: number;
  COST: number;
  NAVAson: number;
  Units: number;
  AUM: number;
  UnrealReturns: number;
  AUM_PERCENTAGE: number;
  FolioXirr: number;
  LifeDays: number;
  TailWindRec: string;
  NavAsOndate: Date;
  CAGR: null,
  SCh: string,
  TransactionAllowed: string;
  AmcID: number;
  AMCName: string;
  productid: number;
  PlanShortName: string;
  DivFlag: string;
  DailyGain: number;
  DailyGainPer: number;
  RealisedRtns: null;
  MinimumPurchaseAmount: number,
  MaximumPurchaseAmount: number
}

export type SchemeDetailInsight = {
  FscbiIndianRiskLevel: string;
}

export interface SchemeDetailTopHoldings {
  company_wise: company_wise[],
  sector_wise: sector_wise[],
  equity_per: number,
  debt_per: number,
  debt_holders: debt_holders[],
  debt_ratings: debt_ratings[],
  db_category_returns: db_category_returns[],
  portfolio_aggregates: portfolio_aggregates[],
  credit_ratings: credit_ratings[]
}

export interface company_wise {
  name: string,
  Weighting: number,
  type: string
}

export interface sector_wise {
  sector: string,
  Weighting: number,
  type: string
}

export interface debt_holders {
  CashEquivalent: string,
  Corporate: string,
  Government: string,
  Municipal: string,
  Securitized: string
}

export interface debt_ratings {
  AA: number,
  AAA: number,
  B: number,
  BB: number,
  BBB: number
}

export interface credit_ratings {
  WEIGHTING: number,
  NAME: string
}

export interface portfolio_aggregates {
  Average_Maturity: string,
  Yield_to_Maturity: string,
  Modified_Duration: string
}

export interface db_category_returns {
  DPCategoryReturn1Mth: string;
  DPCategoryReturn3Mth: string;
  DPCategoryReturn6Mth: string;
  DPCategoryReturn3Yr: string;
  DPCategoryReturn1Yr: string;
}

export type SchemeDetailFundManagement = {
  FUND_NAME: string;
  FUND_MANAGER: string
}

export type SchemeDetailGrowthOptions = {
  Plan: string;
  FSCBIDistributionFrequency: number;
  FSCBIFundStandardName: string;
  FscbiDistributionStatus: string;
  FscbiMStarId: string;
  SchId: number
}

export type SchemeDetailExitLoad = {
  Unit: string;
  BreakpointUnit: string;
  LowBreakpoint: string;
  HighBreakpoint: string;
  Value: number
}

export type GetCategoryAverage = {
  category_averages: CategoryAverage[];
}

export type CategoryAverage = {
  SN_SchID: number;
  SN_NAVDt: string;
  SN_NAV: number;
  MrkValue: number
}

export type GetSchemeNav = {
  scheme_nav: SchemeNav[];
}

export type SchemeNav = {
  SN_NAV: number;
  SN_NAVDt: string;
}
export type GetRecommendedSchemes = {
  recommendedSchemes: [RecommendationsType[]]
}
export type RecommendationsType = {
  RecID: string;
  SchemeID: string;
  InvestmentAmount: number;
  SchemeType: string;
  rmID: string;
  ClientCode: string;
  No_of_Installments: number;
  SIP_date: string;
  Frequency: string;
  ProductName: string;
  SchemeName: string;
  SchemeShortName: string;
  ProductShortName: string;
  Productcode_RTA: string;
  PlanShortName: string;
  AmcID: number;
  AMC: string;
  AMCCode: string;
  RegistrarID: number;
  RegistrarName: string;
  PlanName: string;
  PalnId: number;
  SchemeoptionID: number;
  Schemeoption: string;
  Growthoption: number;
  Dividendreinvestment: number;
  DividendPayout: number;
  Dividendfrequency: string | null;
  Assetclass: number;
  AssetClassName: string;
  Subassetclass: number;
  Sub_AssetclassName: string;
  MstarID: string;
  RiskMapping: number;
  ISIN: string[];
  Mstar_Id: string;
  Expence_Ratio: string;
  Aum: string;
  Cat_Return1yr: string;
  Cat_Return2yr: string;
  Cat_Return3yr: string;
  Cat_Return4yr: string;
  Cat_Return5yr: string;
  Cat_Return7yr: string;
  Cat_Return10yr: string;
  Cat_Return1Mth: string;
  Cat_Return3Mth: string;
  Cat_Return6Mth: string;
  Sch_Return1Day: string;
  Sch_Return1Week: string;
  Sch_Return1Mth: string;
  Sch_Return3Mth: string;
  Sch_Return1Yr: string;
  Sch_Return2Yr: string;
  Sch_Return3Yr: string;
  Sch_Return4Yr: string;
  Sch_Return5Yr: string;
  Sch_Return7Yr: string;
  Sch_Return10Yr: string;
  Sch_Return6Mth: string;
  Sch: string;
  accountID: string;
  Units: number;
  ToschemeName: string;
  EntryDate: string;
  Expirystatus: string;
  NoOfDays: number;
  Folio: string;
  AccountType: string;
  PFFlag: string;
  BucketID:number;
}
export type GetRecommendationValidations = {
  validations: [ValidationRiskMapping[], ValidationForSIP[]];
}
export type GetMasters = {
  masters: Masters[]
}

export type ValidationRiskMapping = {
  RiskMapping: number;
  Productcode_RTA: string;
  Approval: number;
  SIP_startdate: string | null;
  STPstartdate: string | null;
  SWPstartdate: string | null;
}
export type ValidationForSIP = {
  Productcode_RTA: string,
  SIPFREQUENCY: string | null,
  SIPDATES: string,
  SIPMINIMUMINSTALLMENTAMOUNT: string,
  SIPMAXIMUMINSTALLMENTAMOUNT: string,
  SIPMINIMUMINSTALLMENTNUMBERS: string,
  SIPMAXIMUMINSTALLMENTNUMBERS: string,
  SCHEMEISIN: string,
  SIPMINIMUMGAP: string,
  IPMAXIMUMGAP: string,
  SIPMULTIPLIERAMOUNT: string

}
export type Masters = {
  BankAccountType: string,
  City: string,
  Country: string,
  Frequency: string,
  InvestorType: string,
  Marrital_Status: string,
  Occupation: string,
  Relation: string,
  Sex: string,
  States: string,
  Type_of_Resident: string,
  Zone: string,
  Salutation: string,
  Mode_of_holding: string,
  Source_of_wealth: string,
  Income_tax_slab: string,
  Occupation_type: string,
  poltical_exposed: string
}

export type GetAccountType = {
  account_type: [AccountType[]],
}

export type AccountType = {
  AccountId: string,
  AccountType: string
}

export type getRecommendationPayload = {
  sch: any,
  TrType: any
}

export type redeemValidationType = {
  msg: string,
  Acno: string,
  Schid: number,
  SchName: string,
  Units: number,
  Nav: number,
  Amount: number,
  ProductRTACode: string,
  Option: string,
  ErrorCode: string
}

export type redeemValidationResponse = {
  redVal: [[redeemValidationType]]
}

export interface OrdersDataType {
  orders: Orders[]
}

export interface Orders  {
  TYPE: string,
  IHNO: number,
  RecID: number,
  SchemeID: number,
  InvestmentAmount: number,
  ClientCode: string,
  No_of_Installments: number,
  SIP_date: string,
  Frequency: number,
  ProductName: string,
  SchemeName: string,
  SchemeShortName:string,
  ProductShortName: string,
  Productcode_RTA: string,
  PlanShortName: string,
  AmcID: number,
  AMC: string,
  AMCCode: string,
  RegistrarID: number,
  RegistrarName: string,
  PlanName: string,
  PalnId: number,
  SchemeTypee: string,
  SchemeoptionID: number,
  Schemeoption: string,
  Growthoption: number,
  Dividendreinvestment: string,
  DividendPayout: string,
  Dividendfrequency: string,
  Assetclass: number,
  AssetClassName: string,
  Subassetclass: number,
  Sub_AssetclassName: string,
  MstarID: string,
  RiskMapping: number,
  ISIN: string,
  Mstar_Id: string,
  Expence_Ratio: string,
  Aum: string,
  Cat_Return1yr: string,
  Cat_Return2yr: string,
  Cat_Return3yr: string,
  Cat_Return4yr: string,
  Cat_Return5yr: string,
  Cat_Return7yr: string,
  Cat_Return10yr: string,
  Cat_Return1Mth: string,
  Cat_Return3Mth: string,
  Cat_Return6Mth: string,
  Sch_Return1Day: string,
  Sch_Return1Week: string,
  Sch_Return1Mth: string,
  Sch_Return3Mth: string,
  Sch_Return1Yr: string,
  Sch_Return2Yr: string,
  Sch_Return3Yr: string,
  Sch_Return4Yr: string,
  Sch_Return5Yr: string,
  Sch_Return7Yr:string,
  Sch_Return10Yr: string,
Sch_Return6Mth: string,
  accountID: string,
  Sch: string,
  ToschemeID: string,
  Folio: string,
  EntryDate: string,
  Units: number,
  StartDate: string,
  EndDate: string,
  BseOrderNo: string,
  Bse_Reason: string,
  bseOrderStatus: string,
  TRTYPE: string,
  Paymentstatus: string
}

export interface BSESchemeCodeData {
  RTA_ProductCode: string;
  BSE_ProductCod: string;
  ISIN: string;
  AMC_Code: string;
  Scheme_Type: string;
  Scheme_Plan: string;
  Scheme_Name: string;
  Scheme_Option: string;
  MINIMUM_Trans_Amount: number;
  MAXIMUM_Trans_Amount: number;
  Multiplier_Trans_Amount: number;
  CutoffTime_Transaction: string;
}

export interface getBSESchemeCodeResponseType {
  bse_code: [BSESchemeCodeData[]]
}

const TotalData = createContext<{
  loading: boolean;
  assetClasses?: AssetClasses[];
  getAssetClassDetails(): void;
  portfolioData?: PortfolioType[];
  getPortfolioData(body: PortfolioBodyType): void;
  folioList?:FolioList[];
  getFolioList(body:FolioListBodyType): void;
  subAssetClasses?: SubAssetClasses[];
  getSubAssetClassDetails(asset: any): void;
  schemesList?: SchemeList[];
  getSchemeData(asset: any, Flag: string): void;
  schemeData?: SchemeType[];
  setSchemeData(asset: any): void;
  redemptionValidation(asset: any): void;
  redeemValidation?: redeemValidationType;
  getSchemeListDetails(asset_id: any): void;
  schemeDetails?: SchemeDetails;
  getSchemeDetails(schemeId: any): void;
  categoryAverage?: CategoryAverage[];
  getCategoryAverageDetails(requestOptions: CategoryAverageOptions): void;
  schemeNav?: SchemeNav[];
  getSchemeNavDetails(schemeId: any): void
  recommendedScheme?: RecommendationsType[];
  getRecommendedSchemesDetails(requestOptions: RecommendedSchemesOptions): Promise<any>;
  validation?: ValidationForSIP[];
  getValidationDetails(payload: getRecommendationPayload): void;
  updateViewFlag(payload: updateViewFlagPayload): void;
  accountTypes?: AccountType[];
  getAccountTypes(requestOptions: AccountTypeOptions): void;
  masters?: Masters[];
  getMastersDetails(): void,
  getclientmandateIdsDetails(): void,
  initialFilter?: any,
  setInitialFilter(val: any): void,
  orders?: Orders[];
getOrdersData(requestOptions: OrdersBodyType): void;
getBSECode(body: any): Promise<any>;
createTransaction(body: any): Promise<any>
}>({
  loading: true,
  assetClasses: undefined,
  getAssetClassDetails: () => { },
  portfolioData: undefined,
  getPortfolioData: () => { },
  folioList: undefined,
  getFolioList:() => { },
  subAssetClasses: undefined,
  getSchemeData: () => { },
  schemeData: undefined,
  setSchemeData:()=>{},
  redemptionValidation: () => { },
  redeemValidation: undefined,
  getSubAssetClassDetails: () => { },
  schemesList: undefined,
  getSchemeListDetails: () => { },
  schemeDetails: undefined,
  getSchemeDetails: () => { },
  categoryAverage: undefined,
  getCategoryAverageDetails: () => { },
  schemeNav: undefined,
  getSchemeNavDetails: () => { },
  recommendedScheme: undefined,
  getRecommendedSchemesDetails: async () => { },
  validation: undefined,
  getValidationDetails: () => { },
  updateViewFlag: () => { },
  masters: undefined,
  getMastersDetails: () => { },
  getclientmandateIdsDetails: () => { },
  accountTypes: undefined,
  getAccountTypes: () => { },
  initialFilter: undefined,
  setInitialFilter: () => { },
  orders: undefined,
  getOrdersData:() => {},
  getBSECode: async () => {},
  createTransaction: async () => {}
});

export function useGetTotalData() {
  return useContext(TotalData);
}
export const GetTotalDataProvider = ({ children }: { children: any }) => {
  const [assetClasses, setAssetClasses] = useState<AssetClasses[]>();
  const [portfolioData, setPortfolioData] = useState<PortfolioType[]>();
  const [folioList, setFolioList] = useState<FolioList[]>();
  const [subAssetClasses, setSubAssetClasses] = useState<SubAssetClasses[]>();
  const [schemesList, setSchemesList] = useState<SchemeList[]>();
  const [schemeDetails, setSchemeDetails] = useState<SchemeDetails>();
  const [categoryAverage, setCategoryAverage] = useState<CategoryAverage[]>();
  const [schemeNav, setSchemeNav] = useState<SchemeNav[]>();
  const [recommendedScheme, setRecommendedScheme] = useState<RecommendationsType[]>();
  const [validation, setValidation] = useState<ValidationForSIP[]>();
  const [schemeData, setSchemeData] = useState<SchemeType[]>();
  const [masters, setMasters] = useState<Masters[]>()
  const [redeemValidation, setRedeemValidation] = useState<redeemValidationType>();
  const [loading, setLoading] = useState(true);
  const [initialFilter, setInitialFilter] = useState<any>({})
  const [orders, setOrders] = useState<Orders[]>();
  const { showToast } = useRootContext();

  async function getAssetClassDetails() {
    return get_assest_classes()
      .then(({ asset_classes: assetClasses }) => {
      const sortedAssetClasses = [...assetClasses].sort((a, b) =>
                    a.AssetClassName.localeCompare(b.AssetClassName)
                );
      setAssetClasses(sortedAssetClasses)
  })
      .catch((e) => {
        showToast('User details: ' + (e?.messasge || 'Not found'), 'error');
      })
      .finally(() => setLoading(false));
  }

  async function getSubAssetClassDetails(asset: any) {
    return get_sub_asset_classes(asset)
      .then(({ sub_asset_classes: subAssetClasses }) => setSubAssetClasses(subAssetClasses))
      .catch((e) => {
        showToast('User details: ' + (e?.messasge || 'Not found'), 'error');
      })
      .finally(() => setLoading(false));
  }

  async function getSchemeListDetails(asset_id: any) {
    return get_scheme_list(asset_id)
      .then(({ sub_asset_classes: schemesList }) => setSchemesList(schemesList))
      .catch((e) => {
        showToast('User details: ' + (e?.messasge || 'Not found'), 'error');
      })
      .finally(() => setLoading(false));
  }

  async function getSchemeDetails(schemeId: any) {
    
    return get_scheme_details(schemeId)
      .then(({ scheme_details: schemeDetails }) => setSchemeDetails(schemeDetails))
      .catch((e) => {
        showToast('User details: ' + (e?.messasge || 'Not found'), 'error');
      })
      .finally(() => setLoading(false));
  }

  async function getCategoryAverageDetails(requestOptions: CategoryAverageOptions) {
   
    return get_category_average(requestOptions)
      .then(({ category_averages: categoryAverage }) => setCategoryAverage(categoryAverage))
      .catch((e) => {
        showToast('User details: ' + (e?.messasge || 'Not found'), 'error');
      })
      .finally(() => setLoading(false));
  }

  async function getSchemeNavDetails(schemeId: any) {

    return get_scheme_nav(schemeId)
      .then(({ scheme_nav: schemeNav }) => setSchemeNav(schemeNav))
      .catch((e) => {
        showToast('User details: ' + (e?.messasge || 'Not found'), 'error');
      })
      .finally(() => setLoading(false));
  }

  async function getPortfolioData(body: PortfolioBodyType) {
   
    return get_Portfolio(body)
      .then(({ portfolio_details: pData }) => setPortfolioData(pData[0]))
      .catch((e) => {
        showToast('User details: ' + (e?.messasge || 'Not found'), 'error');
      })
      .finally(() => setLoading(false));
  }
  async function getFolioList(body: FolioListBodyType) {
    console.log("getFolioList",folioList)
   
    return get_folioList(body)
      .then(({ folio: folioList }) => setFolioList(folioList[0]))
      .catch((e) => {
        showToast('User detail: ' + (e?.messasge || 'Not found'), 'error');
      })
      .finally(() => setLoading(false));
  }

  async function getSchemeData(body: SchemeBodyType, Flag: 'STPFLAG'| 'SIPFLAG' | 'SWPFlag' | 'SwitchFLAG') {
    
    return get_switch_schemes(body)
      .then(({ schemes: schemes }) => {
        const filteredSchemes  = schemes[0].filter((val: SchemeType)=>{
          return val[Flag as keyof SchemeType] === "Y"
        });
        setSchemeData(filteredSchemes)
      })
      .catch((e) => {
        showToast('User details: ' + (e?.messasge || 'Not found'), 'error');
      })
      .finally(() => setLoading(false));
  }

  async function getRecommendedSchemesDetails(requestOptions: RecommendedSchemesOptions): Promise<any> {
    return get_recommended_schemes(requestOptions)
      .then(({ recommendedSchemes: rScheme }) => {
        setRecommendedScheme(rScheme[0])
        return rScheme[0];
      })
      .catch((e) => {
        showToast('User details: ' + (e?.messasge || 'Not found'), 'error');
      })
      .finally(() => setLoading(false));
  }

  async function getValidationDetails(payload: getRecommendationPayload) {
    return get_recommendation_validations(payload)
      .then(({ validations: validation }) => setValidation(validation[1]))
      .catch((e) => {
        showToast('User details: ' + (e?.messasge || 'Not found'), 'error');
      })
      .finally(() => setLoading(false));
  }

  async function getMastersDetails() {
    return get_masters()
      .then(({ masters: master }) => {
        setMasters(master)
        return master
      })
      .catch((e: any) => {
        showToast((e?.messasge || 'Not found'), 'error');
      })
      .finally(() => setLoading(false));
  }

  async function getclientmandateIdsDetails() {
    return get_client_mandateIds()
      .then(({ mandate: response }) => {
        return response
      })
      .catch((e: any) => {
        showToast((e?.messasge || 'Not found'), 'error');
      })
      .finally(() => setLoading(false));
  }

  async function getAccountTypes(requestOptions: AccountTypeOptions) {
    return get_account_type(requestOptions)
      .then(({ account_type: accountTypes }) => { return accountTypes })
      .catch((e) => {
        showToast('User details: ' + (e?.messasge || 'Not found'), 'error');
      })
      .finally(() => setLoading(false));
  }

  async function redemptionValidation(payload: redeemValidationPayload) {
    return redeem_validation(payload)
      .then(({ redVal: response }) => {
        setRedeemValidation(response[0][0]);
        return response[0][0];
      })
      .catch((e) => {
        showToast((e?.messasge || 'Not found'), 'error');
      })
      .finally(() => { });
  }

  async function updateViewFlag(payload: updateViewFlagPayload) {
    return update_view_flag(payload)
      .then((response) => {
        return response[0][0];
      })
      .catch((e) => {
        // showToast((e?.messasge || 'Not found'), 'error');
        console.log("error", e?.messasge);
      })
      .finally(() => { });
  }

  async function getOrdersData(payload: OrdersBodyType) {
   
    return get_orders_data(payload)
      .then(
      ({  orders: orders }) => {
        setOrders(orders) 
      }
      )
      .catch((e) => {
        console.log("error", e?.message);
      })
      .finally(() => setLoading(false));
  }

  async function getBSECode(payload: getBSESchemeCodePayloadType) {
   
    return get_bse_code(payload)
      .then(
      (response: getBSESchemeCodeResponseType) => {
        return response;
      }
      )
      .catch((e: any) => {
        console.log("error", e?.message);
      })
      .finally(() => {});
  }

  
  async function createTransaction(payload: any) {
   
    return create_transaction(payload)
      .then(
      (response: any) => {
        return response;
      }
      )
      .catch((e) => {
        console.log("error", e?.message);
      })
      .finally(() => {});
  }

  return (
    <TotalData.Provider
      value={{
        assetClasses, loading, getAssetClassDetails, portfolioData, getPortfolioData,folioList, getFolioList,
        subAssetClasses, getSubAssetClassDetails, schemesList, getSchemeListDetails, redeemValidation, redemptionValidation,
        schemeNav, getSchemeNavDetails, categoryAverage, getCategoryAverageDetails, schemeDetails, getSchemeDetails, recommendedScheme, getRecommendedSchemesDetails, validation, getValidationDetails, updateViewFlag, schemeData, getSchemeData,setSchemeData, masters, getMastersDetails, getclientmandateIdsDetails,
        getAccountTypes, initialFilter, setInitialFilter,orders, getOrdersData, getBSECode, createTransaction
      }}>
      {children}
    </TotalData.Provider>
  );
}


