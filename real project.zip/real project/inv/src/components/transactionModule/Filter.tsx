import { Accordion, AccordionDetails, AccordionSummary, Box, Button, Checkbox, Chip, Collapse, FormControlLabel, FormGroup, Menu, MenuItem, Modal, Typography } from "@mui/material";
import { useEffect, useState } from "react";
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import "./styles.css"
import { useGetTotalData } from "./transaction.context";
import VerifiedIcon from '@mui/icons-material/Verified';
import { DatePicker, LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { DatePickerInput } from "../reports/common";
import { recommendationStatusMap } from "./constants";

export function FilterComponent({
    open,
    anchorEl,
    setAnchorEl,
    setSearch,
    setFilterState,
    page,
    setListData,
    filteredState,
    setFilterCount,
    setFinalCheckedItems,
    finalCheckedItems,
    filterDateData,
    setFilterDateData }:
    {
        open: boolean,
        anchorEl: any,
        setAnchorEl: (val: any) => void,
        setSearch?: (val: string) => void,
        filteredState: any,
        setFilterState?: any,
        page: string,
        setListData: (val: any) => void,
        setFilterCount: any,
        finalCheckedItems: any
        setFinalCheckedItems: any,
        filterDateData?: any,
        setFilterDateData?: any
    }) {


    const [expandedAccordion, setExpandedAccordion] = useState<string | false>(false);
    const { initialFilter, setInitialFilter } = useGetTotalData();
    const [checkedItems, setCheckedItems] = useState<any>(initialFilter);
    const [filterList, setFilterList] = useState<any>({});

    const orderTypeMapping: Record<string, string> = {
        "ISIP": "Purchase- SIP",
        "XSIP": "Additional Purchase- SIP",
        "Add": "Additional Purchase- Lumpsum",
        "New": "Purchase- Lumpsum",
        "Red": "Redemption",
        "Swt": "Switch",
        "SWP": "SWP",
        "STP": "STP",
    };
    useEffect(() => {
        if (page == "Recommendation") {
            let filteredAMCName = new Set();
            let filteredStatus = new Set();
            let filteredSchemeType = new Set();
            let filteredAccountType = new Set();
            filteredState?.map((value: any) => {
                filteredAMCName.add(value.AMC.split(" ")[0]);
                // filteredStatus.add(value?.Expirystatus == "Order confirmed_Success" ? "Order Placed" : value?.Expirystatus == "Order confirmed_Failed" ? "Order Confirmation Failed" : value?.Expirystatus == "Order confirmed_Payment Successfully Completed" ? "Payment Successfull" : value?.Expirystatus)
                filteredSchemeType.add(value.Schemeoption);
                if (value.AccountType != "NA") {
                    filteredAccountType.add(value.AccountType)
                }
            })
            recommendationStatusMap.map((val:String)=>{filteredStatus.add(val)})
            setFilterList({
                "AMC Name": Array.from(filteredAMCName).sort((a: any, b: any) => a.toLowerCase().localeCompare(b.toLowerCase())),
                "Status": Array.from(filteredStatus),
                "Scheme Type": Array.from(filteredSchemeType),
                "Account Name": Array.from(filteredAccountType),
            })
            setCheckedItems(finalCheckedItems);
            setInitialFilter(finalCheckedItems);
        }
        else if (page == "Holding") {
            let filteredAMCName = new Set();
            let filteredSchemeType = new Set();
            let filteredholdingName = new Set();
            filteredState?.map((value: any) => {
                filteredAMCName.add(value.AMCName.split(" ")[0]);
                filteredSchemeType.add(value.Growthoption === 1 ? "Growth" : value.Dividendreinvestment === 1 ? "Dividend" : value.DividendPayout === 1 ? "Dividend" : "");
                if (value.HoldingName != "NA") {
                    filteredholdingName.add(value.HoldingName)
                }
            })
            setFilterList({
                "AMC Name": Array.from(filteredAMCName).sort((a: any, b: any) => a.toLowerCase().localeCompare(b.toLowerCase())),
                "Scheme Type": Array.from(filteredSchemeType),
                "Holding Name": Array.from(filteredholdingName)
            })
            setCheckedItems(finalCheckedItems);
        }
        else if (page == "Orders") {
            let filteredOrderType = new Set();
            let filteredOrderStatus = new Set();
            filteredState?.map((group: any) => {
                group.orders?.map((value: any) => {
                    if (value?.TRTYPE) {
                        filteredOrderType.add(orderTypeMapping[value.TRTYPE] || value.TRTYPE);
                    }
                    if (value?.bseOrderStatus) {
                        filteredOrderStatus.add(value.bseOrderStatus);
                    }
                });
            });
            setFilterList({
                "Order Type": Array.from(filteredOrderType),
                "Order Status": Array.from(filteredOrderStatus),

            })
            setCheckedItems(finalCheckedItems);
        }
        else {
            let filteredRisk = new Set();
            let filteredAMCName = new Set();
            let filteredSchemeType = new Set();
            let filteredMinimumInvestment = new Set();
            filteredState?.map((value: any) => {
                filteredAMCName.add(value.AMC.split(" ")[0]);
                filteredSchemeType.add(value.Growthoption === 1 ? "Growth" : value.Dividendreinvestment === 1 ? "Dividend" : value.DividendPayout === 1 ? "Dividend" : "");
                filteredMinimumInvestment.add((Number(value.MinimumPurchaseAmount)) >= 5001 ? "High 5001 & Above" : (Number(value.MinimumPurchaseAmount) >= 1001 && Number(value.MinimumPurchaseAmount) <= 5000) ? "Mid 1001-5000" : "Low 0-1000")
                filteredRisk.add(value.RiskRating)
            })
            setFilterList({
                "Risk": Array.from(filteredRisk),
                "AMC Name": Array.from(filteredAMCName).sort((a: any, b: any) => a.toLowerCase().localeCompare(b.toLowerCase())),
                "Scheme Type": Array.from(filteredSchemeType),
                "Minimum Investment": Array.from(filteredMinimumInvestment)
            })
            setCheckedItems(finalCheckedItems);
        }

    }, [filteredState])

    const handleCheckboxChange = (event: any, label: any, title: any) => {
        if (event.target.checked) {
            setCheckedItems((prevCheckedItems: any) => ({
                ...prevCheckedItems,
                [title]: [...(prevCheckedItems[title] || []), label]
            }));
            setInitialFilter((prevCheckedItems: any) => ({
                ...prevCheckedItems,
                [title]: [...(prevCheckedItems[title] || []), label]
            }));
        }
        else {
            setCheckedItems((prevCheckedItems: any) => ({
                ...prevCheckedItems,
                [title]: prevCheckedItems[title].filter((item: any) => item !== label)
            }));
            setInitialFilter((prevCheckedItems: any) => ({
                ...prevCheckedItems,
                [title]: prevCheckedItems[title].filter((item: any) => item !== label)
            }));
        }
    };

    const handleAccordionChange = (key: string) => (event: React.ChangeEvent<{}>, isExpanded: boolean) => {
        setExpandedAccordion(isExpanded ? key : false);
    };

    const renderAccordion = (title: string, data: any[], key: string) => (
        <Accordion
            expanded={expandedAccordion === key}
            onChange={handleAccordionChange(key)}
            sx={{ width: '100%', margin: 0, border: 'none' }}
        >
            <AccordionSummary
                expandIcon={<ArrowDropDownIcon />}
                aria-controls={`panel-${key}-content`}
                id={`panel-${key}-header`}
            >
                {title} {checkedItems[title] != undefined && checkedItems[title].length != 0 ? <span style={{ marginLeft: '10px', width: '16px', height: '16px', color: 'white', fontSize: '12px', textAlign: 'center', backgroundColor: 'red', borderRadius: "50%" }}>{checkedItems[title].length}</span> : ''}
            </AccordionSummary>
            <AccordionDetails >
                <FormGroup sx={{ width: { xs: "8rem", sm: '21rem' }, display: "flex", flexDirection: { xs: "column", sm: "row" }, flexWrap: "wrap", fontSize: "11px", }}>
                    {data.map((ele: any, index: any) => (
                        <FormControlLabel key={index} control={<Checkbox checked={checkedItems[title]?.includes(ele) ? true : false} onChange={(e) => handleCheckboxChange(e, ele, title)} />
                        } label={<Box sx={{ display: "flex", flexDirection: { xs: "column", sm: "row" }, width: "100%", fontSize: { xs: "0.7rem", sm: "0.8rem" } }}><Box sx={(title == "Holding Name" || title == "Account Name") ? { whiteSpace: "wrap", width: "85%", fontSize: { xs: "0.7rem", sm: "14px" } } : {}}>
                            {(title == "Holding Name" || title == "Account Name") ? ele?.split("$")[1] : ele}
                        </Box>
                            {((title == "Holding Name" || title == "Account Name") && (ele && ele[0] == "Y")) &&
                                <Box sx={{ color: "#0090FF", display: "flex", justifyContent: "center", alignItems: "center", width: "30%", mt: { xs: "0.3rem", sm: "0rem" } }}>
                                    <VerifiedIcon style={{ color: "#0090FF", height: "1.2rem" }} />
                                    <span style={{ fontSize: "0.6rem" }}>{"BSE Active"}</span>
                                </Box>
                            }
                        </Box>} />
                    ))}

                </FormGroup>
            </AccordionDetails>
        </Accordion>

    );

    const filterApply = () => {
        let filteredValues = filteredState, flag: boolean = true, checkedFilterCount = 0;
        setFinalCheckedItems(checkedItems);
        Object.keys(checkedItems).map((key: any) => {
            if (checkedItems[key].length > 0) {
                if (page == "Recommendation") {
                    if (key == "AMC Name") {
                        if (flag) {
                            let filteredResult: any = filteredState.filter((value: any) => checkedItems["AMC Name"].includes(value?.AMC.split(" ")[0]))
                            filteredValues = filteredResult
                            flag = false;
                        }
                        else {
                            let filteredResult: any = filteredValues.filter((value: any) => checkedItems["AMC Name"].includes(value?.AMC.split(" ")[0]))
                            filteredValues = filteredResult
                        }
                    }
                    else if (key == "Status") {
                        if (flag) {
                            let filteredResult: any = filteredState.filter((value: any) => checkedItems["Status"].includes(value?.Expirystatus == "Order confirmed_Success" ? "Order Placed" : value?.Expirystatus == "Order confirmed_Failed" ? "Order Confirmation Failed" : value?.Expirystatus == "Order confirmed_Payment Successfully Completed" ? "Payment Successfull" : value?.Expirystatus))
                            filteredValues = filteredResult
                            flag = false;
                        }
                        else {
                            let filteredResult: any = filteredValues.filter((value: any) => checkedItems["Status"].includes(value?.Expirystatus == "Order confirmed_Success" ? "Order Placed" : value?.Expirystatus == "Order confirmed_Failed" ? "Order Confirmation Failed" : value?.Expirystatus == "Order confirmed_Payment Successfully Completed" ? "Payment Successfull" : value?.Expirystatus))
                            filteredValues = filteredResult
                        }
                    }
                    else if (key == "Scheme Type") {
                        if (flag) {
                            let filteredResult = filteredState.filter((value: any) => checkedItems["Scheme Type"].includes(value.Schemeoption))
                            filteredValues = filteredResult
                            flag = false;
                        }
                        else {
                            let filteredResult = filteredValues.filter((value: any) => checkedItems["Scheme Type"].includes(value.Schemeoption))
                            filteredValues = filteredResult
                        }
                    }
                    else {
                        if (flag) {
                          
                            let filteredResult = filteredState.filter((value: any) => {checkedItems["Account Name"].includes(value.AccountType)
                            })
                            filteredValues = filteredResult
                            flag = false;
                        }
                        else {
                            let filteredResult = filteredValues.filter((value: any) => checkedItems["Account Name"].includes(value.AccountType))
                            filteredValues = filteredResult
                        }
                    }

                }
                else if (page == "Holding") {
                    if (key == "AMC Name") {
                        if (flag) {
                            let filteredResult: any = filteredState.filter((value: any) => checkedItems["AMC Name"].includes(value.AMCName.split(" ")[0]))
                            filteredValues = filteredResult
                            flag = false;
                        }
                        else {
                            let filteredResult: any = filteredValues.filter((value: any) => checkedItems["AMC Name"].includes(value.AMCName.split(" ")[0]))
                            filteredValues = filteredResult
                        }
                    }
                    else if (key == "Scheme Type") {
                        if (flag) {
                            let filteredResult = filteredState.filter((value: any) => checkedItems["Scheme Type"].includes(value.Growthoption === 1 ? "Growth" : value.Dividendreinvestment === 1 ? "Dividend" : value.DividendPayout === 1 ? "Dividend" : ""))
                            filteredValues = filteredResult
                            flag = false;
                        }
                        else {
                            let filteredResult = filteredValues.filter((value: any) => checkedItems["Scheme Type"].includes(value.Growthoption === 1 ? "Growth" : value.Dividendreinvestment === 1 ? "Dividend" : value.DividendPayout === 1 ? "Dividend" : ""))
                            filteredValues = filteredResult
                        }
                    }
                    else {
                        if (flag) {
                            let filteredResult = filteredState.filter((value: any) => checkedItems["Holding Name"].includes(value.HoldingName))
                            filteredValues = filteredResult
                            flag = false;
                        }
                        else {
                            let filteredResult = filteredValues.filter((value: any) => checkedItems["Holding Name"].includes(value.HoldingName))
                            filteredValues = filteredResult
                        }
                    }
                }
                else if (page == "Orders") {
                    if (key === "Order Type") {
                        if (flag) {
                            let filteredResult = filteredValues.map((group: any) => ({
                                date: group.date,
                                orders: group.orders.filter((order: any) =>
                                    checkedItems["Order Type"].includes(orderTypeMapping[order.TRTYPE])
                                ),
                            }));
                            filteredValues = filteredResult;
                            flag = false;
                        } else {
                            let filteredResult = filteredValues.map((group: any) => ({
                                date: group.date,
                                orders: group.orders.filter((order: any) =>
                                    checkedItems["Order Type"].includes(order.TRTYPE)
                                ),
                            }));
                            filteredValues = filteredResult;
                        }
                    }
                    else if (key == "Order Status") {
                        if (flag) {
                            let filteredResult = filteredValues.map((group: any) => ({
                                date: group.date,
                                orders: group.orders.filter((order: any) => checkedItems["Order Status"].includes(order.bseOrderStatus)),
                            }));
                            filteredValues = filteredResult
                            flag = false;
                        }
                        else {
                            let filteredResult = filteredValues.map((group: any) => ({
                                date: group.date,
                                orders: group.orders.filter((order: any) => checkedItems["Order Status"].includes(order.bseOrderStatus)),
                            }));
                            filteredValues = filteredResult
                        }
                    }

                }
                else {
                    if (key == "Risk") {
                        if (flag) {
                            let filteredResult: any = filteredState.filter((value: any) => checkedItems["Risk"].includes(value.RiskRating))
                            filteredValues = filteredResult
                            flag = false;
                        }
                        else {
                            let filteredResult: any = filteredValues.filter((value: any) => checkedItems["Risk"].includes(value.RiskRatings))
                            filteredValues = filteredResult
                        }
                    }
                    else if (key == "AMC Name") {
                        if (flag) {
                            let filteredResult: any = filteredState.filter((value: any) => checkedItems["AMC Name"].includes(value.AMC.split(" ")[0]))
                            filteredValues = filteredResult
                            flag = false;
                        }
                        else {
                            let filteredResult: any = filteredValues.filter((value: any) => checkedItems["AMC Name"].includes(value.AMC.split(" ")[0]))
                            filteredValues = filteredResult
                        }
                    }
                    else if (key == "Scheme Type") {
                        if (flag) {
                            let filteredResult = filteredState.filter((value: any) => checkedItems["Scheme Type"].includes(value.Growthoption === 1 ? "Growth" : value.Dividendreinvestment === 1 ? "Dividend" : value.DividendPayout === 1 ? "Dividend" : ""))
                            filteredValues = filteredResult
                            flag = false;
                        }
                        else {
                            let filteredResult = filteredValues.filter((value: any) => checkedItems["Scheme Type"].includes(value.Growthoption === 1 ? "Growth" : value.Dividendreinvestment === 1 ? "Dividend" : value.DividendPayout === 1 ? "Dividend" : ""))
                            filteredValues = filteredResult
                        }
                    }
                    else {
                        if (flag) {
                            let filteredResult = filteredState.filter((value: any) => checkedItems["Minimum Investment"].includes((Number(value.MinimumPurchaseAmount)) >= 5001 ? "High 5001 & Above" : (Number(value.MinimumPurchaseAmount) >= 1001 && Number(value.MinimumPurchaseAmount) <= 5000) ? "Mid 1001-5000" : "Low 0-1000"))
                            filteredValues = filteredResult
                            flag = false;
                        }
                        else {
                            let filteredResult = filteredValues.filter((value: any) => checkedItems["Minimum Investment"].includes((Number(value.MinimumPurchaseAmount)) >= 5001 ? "High 5001 & Above" : (Number(value.MinimumPurchaseAmount) >= 1001 && Number(value.MinimumPurchaseAmount) <= 5000) ? "Mid 1001-5000" : "Low 0-1000"))
                            filteredValues = filteredResult
                        }
                    }
                }
                checkedFilterCount = checkedFilterCount + checkedItems[key].length;
            }
        })

        //filter for date
        if (page == "Recommendation") {
            if (filterDateData.FromDate != "" && filterDateData.ToDate != "") {
                checkedFilterCount=checkedFilterCount+1;
                let filteredResult = filteredValues.filter((value: any) =>
                    value.EntryDate !== undefined && new Date(value.EntryDate) >= new Date(filterDateData.FromDate) && new Date(value.EntryDate) <= new Date(new Date(filterDateData.ToDate).getTime() + 60 * 60 * 24 * 1000)
                )
                filteredValues = filteredResult
                checkedFilterCount = checkedFilterCount + 1;
            }
            setFilterDateData(filterDateData)
        }
        else if (page == "Orders") {
            if (filterDateData.FromDate != "" && filterDateData.ToDate != "") {
                checkedFilterCount=checkedFilterCount+1;
                let filteredResult = filteredValues.filter((group: any) => (
                    (group.date !== undefined && new Date(group.date) >= new Date(filterDateData.FromDate) && new Date(group.date) <= new Date(new Date(filterDateData.ToDate).getTime() + 60 * 60 * 24 * 1000))
                ))
                filteredValues = filteredResult;
            }
            setFilterDateData(filterDateData)
        }
        setFilterCount(checkedFilterCount);
       
        setListData(filteredValues)
        if (setFilterState != undefined) {
            setFilterState(filteredValues)
        }
        if (setSearch != undefined) {
            setSearch('')
        }
        setAnchorEl(null);
    }

    const filterClear = () => {
        if(page=== "Recommendation" || page === "Orders"){
        setFilterDateData({ FromDate: "", ToDate: "" })}
        setCheckedItems({})
        setFinalCheckedItems({});
        setFilterCount(0);
        setInitialFilter({})
        setListData(filteredState)
        setAnchorEl(null)
    }

    const handleCloseFilter = () => {
        setAnchorEl(null);
    };

    return (
        <Menu
            id="basic-menu"
            anchorEl={anchorEl}
            open={open}
            onClose={handleCloseFilter}
            MenuListProps={{
                'aria-labelledby': 'basic-button',
            }}
            sx={{
                maxHeight: "450px",
                width: "60%",
                fontSize: { xs: "10px", sm: "14px" }
            }}
            transformOrigin={{ horizontal: 'right', vertical: 'top' }}
            anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
        >
            {Object.keys(filterList).map((val: any, index: number) => {
                return <MenuItem key={index} sx={{ width: "100%", fontSize: { xs: "0.7rem", sm: "0.9rem" }, }}>
                    {renderAccordion(val, filterList[val], val.toLowerCase())}

                </MenuItem>
            })}
            {(page == "Recommendation" || page == "Orders") && (

                <MenuItem>
                    <Accordion
                        sx={{ width: "100%", margin: 0, border: 'none', '& .MuiAccordionDetails-root': { pt: 0 }, '& .Mui-expanded': { minHeight: 0, maxHeight: "32px" } }}>
                        <AccordionSummary
                            expandIcon={<ArrowDropDownIcon />}
                            aria-controls="panel1-content"
                            id="panel1-header"
                            sx={{ minHeight: '0.1rem' }}
                        >
                            <Typography sx={{ fontSize: '0.8rem', minHeight: '0.1rem' }}>Date</Typography>
                            {filterDateData?.FromDate != '' && filterDateData?.ToDate != '' && <span style={{ marginLeft: '10px', width: '16px', height: '16px', color: 'wheat', fontSize: '12px', textAlign: 'center', backgroundColor: 'red', borderRadius: "50%" }}>1</span>}
                        </AccordionSummary>
                        <AccordionDetails>
                            <FormGroup sx={{ width: '100%', display: "flex", flexDirection: "column" }}>
                                <Box sx={{ '& .MuiOutlinedInput-root': { height: "2rem", fontSize: 12 }, '& .MuiSvgIcon-root': { fontSize: '24px' }, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                                    <Typography style={{ fontSize: '1rem', width: "50%" }}>From</Typography>
                                    <LocalizationProvider dateAdapter={AdapterDayjs}>
                                        <DatePicker
                                            disableFuture
                                            inputFormat="DD/MM/YYYY"
                                            maxDate={filterDateData?.ToDate}
                                            value={filterDateData?.FromDate}
                                            onChange={(date: any) =>
                                                setFilterDateData({ ...filterDateData, FromDate: date })
                                            }
                                            renderInput={(params: any) => (
                                                <DatePickerInput
                                                    {...params}
                                                    sx={{ width: ['100%', '100%', '300px'] }}
                                                />
                                            )}
                                        />
                                    </LocalizationProvider>
                                </Box>
                                <Box sx={{ '& .MuiOutlinedInput-root': { height: "2rem", fontSize: 12 }, '& .MuiSvgIcon-root': { fontSize: '24px' }, display: "flex", alignItems: "center", justifyContent: "space-between"}}>
                                    <Typography style={{ fontSize: '1rem', width: "50%" }}>To</Typography>
                                    <LocalizationProvider dateAdapter={AdapterDayjs}>
                                        <DatePicker
                                            disableFuture
                                            inputFormat="DD/MM/YYYY"
                                            minDate={filterDateData?.FromDate}
                                            value={filterDateData?.ToDate}
                                            onChange={(date: any) =>
                                                setFilterDateData({ ...filterDateData, ToDate: date })
                                            }
                                            renderInput={(params: any) => (
                                                <DatePickerInput
                                                    {...params}
                                                    sx={{ width: ['100%', '100%', '300px'] }}
                                                />
                                            )}
                                        />
                                    </LocalizationProvider>
                                </Box>
                            </FormGroup>
                        </AccordionDetails>
                    </Accordion>
                </MenuItem>
            )}

            <MenuItem style={{ width: "100%", justifyContent: "space-around", position: "sticky", bottom: 0, zIndex: 10, backgroundColor: 'white' }}>
                <Button variant="contained" onClick={filterApply} sx={{
                    fontfamily: "Roboto,Nunito,Helvetica,Arial,sans-serif",
                    fontWeight: 600,
                    pt: "8px",
                    pb: "8px",
                    color: "white",
                    background: "linear-gradient(90deg,#0090FF,#1EB1F3,#0090FF)",
                    fontSize: { xs: "10px", sm: "14px" },
                    width: "40%",
                    borderRadius: "10px"
                }}>Apply</Button>
                <Button onClick={filterClear} sx={{
                    fontfamily: "Roboto,Nunito,Helvetica,Arial,sans-serif",
                    fontWeight: 600,
                    pt: "7px",
                    pb: "7px",
                    fontSize: { xs: "10px", sm: "14px" },
                    width: "40%",
                    borderRadius: "10px",
                    background: "#fff",
                    border: "0.5px solid #0090FF",
                    color: "#0090FF"
                }}>Clear All</Button>
            </MenuItem>
        </Menu >
    )
}