import { Backdrop, Box, Button, CardMedia, Checkbox, CircularProgress, Divider, Drawer, FormControl, IconButton, InputLabel, MenuItem, Select, Tab, TextField, TextFieldProps, Typography } from "@mui/material";
import { JSXElementConstructor, ReactElement, memo, useEffect, useRef, useState } from "react";
import { AddToCartButtons, TopHoldingButtons } from "../commonComponents";
import { TabContext, TabList, TabPanel } from "@mui/lab";

import { CheckBox } from "@mui/icons-material";
import DatePicker, { registerLocale } from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';

import dayjs from "dayjs";
// import { DemoContainer } from '@mui/x-date-pickers/internals/demo';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { Masters, RecommendationsType, SchemeList, ValidationForSIP, useGetTotalData } from "./transaction.context";
import Scheme_List from "./scheme-list";
import './styles.css';
import { bseCodePayload, createTransactionPayload } from "./investor-transaction-helper";
import { useNavigate } from 'react-router';
import Swal from "sweetalert2";
import { useLoginContext } from "../login/data/login.context";
import { CloseIcon } from "../customSVGs";



// export function Sipbox(){
//   console.log("sip click")
//   return(
//       <Box style={{color:'blue', backgroundColor:'yellow', fontSize:30}}>
//           hiii
//       </Box>
//   )
// }

interface schemeParams {
  SchemeID: number;
  SchemeName: string;
  Aum: string;
  Sch_Return5Yr: number;
  minPurchase: any;
  maxPurchase: any;
  invAmount: number;
  instalmentAmount: number;
  error: boolean;
  errorInstalment: boolean;
  errorSIPDay: boolean;
  errorFolio: boolean;
  errorFrequency: boolean;
  errorInstalmentAmount: boolean;
  errorMessage: string;
  errorMessageInstalment: string;
  errorMessageFolio: string;
  errorMessageSIPDay: string;
  errorMessageFrequency: string;
  errorMessageInstalmentAmount: string;
  AssetClassName: string;
  Sub_AssetclassName: string;
  Dividendfrequency: string | null;
  Growthoption: number;
  Dividendreinvestment: number;
  DividendPayout: number;
  instalments: number;
  SIPDay: string;
  mandate: string;
  frequency: string;
  Sch: any;
}

interface sipSchemeValidation {
  Productcode_RTA: string,
  SIPFREQUENCY: string | null,
  SIPDATES: string,
  SIPMINIMUMINSTALLMENTAMOUNT: string,
  SIPMAXIMUMINSTALLMENTAMOUNT: string,
  SIPMINIMUMINSTALLMENTNUMBERS: string,
  SIPMAXIMUMINSTALLMENTNUMBERS: string,
  SCHEMEISIN: string,
  SIPMINIMUMGAP: string,
  IPMAXIMUMGAP: string,
  SIPMULTIPLIERAMOUNT: string
}
export const AddToCartDrawer = memo(({
  anchorEl,
  handleClose,
  schemeName,
  recommendedSchemeData,
  recommendedDate,
  type,
  tab,
  AmcID
}: { anchorEl: boolean; handleClose: () => void; schemeName: string, recommendedSchemeData: SchemeList | RecommendationsType, recommendedDate?: string, type?: string, tab?: string, AmcID?: number }): JSX.Element => {

  const { getBSECode, createTransaction } = useGetTotalData();
  const { validation, getValidationDetails, schemesList, getclientmandateIdsDetails, getFolioList, folioList } = useGetTotalData(); ///take reference
  const { getCartCount } = useLoginContext();
  const navigate = useNavigate();
  const { masters, getMastersDetails } = useGetTotalData();
  const [schemeValidation, setSchemeValidation] = useState<ValidationForSIP[]>();
  const [mastersData, setMastersData] = useState<Masters[]>()
  const [modalState, setModalState] = useState(false);
  // const [value, setValue] = useState<string>('SchemeType' in recommendedSchemeData ? recommendedSchemeData.SchemeType.includes('Lumpsum')
  //   ? 'lumpsum'
  //   : 'sip' : 'sip');
  const [value, setValue] = useState<any>(tab || 'sip');
  // console.log("recommendedSchemeData-->", recommendedSchemeData);
  // const [select, setSelect] = useState(`${recommendedSchemeData?.Frequency}`);
  const [mandateselect, setMandateselect] = useState('');
  // const [selectedDate, setSelectedDate] = useState(new Date('2014-08-18T21:11:54'));
  const [endDate, setEndDate] = useState<string | Date>(new Date());
  const [checked, setChecked] = useState(false);
  const [loading, setLoading] = useState(false);
  const [schemeParams, setSchemeParams] = useState<schemeParams>({
    SchemeID: recommendedSchemeData?.SchemeID ? Number(recommendedSchemeData.SchemeID) : 0,
    SchemeName: recommendedSchemeData?.SchemeName ? recommendedSchemeData.SchemeName : "",
    Aum: recommendedSchemeData?.Aum ? recommendedSchemeData.Aum : "",
    Sch_Return5Yr: recommendedSchemeData?.Sch_Return5Yr ? Number(recommendedSchemeData.Sch_Return5Yr) : 0,
    minPurchase: recommendedSchemeData && 'MinimumPurchaseAmount' in recommendedSchemeData ? recommendedSchemeData.MinimumPurchaseAmount : 0,
    maxPurchase: recommendedSchemeData && 'MaximumPurchaseAmount' in recommendedSchemeData ? recommendedSchemeData.MaximumPurchaseAmount : 100,

    instalmentAmount: recommendedSchemeData && 'InvestmentAmount' in recommendedSchemeData
      ? recommendedSchemeData.InvestmentAmount
      : 0,
    invAmount: recommendedSchemeData && 'InvestmentAmount' in recommendedSchemeData
      ? recommendedSchemeData.InvestmentAmount
      : 0,
    error: false,
    errorInstalment: false,
    errorSIPDay: false,
    errorFolio: false,
    errorFrequency: false,
    errorInstalmentAmount: false,
    errorMessage: "",
    errorMessageInstalment: "",
    errorMessageFolio: "",
    errorMessageSIPDay: "",
    errorMessageFrequency: "",
    errorMessageInstalmentAmount: "",
    AssetClassName: recommendedSchemeData?.AssetClassName ? recommendedSchemeData.AssetClassName : "",
    Sub_AssetclassName: recommendedSchemeData?.Sub_AssetclassName ? recommendedSchemeData.Sub_AssetclassName : "",
    Dividendfrequency: recommendedSchemeData?.Dividendfrequency ? recommendedSchemeData.Dividendfrequency : "",
    Growthoption: recommendedSchemeData?.Growthoption ? recommendedSchemeData?.Growthoption : 0,
    Dividendreinvestment: recommendedSchemeData?.Dividendreinvestment ? recommendedSchemeData.Dividendreinvestment : 0,
    DividendPayout: recommendedSchemeData?.DividendPayout ? recommendedSchemeData.DividendPayout : 0,
    instalments: recommendedSchemeData && 'No_of_Installments' in recommendedSchemeData ? recommendedSchemeData.No_of_Installments : 0,
    SIPDay: "",
    mandate: "",
    frequency: recommendedSchemeData && 'Frequency' in recommendedSchemeData ? (recommendedSchemeData?.Frequency).toUpperCase() : "",
    Sch: recommendedSchemeData?.Sch ? recommendedSchemeData.Sch : 0

  });
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [rmId, setRmId] = useState<number | null>();
  const [SIPvalidations, SetSIPValidations] = useState<ValidationForSIP | undefined>();
  const frequencyMapping: any = {
    "DAILY": "1",
    "Weekly": "2",
    "MONTHLY": "3",
    "QUARTERLY": "4",
    "ANNUALLY": "6",
  }
  const [mandateIDs, setMandateIDs] = useState<any>();
  const [folio, setFolio] = useState<any>("");
  const [foliolist, setFolioList] = useState<any>();
  // const datePickerRef = useRef<DatePicker>(null);

  const [selectedDate, setSelectedDate] = useState<Date | null>(null);

  const isDateDisabled = (date: Date): boolean => {

    const currentDate = new Date();
    currentDate.setHours(0, 0, 0, 0);
    if (date < currentDate) {
      return false;
    }

    let foundValue: any = schemeValidation?.find((val: any) => val.SIPFREQUENCY == schemeParams.frequency);
    let datesArray: any = foundValue?.SIPDATES.split(',');

    if (datesArray.includes(date.getDate().toString())) {
      return true;
    } else {
      return false;
    }
  };

  // useEffect(() => {

  //   try {
  //     getValidationDetails(recommendedSchemeData.Sch);
  //     console.log(recommendedSchemeData.Sch)
  //   } catch (error) {
  //     console.error("Error ", error);
  //   }

  // }
  //   , []);
  useEffect(() => {
    const minPurchase_ = recommendedSchemeData ? schemesList?.filter((val) => val.SchemeID == recommendedSchemeData.SchemeID)[0]?.MinimumPurchaseAmount : "";
    const maxPurchase_ = recommendedSchemeData ? schemesList?.filter((val) => val.SchemeID == recommendedSchemeData.SchemeID)[0]?.MaximumPurchaseAmount : "";
    setSchemeParams({
      ...schemeParams,
      minPurchase: recommendedSchemeData && 'MinimumPurchaseAmount' in recommendedSchemeData ? recommendedSchemeData.MinimumPurchaseAmount : minPurchase_,
      maxPurchase: recommendedSchemeData && 'MaximumPurchaseAmount' in recommendedSchemeData ? recommendedSchemeData.MaximumPurchaseAmount : maxPurchase_
    })
    try {
      if (recommendedSchemeData && recommendedSchemeData.Sch) {
        getValidationDetails({ sch: recommendedSchemeData.Sch, TrType: "SIP" });
      } else {
        console.log("recommendedSchemeData or recommendedSchemeData.Sch is undefined");
      }
    } catch (error) {
      console.error("Error ", error);
    }
  }, [recommendedSchemeData]);


  useEffect(() => {
    setSchemeValidation(validation);
    recommendedSchemeData && 'Frequency' in recommendedSchemeData && SetSIPValidations(validation?.filter((item) => item.SIPFREQUENCY === recommendedSchemeData.Frequency.toUpperCase())[0]);
  }, [validation, recommendedSchemeData])

  const _handleModalState = () => {
    handleClose();
    setModalState(modalState);
  };
  const handleChange = (event: any, value: any) => {
    setValue(value);
    setLoading(false);
    setFolio("")
  };

  const handleSelectChange = (event: any) => {

  };

  const handleMandateSelectChange = (event: any) => {
    console.log("in mandate change", event.target.value)
    setMandateselect(event.target.value as string);
  };

  // Function to handle checkbox state change
  const handleCheckboxChange = () => {
    setChecked(!checked);
  };

  const changeInsSIPAmt = (FrequencyVal: any) => {
    SetSIPValidations(schemeValidation?.filter((item: any) => item.SIPFREQUENCY === FrequencyVal)[0]);
  }

  // const openDatePicker = () => {
  //   if (datePickerRef.current) {
  //     datePickerRef.current.setOpen(true);
  //   }
  // };

  // const CustomInput = ({ value }: any) => (
  //   <div className="custom-input-container">
  //     <input className="custom-datepicker">{selectedDate}</input>
  //     <IconButton onClick={openDatePicker}>
  //       <CalendarTodayIcon />
  //     </IconButton>
  //   </div>
  // );

  useEffect(() => {
    (async function () {
      try {
        let mandateIds_reponse: any = await getclientmandateIdsDetails()
        // console.log("mandateIds_reponse value", mandateIds_reponse[0])
        setMandateIDs(mandateIds_reponse[0])
      } catch (e) {
        console.error(e);
      }
    })();
  }, [])

  useEffect(() => {
    getFolioList({ "AMC": AmcID || 0 })
  }, [])
  useEffect(() => {
    setFolioList(folioList)
    console.log("foliolist", foliolist)
  }, [schemeParams, mandateIDs])

  const handleSubmit = () => {

    let shouldReturn = false;
    if (!invAmountValidation() || !SIPDataValidation()) {
      shouldReturn = true;
    }
    else {
      setLoading(true)
    }
    // const data: any = [];
    // schemeParams?.map((item) => {
    //   const obj = {
    //     SchemeID: item.SchemeID,
    //     InvestmentAmount: item.switchValue === 'SIP' ? item.instalmentAmount : item.invAmount,
    //     SchemeType: item.switchValue,
    //     rmID: rmId,
    //     ClientCode: investorId,
    //     No_of_Installments: item.switchValue === 'SIP' ? item.instalments : null,
    //     SIP_date: item.switchValue === 'SIP' ? item.SIPDay : "",
    //     Frequency: item.switchValue === 'SIP' ? item.frequency : null
    //   }
    //   data.push(obj);
    // })
    // const recommendationData = {
    //   recommendation_data: data
    // }
    if (shouldReturn == true) {
      return;
    }
    if (type == 'Add') {
      let payload: any = {}
      getBSECode({
        "TrType": value == "sip" ? "XSIP" : "Add",
        "Amount": value == "sip" ? schemeParams.instalmentAmount.toString() : schemeParams.invAmount.toString(),
        "Growthoption": recommendedSchemeData?.Growthoption,
        "DividendReinvestment": recommendedSchemeData?.Dividendreinvestment,
        "RTACODE": recommendedSchemeData?.Sch
      }).then(({ bse_code }) => {
        if (value == "sip") {
          payload = {
            "RecId": recommendedSchemeData?.RecID,
            "AccNo": folio,
            "AmcId": recommendedSchemeData?.AmcID,
            "BSE_SchemeCode": bse_code[0][0]?.BSE_ProductCod,
            "DividendReinvestment": recommendedSchemeData?.Dividendreinvestment,
            "FirstOrderToday": checked == true ? "Y" : "N",
            "Frequency": frequencyMapping[schemeParams.frequency],
            "Growthoption": schemeParams.Growthoption,
            "Installments": schemeParams.instalments,
            "InstallmentsAmt": schemeParams.instalmentAmount.toString(),
            "MandateId": "",
            "Sch": recommendedSchemeData?.Sch,
            "StartDate": schemeParams.SIPDay != null ? schemeParams.SIPDay.slice(0, 10).split("-").reverse().join('/') : new Date().toJSON().slice(0, 10).split("-").reverse().join('/'),
            "TrType": "XSIP"
          }
        }
        else {
          payload = {
            "RecId": recommendedSchemeData?.RecID,
            "AccNo": folio,
            "AmcId": recommendedSchemeData?.AmcID,
            "Amount": schemeParams?.invAmount?.toString(),
            "BSE_SchemeCode": bse_code[0][0]?.BSE_ProductCod,
            "DividendReinvestment": schemeParams?.Dividendreinvestment,
            "Growthoption": schemeParams?.Growthoption,
            "Sch": recommendedSchemeData?.Sch,
            "TrType": "Add"
          }
        }
        createTransaction(payload).then((response) => {
          // console.log("response for createTransaction", response)
          if (response.transaction_created != "" && response.transaction_created != null) {

            getCartCount()
            handleClose()
            Swal.fire({
              title: "Added to cart!",
              icon: "success",
              customClass: {
                confirmButton: 'sweet-alert-button'
              }
            }).then(() => {
              navigate("/cart", { state: { "value": payload.TrType, "subValue": value } });
            });
          }
        })
      })

    }
    else {
      getBSECode({
        "TrType": value == "sip" ? "ISIP" : "New",
        "Amount": value == "sip" ? schemeParams.instalmentAmount.toString() : schemeParams.invAmount.toString(),
        "Growthoption": recommendedSchemeData?.Growthoption,
        "DividendReinvestment": recommendedSchemeData?.Dividendreinvestment,
        "RTACODE": recommendedSchemeData?.Sch
      }).then(({ bse_code }) => {
        let payload: any = {}
        if (value == "sip") {
          payload = {
            "StartDate": schemeParams.SIPDay, // date from form
            "Installments": schemeParams.instalments,
            "InstallmentsAmt": schemeParams.instalmentAmount.toString(),
            "MandateId": "",
            "AccNo": folio == "New Folio" ? "": folio,
            "MandateType": "",
            "FirstOrderToday": checked == true ? "Y" : "N",
            "Frequency": frequencyMapping[schemeParams.frequency],
            "AmcId": recommendedSchemeData?.AmcID,
            "Sch": recommendedSchemeData?.Sch,
            "TrType": value == "sip" ? "ISIP" : "New",
            "Growthoption": recommendedSchemeData?.Growthoption,
            "DividendReinvestment": recommendedSchemeData?.Dividendreinvestment,
            "BSE_SchemeCode": bse_code[0][0].BSE_ProductCod,
            "RecId": recommendedSchemeData?.RecID ? recommendedSchemeData?.RecID : 0
          }
        }
        else {
          payload = {
            "Amount": schemeParams.invAmount.toString(),
            "AmcId": recommendedSchemeData?.AmcID,
            "Sch": recommendedSchemeData?.Sch,
            "TrType": "New",
            "AccNo": folio == "New Folio" ? "": folio,
            "Growthoption": recommendedSchemeData?.Growthoption,
            "DividendReinvestment": recommendedSchemeData?.Dividendreinvestment,
            "BSE_SchemeCode": bse_code[0][0].BSE_ProductCod,
            "RecId": recommendedSchemeData?.RecID ? recommendedSchemeData?.RecID : 0
          }
        }
        createTransaction(payload).then((response) => {
          // console.log("response for createTransaction", response)
          if (response.transaction_created != "" && response.transaction_created != null) {
            getCartCount()
            handleClose()
            Swal.fire({
              title: "Added to cart!",
              icon: "success",
              customClass: {
                confirmButton: 'sweet-alert-button'
              }
            }).then(() => {
              navigate("/cart", { state: { "value": payload.TrType, "subValue": value } });
            });
          }
        })
      })
    }
    // await postRecommendedSchemes(recommendationData);
    // setIsLoading(false);
  }

  useEffect(() => {
    if (schemeParams.frequency != "NULL" && recommendedDate != undefined) {
      setSelectedDate(new Date(recommendedDate))
      setSchemeParams((prevParams) => ({ ...prevParams, SIPDay: recommendedDate.split('T')[0].split("-").reverse().join('/') }));
    }
  }, [])


  //validation for SIP data
  const SIPDataValidation = () => {
    let valid = true;
    // if(value === 'sip' && folio == "")
    //   {
    //     setSchemeParams((prevParams)=>({...prevParams,errorFolio: true, errorMessageFolio:"Folio can not be empty"}))
    //     valid=false;
    //   }
    if (value === 'sip' && (schemeParams.frequency == null || schemeParams.frequency === "")) {
      if (schemeParams.frequency == null || schemeParams.frequency === "") {
        setSchemeParams((prevParams) => ({ ...prevParams, errorFrequency: true, errorMessageFrequency: "Frequency can not be empty" }));
        valid = false;
      }
      else {
        setSchemeParams((prevParams) => ({ ...prevParams, errorFrequency: false }));
      }
      return valid;
    }
    if (value === 'sip' && !(schemeParams.frequency == null || schemeParams.frequency === "")) {
      setSchemeParams((prevParams) => ({ ...prevParams, errorFrequency: false }));
      if (schemeParams.instalmentAmount === null || schemeParams.instalmentAmount === 0) {
        setSchemeParams((prevParams) => ({ ...prevParams, errorInstalmentAmount: true, errorMessageInstalmentAmount: "Instalment Amount can not be empty" }));
        valid = false;
      }
      else if (schemeParams.instalmentAmount && (schemeParams.instalmentAmount < Number(SIPvalidations?.SIPMINIMUMINSTALLMENTAMOUNT) || schemeParams.instalmentAmount > Number(SIPvalidations?.SIPMAXIMUMINSTALLMENTAMOUNT))) {
        setSchemeParams((prevParams) => ({
          ...prevParams,
          errorInstalmentAmount: true,
          errorMessageInstalmentAmount: `Please enter amount greater than ${SIPvalidations?.SIPMINIMUMINSTALLMENTAMOUNT} or less than ${SIPvalidations?.SIPMAXIMUMINSTALLMENTAMOUNT}`
        }));
        valid = false;
      }
      else {
        setSchemeParams((prevParams) => ({ ...prevParams, errorInstalmentAmount: false }));
      }

      if (schemeParams.instalments == null || schemeParams.instalments === 0) {
        setSchemeParams((prevParams) => ({ ...prevParams, errorInstalment: true, errorMessageInstalment: "No. of Instalments can not be empty" }));
        valid = false;
      }
      else if (schemeParams.instalments && (schemeParams.instalments < Number(SIPvalidations?.SIPMINIMUMINSTALLMENTNUMBERS) || schemeParams.instalments > Number(SIPvalidations?.SIPMAXIMUMINSTALLMENTNUMBERS))) {
        setSchemeParams((prevParams) => ({
          ...prevParams, errorInstalment: true,
          errorMessageInstalment: `Please enter amount greater than ${SIPvalidations?.SIPMINIMUMINSTALLMENTNUMBERS} or less than ${SIPvalidations?.SIPMAXIMUMINSTALLMENTNUMBERS}`
        }));
        valid = false;
      }
      else {
        setSchemeParams((prevParams) => ({ ...prevParams, errorInstalment: false }));
      }

      if (schemeParams.SIPDay == "") {
        setSchemeParams((prevParams) => ({ ...prevParams, errorSIPDay: true, errorMessageSIPDay: "SIP Day can not be empty" }));
        valid = false;
      }
      else {
        setSchemeParams((prevParams) => ({ ...prevParams, errorSIPDay: false }));
      }
    }
    return valid;
  }

  //validation for Lumpsum
  const invAmountValidation = () => {
    let valid = true;
    // if(value !== 'sip' && folio == "")
    //   {
    //     setSchemeParams((prevParams)=>({...prevParams,errorFolio: true, errorMessageFolio:"Folio can not be empty"}))
    //     valid=false;
    //   }
    if (value !== 'sip') {
      if (schemeParams.invAmount == null || schemeParams.invAmount == 0) {
        setSchemeParams((prevParams) => ({ ...prevParams, error: true, errorMessage: "Amount Can not be empty" }));
        valid = false;
      }
      else if (schemeParams.invAmount && (schemeParams.invAmount < schemeParams.minPurchase || schemeParams.invAmount > schemeParams.maxPurchase)) {
        setSchemeParams((prevParams) => ({ ...prevParams, error: true, errorMessage: `Enter Amount between ${schemeParams.minPurchase} - ${schemeParams.maxPurchase}` }));
        valid = false;
      }
      else {
        setSchemeParams((prevParams) => ({ ...prevParams, error: false }));
      }
    }
    return valid;
  }

  return (
    <Box>
      <Drawer anchor={'right'} open={anchorEl} onClose={_handleModalState} sx={{ overflowX: "hidden" }}>
        <Box sx={{ width: { xs: "100%", sm: '500px' } }}>
          <Box sx={{ display: "flex", flexDirection: "row", justifyContent: 'space-between', alignItems: 'flex-end', px: '1rem', py: '1.4rem', position: "sticky", top: 0, zIndex: 10, bgcolor: "white" }}>
            <Box sx={{ display: 'flex', alignItems: 'center' }}>
              <span style={{ width: '12px', height: '12px', borderRadius: '50%', marginRight: '0.8rem', backgroundColor: '#1EB1F3' }}></span>
              <Typography sx={{ fontSize: 18, fontWeight: 500 }}>{schemeName}</Typography>
            </Box>
            <Box sx={{ cursor: 'pointer' }} onClick={handleClose} >
              <CloseIcon />
            </Box>
          </Box>

          <Divider />
          <Box
            sx={{
              width: '100%',
              '& .MuiTabPanel-root': {
                py: 2,
                px: 0
              },
              '& .MuiTab-root': {
                color: '#A1A2A2',
                opacity: 0.8,
                fontSize: 14,
                lineHeight: '18px',
                textTransform: 'capitalize',
                mx: { xs: 0, sm: 1 },
                px: { xs: 2, md: 2, lg: 4 },
                minWidth: "5rem",
                '&.Mui-selected': {
                  color: '#1EB1F3',
                  border: 'none'
                },
              },
              ' & .MuiTab': {
                backgroundColor: 'yellow'
              },
              '& .MuiTabs-indicator': {
                height: 2,
                background: '#1EB1F3'
              },
              '& .MuiButtonBase-root': {
                px: 3,
              },
              '& .MuiTabs-flexContainer': {
                display: "flex",
                justifyContent: "flex-start",
                width: "100%",
              }
            }}>
            <TabContext value={value} >
              <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
                <TabList onChange={handleChange}>
                  <Tab label="SIP" value="sip" />
                  <Tab label="Lumpsum" value="lumpsum" />
                </TabList>
              </Box>

              <TabPanel value="sip">

                <Box sx={{ mx: { xs: 3, sm: 6 } }}>

                  {/* Frequency */}
                  <Box sx={{ my: 1.5 }}>
                    <Typography>Frequency</Typography>
                    <FormControl sx={{ width: '100%' }} >

                      <Select
                        labelId="demo-simple-select-label"
                        id="demo-simple-select"
                        value={schemeParams?.frequency}
                        onChange={(e) => {
                          const objectToUpdate = schemeParams;
                          if (objectToUpdate) {
                            objectToUpdate.frequency = e.target.value
                            objectToUpdate.SIPDay = ""
                            if (recommendedDate != undefined) {
                              objectToUpdate.SIPDay = recommendedDate.split('T')[0].split("-").reverse().join('/')
                              setSelectedDate(new Date(recommendedDate))
                            }
                            setSchemeParams(objectToUpdate);
                          }
                          changeInsSIPAmt(e.target.value);
                        }}
                        defaultValue={schemeParams?.frequency}
                        inputProps={{ 'aria-label': 'Without label' }}
                      >
                        {schemeValidation?.map((item: any, index: number) => (
                          <MenuItem key={index} value={item.SIPFREQUENCY}>{item.SIPFREQUENCY}</MenuItem>
                        ))}
                      </Select>
                    </FormControl>
                    {schemeParams.errorFrequency && <Typography sx={{ fontSize: 10, color: 'red', mb: 0.5 }}> {schemeParams.errorMessageFrequency} </Typography>}
                  </Box>

                  {((schemeParams.frequency != "" && recommendedDate == undefined) || (schemeParams.frequency != "NULL" && recommendedDate != undefined)) &&
                    <Box>
                      {/* // Mandate  */}
                      <Box>
                        <Typography>Mandates</Typography>

                        <FormControl sx={{ width: '100%', my: 1 }} >
                          <Select
                            labelId="demo-simple-select-label"
                            id="demo-simple-select"
                            value={mandateselect}

                            onChange={handleMandateSelectChange}
                            displayEmpty
                            inputProps={{ 'aria-label': 'Without label' }}
                          >
                            {mandateIDs?.map((data: any, index: number) => {
                              return <MenuItem key={index} value={data.Details}>{data.Details}</MenuItem>
                            })}

                          </Select>
                        </FormControl>
                        <Typography>
                          <span>Not available ? </span>
                          <a onClick={() => navigate('/add-mandate')} style={{ cursor: "pointer", color: "#0090FF" }}>Add Mandate</a>
                        </Typography>
                      </Box>
                      <Box sx={{ my: 1.5 }}>
                        <Typography>Folio</Typography>
                        <FormControl sx={{ width: '100%' }} >

                          <Select
                            labelId="demo-simple-select-label"
                            id="demo-simple-select"
                            value={folio}
                            onChange={(e: any) => {
                              setFolio(e.target.value);
                            }}

                            inputProps={{ 'aria-label': 'Without label' }}
                          >
                            {foliolist?.length == 0 ?
                              <MenuItem value="New Folio">
                                New Folio
                              </MenuItem> :

                              foliolist?.map((i: any, index: any) => (
                                <MenuItem key={index} value={i.Folio}> {i.Folio}</MenuItem>))
                            }
                          </Select>
                        </FormControl>
                        {/* {schemeParams.errorFolio && <Typography sx={{ fontSize: 10, color: 'red', mb: 0.5 }}> {schemeParams.errorMessageFolio} </Typography>} */}
                      </Box>

                      {/* SIP Day */}
                      <Box sx={{ my: 1.5 }}>
                        <Typography>SIP Day</Typography>
                        <DatePicker
                          className="custom-datepicker"
                          // ref={datePickerRef}
                          selected={selectedDate}
                          onChange={(date: Date) => {
                            setSelectedDate(date)
                            const mapToDoubleDigit = (number: number): string => {
                              return number < 9 ? `0${number + 1}` : `${number + 1}`;
                            };
                            const mapDayToDoubleDigit = (number: any): string => {
                              return number <= 9 ? `0${number}` : `${number}`;
                            };
                            setSchemeParams((prevParams) => ({ ...prevParams, SIPDay: `${mapDayToDoubleDigit(date?.getDate())}/${mapToDoubleDigit(date?.getMonth())}/${date?.getFullYear()}` }));
                          }}
                          dateFormat="dd-MM-yyyy"
                          filterDate={isDateDisabled}
                          placeholderText={'dd-mm-yyyy'}
                        // customInput={<CustomInput />}

                        />
                        {schemeParams?.errorSIPDay && <Typography sx={{ fontSize: 10, color: 'red', mb: 0.5 }}> {schemeParams.errorMessageSIPDay} </Typography>}
                      </Box>

                      {/* No. of installments */}
                      <Box sx={{ my: 1.5 }}>
                        <Typography>No. of Installments</Typography>
                        <input type="text" className='investmentAmount2' placeholder={`Enter Number ${SIPvalidations?.SIPMINIMUMINSTALLMENTNUMBERS} - ${SIPvalidations?.SIPMAXIMUMINSTALLMENTNUMBERS}`} value={schemeParams.instalments}
                          onChange={(e) => {
                            let newValue = e.target.value;

                            newValue = newValue.replace(/[^0-9]/g, '');

                            if (newValue.length < schemeParams.instalments?.toString().length) {
                              newValue = newValue.slice(0, -1);
                            }

                            setSchemeParams((prevParams) => ({ ...prevParams, instalments: Number(newValue) }));
                          }}
                        >
                        </input>
                        {schemeParams?.errorInstalment && <Typography sx={{ fontSize: 10, color: 'red', mb: 0.5 }}> {schemeParams.errorMessageInstalment} </Typography>}
                      </Box>

                      {/* First Order Today */}
                      <Box sx={{ display: 'flex', my: 1.5 }}>
                        <Checkbox
                          checked={checked}
                          onChange={handleCheckboxChange}
                          inputProps={{ 'aria-label': 'controlled' }}
                          sx={{ p: 0, m: 0 }}
                        />
                        <Typography sx={{ mx: 2 }} >First Order Today</Typography>

                      </Box>

                      {/* Amount */}
                      <Box sx={{ width: '100%', my: 1.5 }}>
                        <Typography>Amount <span style={{ fontSize: '12px', color: 'grey' }}> {`Minimum- ₹${SIPvalidations?.SIPMINIMUMINSTALLMENTAMOUNT}`}</span></Typography>
                        <input type="text" className='investmentAmount2' value={schemeParams?.instalmentAmount}
                          onChange={(e) => {
                            let newValue = e.target.value;

                            newValue = newValue.replace(/[^0-9]/g, '');

                            if (newValue.length < schemeParams.instalmentAmount.toString().length) {
                              newValue = newValue.slice(0, -1);
                            }

                            setSchemeParams((prevParams) => ({ ...prevParams, instalmentAmount: Number(newValue) }));
                          }}>
                        </input>
                        {schemeParams?.errorInstalmentAmount && <Typography sx={{ fontSize: 10, color: 'red', mb: 0.5 }}> {schemeParams.errorMessageInstalmentAmount} </Typography>}
                        <Box sx={{ display: 'flex', flexDirection: 'row', justifyContent: 'space-between', mt: 3 }}>
                          {[2000, 5000, 10000].map((item: any, idx: number) =>
                            <Button key={idx} sx={{ border: '0.5px solid #dfdfdf', color: '#dfdfdf', boxShadow: '0px 0px 0.5px 0.5px', height: { xs: '25px', sm: '35px' }, borderRadius: '10px', width: '28%', fontSize: { xs: 12, sm: 17 } }}
                              onClick={() => {
                                setSchemeParams((prevParams) => ({ ...prevParams, instalmentAmount: schemeParams.instalmentAmount + item }));
                              }}
                            >+{item}</Button>
                          )}
                        </Box>

                      </Box>
                    </Box>}

                  <Box sx={{ mt: 2 }}>
                    <Typography sx={{ fontSize: '9px', color: 'green' }}>NOTE:</Typography>
                    <Typography sx={{ fontSize: '9px', color: 'grey' }}>SIP: Systematic Investment Plan</Typography>
                    <Typography sx={{ fontSize: '9px', color: 'grey' }}>Lumpsum: One time payment</Typography>
                  </Box>
                  <Box sx={{ display: 'flex', flexDirection: 'column', mt: 3 }}>
                    <i style={{ fontSize: '11px', fontWeight: 500, justifyContent: 'center', width: '70%', margin: '0% 0% 0% 15%' }}>
                      By continuing, I agree with <span style={{ color: 'green' }}> Disclaimers</span> and <span style={{ color: 'green' }}> Terms and Conditions </span> of Kfin Technologies Limited
                    </i>
                    <Button sx={{ background: 'linear-gradient(90deg,  #36DAE9 ,#0090FF)', height: "2.5rem", color: '#ffffff', borderRadius: '8px', mt: 3 }} onClick={handleSubmit}>
                      {loading ? <Box sx={{ display: 'flex' }}>
                        <CircularProgress style={{ color: "white" }} size="1.8rem" />
                      </Box> :
                        "Add To Cart"}
                    </Button>
                  </Box>
                </Box>
              </TabPanel>


              <TabPanel value="lumpsum">
                <Box sx={{ mx: { xs: 3, sm: 6 } }}>
                  <Box sx={{ my: 1.5 }}>
                    <Typography>Folio</Typography>
                    <FormControl sx={{ width: '100%' }} >

                      <Select
                        labelId="demo-simple-select-label"
                        id="demo-simple-select"
                        value={folio}
                        onChange={(e: any) => {
                          setFolio(e.target.value as string);
                        }}

                        inputProps={{ 'aria-label': 'Without label' }}
                      >
                       {foliolist?.length == 0 ?
                              <MenuItem value="New Folio">
                                New Folio
                              </MenuItem> :

                              foliolist?.map((i: any, index: any) => (
                                <MenuItem key={index} value={i.Folio}> {i.Folio}</MenuItem>))
                            }
                      </Select>
                    </FormControl>
                    {/* {schemeParams.errorFolio && <Typography sx={{ fontSize: 10, color: 'red', mb: 0.5 }}> {schemeParams.errorMessageFolio} </Typography>} */}
                  </Box>

                  <Box sx={{ my: 1.5 }}>
                    <Typography>Amount <span style={{ fontSize: '12px', color: 'grey' }}> {`Minimum- ₹${schemeParams.minPurchase}`}</span></Typography>
                    <input type="text" className='investmentAmount2' value={schemeParams?.invAmount}
                      onChange={(e) => {
                        let newValue = e.target.value;

                        newValue = newValue.replace(/[^0-9]/g, '');

                        if (newValue.length < schemeParams.invAmount.toString().length) {
                          newValue = newValue.slice(0, -1);
                        }

                        setSchemeParams((prevParams) => ({ ...prevParams, invAmount: Number(newValue) }));
                      }}>
                    </input>
                    {schemeParams?.error && <Typography sx={{ fontSize: 10, color: 'red', mb: 0.5 }}> {schemeParams.errorMessage} </Typography>}
                    <Box sx={{ display: 'flex', flexDirection: 'row', justifyContent: 'space-between', mt: 3 }}>
                      {[2000, 5000, 10000].map((item: any, index: number) =>
                        <Button key={index} sx={{ border: '0.5px solid #dfdfdf', color: '#dfdfdf', boxShadow: '0px 0px 0.5px 0.5px', height: { xs: '25px', sm: '35px' }, borderRadius: '10px', width: '28%', fontSize: { xs: 12, sm: 17 } }}
                          onClick={() => {
                            setSchemeParams((prevParams) => ({ ...prevParams, invAmount: schemeParams.invAmount + item }));
                          }}
                        >+{item}</Button>
                      )}
                    </Box>

                  </Box>
                  <Box sx={{ mt: 2 }}>
                    <Typography sx={{ fontSize: '9px', color: 'green' }}>NOTE:</Typography>
                    <Typography sx={{ fontSize: '9px', color: 'grey' }}>SIP: Systematic Investment Plan</Typography>
                    <Typography sx={{ fontSize: '9px', color: 'grey' }}>Lumpsum: One time payment</Typography>
                  </Box>
                  <Box sx={{ display: 'flex', flexDirection: 'column', mt: 3 }}>
                    <i style={{ fontSize: '11px', fontWeight: 500, justifyContent: 'center', width: '70%', margin: '0% 0% 0% 15%' }}>
                      By continuing, I agree with <span style={{ color: 'green' }}> Disclaimers</span> and <span style={{ color: 'green' }}> Terms and Conditions </span> of Kfin Technologies Limited
                    </i>
                    <Button
                      sx={{
                        background: 'linear-gradient(90deg, #36DAE9, #0090FF)',
                        height: "2.5rem",
                        color: '#ffffff',
                        borderRadius: '8px',
                        mt: 3,
                      }}
                      onClick={handleSubmit}
                    >
                      {loading ? <Box sx={{ display: 'flex' }}>
                        <CircularProgress style={{ color: "white" }} size="1.8rem" />
                      </Box> :
                        "Add To Cart"}
                    </Button>
                  </Box>
                </Box>

              </TabPanel>


            </TabContext>
          </Box>
        </Box>
      </Drawer >
    </Box >
  )
})