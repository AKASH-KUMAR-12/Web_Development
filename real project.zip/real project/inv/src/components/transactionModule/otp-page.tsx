import { Box, Button, Card, CardMedia, Checkbox, Divider, Grid, IconButton, Stack, Switch, Tab, Typography } from "@mui/material";
import SideNavResponsive from "../Sidebar/sidebar.responsive";
import DashboardResponsiveHeader from "../dashboard/dashboard.responsive.header";
import { useEffect, useState } from "react";
import { useRootContext } from "../data/root.context";
import DashboardHeader from "../dashboard/dashboard.header";
import './styles.css'
import { TabContext, TabList } from "@mui/lab";
import { CutOffTimeDrawer } from "./cut.off.time.modal";
import { useNavigate } from 'react-router';

export default function OtpPage() {

  const [otpMessage, setOtpMessage] = useState("")
  const [otpValue, setOtpValue] = useState<string[]>([]);


  const keyDownHandler = (e: any) => {

    if (otpMessage != "") {
      setOtpMessage("")
    }

    if (e.key == "Backspace" && e.target.id > -1) {
      let newOtp = [...otpValue];
      e.preventDefault();
      newOtp[e.target.id] = "";
      setOtpValue(newOtp);
      if (e.target.id > 0) {
        document?.getElementById((parseInt(e.target.id) - 1).toString())?.focus();
      }
    }
  };


  const inputHandler = (e: any) => {

    if (otpMessage != "") {
      setOtpMessage("")
    }

    if (!isNaN(e.target.value)) {
      let newOtp = [...otpValue];
      newOtp[e.target.id] = e.target.value;
      setOtpValue(newOtp);
      if (e.target.id < 5) {
        document?.getElementById((parseInt(e.target.id) + 1).toString())?.focus();
      }
    }
  };

  const handleOTP = (e: any) => {
    // console.log("In submit")
    e.preventDefault();
    let FinalOTP = otpValue.join('')
  };
  
  return (
    <Box>
      <Grid container sx={{ width: '100vw', height: '100vh', overflow: 'auto' }}>
        <Box sx={{ marginTop: '5vh', width: '85%', px: '5vw' }}>
          <DashboardHeader />
          <Typography sx={{ mt: '5vh', fontSize: '20px', fontWeight: 500 }}>
            Transaction Confirmation
          </Typography>
          <Card style={{marginTop: "5vh", "boxShadow": "0px 0px 20px #dfdfdf", borderRadius: "10px"}}>
          <form
            // type="submit"
            style={{ marginTop: "35px" }}
            onSubmit={handleOTP}
          // autoComplete="off"
          >
            <div className="loginform_inputcontainer">

              <div style={{ display: "flex", justifyContent: "center", marginTop: "40px", marginBottom: "20px", alignItems: "center", width: "100%" }}>
                <div style={{ width: "45%" }}>
                  <div className="title_containr" style={{ width: "100%", display: "flex", justifyContent: "center", color: "black", fontWeight: "600", fontSize: '20px' }}>
                    <p className="content_title">Confirmation</p>
                  </div>
                  <div className="title_containr" style={{ width: "100%", display: "flex", justifyContent: "flex-start"}}>
                    <p className="content_title">Please enter the OTP received on the Mobile or Email</p>
                  </div>
                  <div className="title_containr" style={{ width: "100%", display: "flex", justifyContent: "flex-start", color: "black" }}>
                    <p className="content_title">Enter OTP</p>
                  </div>
                  <Stack className="otp-stack" sx={{ height: "3rem", "& .otp-input": { width: "20%", textAlign: "center", margin: ".3rem", aspectRatio: "1/2", padding: "0px" } }} direction="row" spacing={0.1}>

                    <input
                      type="text"
                      inputMode="numeric"
                      id="0"
                      className="otp-input loginform_inputType"
                      maxLength={1}
                      autoComplete="off"
                      autoFocus={true}
                      style={{marginLeft: "0rem"}}
                      onChange={inputHandler}
                      onKeyDown={keyDownHandler}
                      value={otpValue[0]}
                    />
                    <input
                      type="text"
                      inputMode="numeric"
                      id="1"
                      className="otp-input loginform_inputType"
                      maxLength={1}
                      autoComplete="off"
                      onChange={inputHandler}
                      onKeyDown={keyDownHandler}
                      value={otpValue[1]}
                    />
                    <input
                      type="text"
                      inputMode="numeric"
                      id="2"
                      className="otp-input loginform_inputType"
                      maxLength={1}
                      autoComplete="off"
                      onChange={inputHandler}
                      onKeyDown={keyDownHandler}
                      value={otpValue[2]}
                    />
                    <input
                      type="text"
                      inputMode="numeric"
                      id="3"
                      className="otp-input loginform_inputType"
                      maxLength={1}
                      autoComplete="off"
                      onChange={inputHandler}
                      onKeyDown={keyDownHandler}
                      value={otpValue[3]}
                    />
                    <input
                      type="text"
                      inputMode="numeric"
                      id="4"
                      className="otp-input loginform_inputType"
                      maxLength={1}
                      autoComplete="off"
                      onChange={inputHandler}
                      onKeyDown={keyDownHandler}
                      value={otpValue[4]}
                    />
                    <input
                      type="text"
                      inputMode="numeric"
                      id="5"
                      className="otp-input loginform_inputType"
                      maxLength={1}
                      autoComplete="off"
                      autoFocus={otpMessage == "**Incorrect OTP" ? true : false}
                      onChange={inputHandler}
                      onKeyDown={keyDownHandler}
                      value={otpValue[5]}
                    />
                  </Stack>
                </div>
              </div>
            </div>
            <div style={{ color: "rgb(230, 67, 91)", display: "flex", marginTop: "1.2rem" }}>
              <span>{otpMessage}</span>
            </div>
            <div className="otp-submit" style={{ display: "flex", justifyContent: "center", alignItems: "center" }}>
              <button
                className="login_buttoncontainer"
              // type="submit"
              // value="SUBMIT"
              >
                SUBMIT
              </button>
            </div>
          </form>
          <div className="signupLink_container" style={{ display: "flex", justifyContent: "center", alignItems: "center" , marginTop: "1rem",marginBottom: "2rem", gap: "1rem" }}>
            <span>Didn't Receive OTP?</span>
            <a href={""} target="_blank">
              RESEND
            </a>
          </div>
          </Card>
        </Box>
      </Grid>
    </Box>
  );
}
