export interface schemParams_Holdings {
    SchemeID: number;
    SchemeName: string;
    ToSchemeName: string;
    ToSchemeID: string;
    AUM: string| number | null,
    Units: number | null,
    Sch_Return5Yr: string,
    minPurchase: number ,
    maxPurchase: number,
    instalmentAmount: string,
    invAmount: string,
    error: boolean,
    errorInstalment: boolean,
    errorSIPDay: boolean,
    errorSIPFrequency: boolean,
    errorInstalmentAmount: boolean,
    errorMessage: string,
    errorMessageInstalment: string,
    errorMessageSIPDay: string,
    errorMessageSIPFrequency: string,
    errorMessageInstalmentAmount: string,
    // AssetClassName: selectedSchemeData?.AssetClassName ? selectedSchemeData.AssetClassName : "",
    // Sub_AssetclassName: selectedSchemeData?.Sub_AssetclassName ? selectedSchemeData.Sub_AssetclassName : "",
    // Dividendfrequency: selectedSchemeData?.Dividendfrequency ? selectedSchemeData.Dividendfrequency : "",selected
    // Growthoption: selectedSchemeData?.Growthoption ? selectedSchemeData?.Growthoption : 0,
    Dividendreinvestment: number,
    // DividendPayout: selectedSchemeData?.DividendPayout ? selectedSchemeData.DividendPayout : 0,
    instalments: string,
    SIPDay: string,
    STPDay: string,
    SWPDay: string,
    mandate: string,
    sipFrequency: string,
    stpFrequency: string,
    swpFrequency: string,
    switchValue: { value: string|number, type: string },
    switchType: string,
    redeemValue: { value: string|number, type: string },
    redeemType: string,
    // frequency: SchemeData && 'Frequency' in SchemeData ? (SchemeData?.Frequency).toUpperCase() : "",
    SCh: string,
}

// export interface addToCartDrawer_SIPFormData {

// }

export interface errorStatesSIP {
    errorSIPAmount: boolean;
    errorSIPAmountMsg: string;
    errorSIPNoOfInstalment: boolean;
    errorSIPNoOfInstalmentMsg: string;
    errorSIPDay: boolean;
    errorSIPDayMsg: string;
    errorMandates: boolean;
    errorMandateMsg: string;
    errorSIPFrequency: boolean;
    errorSIPFrequencyMsg: string;
}

export const errorStateSIPInitialData = {
    errorSIPAmount: false,
    errorSIPAmountMsg: "",
    errorSIPNoOfInstalment: false,
    errorSIPNoOfInstalmentMsg: "",
    errorSIPDay: false,
    errorSIPDayMsg: "",
    errorMandates: false,
    errorMandateMsg: "",
    errorSIPFrequency: false,
    errorSIPFrequencyMsg: ""
}

export interface errorStatesLumpsum {
    errorLumpsumAmount: boolean;
    errorLumpsumAmountMsg: string;
}

export const errorStateLumpsumInitialData = {
    errorLumpsumAmount: false,
    errorLumpsumAmountMsg: ""
}

export interface errorStatesSTP {
    errorSTPAmount: boolean,
    errorSTPAmountMsg: string,
    errorSTPNoOfInstalment: boolean,
    errorSTPNoOfInstalmentMsg: string,
    errorSTPDay: boolean,
    errorSTPDayMsg: string,
    errorToSchemeID: boolean,
    errorToSchemeIDMsg: string,
    errorFrequency: boolean,
    errorFrequencyMsg: string
}

export const errorStateSTPInitialData: errorStatesSTP = {
    errorSTPAmount: false,
    errorSTPAmountMsg: "",
    errorSTPNoOfInstalment: false,
    errorSTPNoOfInstalmentMsg: "",
    errorSTPDay: false,
    errorSTPDayMsg: "",
    errorToSchemeID: false,
    errorToSchemeIDMsg: "",
    errorFrequency: false,
    errorFrequencyMsg: ""
}

export interface errorStatesSWP {
    errorSWPAmount: boolean,
    errorSWPAmountMsg: string,
    errorSWPNoOfInstalment: boolean,
    errorSWPNoOfInstalmentMsg: string,
    errorSWPDay: boolean,
    errorSWPDayMsg: string,
    errorFrequency: boolean,
    errorFrequencyMsg: string
}

export const errorStateSWPInitialData: errorStatesSWP = {
    errorSWPAmount: false,
    errorSWPAmountMsg: "",
    errorSWPNoOfInstalment: false,
    errorSWPNoOfInstalmentMsg: "",
    errorSWPDay: false,
    errorSWPDayMsg: "",
    errorFrequency: false,
    errorFrequencyMsg: ""
}

export interface errorStatesSWT {
    errorSwitchValue: boolean,
    errorSwitchValueMsg: string,
    errorToSchemeID: boolean,
    errorToSchemeIDMsg: string,
}

export const errorStateSWTInitialData: errorStatesSWT = {
    errorSwitchValue: false,
    errorSwitchValueMsg: "",
    errorToSchemeID: false,
    errorToSchemeIDMsg: "",
}

export interface errorStatesRedeem {
    errorRedeemValue: boolean,
    errorRedeemValueMsg: string
}

export const errorStateRedeemInitialData: errorStatesRedeem = {
    errorRedeemValue: false,
    errorRedeemValueMsg: ""
}

export const frequencyMapping: any = {
    "DAILY": "1",
    "Daily": "1",
    "Weekly": "2",
    "MONTHLY": "3",
    "QUARTERLY": "4",
    "ANNUALLY": "6",
}

export const AssetclassMapping: any = {
    "Equity": "1",
    "Liquid": "2",
    "Hybrid": "3",
    "Debt": "4",
}