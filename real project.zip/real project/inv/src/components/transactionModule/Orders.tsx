import { Box, Button, Divider, Typography, LinearProgress, Tab, IconButton, Modal, Backdrop } from "@mui/material";
import { useGetTotalData, Orders, OrdersDataType } from "./transaction.context";
import { useEffect, useState } from "react";
import { TabContext, TabList, TabPanel } from "@mui/lab";
import { formatToIndianCurrency } from "../utils/utilityFunctions";
import FilterListIcon from '@mui/icons-material/FilterList';
import { FilterComponent } from './Filter';
import CloseRoundedIcon from '@mui/icons-material/CloseRounded';
import { Bubble } from "./investor-transaction-helper";
export const formatLongDate = (date?: string | Date | null): string => {
  if (!date) {
    return '';
  }
  return new Date(date).toLocaleDateString('en-in', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
};
export const formatTime = (inputDateTime: string): string => {
  const date = new Date(inputDateTime);
  date.setHours(date.getHours()-5);
  date.setMinutes(date.getMinutes()-30) ;
  const hours = date.getHours();
  const minutes = date.getMinutes();
  const period = hours >= 12 ? 'pm' : 'am';
  const formattedHours = hours % 12 === 0 ? 12 : hours % 12;
  const formattedMinutes = minutes < 10 ? `0${minutes}` : minutes;

  return `${formattedHours}:${formattedMinutes} ${period}`;
};
export function OrdersModal({ openModal, setOpenModal, OrdersData }: { openModal: boolean, setOpenModal: (val: boolean) => void, OrdersData: any }) {

  const handleModalClose = () => {
    setOpenModal(false)
  };
  const frequencyMapping: any = {
    1: "Daily",
    2: "Weekly",
    3: "Monthly",
    4: "Quarterly",
    6: "Annually",
  }
  return (
    <Modal
      open={openModal}
      onClose={handleModalClose}
      aria-labelledby="modal-modal-title"
      aria-describedby="modal-modal-description"
    >
      <Box sx={{
        position: 'absolute',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        display: 'flex',
        bgcolor: 'white',
        borderRadius: '10px',
        width: { xs: '90%', sm: '50%' },
        outline: 'none', // Remove outline on modal open
      }}>


        <Box sx={{ mx: { xs: 1, sm: 3 }, display: 'flex', flexDirection: 'column', width: '100%' }} >
          <Box sx={{ display: 'flex', flexDirection: 'row', justifyContent: 'space-between' }}>
            <Typography sx={{ fontSize: { xs: 11, sm: 14 }, fontWeight: 600, mt: 2 }}>
              {OrdersData.ProductName}
            </Typography>
            <IconButton ><CloseRoundedIcon sx={{ fontSize: 20 }} onClick={handleModalClose} /></IconButton>
          </Box>
          <Box sx={{ display: 'flex', my: 1 }}>
            {!!OrdersData.AssetClassName && (
              <Bubble text={OrdersData.AssetClassName} />
            )}
            {!!OrdersData.Sub_AssetclassName && (
              <Bubble text={OrdersData.Sub_AssetclassName} />
            )}
            {!!OrdersData.PlanName && (
              <Bubble text={OrdersData.PlanName} />
            )}
            {OrdersData.DividendPayout === 1 ? <><Bubble text={"Payout"} /> <Bubble text={OrdersData.Dividendfrequency} /></>
              : OrdersData.DividendReinvestment === 1 ? <> <Bubble text={"Reinvestment"} /> <Bubble text={OrdersData.Dividendfrequency} /></>
                : ''
            }
          </Box>
          <Divider />
          <Box>
            <Box sx={{ display: 'flex', flexDirection: 'row', mt: 2 }}>
              <Typography sx={{ fontWeight: 500, fontSize: { xs: 11, sm: 14 } }}>{OrdersData.TRTYPE === "New" || OrdersData.TRTYPE === "ISIP" ? "Purchase" : OrdersData.TRTYPE === "XSIP" || OrdersData.TRTYPE === "Add" ? "Additional Purchase" : OrdersData.TRTYPE === 'Red' ? 'Redemption' : OrdersData.TRTYPE === 'Swt' ? 'Switch' : OrdersData.TRTYPE}
                <span style={{ fontSize: 14, fontWeight: 500, marginLeft: 4 }}>{OrdersData.TRTYPE === "New" || OrdersData.TRTYPE === "Add" ? "Lumpsum" : OrdersData.TRTYPE === "XSIP" || OrdersData.TRTYPE === "ISIP" ? "SIP" : ""}</span>
               
              </Typography>
              <Box sx={{ mx: 2, my: 0.8, width: "8px", height: "8px", borderRadius: '50%', backgroundColor: `${OrdersData.bseOrderStatus == "Success" ? "green" : "red"}` }}></Box>
              {OrdersData.RMIFlag === 1 || OrdersData.RMIFlag === 2 ? <span style={{ fontSize: 14, color: '#677885', fontWeight: 500 }}>RM initiated</span> : ''}
            </Box>
            <Box sx={{ display: 'flex', flexDirection: 'row', justifyContent: 'space-between', py: 3 }}>
              <Box sx={{ display: 'flex', flexDirection: 'column', width: { xs: '70%', sm: '50%' } }}>
                <Box sx={{ display: 'flex', flexDirection: 'row' }}>
                  <Typography sx={{ width: '50%', color: '#677885', fontWeight: '400', fontSize: { xs: 11, sm: 14 } }}>BSE Order Number</Typography>
                  <Typography sx={{ color: '#1C2D47', fontWeight: '500', fontSize: { xs: 11, sm: 14 } }}>{OrdersData.bseOrderStatus == "Success"?OrdersData.BseOrderNo:"NA"}</Typography>
                </Box>
                <Box sx={{ display: 'flex', flexDirection: 'row' }}>
                  <Typography sx={{ width: '50%', color: '#677885', fontWeight: '400', fontSize: { xs: 11, sm: 14 } }}>Order Date</Typography>
                  <Typography sx={{ color: '#1C2D47', fontWeight: '500', fontSize: { xs: 11, sm: 14 } }}>{formatLongDate(OrdersData.EntryDate.split('T')[0])}</Typography>
                </Box>
                {OrdersData.TRTYPE === 'Swt' ? '' : <>{OrdersData.TRTYPE === 'Red' || OrdersData.TRTYPE === 'Add' || OrdersData.TRTYPE === 'New' ? '' :
                  <Box sx={{ display: 'flex', flexDirection: 'row' }}>
                    <Typography sx={{ width: '50%', color: '#677885', fontWeight: '400', fontSize: { xs: 11, sm: 14 } }}>Frequency</Typography>
                    <Typography sx={{ color: '#1C2D47', fontWeight: '500', fontSize: { xs: 11, sm: 14 } }}>{frequencyMapping[OrdersData.Frequency]}</Typography>
                  </Box>}
                  {OrdersData.TRTYPE === 'STP' || OrdersData.bseOrderStatus != 'Success' ? '' :
                    <Box sx={{ display: 'flex', flexDirection: 'row' }}>
                      <Typography sx={{ width: '50%', color: '#677885', fontWeight: '400', fontSize: { xs: 11, sm: 14 } }}>NAV Date</Typography>
                      <Typography sx={{ color: '#1C2D47', fontWeight: '500', fontSize: { xs: 11, sm: 14 } }}>{formatLongDate(OrdersData.NAVDate.split('T')[0])}</Typography>
                    </Box>
                  }
                </>}
                <Box sx={{ display: 'flex', flexDirection: 'row' }}>
                  <Typography sx={{ width: '50%', color: '#677885', fontWeight: '400', fontSize: { xs: 11, sm: 14 } }}>Amount</Typography>
                  <Typography sx={{ color: '#1C2D47', fontWeight: '500', fontSize: { xs: 11, sm: 14 } }}> {formatToIndianCurrency(OrdersData.InvestmentAmount)}</Typography>
                </Box>
              </Box>
              <Box sx={{ display: 'flex', flexDirection: 'column', width: '50%' }}>
                {OrdersData.TRTYPE === 'Swt' ? <Box sx={{ display: 'flex', flexDirection: 'row' }}>
                  <Typography sx={{ width: '50%', color: '#677885', fontWeight: '400', fontSize: { xs: 11, sm: 14 } }}>Target Scheme</Typography>
                  <Typography sx={{ color: '#1C2D47', fontWeight: '500', fontSize: { xs: 11, sm: 14 } }}>{OrdersData.ToschemeName}</Typography>
                </Box> : OrdersData.TRTYPE === 'Red' || OrdersData.TRTYPE === 'Add' || OrdersData.TRTYPE === 'New' ? '' : <>
                  <Box sx={{ display: 'flex', flexDirection: 'row' }}>
                    <Typography sx={{ width: '50%', color: '#677885', fontWeight: '400', fontSize: { xs: 11, sm: 14 } }}>{OrdersData.TRTYPE === 'SWP' ? 'SWP Start Date' : OrdersData.TRTYPE === 'STP' ? 'STP Start Date' : 'SIP Start Date'}</Typography>
                    <Typography sx={{ color: '#1C2D47', fontWeight: '500', fontSize: { xs: 11, sm: 14 } }}>{formatLongDate(OrdersData.StartDate.split('T')[0])}</Typography>
                  </Box>
                  <Box sx={{ display: 'flex', flexDirection: 'row' }}>
                    <Typography sx={{ width: '50%', color: '#677885', fontWeight: '400', fontSize: { xs: 11, sm: 14 } }}>{OrdersData.TRTYPE === 'SWP' ? 'SWP End Date' : OrdersData.TRTYPE === 'STP' ? 'STP End Date' : 'SIP End Date'}</Typography>
                    <Typography sx={{ color: '#1C2D47', fontWeight: '500', fontSize: { xs: 11, sm: 14 } }}>{formatLongDate(OrdersData.EndDate.split('T')[0])}</Typography>
                  </Box>
                  <Box sx={{ display: 'flex', flexDirection: 'row' }}>
                    <Typography sx={{ width: '50%', color: '#677885', fontWeight: '400', fontSize: { xs: 11, sm: 14 } }}>{OrdersData.TRTYPE === 'SWP' ? 'SWP Day' : OrdersData.TRTYPE === 'STP' ? 'STP Day' : 'SIP Day'}</Typography>
                    <Typography sx={{ color: '#1C2D47', fontWeight: '500', fontSize: { xs: 11, sm: 14 } }}>{formatLongDate(OrdersData.SIP_date.split('T')[0])}</Typography>
                  </Box>
                </>}

                {OrdersData.Units && OrdersData.Units != 0 && OrdersData.Units.length > 0 ?
                  <Box sx={{ display: 'flex', flexDirection: 'row' }}>
                    <Typography sx={{ width: '50%', color: '#677885', fontWeight: '400', fontSize: { xs: 11, sm: 14 } }}>Units</Typography>
                    <Typography sx={{ color: '#1C2D47', fontWeight: '500', fontSize: { xs: 11, sm: 14 } }}>{OrdersData.Units}</Typography>
                  </Box> : null}
                {OrdersData.TRTYPE === 'Swt' ? '' :
                  <>{OrdersData.bseOrderStatus === 'Success' ?
                    <Box sx={{ display: 'flex', flexDirection: 'row' }}>
                     { OrdersData.Folio ?
                     <><Typography sx={{ width: { xs: '40%', sm: '50%' }, color: '#677885', fontWeight: '400', fontSize: { xs: 11, sm: 14 } }}>{OrdersData.TRTYPE === 'SWP' ? 'Withdrawal to' : OrdersData.TRTYPE === 'Red' ? 'Redeemed to' : 'Paid Via'}</Typography>
                      <Typography sx={{ color: '#1C2D47', fontWeight: 500, fontSize: { xs: 11, sm: 14 } }}>{OrdersData.Folio}</Typography> 
                      </>: ''}

                    </Box> : ''}</>}

              </Box>
            </Box>
            <Box sx={{ display: 'flex', flexDirection: 'row', py: 2 }}>
              <Typography sx={{ color: '#677885', fontWeight: '500', fontSize: { xs: 11, sm: 14 } }}>Status</Typography>
              <Typography sx={{ color: `${OrdersData.bseOrderStatus == "Success" ? "green" : "red"}`, fontWeight: '500', fontSize: { xs: 11, sm: 14 }, mx: 3 }}>{OrdersData.bseOrderStatus}</Typography>
            </Box>


            <Divider />
            {OrdersData.bseOrderStatus === "Success" ? ''
              : <Box sx={{ py: 1.5 }}>
                <Typography sx={{ fontSize: 12, color: '#2057A6', fontWeight: 400 }}>Note: </Typography>
                <Typography sx={{ color: '#677885', fontWeight: 400, fontSize: 12 }}>Any Amount deducted will be transferred/refunded to the source account in 3-5 working days.</Typography></Box>}
          </Box>

        </Box>


      </Box>
    </Modal >
  )
}

export default function OrdersPage() {
  const [loadingOrders, setLoadingOrders] = useState(true);
  const { orders, getOrdersData } = useGetTotalData();
  const [value, setValue] = useState<string>("recommended");
  const [filteredState, setFilteredState] = useState<any>([]);
  // const [open, setOpen] = useState<boolean>(false);
  const [ordersResponse, setOrdersResponse] = useState<any>();
  const [openModal, setOpenModal] = useState<boolean>(false);
  const [selectedOrder, setSelectedOrder] = useState<any>(null);
  const [filterCount, setFilterCount] = useState<number>(0);
  const [finalCheckedItems, setFinalCheckedItems] = useState<any>([]);
  const [filterDateData, setFilterDateData] = useState<any>({ FromDate: "", ToDate: "" });
  // const handleOpen = () => setOpen(true);
  const handleOpenModal = (ele: any) => {
    setSelectedOrder(ele)
    setOpenModal(true);
  };

  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const open = Boolean(anchorEl);

  const handleClickFilter = (event: React.MouseEvent<HTMLButtonElement>) => {
    setAnchorEl(event.currentTarget);
  };


  const handleChange = (event: any, value: any) => {
    setFinalCheckedItems({})
    setFilterCount(0)
    setValue(value);
    setFilterDateData({FromDate:"",ToDate:""})
  };
  const groupOrdersByDate = (data: Orders[] | undefined) => {
    const groupedOrders: Record<string, Orders[]> = {};

    if (data) {
      data.forEach((order) => {
        const entryDate = order.EntryDate?.split('T')[0];
        groupedOrders[entryDate] = groupedOrders[entryDate] || [];
        groupedOrders[entryDate].push(order);
      });
    }

    const formattedOrders = Object.entries(groupedOrders).map(([date, orders]) => {
      return {
        date: date, // You can format the date here if needed
        orders: orders.map((order) => ({
          ...order,
        })).sort((a, b) => new Date(b.EntryDate).getTime() - new Date(a.EntryDate).getTime())
      };
    }).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    return formattedOrders;
  }

  useEffect(() => {
    try {
      setLoadingOrders(true);
      getOrdersData({ rmID: 5 });
    } catch (error) {
      console.error("Error in getting orders:", error);
    } 
  }, []);
  useEffect(() => {
    if (orders) {
      setLoadingOrders(false)
      // setFilteredState(([...[orders[0]], ...[orders[1]]]))
      if (value === "recommended") {
        setFilteredState(groupOrdersByDate(Array.isArray(orders?.[0]) ? orders?.[0] : []));
      } else if (value === "direct") {
        setFilteredState(groupOrdersByDate(Array.isArray(orders?.[1]) ? orders?.[1] : []));
      }
    }
  }, [orders, value])
  useEffect(() => {
    setOrdersResponse(filteredState);
  }, [filteredState])
  return (
    <>
      {loadingOrders ? <LinearProgress sx={{ mt: 2.5 }} /> :
        <Box sx={{ boxShadow: '0px 0px 20px #dfdfdf', bgcolor: 'white', mt: 0, borderRadius: '10px' }}>

          <TabContext value={value}>
            <Box sx={{
              display: "flex",
              justifyContent: "space-between",


              '& .MuiTabPanel-root': { px: 0 },
              '& .MuiTab-root': {
                color: '#A1A2A2',
                opacity: 0.8,
                fontSize: 14,
                lineHeight: '15px',
                textTransform: 'capitalize',
                my: 0.5, py: 0,
                px: { xs: 1, md: 2, lg: 3 },
                mx: 1,
                '&.Mui-selected': {
                  color: '#35A9FE',
                  border: 'none'
                },
              },
              '& .MuiTabs-indicator': {
                height: 3,
                background: '#35A9FE',
              },
            }}>
              <TabList onChange={handleChange}>
                <Tab label="Recommended" value="recommended" />
                <Tab label="Direct" value="direct" />
              </TabList>
              <IconButton onClick={handleClickFilter} sx={{ color: "#0393FE", border: "2px solid #0393FE", borderRadius: "30px", fontSize: { xs: "10px", sm: "15px" }, marginRight: "1rem", height: "2rem", marginTop: "10px", padding: { xs: "0rem 0.5rem", sm: "1rem" } }}>
                <FilterListIcon />
                <span><b>FILTER</b></span> {filterCount!=0?<span style={{marginLeft:'10px',width:'16px', height:'16px',color:'wheat', fontSize:'12px',textAlign:'center', backgroundColor:'red', borderRadius:"50%", display:'flex', alignItems:'center', justifyContent:'center'}}>{filterCount}</span>:""}
              </IconButton>
              {open &&
                <FilterComponent
                  open={open}
                  anchorEl={anchorEl}
                  setAnchorEl={setAnchorEl}
                  page={"Orders"}
                  setListData={setOrdersResponse}
                  filteredState={filteredState}
                  setFilterCount={setFilterCount}
                  setFinalCheckedItems={setFinalCheckedItems}
                  finalCheckedItems={finalCheckedItems}
                  filterDateData={filterDateData}
                  setFilterDateData={setFilterDateData}
                />}
            </Box>
            <Divider />
            {value === "recommended" || value === "direct" ?
              <Box sx={{height:{xs:"100%",sm:"24rem"},overflow:"scroll"}}>
                {ordersResponse && ordersResponse.length > 0 ?
                  <>
                    {ordersResponse?.map((group: any,idx:number) => {
                      return (

                        <Box sx={{ px: 3, pb: 2 }} >
                          {group.orders && group.orders.length > 0 && (
                            <>
                              <Typography sx={{ color: '#35A9FE', pt: 2 }}> {formatLongDate(group?.date)}</Typography>
                              <Box sx={{ display: 'flex', flexWrap: 'wrap', width: '100%' }}>
                                {group.orders.map((ele: any,idx:number) => (

                                  <Box key={idx} sx={{ display: 'flex', flexDirection: 'column', boxShadow: 'rgba(99, 99, 99, 0.2) 0px 2px 8px 0px', width: { xs: '100%', sm: "29%",lg: "28%" }, borderRadius: '8px', mx: {xs:"1rem",sm:"0.7rem",lg:"1.5rem"}, my: "1rem", cursor: 'pointer' }} onClick={() => handleOpenModal(ele)}>
                                    {/* Head */}
                                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', width: '100%', p: 1 }}>
                                      <Typography sx={{ color: '#35A9FE', fontWeight: 500, fontSize: '0.8rem' }}>{ele?.TRTYPE === "New" || ele?.TRTYPE === "ISIP" ? "Purchase" : ele?.TRTYPE === "XSIP" || ele?.TRTYPE === "Add" ? "Additional Purchase" : ele?.TRTYPE === 'Red' ? 'Redemption' : ele?.TRTYPE === 'Swt' ? 'Switch' : ele?.TRTYPE}
                                        <span style={{ fontSize: "0.7rem", fontWeight: 600, color: "#293139", marginLeft: "8px" }}>{ele?.TRTYPE === "New" || ele?.TRTYPE === "Add" ? "Lumpsum" : ele?.TRTYPE === "XSIP" || ele?.TRTYPE === "ISIP" ? "SIP" : ""}</span>
                                      </Typography>
                                      <span style={{ width: "8px", height: "8px", borderRadius: '50%', backgroundColor: `${ele?.bseOrderStatus === "Success" ? "green" : "red"}` }}></span>
                                    </Box>
                                    <Divider />
                                    {/* Body */}
                                    <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start', width: '100%', px: "0.8rem" }}>
                                      <Typography sx={{ textAlign: 'center', fontWeight: 600, fontSize: '0.8rem', my: "0.5rem" }}>{ele?.SchemeName}</Typography>
                                      <Box sx={{ display: 'flex', justifyContent: 'space-between', width: '100%' }}>
                                        <Typography sx={{ textAlign: 'start', fontSize: '0.77rem', color: '#677885', fontWeight: 500 }}>{ele?.InvestmentAmount != null ? formatToIndianCurrency(ele?.InvestmentAmount) : ""}</Typography>
                                        <Typography sx={{ textAlign: 'end', fontSize: '0.77rem', color: '#677885', fontWeight: 500 }}>{ele?.Units != null ? `${ele?.Units} Units` : ""}</Typography>
                                      </Box>
                                      {ele.RMIFlag === 1 || ele.RMIFlag === 2 ? <Typography sx={{ fontSize: '0.77rem', my: "0.5rem", color: '#35A9FE', fontWeight: 500 }}>RM initiated</Typography> : ''}
                                      <Typography sx={{ fontSize: '0.75rem', my: "0.5rem", color: '#b3b3b3', fontWeight: 500 }}>{formatTime(ele?.EntryDate)}</Typography>
                                    </Box>
                                  </Box>


                                ))}
                              </Box>

                              <Divider />
                            </>)}

                        </Box>

                      )
                    })}
                  </> : <Typography sx={{ fontSize: 20, fontWeight: 600, color: '#dfdfdf', display: 'flex', flexDirection: 'row', justifyContent: 'center', p: 5 }}>No Orders available</Typography>}
                {openModal && selectedOrder && (

                  <OrdersModal
                    openModal={openModal}
                    setOpenModal={setOpenModal}
                    OrdersData={selectedOrder}

                  />

                )}
              </Box>
              : <Box sx={{ width: '100%', display: 'flex', justifyContent: 'center' }}>
              <Typography sx={{ fontSize: 18, color: '#5a7c82', mt: 2 }}>No Orders available</Typography>
          </Box>}
          </TabContext>
        </Box>
      }
    </>
  )
}