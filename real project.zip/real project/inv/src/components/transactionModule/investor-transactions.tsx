import {
  Box,
  Breadcrumbs,
  Grid,
  Typography, Button, Stack, Tab, Divider, Skeleton, LinearProgress
} from '@mui/material';
import { TabContext, TabList, TabPanel } from '@mui/lab';

import { useEffect, useState } from 'react';
import { TransactionAssetClassTab } from './transaction-tabs';
import Scheme_List from './scheme-list';
import SchemeDetail from './scheme-detail';
import { AssetClasses, CategoryAverage, SchemeDetails, SchemeList, SchemeNav, SubAssetClasses, SubAssetclassName, useGetTotalData } from './transaction.context';
import "./styles.css"

export default function InvestorTransactions(){

  const [isLoadingschemeDetail, setLoadingSchemeDetail] = useState(false);
  const [isLoadingschemeList, setLoadingSchemeList] = useState(false);
  const [isLoadingSubAsset, setLoadingSubAsset] = useState(false);
  const [isLoadingAsset, setLoadingAsset] = useState(false);
  const [isLoadingCatAvg, setLoadingCatAvg] = useState(false);
  const [isLoadingSchemeNav, setLoadingSchemeNav] = useState(false);
  const [value, setValue] = useState<string>("Debt");
  const [itemSelected, setItemSelected] = useState<SubAssetClasses>();
  const [viewSubList, setViewSubList] = useState(false);
  const [viewSchemeDetails, setViewSchemeDetails] = useState<boolean>(false);
  const [currentSchemeDetail, setCurrentSchemeDetail] = useState<SchemeList>();


  const handleChange = (event: any, value: any) => {
    setValue(value);
  };

  const {assetClasses,getAssetClassDetails}= useGetTotalData();
  const {subAssetClasses,getSubAssetClassDetails}= useGetTotalData();
  const {schemesList,getSchemeListDetails}= useGetTotalData();
  const {schemeNav, getSchemeNavDetails} = useGetTotalData();
  const {categoryAverage,getCategoryAverageDetails}= useGetTotalData();
  const {schemeDetails, getSchemeDetails} = useGetTotalData();

  const [assetClassesData, setAssetClassesData] = useState<AssetClasses[]>();

  const [subAssetClassesData, setSubAssetClassesData] = useState<SubAssetClasses[]>();

  const [schemeList, setSchemeList] = useState<SchemeList[]>();

  const [schemeDetail, setSchemeDetail] = useState<SchemeDetails>();

  const [categoriesAverage, setCategoriesAverage] = useState<CategoryAverage[]>();

  const [schemesNav, setSchemesNav] = useState<SchemeNav[]>();


  const handleClick = (item: any, index: any) => () => {
    setViewSubList(true);
    setItemSelected(item);
  };

  const handleSetViewSchemeDetails = (val: boolean, schemeDetail: SchemeList | undefined | null) => {
    setViewSchemeDetails(val);
    schemeDetail ? setCurrentSchemeDetail(schemeDetail) : "";
  }
  useEffect(()=>{if (itemSelected) {
    setLoadingSchemeList(true);
    getSchemeListDetails(itemSelected?.ID)
  }},[itemSelected?.ID]) 
  
  useEffect(()=>{if (currentSchemeDetail) {
    setLoadingCatAvg(true);
    setLoadingSchemeDetail(true);
    setLoadingSchemeNav(true);
    getSchemeDetails(currentSchemeDetail?.SchemeID)
    getCategoryAverageDetails({schemaId: currentSchemeDetail.SchemeID , marketValue:false})
    getSchemeNavDetails(currentSchemeDetail?.SchemeID)
  }},[currentSchemeDetail?.SchemeID]) 
  
  useEffect(() => {
    setLoadingSubAsset(true);
    getSubAssetClassDetails(value);
  }, [value]);

  useEffect(() => {
    setLoadingAsset(true);
    getAssetClassDetails();
  }, []);
  
  useEffect(() => {

    setAssetClassesData(assetClasses);

    setSubAssetClassesData(subAssetClasses);

  setSchemeList(schemesList);
  setSchemesNav(schemeNav);
  setCategoriesAverage(categoryAverage);
  setSchemeDetail(schemeDetails);
  console.log("schemeDetailssssss",schemeDetail)
  if(assetClasses!=undefined) setLoadingAsset(false);
  if(categoryAverage!=undefined)setLoadingCatAvg(false);
  if(subAssetClasses!=undefined)setLoadingSubAsset(false);
  if(schemeDetails!=undefined)setLoadingSchemeDetail(false);
  if(schemesList!=undefined)setLoadingSchemeList(false);
  if(schemeNav!=undefined)setLoadingSchemeNav(false);
  }, [assetClasses, subAssetClasses,schemesList, schemeNav, categoryAverage, schemeDetails]);
  

  return (
    <div>
      
          {isLoadingAsset || isLoadingschemeDetail || isLoadingschemeList || isLoadingCatAvg || isLoadingSchemeNav ? (
            <LinearProgress sx={{ mt: 2.5 }} />
    
          ) : (<Box
            sx={{
              bgcolor: 'common.white',
              boxShadow: '0px 4px 28px 2px rgba(0, 0, 0, 0.08)',
              borderRadius: '5px',
             
            }}>
            {!viewSubList && !viewSchemeDetails && 
            
            <Grid container>
              <Box
                sx={{
                  width: '100%',
                  '& .MuiTabPanel-root': { py: 1, px: 0 },
                  '& .MuiTab-root': {
                    color: '#A1A2A2',
                    opacity: 0.8,
                    fontSize: {xs:12,sm:17},
                    lineHeight: '20px',
                    textTransform: 'capitalize',
                    border:'none',
                    minWidth:80,
                    mx:{xs:0,sm:1},
                    px: { xs: 0, md: 2, lg: 4 },
                    '&.Mui-selected': {
                      color: '#1EB1F3',
                      border:'none'
                    },
                  },
                  '& .MuiTabs-indicator': {
                    height: 3,
                    background: '#1EB1F3',
                  
                  },  '& .MuiTabs-flexContainer': {
                    display: "flex",
                    justifyContent: {xs:"space-between",sm:"flex-start"},
                    width: "100%",
                }
                }}>
                {isLoadingAsset ? <Skeleton /> : <TabContext value={value}>
                  <Box sx={{ px:{xs:1,sm:3} }}>
                    <TabList
                      onChange={handleChange}
                      aria-label="product tabs"
                      variant="scrollable"
                      scrollButtons="auto">
                      {assetClassesData?.map((ele, index) => {
                        return (<Tab label={ele.AssetClassName} value={ele.AssetClassName} key={index} />)
                      })}
                    </TabList>
                  </Box>
                  <Divider />
                  <Box  sx={{ px: 3,height:{xs:"100%",sm:"22.5rem"},overflow:"scroll",}}>
                    {assetClassesData?.map((ele, index) => {
                      return (
                        <TabPanel className="showScroll" value={ele.AssetClassName} key={index}>
                          {isLoadingSubAsset ? <Skeleton /> : <>
                            {subAssetClassesData?.map((ele: any, index: number) => (
                              <div
                                key={index}
                                style={{ cursor: "pointer" }}
                                onClick={handleClick(ele, index)}
                              >
                                <TransactionAssetClassTab subAssetClassNames={ele} />
                              </div>
                            )
                            )}
                          </>}
                        </TabPanel>
                      )
                    })}
                  </Box>
                </TabContext>}
              </Box>

            </Grid>
            }
            {viewSubList && !viewSchemeDetails && <Grid container >
              <Scheme_List
                handleBackClick={() => {
                  setViewSubList(false);
                }
                }
                selectedSubAssetClass={itemSelected}
                setSelectedSubAssetClass={setItemSelected}
                handleSetViewSchemeDetails={handleSetViewSchemeDetails}
                sub_asset_classes={subAssetClassesData}
                schemeList={schemeList}
              />
            </Grid>
            }
            {viewSchemeDetails && <Grid container >
              <SchemeDetail
                handleBackClick={() => {
                  setViewSubList(true);
                  setViewSchemeDetails(false);
                }
                }
                handleSetViewSchemeDetails={handleSetViewSchemeDetails}
                schemeDetail={schemeDetail}
                schemeData={currentSchemeDetail}
                categoryAverage={categoriesAverage}
                schemeNav={schemesNav}
              />
            </Grid>}
          </Box>)}


    </div>
    
  );
}
