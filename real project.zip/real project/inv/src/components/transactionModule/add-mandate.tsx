import { Box, Button, Card, CardMedia, Checkbox, Divider, FormControl, FormControlLabel, FormLabel, Grid, IconButton, MenuItem, Radio, RadioGroup, Select, Stack, Switch, Tab, Typography } from "@mui/material";
import DashboardHeader from "../dashboard/dashboard.header";
import { useEffect, useState } from "react";
import { usePaymentContext } from "../payment/payment.context";
import Swal from "sweetalert2";

export default function AddMandate() {

  const [value, setValue] = useState<string>('XSIP');
  const [headerSelected,setHeaderSelected]=useState<String>("Bugle Rock");
  const [pageData, setPageData] = useState<any>({ amount: 0, account: 0, bank: "", ifsc: "" })
  const { profieData, registerMandate } = usePaymentContext();
  const [bankDetails, setBankDetails] = useState<any>();

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setValue((event.target as HTMLInputElement).value);
  };

  const handleChangeData = (e: any, type: any) => {

    let data: any = pageData
    if (type == "amount") {
      data = { ...data, amount: e.target.value.replace(/[^0-9]/g, '') }
    }
    else if (type == "account") {
      let foundValue: any = bankDetails.find((a: any) => a.ACNo === e.target.value);
      data = { ...data, account: foundValue.ACNo, bank: foundValue.BankName, ifsc: foundValue.IFSCCode }
    }
    setPageData(data)

  }

  const handleSubmit = async () => {
    let payload: any = {
      AC_TYPE: "1",
      AccountNO: pageData.account,
      Amount: pageData.amount.toString(),
      BankName: pageData.bank,
      IFSC_CODE: pageData.ifsc,
      is_encrypted: true,
      mandate_type: value == "XSIP" ? "X" : "N"
    }
    // console.log("payload check for mandate", payload)
    let mandate_response: any = await registerMandate(payload)
    if(mandate_response.is_mandate_registered == true){
      Swal.fire({
        title: "Request for registering Emandate is confirmed",
        icon: "success",
        customClass: {
          confirmButton: 'sweet-alert-button'
        }
      });
      setPageData({ amount: 0, account: 0, bank: "", ifsc: "" })
    }
  }

  useEffect(() => {
    (async function () {
      try {
        let profileData_reponse: any = await profieData()
        // console.log("profileData_reponse value", profileData_reponse)
        setBankDetails(profileData_reponse.bank_details)
      } catch (e) {
        console.error(e);
      }
    })();
  }, [])

  return (
    <Box>
      <Grid container sx={{ width: '100%', height: '100vh', overflow: 'auto' }}>
        <Box sx={{ marginTop: '5vh', width: '85%', px: '5vw' }}>
          <DashboardHeader 
          headerOption={headerSelected} 
          setHeaderOption={setHeaderSelected} 
          />
          <Typography sx={{ mt: '5vh', fontSize: '20px', fontWeight: 500 }}>
            Add New Bank Mandate
          </Typography>
          <Card style={{ marginTop: "5vh", marginBottom: "5vh", "boxShadow": "0px 0px 20px #dfdfdf", borderRadius: "10px", paddingLeft: "2rem", paddingRight: "2rem" }}>
            <div style={{ display: "flex", marginTop: "1rem", marginBottom: "1rem" }}>
              <FormControl>
                <RadioGroup
                  row
                  aria-labelledby="demo-row-radio-buttons-group-label"
                  name="row-radio-buttons-group"
                  value={value}
                  onChange={handleChange}
                >
                  <FormControlLabel value="XSIP" control={<Radio />} label="XSIP" />
                  <FormControlLabel value="E-MANDATE" control={<Radio />} label="E-MANDATE" />
                </RadioGroup>
              </FormControl>
            </div>
            <div>
              <Box style={{ width: "50%", marginBottom: "15px" }}>
                {value == "XSIP" ? <Typography style={{ fontSize: "14px", color: "#ffa983" }}>This is a Physical Mandate which will require you to take a print, sign it and upload the scanned version. It takes 21 working days to get verified with your bank.</Typography> :
                  <Typography style={{ fontSize: "14px", color: "#ffa983" }}>This is a Digital Mandate which will require Netbanking Facility as you will be sent a link on which you have to make a payment of 1 Rupee from your bank account. It takes 2 working days to get this mandate verified. List of Allowed Banks is below.</Typography>
                }
              </Box>
              <Box style={{ width: "50%", marginBottom: "15px" }}>
                <Typography>Mandate Amount</Typography>
                <input type="text" className='investmentAmount2' value={pageData.amount}
                  style={{ width: "100%", fontSize: "15px", padding: "0.5rem", backgroundColor: "transparent" }}
                  onChange={(e: any) => handleChangeData(e, "amount")}
                >
                </input>
              </Box>
              <Box style={{ marginTop: "15px", marginBottom: "15px" }}>
                <Typography>Bank Account</Typography>
                <FormControl sx={{ width: "50%", marginTop: "8px" }} >
                  <Select
                    labelId="demo-simple-select-label"
                    id="demo-simple-select"
                    value={pageData.account}
                    onChange={(e: any) => handleChangeData(e, "account")}
                    inputProps={{ 'aria-label': 'Without label' }}
                  >
                    {bankDetails?.map((val: any) => {
                      return <MenuItem key={val.ACNo} value={val.ACNo}>{val.ACNo}</MenuItem>
                    })}
                  </Select>
                </FormControl>
              </Box>
              <Box style={{ width: "50%", marginBottom: "15px", marginTop: "15px" }}>
                <Typography>Bank Name</Typography>
                <input type="text" className='investmentAmount2' value={pageData.bank}
                  style={{ width: "100%", fontSize: "15px", padding: "0.5rem", backgroundColor: "transparent" }}
                // onChange={(e: any) => handleChangeData(e, "amount")}
                >
                </input>
              </Box>
              <Box style={{ width: "50%", marginTop: "15px" }}>
                <Typography>IFSC</Typography>
                <input type="text" className='investmentAmount2' value={pageData.ifsc}
                  style={{ width: "100%", fontSize: "15px", padding: "0.5rem", backgroundColor: "transparent" }}
                // onChange={(e: any) => handleChangeData(e, "amount")}
                >
                </input>
              </Box>
              <Box style={{ width: "100%", marginTop: "15px", display: "flex", justifyContent: "center", alignItems: "center" }}>
                <Button onClick={handleSubmit} sx={{ color: 'white', background: 'linear-gradient(90deg,#0090FF,#1EB1F3,#0090FF)', fontSize: '16px', fontWeight: '600', mt: 3, mb: 3, width: '30%', borderRadius: '10px' }}>SUBMIT</Button>
              </Box>
            </div>
          </Card>
        </Box>
      </Grid>
    </Box>
  );
}
