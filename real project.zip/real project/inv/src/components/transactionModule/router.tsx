import { Navigate, Route, Routes } from 'react-router-dom';
import { GetTotalDataProvider } from './transaction.context';
import { TransactionIndex } from '.';
import InvestorTransactions from './investor-transactions';
import { SchemeRecommendations } from './recommendations';
import Holding from './holding';
import OrdersPage from './Orders';


export default function TransactionRouter() {
  return (
    <GetTotalDataProvider>
      <Routes>
      <Route path="/" element={<TransactionIndex />}>
          <Route index element={<Navigate to="explore" />} />
          <Route path="explore" element={<InvestorTransactions />} />
          <Route path="holding" element={<Holding />} />
          <Route path="recommendations" element={<SchemeRecommendations />} />
          <Route path="orders" element={<OrdersPage />} />
        </Route>
      </Routes>
    </GetTotalDataProvider>
  );
}
