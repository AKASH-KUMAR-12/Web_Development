import { Box, CardMedia, Drawer, IconButton, Typography } from "@mui/material";
import { useState } from "react";

type CutOffTimeProps = {
   
    anchorEl: boolean;

    handleClose: () => void;

  };
  
  export const CutOffTimeDrawer = ({

    anchorEl,

    handleClose,
   
  }: CutOffTimeProps): JSX.Element => {
    const [modalState, setModalState] = useState(false);
    const _handleModalState = () => {
        handleClose();
        setModalState(modalState);
      };
    return(
        <Box>
        <Drawer anchor={'right'} open={anchorEl} onClose={_handleModalState}>
            <Box sx={{width:'700px'}}>
            <Box >
            <Box
               sx={ { display:"flex",flexDirection: "row",justifyContent: "center", px:10,py:5,height:'30px'}}
            >
              <Typography
               
                sx={  { fontSize: 16, margin:'0% 0% 25% 0%', color: "#101317", fontweight:600 }}
               
              >
                CUT-OFF TIME FOR BUYING MUTUAL FUNDS
              </Typography>
              <IconButton
                style={{  right: 0, position: "absolute", top: 10 }}
                onClick={handleClose}
              >
                <CardMedia
                component="img"
                src="/images/cross.svg"
                alt="info"
                sx={{ width: 25, height:25,mx:3 }}
               
              />
              </IconButton>
            </Box>

            <Box
                sx={{ background: "linear-gradient(90deg,#0090FF,#36DAE9)",
                   display: "flex",
                  flexDirection: "row",
                  justifyContent: "space-between", height:'70px'}} 
            >
              <Typography 

            sx={{ fontSize:14, fontWeight:600,fontFamily:'Roboto',
                color: "#ffffff",
                width: "15%",p:1}}
              >Mutual Fund Scheme</Typography>
              <Typography
                sx={{
                    fontSize:14, fontWeight:600,fontFamily:'Roboto',
                 p:1,
                  color: "#ffffff",
                  width: "26.3%"
                }}
              >
                Purchase Cut-off Time
              </Typography>
              <Typography 
                sx={{  fontSize:14, fontWeight:600,fontFamily:'Roboto',
                color: "#ffffff",
               width: "26.3%",p:1}}
              >
                If submitted by Cut-off Time
              </Typography>
              <Typography sx={{  fontSize:14, fontWeight:600,fontFamily:'Roboto',
              color: "#ffffff",
              width: "26.3%",p:1}}
              >
                If submitted after Cut-off Time
              </Typography>
            </Box>

            <Box

            sx={{ display: "flex",
            flexDirection: "row",
            justifyContent: "space-between",paddingTop:5, px:1}}
            >
              <Typography 
            //   style={styles.sipModalTypography}
            sx={{fontSize:14, fontWeight:400,fontFamily:'Roboto',
            color: "#101317",
          
            width: "15%",}}
              >Liquid Fund</Typography>
              <Typography 
            //   style={styles.cutoff}
            sx={{ fontSize:14, fontWeight:400,fontFamily:'Roboto',
            color: "#101317",
            width: "26.3%",p:1}}
              >
                Previous day NAV for investments upto 1pm, same day NAV for
                investment upto 3pm
              </Typography>
              <Typography 
            //   style={styles.sipModalTypography}
            sx={{  fontSize:14, fontWeight:400,fontFamily:'Roboto',
            color: "#101317",
            width: "26.3%",p:2}}
              >NAV of preceding day</Typography>
              <Typography 
            //   style={styles.sipModalTypography}
            sx={{  fontSize:14, fontWeight:400,fontFamily:'Roboto',
            color: "#101317",
            width: "26.3%",p:2}}
              >NAV of same day</Typography>
            </Box>

            <Box
            sx={{ display: "flex",
            flexDirection: "row",
            justifyContent: "space-between",paddingTop:3,px:1}}
            >
              <Typography 

            sx={{ fontSize:14, fontWeight:400,fontFamily:'Roboto',
            color: "#101317",
            width: "15%"}}
              >
                Equity Investments
                {/* Fund (Investment amount less than Rs. 2 lakh) */}
              </Typography>
              <Typography 
            sx={{ fontSize:14, fontWeight:400,fontFamily:'Roboto',
            color: "#101317",
            width: "26.3%",p:1}}
              >
                {/* 1.00 pm */}
                {/* Below 2 lakhs investment till 3pm Above 2 lakhs investments till
                2:30pm allotment upon fund realisation. */}
                Below 2 lakhs investment till 2:30pm <div>Above 2 lakhs investments
                till 3pm, allotment upon fund realisation.</div>
              </Typography>
              <Typography 

            sx={{ fontSize:14, fontWeight:400,fontFamily:'Roboto',
            color: "#101317",
            width: "26.3%",p:2}}
              >NAV of same day</Typography>
              <Typography 
         
            sx={{ fontSize:14, fontWeight:400,fontFamily:'Roboto',
            color: "#101317",
            width: "26.3%",p:2}}
              >NAV of next day</Typography>
            </Box>

            <Box
                sx={{ display: "flex",
            flexDirection: "row",
            justifyContent: "space-between",paddingTop:3,px:1}}
          
            >
              <Typography 
            //   style={styles.sipModalTypography}
            sx={{ fontSize:14, fontWeight:400,fontFamily:'Roboto',
            color: "#101317",
            width: "15%"}}
              >Debt Investments</Typography>
              <Typography 
            //   style={styles.cutoff}
            sx={{ fontSize:14, fontWeight:400,fontFamily:'Roboto',
            color: "#101317",
            width: "26.3%",p:1}}
              >
                {/* 1.00 pm */}
                {/* Below 2 lakhs investment till 3pm Above 2 lakhs investments till
                2:30pm allotment upon fund realisation. */}
                Below 2 lakhs investment till 2:30pm <div>Above 2 lakhs investments
                till 3pm, allotment upon fund realisation.</div> 
              </Typography>
              <Typography
            //    style={styles.sipModalTypography}
            sx={{ fontSize:14, fontWeight:400,fontFamily:'Roboto',
            color: "#101317",
            width: "26.3%",p:2}}
               >NAV of same day</Typography>
              <Typography 
            //   style={styles.sipModalTypography}
            sx={{ fontSize:14, fontWeight:400,fontFamily:'Roboto',
            color: "#101317",
            width: "26.3%",p:2}}
              >NAV of next day</Typography>
            </Box>
            {/* <Typography
                sx={{ fontSize: 12, color: "#01A4BD" ,textAlign: "center", py:5}}
            >
              Subject to Funds Reaching BSE before Cut-Off Time
            </Typography> */}
          {/* </ScrollBox> */}
        </Box>
            </Box>
            </Drawer>
        </Box>
    )
}