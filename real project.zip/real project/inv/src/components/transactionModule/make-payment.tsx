import { Box, Button, Divider, FormControl, FormControlLabel, FormLabel, Grid, Radio, RadioGroup, Tab, Typography } from "@mui/material";
import DashboardHeader from "../dashboard/dashboard.header";
import ArrowBackIosOutlinedIcon from '@mui/icons-material/ArrowBackIosOutlined';
import { TabContext, TabList } from "@mui/lab";
import { useState } from "react";
import { useNavigate } from "react-router";
const MakePayment=()=>
{ 
    const [value, setValue]=useState("Net Banking")
    const handleChange = (event: any, value: any) => {
    setValue(value);};
    const navigate= useNavigate();
    const handleClick=()=>{
      navigate("/cart")
    }
  
    return(
        <Grid container sx={{ width: '100vw', height: '100vh', overflow: 'auto' }}>
        <Box sx={{marginTop:'5vh', width:'85%', px:'5vw'}}>
            <DashboardHeader/>
            <Box sx={{display:'flex', flexDirection:'row'}}>
                <ArrowBackIosOutlinedIcon sx={{fontSize:20, my:0.6, cursor:'pointer'}} onClick={handleClick} />
                <Typography sx={{fontSize:20, fontWeight:500}}>
                    MAKE PAYMENT
                </Typography>
            </Box>
            <Box sx={{width:'100%', background:'linear-gradient(90deg, #0A2A88, #59CDE9)',opacity:0.8
            ,height:'unset',borderRadius:'10px',mt:5,}}>
              <Box sx={{px:10,py:4,display:'flex', justifyContent:'space-between', flexDirection:'row'}}>  <Typography sx={{color:'#ffffff'}}>
                    Paying for <div>Canara Robeco </div>
                </Typography>
                <Typography sx={{color:'#ffffff'}}>
                Payable Amount <div>500</div>
                </Typography>
                </Box>
                <Divider sx={{width:'90%',margin:'0% 0% 0% 5%'}}/>
                <Box sx={{px:10,py:4,display:'flex', justifyContent:'space-between', flexDirection:'row'}}>
                    <Typography sx={{color:'#ffffff'}}>
                     Investor
                    </Typography>
                    <Typography sx={{color:'#ffffff'}}>
                        Investment Mode <div>SIP</div>
                    </Typography>
                </Box>
            </Box>
            <Box sx={{height:'unset', bgcolor:'#ffffff',mt:5, borderRadius:'10px',mb:5,boxShadow:'0px 0px 20px #dfdfdf'}}>
                <Typography sx={{fontSize:'14px', p:3, fontWeight:500}}>
                    Choose your mode of payment
                </Typography>
                <Divider/>
                <TabContext value={value}>
            <Box sx={{mx:1,
          width: '100%',
          '& .MuiTabPanel-root': { py: 2, px: 0 },
          '& .MuiTab-root': {
            color: '#A1A2A2',
            opacity: 0.8,
            fontSize: 17,
            lineHeight: '24px',
            textTransform: 'capitalize',
            px: { xs: 2, md: 3, lg: 5 },
            '&.Mui-selected': {
              color: '#0393FE',
            },
          },
          '& .MuiTabs-indicator': {
            height: 3,
            background: '#0393FE',
          },
        }}>
                <TabList
                    onChange={handleChange}
                    aria-label="product tabs"
                    variant="scrollable"
                    scrollButtons="auto"
                    >
                    <Tab label="Net Banking" value="Net Banking" />
                    <Tab label="UPI / One Time Mandate" value="UPI" />
                    <Tab label="Cheque / NEFT" value="Cheque" />
                </TabList>
                </Box>
                </TabContext>
          
            {value==='Net Banking'?
            <Box sx={{pb:4}}>
                <Box  sx={{display:'flex',justifyContent:'space-between',flexDirection:'row',p:3}}>
                <Box >
                <img src='' alt='img' style={{width:5,height:5}}/>
                </Box>
                <Box sx={{marginRight:'25vw'}}>
                <Typography sx={{fontSize:14,fontWeight:400}}>3123456789</Typography>
                <Typography sx={{fontSize:14,fontWeight:400}}>Linked Bank Account</Typography>
                </Box>
                <Button sx={{background:'linear-gradient(90deg, #1EB1F3,#0090FF)',color:'#ffffff',borderRadius:'8px',width:'30%'}}>Pay using this account</Button>
                </Box>
              <Typography sx={{px:5,py:0.5,fontSize:'14px',fontWeight:400}}>Please enter details of your Account 3123456789 to make payment</Typography>
              <Divider sx={{p:1,width:'90%', margin:'0% 0% 0% 5%'}}/>
              <Box  sx={{display:'flex',justifyContent:'space-between',flexDirection:'row',p:3}}>
                <Box >
                <img src='' alt='img' style={{width:5,height:5}}/>
                </Box>
                <Box sx={{marginRight:'25vw'}}>
                <Typography sx={{fontSize:14,fontWeight:400}}>3123456789</Typography>
                <Typography sx={{fontSize:14, fontweight:400}}>Linked Bank Account</Typography>
                </Box>
                <Button sx={{background:'linear-gradient(90deg, #1EB1F3,#0090FF)',color:'#ffffff',borderRadius:'8px',width:'30%'}}>Pay using this account</Button>
                </Box>
              <Typography sx={{px:5,py:0.5,fontSize:'14px',fontWeight:400}}>Please enter details of your Account 3123456789 to make payment</Typography>
              <Divider sx={{p:1,width:'90%', margin:'0% 0% 0% 5%'}}/>
            </Box>
            :
            value==='UPI'?
            <Box>
                <Box  sx={{display:'flex',justifyContent:'space-between',flexDirection:'row',p:3}}>
                <Box >
                <img src='' alt='img' style={{width:5,height:5}}/>
                </Box>
                <Box sx={{marginRight:'25vw'}}>
                <Typography sx={{fontSize:14,fontWeight:400}}>BSE Gateway</Typography>
                {/* <Typography sx={{fontSize:14,fontWeight:400}}>Linked Bank Account</Typography> */}
                </Box>
                <Button sx={{background:'linear-gradient(90deg, #1EB1F3,#0090FF)',color:'#ffffff',borderRadius:'8px',width:'30%'}}>Submit</Button>
                </Box>
                <Typography sx={{px:5,py:0.5,fontSize:'14px',fontWeight:400,pb:5}}>You will be navigated to BSE Star website </Typography>
            </Box>
            :
            <Box>
                <Box sx={{display:'flex',justifyContent:'space-between',flexDirection:'row',p:4}}>
                <FormControl>
                <RadioGroup
                    row
                    aria-labelledby="demo-row-radio-buttons-group-label"
                    name="row-radio-buttons-group"
                >
                    <FormControlLabel value="cheque" control={<Radio />} label="Cheque" />
                    <FormControlLabel value="neft" control={<Radio />} label="NEFT" />
                    
                </RadioGroup>
                </FormControl>
                <Box>
                <Button sx={{background:'linear-gradient(90deg, #1EB1F3,#0090FF)',color:'#ffffff',borderRadius:'8px',width:'100%'}}>Submit</Button>
                <Typography sx={{fontSize:'14px',fontWeight:400,pt:2}}>Our Support team will contact you</Typography>
                </Box>
                </Box>
                
            </Box>
            }
          </Box>
        </Box>
        </Grid>
    )
}
export default MakePayment;