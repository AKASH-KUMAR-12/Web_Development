import { Box, Button, CircularProgress, Collapse, Dialog, DialogActions, DialogContent, Divider, FormControl, IconButton, InputAdornment, LinearProgress, Modal, OutlinedInput, Tab, Typography, Zoom } from "@mui/material";
import { Bubble } from "../payment/cart";
import { useEffect, useState } from "react";
import { AddToCartDrawer } from "./add.to.cart.drawer";
import { CloseIcon, InvestNowIcon, InvestNowIconDisabled } from "../customSVGs";
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import { RecommendationsType, SchemeDetails, SchemeList, SchemeNav, useGetTotalData } from "./transaction.context";
import SchemeDetail from "./scheme-detail";
import { TabContext, TabList, TabPanel } from "@mui/lab";
import { _request } from "../../api/requests";
import { InvestNowTooltip, Nanprocessor, convertDate, formatToIndianCurrency, roundToTwo } from "../utils/utilityFunctions";
import SearchIcon from '@mui/icons-material/Search';
import FilterListIcon from '@mui/icons-material/FilterList';
import { FilterComponent } from "./Filter";
import { AddToCartRecommendation } from "./addToCartRecommendation";
import { tabMap } from "./constants";
import { clockNumberClasses } from "@mui/x-date-pickers";
import { create_transaction, get_bse_code } from "../../api/transaction";
import Swal from "sweetalert2";
import { place_order } from "../../api/payment";
import CancelOutlinedIcon from '@mui/icons-material/CancelOutlined';
import CheckCircleOutlineOutlinedIcon from '@mui/icons-material/CheckCircleOutlineOutlined';

export function SchemeRecommendations() {

  const { initialFilter } = useGetTotalData();
  const { recommendedScheme, getRecommendedSchemesDetails, getAccountTypes, updateViewFlag } = useGetTotalData();
  const { schemeNav, getSchemeNavDetails } = useGetTotalData();
  const { categoryAverage, getCategoryAverageDetails } = useGetTotalData();
  const { schemeDetails, getSchemeDetails } = useGetTotalData();
  const [isLoadingRecommendation, setLoadingRecommendation] = useState(true);
  const [currentSchemeDetail, setCurrentSchemeDetail] = useState<RecommendationsType>();
  const [viewSchemeDetails, setViewSchemeDetails] = useState<boolean>(false);
  const [isLoadingCatAvg, setLoadingCatAvg] = useState(false);
  const [isLoadingSchemeNav, setLoadingSchemeNav] = useState(false);
  const [isLoadingschemeDetail, setLoadingSchemeDetail] = useState(false);
  const [schemeDetail, setSchemeDetail] = useState<SchemeDetails>();
  const [investScheme, setInvestScheme] = useState<RecommendationsType>();
  const [value, setValue] = useState<string>('New');
  const [search, setSearch] = useState<string>('');
  const [subVal, setSubVal] = useState<string>('lumpsum');
  const [moreDetails, setMoreDetails] = useState<{ [key: number]: boolean }>({});
  const [modalMoreDetails, setModalMoreDetails] = useState<{ [key: number]: boolean }>({});
  const [filterCount, setFilterCount] = useState<number>(1);
  const [filteredRecommendations, setfilteredRecommendations] = useState<any>([]);
  const [totalFilter, setTotalFilter] = useState<any>([]);
  const [finalCheckedItems, setFinalCheckedItems] = useState<any>({ Status: ['Active'] });
  const [filterAnchorEl, setFilterAnchorEl] = useState<null | HTMLElement>(null);
  const [filterDateData, setFilterDateData] = useState<any>({ FromDate: "", ToDate: "" });
  const [addToCartAnchorsEl, setAddToCartAnchorsEl] = useState<boolean>(false);
  const [userDetails, setUserDetails] = useState<{ clientId: string }>();
  const [recommendedBucketSchemes, setRecommendedBucketSchemes] = useState<any>({})
  const [groupedSchemes, setGroupedSchemes] = useState<any>([])
  const [selectedBasketSchemes, setSelectedBasketSchemes] = useState<any>([]);
  const [failedOrderList, setFailedOrderList] = useState<any>([])
  const [loading, setLoading] = useState(false);
  const [successOrderList, setSuccessOrderList] = useState<any>([])
  const [openDialog, setOpenDialog] = useState<boolean>(false)
  const open = Boolean(filterAnchorEl);
  const SESSION_KEY_USER_DETAILS = 'userDetails';
  const [schemeModalOpen, setSchemeModalOpen] = useState<boolean>(false);

  const handleOpenSchemeModal = (schemeDetails: []) => {
    setGroupedSchemes(schemeDetails)

    if (schemeDetails.length > 1)
      setSchemeModalOpen(true)
  };
  const handleCloseSchemeModal = () => setSchemeModalOpen(false);

  const style = {
    position: 'absolute' as 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 800,
    bgcolor: 'background.paper',
    boxShadow: 24,
    borderRadius: "10px",
    p: 2,
  };

  //This function is used to handle click of filter button, it will either open or close filter menu
  const handleClickFilter = (event: React.MouseEvent<HTMLButtonElement>) => {
    setFilterAnchorEl(event.currentTarget);
  };

  //This function is used to switch tabs between SIP and lumpsum in case of new and additional purchase - it changes the value of 'subVal' to the current selected tab
  const handleSubValChange = (event: any, val: any) => {
    setSubVal(val);
  }

  //This function will be triggred when any recommendation is clicked to view additional details about recommendation
  const handleMoreDetailsClick = (index: number) => {
    setMoreDetails((lessDetails) => {
      const updatedDetails = { ...lessDetails, [index]: !lessDetails[index] };
      return updatedDetails;
    });
  };
  const handleMoreDetailsClickModal = (index: number) => {
    setModalMoreDetails((lessDetails) => {
      const updatedDetails = { ...lessDetails, [index]: !lessDetails[index] };
      return updatedDetails;
    });
  };
  const formatDate = (date: string) => {

    const newDate = new Date(date);
    const day = newDate.getDate()
    const month = newDate.getMonth()
    const year = newDate.getFullYear()
    console.log("date", `${day}/${month}/${year}`)
    return `${day}/${month}/${year}`
  }

  useEffect(() => {
    if (selectedBasketSchemes.length != 0 && selectedBasketSchemes.length == groupedSchemes.length) {
      placeOrder()
    }
  }, [selectedBasketSchemes])

  //This useEffect is used to get user details which contains client ID that will be used as payload for fetching recommendation list
  useEffect(() => {
    const details = sessionStorage.getItem(SESSION_KEY_USER_DETAILS);
    if (details) {
      setUserDetails(JSON.parse(details));
    }
  }, []);

  //This function is triggered on tab switch 
  const handleChange = (event: any, value: any) => {
    setValue(value);
  };

  const frequencyMapping: any = {
    "DAILY": "1",
    "Weekly": "2",
    "MONTHLY": "3",
    "QUARTERLY": "4",
    "ANNUALLY": "6",
  }

  //This useEffect is used to fetch list of recommendations 
  useEffect(() => {
    setLoadingRecommendation(true);
    if (userDetails?.clientId) {
      try {
        const recommendationList = getRecommendedSchemesDetails({ rmId: 0, clientId: `${userDetails.clientId}` });

        // Code to show new schemes and update view flag
        recommendationList.then((resp) => {
          const storedValue = localStorage.getItem('newRecId');
          const existingItems = storedValue ? JSON.parse(storedValue) : [];
          const recIdArray: any = existingItems;
          resp?.map((item: any) => {
            if (item.ViewFlag === false) {
              recIdArray.push(item.RecID);
            }
          })

          const newRecIdInCurrentSession: any = [];
          recIdArray.map((item: any) => {
            const storedValue1 = localStorage.getItem('newRecId');
            const existingItems1 = storedValue1 ? JSON.parse(storedValue1) : [];
            const tempArray = existingItems1;
            if (tempArray.find((existingItem: any) => existingItem === item) === null) {
              newRecIdInCurrentSession.push(item);
            }
          })

          if (newRecIdInCurrentSession.length > 0) {
            localStorage.setItem('newRecId', JSON.stringify(recIdArray) + JSON.stringify(newRecIdInCurrentSession));
          }
          else {
            localStorage.setItem('newRecId', JSON.stringify(recIdArray));
          }
          setLoadingRecommendation(false)
        })
          .finally(
            () => {
              updateViewFlag({ clientId: userDetails.clientId })
            }
          )


      } catch (error) {

        console.error("Error ", error);
      }

    }
  }, [userDetails?.clientId]);

  //This function opens Add to cart drawer
  const handleAddToCartAnchorsEl = async (item: RecommendationsType) => {
    try {
      setAddToCartAnchorsEl(true);
      setInvestScheme(item);
    } catch (e) {
      console.error((e as Error).message);

    }
  };

  //This function closes Add to cart drawer
  const handleAddToCartAnchorsElClose = () => {
    setAddToCartAnchorsEl(false);
  };

  //This function is used to set value of viewSchemeDetails as true, which will open the details of the recommended scheme
  const handleSetViewSchemeDetails = async (val: boolean, schemeDetail: SchemeList | RecommendationsType | undefined | null) => {
    setCurrentSchemeDetail(schemeDetail as RecommendationsType);
    setViewSchemeDetails(val);
  };

  //This useEffect is used to get Nav details, category average and scheme details of the schemes of which scheme details button was clicked
  useEffect(() => {
    if (currentSchemeDetail) {
      var schemaId = parseInt(currentSchemeDetail.SchemeID, 10);
      setLoadingCatAvg(true);
      setLoadingSchemeDetail(true);
      setLoadingSchemeNav(true);
      getSchemeDetails(currentSchemeDetail?.SchemeID)
      getCategoryAverageDetails({ schemaId: schemaId, marketValue: false })
      getSchemeNavDetails(currentSchemeDetail?.SchemeID)
    }
  }, [currentSchemeDetail?.SchemeID])

  //This useEffect stops the loading when Nav details, category average and scheme details are fetched for newly selected scheme
  useEffect(() => {
    setSchemeDetail(schemeDetails);
    setLoadingCatAvg(false);
    setLoadingSchemeDetail(false);
    setLoadingSchemeNav(false);
  }, [schemeNav, categoryAverage, schemeDetails]);

  //This useEffect is used for filter functionality - basically to handle search along with filtered items
  useEffect(() => {
    (async function () {
      try {
        if (recommendedScheme != undefined) {
          if (Object.keys(initialFilter).length == 0) {
            const filtered: any = recommendedScheme?.filter((value: any) => finalCheckedItems["Status"].includes(value?.Expirystatus == "Order confirmed_Success" ? "Order Placed" : value?.Expirystatus == "Order confirmed_Failed" ? "Order Confirmation Failed" : value?.Expirystatus == "Order confirmed_Payment Successfully Completed" ? "Payment Successfull" : value?.Expirystatus)).filter((item) =>
              Object.values(item).some((value) => String(value).toLowerCase().includes(search.toLowerCase()))
            );
            let response_accountType: any = await getAccountTypes({ rmID: Number(filtered[0]?.rmID) })
            filtered?.map(async (item: RecommendationsType) => {
              let foundValue = response_accountType.find((val: any) => val.AccountId == item.accountID)
              if (foundValue == undefined) {
                item.AccountType = "NA"
              }
              else {
                item.AccountType = foundValue?.BseRegStatus == "Y" ? "Y$" + foundValue.AccountType : "N$" + foundValue.AccountType
              }
            })
            setfilteredRecommendations(filtered)
          }
          else {
            const filtered: any = totalFilter?.filter((item: any) =>
              Object.values(item).some((value) => String(value).toLowerCase().includes(search.toLowerCase()))
            );
            let response_accountType: any = await getAccountTypes({ rmID: Number(filtered[0]?.rmID) })
            filtered?.map(async (item: RecommendationsType) => {
              let foundValue = response_accountType.find((val: any) => val.AccountId == item.accountID)
              if (foundValue == undefined) {
                item.AccountType = "NA"
              }
              else {
                item.AccountType = foundValue?.BseRegStatus == "Y" ? "Y$" + foundValue.AccountType : "N$" + foundValue.AccountType
              }
            })
            setfilteredRecommendations(filtered)
          }
        }
      } catch (e) {
        console.error(e);
      }
    })();
  }, [search, recommendedScheme])


  useEffect(() => {
    setRecommendedBucketSchemes(groupOrdersByBucket(filteredRecommendations.filter((ele: any) => (ele?.SchemeType == 'ISIP' || ele?.SchemeType == "New" || ele?.SchemeType == 'XSIP' || ele?.SchemeType == 'Add'))))
  }, [filteredRecommendations])

  const groupOrdersByBucket = (data: RecommendationsType[] | undefined) => {
    const groupedRecommendedSchemes: Record<number, RecommendationsType[]> = {};

    if (data) {
      data.forEach((ele) => {
        const BucketID = ele?.BucketID
        groupedRecommendedSchemes[BucketID] = groupedRecommendedSchemes[BucketID] || [];
        if (ele?.BucketID != null) {
          groupedRecommendedSchemes[BucketID].push(ele);
        }
        else {
          groupedRecommendedSchemes[0]?.push(ele);
        }
      });
    }
    return groupedRecommendedSchemes;
  }

  const handleSubmit = async (item: any) => {
    setSelectedBasketSchemes([])
    var payload: any = {}
    for (let i = 0; i < item.length; i++) {
      let ele = item[i]
      if (subVal == 'sip') {
        const { bse_code } = await get_bse_code({
          "TrType": "ISIP",
          "Amount": ele.InvestmentAmount.toString(),
          "Growthoption": ele?.Growthoption,
          "DividendReinvestment": ele?.Dividendreinvestment,
          "RTACODE": ele?.Sch
        })
        payload = {
          "StartDate": formatDate(ele.SIP_date),
          "Installments": ele.No_of_Installments,
          "InstallmentsAmt": ele.InvestmentAmount.toString(),
          "MandateId": "",
          "MandateType": "",
          "FirstOrderToday": "N",
          "Frequency": frequencyMapping[ele.Frequency],
          "AmcId": ele?.AmcID,
          "Sch": ele?.Sch,
          "TrType": "ISIP",
          "Growthoption": ele?.Growthoption,
          "DividendReinvestment": ele?.Dividendreinvestment,
          "BSE_SchemeCode": bse_code[0][0].BSE_ProductCod,
          "RecId": ele?.RecID ? ele?.RecID : 0
        }
        if (bse_code[0].length > 0) {
          const response = await create_transaction(payload)
          if (response.transaction_created != null || response.transaction_created != "" || response.transaction_created != undefined) {
            selectedBasketSchemes.push({ order_id: response.transaction_created, type: "sys" })
            setSelectedBasketSchemes([...selectedBasketSchemes])
          }
        }

      }
      if (subVal == 'lumpsum') {
        const { bse_code } = await get_bse_code({
          "TrType": "New",
          "Amount": ele?.InvestmentAmount?.toString(),
          "Growthoption": ele?.Growthoption,
          "DividendReinvestment": ele?.Dividendreinvestment,
          "RTACODE": ele?.Sch
        })
        payload = {
          "Amount": ele.InvestmentAmount.toString(),
          "AmcId": ele?.AmcID,
          "Sch": ele?.Sch,
          "TrType": "New",
          "Growthoption": ele?.Growthoption,
          "DividendReinvestment": ele?.Dividendreinvestment,
          "BSE_SchemeCode": bse_code[0][0]?.BSE_ProductCod,
          "RecId": ele?.RecID ? ele?.RecID : 0
        }
        setSelectedBasketSchemes([])
        if (bse_code[0].length > 0) {
          const response = await create_transaction(payload)
          if (response.transaction_created != null || response.transaction_created != "" || response.transaction_created != undefined) {
            selectedBasketSchemes.push({ order_id: response.transaction_created, type: "Normal" })
            setSelectedBasketSchemes([...selectedBasketSchemes])

          }
        }

      }
    }
  }
  const placeOrder = async () => {
    let placeOrder_response: any = await place_order({
      orders: selectedBasketSchemes
    })
    setLoading(false)
    setSelectedBasketSchemes([])
    let all_success = true;
    for (let i = 0; i < placeOrder_response.bse_order.length; i++) {
      console.log("placeOrder_response.bse_order[0].order_success", placeOrder_response.bse_order[i].order_success)
      if (placeOrder_response.bse_order[i].order_success === false)
        all_success = false;
    }
    if (all_success) {
      handleCloseSchemeModal()
      Swal.fire({
        title: "Order Placed!",
        icon: "success",
        customClass: {
          confirmButton: 'sweet-alert-button'
        }
      });
      let successList: any = []
      placeOrder_response.bse_order.filter((val: any) => { return (val.order_success == true) }).map((i: any) => {
        successList.push({
          name: i.order_data_params.Schdesc,
          AssetClassName: i.order_data_params.AssetClassName,
          Sub_AssetclassName: i.order_data_params.Sub_AssetclassName,
          Schemeoption: i.order_data_params.Schemeoption,
          success_reason: i.order_status
        })
      })
      setSuccessOrderList(successList)
    }
    else {
      setOpenDialog(true)
      handleCloseSchemeModal()
      let failedList: any = []
      placeOrder_response.bse_order.filter((val: any) => { return (val.order_success == false) }).map((i: any) => {
        let foundValue: any = groupedSchemes.filter((a: any) =>
          (a.Sch === i.order_data_params.SchemeCd)
        );
        failedList.push({
          name: foundValue[0].ProductName,
          AssetClassName: foundValue[0].AssetClassName,
          Sub_AssetclassName: foundValue[0].Sub_AssetclassName,
          Schemeoption: foundValue[0].Schemeoption,
          failure_reason: i.order_status
        })
      })
      setFailedOrderList(failedList)
    }
    setSelectedBasketSchemes([])
  }


  return (<>
    {isLoadingschemeDetail || isLoadingCatAvg || isLoadingSchemeNav || isLoadingRecommendation ?
      <> <LinearProgress sx={{ mt: 2.5 }} />
      </>
      : <>
        {viewSchemeDetails ?
          //Details of scheme in selected recommendation
          <Box sx={{
            bgcolor: 'common.white',
            boxShadow: '0px 4px 28px 2px rgba(0, 0, 0, 0.08)',
            borderRadius: '15px',
            py: 2,
          }}>
            <div>
              <SchemeDetail
                handleBackClick={() => setViewSchemeDetails(false)}
                handleSetViewSchemeDetails={handleSetViewSchemeDetails}
                schemeDetail={schemeDetail}
                schemeData={currentSchemeDetail as unknown as SchemeList}
                categoryAverage={categoryAverage}
                schemeNav={schemeNav}
              />
            </div>
          </Box>
          :
          //List of recommendation
          <Box sx={{ boxShadow: '0px 0px 20px #dfdfdf', bgcolor: 'white', mt: { xs: 0, sm: 0 }, borderRadius: '10px' }}>
            <Box style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <FormControl sx={{ width: { xs: 180, sm: 225 }, ml: 2, mt: 2 }} variant="outlined">
                <OutlinedInput
                  value={search}
                  onChange={({ target: { value } }) => {
                    setSearch(value);
                  }}
                  sx={{ '& .MuiOutlinedInput-input': { py: 1, fontSize: { xs: 11, sm: 13 } } }}
                  id="search-field"
                  placeholder="Search by Scheme Name"
                  startAdornment={
                    <InputAdornment position="start">
                      <SearchIcon fontSize="small" />
                    </InputAdornment>
                  }
                />
              </FormControl>
              <IconButton onClick={handleClickFilter} sx={{ color: "#0393FE", border: "2px solid #0393FE", borderRadius: "30px", fontSize: { xs: "10px", sm: "15px" }, marginRight: "1rem", height: "2rem", marginTop: "10px", padding: { xs: "0rem 0.5rem", sm: "1rem" } }}>
                <FilterListIcon />
                <span><b>FILTER</b></span> {filterCount != 0 ? <span style={{ marginLeft: '10px', width: '16px', height: '16px', color: 'white', fontSize: '12px', textAlign: 'center', backgroundColor: 'red', borderRadius: "50%", display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{filterCount}</span> : ""}
              </IconButton>
              {open &&
                <FilterComponent
                  open={open}
                  anchorEl={filterAnchorEl}
                  setAnchorEl={setFilterAnchorEl}
                  setSearch={setSearch}
                  setFilterState={setTotalFilter}
                  page={"Recommendation"}
                  setListData={setfilteredRecommendations}
                  filteredState={recommendedScheme}
                  setFilterCount={setFilterCount}
                  setFinalCheckedItems={setFinalCheckedItems}
                  finalCheckedItems={finalCheckedItems}
                  filterDateData={filterDateData}
                  setFilterDateData={setFilterDateData}
                />}
            </Box>
            <Box sx={{ '& .MuiTabPanel-root': { py: 0, px: 0 } }}>
              <TabContext value={value} >
                <Box sx={{
                  display: "flex",
                  justifyContent: "space-between",
                  width: '100%',
                  '& .MuiTabPanel-root': { px: 0 },
                  '& .MuiTab-root': {
                    color: '#A1A2A2',
                    opacity: 0.8,
                    fontSize: { xs: 12, sm: 17 },
                    textTransform: 'capitalize',
                    border: 'none',
                    px: { xs: 1, md: 2, lg: 3 },
                    mx: { xs: 0.5, sm: 2 },
                    my: 0.5,
                    py: 0,
                    '&.Mui-selected': {
                      color: '#35A9FE',
                      border: 'none'
                    },
                  },
                  '& .MuiTabs-indicator': {
                    height: 3,
                    background: '#35A9FE',
                  },
                }}>
                  <TabList
                    variant="scrollable"
                    scrollButtons="auto"
                    onChange={handleChange}>

                    {tabMap.map((val: any, index: number) => {
                      return (
                        <Tab label={`${val.label} (${filteredRecommendations?.filter((i: any) => {
                          return (i.SchemeType == val.trType || i.SchemeType == val.trType2)
                        }).length})`} value={val.value} key={index} />
                      )
                    })}
                  </TabList>
                  {/* <Button variant="contained">Edit</Button> */}
                </Box>
                <Divider />
                <Box sx={{ px: { xs: 0, sm: 1 } }}>
                  {tabMap.map((val) =>

                    <TabPanel value={val.value} key={val.value}>
                      {val.value == "New" || val.value == "Add" ?
                        //Tab for New and Additional purchase
                        <Box sx={{ '& .MuiTabPanel-root': { py: 0, px: 1 }, }}>
                          <TabContext value={subVal}>
                            <Box
                              sx={{

                                width: '100%',
                                '& .MuiTabPanel-root': { px: 0 },
                                '& .MuiTab-root': {
                                  color: '#A1A2A2',
                                  opacity: 0.8,
                                  fontSize: 12,
                                  width: { xs: "50%", sm: "12%" },
                                  textTransform: 'capitalize',
                                  px: { xs: 1, md: 2, lg: 3 },
                                  my: 0,
                                  py: 0,
                                  '&.Mui-selected': {
                                    color: { xs: "white", sm: '#35A9FE' },
                                    border: 'none',
                                    bgcolor: { xs: "#0393FE", sm: "white" },
                                    borderRadius: "5px",
                                    p: 2.5,

                                  },
                                },
                                '& .MuiTabs-indicator': {
                                  height: 2,
                                  background: { xs: "none", sm: '#35A9FE' },
                                },
                                '& .MuiTabs-flexContainer': {
                                  display: "flex",
                                  justifyContent: { xs: "center", sm: "flex-start" },
                                  width: "100%",
                                  mt: 0.5
                                }
                              }}>
                              <TabList
                                onChange={handleSubValChange}
                                aria-label="product tabs"
                                variant="scrollable"
                                scrollButtons="auto"
                              >
                                {[{ label: "SIP", value: "sip" }, { label: "Lumpsum", value: "lumpsum" }].map((val_: any, index: number) => {
                                  return (
                                    <Tab label={`${val_.label} (${filteredRecommendations?.filter((i: any) => {
                                      return (val_.value == 'sip' ? i.SchemeType === val.trType2 : i.SchemeType == val.trType)
                                    }).length})`} value={val_.value} key={index} />
                                  )
                                })}
                              </TabList>
                            </Box>
                            <Divider />
                            <Box sx={{ height: { xs: "100%", sm: "17.5rem" }, overflow: "scroll" }} >
                              {[{ label: "SIP", value: "sip" }, { label: "Lumpsum", value: "lumpsum" }].map((val_) => {
                                return (
                                  <TabPanel value={val_.value} key={val_.value}>

                                    {filteredRecommendations?.filter((i: any) => {
                                      return (val_.value == 'sip' ? i.SchemeType === val.trType2 : i.SchemeType == val.trType)
                                    }).length === 0 ?
                                      <Box sx={{ display: "flex", justifyContent: "center" }}>
                                        <Typography sx={{ color: "lightgrey", fontSize: { xs: 14, sm: 18 }, fontWeight: 500, p: { xs: 1, sm: 2 } }}>No Recommendations</Typography>
                                      </Box>
                                      :
                                      <>
                                        {Object.values(recommendedBucketSchemes)?.sort((a: any, b: any) => new Date(b[0]?.EntryDate).getTime() - new Date(a[0]?.EntryDate).getTime()).filter((i: any) => {
                                          return (val_.value == 'sip' ? i[0]?.SchemeType === val.trType2 : i[0]?.SchemeType == val.trType)
                                        }).map((itemArr: any, index: number) => {
                                          let item = itemArr[0]  //to get first element from bucket arrays
                                          const storedValue = localStorage.getItem('newRecId');
                                          const existingItems = storedValue ? JSON.parse(storedValue) : [];
                                          const isNew = existingItems.find((existingItem: any) => existingItem === item.RecID) !== undefined;
                                          const noOfElements = filteredRecommendations?.filter((i: any) => {
                                            return (val_.value == 'sip' ? i.SchemeType === val.trType2 : i.SchemeType == val.trType)
                                          }).length;

                                          return <Box key={index}>
                                            <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'flex', my: '0.7rem' }}>

                                              {isNew ?
                                                <Box sx={{ backgroundColor: "red", color: "white", width: "30px", fontSize: 9, borderRadius: "50%", display: 'flex', justifyContent: 'center', mt: 1 }}>
                                                  New
                                                </Box> : null}

                                              <Box sx={{ display: 'flex', justifyContent: 'space-between', flexDirection: { xs: "column", sm: 'row' }, alignItems: 'flex-start', mx: { xs: 1, sm: 2 }, p: { xs: 0, sm: 1 }, cursor: 'pointer' }} onClick={() => { handleMoreDetailsClick(index);  handleOpenSchemeModal(itemArr) }}>
                                                <Box sx={{ display: 'flex', flexDirection: 'column', width: { xs: '100%', sm: "75%" } }}>

                                                  <Box sx={{ display: 'flex', flexDirection: 'row', justifyContent: 'flex-start', pt: { xs: 1, sm: 0 } }}>
                                                    <Box sx={{ width: { xs: "100%", sm: '70%' } }}><Typography sx={{ fontSize: 12.5, fontWeight: 500, mb: 0.5 }}>
                                                      {item?.SchemeName}<span style={{ color: "gray", marginLeft: "0.5rem", fontSize: "0.8rem", width: "4rem" }}>{recommendedBucketSchemes[item?.BucketID]?.length != 1 ? ` +${recommendedBucketSchemes[item?.BucketID]?.length - 1} more` : ""}</span>
                                                    </Typography>
                                                    </Box>
                                                    {item?.Expirystatus === "Active" ?
                                                      <Box sx={{ width: "fit-content", borderRadius: '15px', height: '20px', bgcolor: 7 - item?.NoOfDays >= 5 ? "#52AC8C" : 7 - item?.NoOfDays > 2 && item?.NoOfDays < 5 ? "#EA8B24" : "#EB4646", display: "inline-block", margin: "0px", marginLeft: "2px" }}>

                                                        <Typography sx={{ color: '#ffffff', fontSize: '9.5px', fontWeight: '0', p: 0.5 }} >{`${7 - Number(item?.NoOfDays)}`}{`${7 - Number(item?.NoOfDays)}` === '1' ? ' day left' : ' days left'}</Typography>

                                                      </Box> : ''
                                                    }
                                                  </Box>
                                                  <Box sx={{ display: 'flex', mt: { xs: 0, sm: 1 }, width: "100%", flexWrap: "wrap" }}>
                                                    {/* {!!fundItem.AssetClassName && ( */}
                                                    <Bubble text={item?.AssetClassName} />
                                                    {/* )} */}
                                                    {/* {!!fundItem.Sub_AssetclassName && ( */}
                                                    <Bubble text={item?.Sub_AssetclassName} />
                                                    {/* )} */}
                                                    <Bubble text={item?.PlanName} />

                                                  </Box>
                                                </Box>
                                                <Box sx={{ display: "flex", alignItems: 'flex-start', justifyContent: "space-between", cursor: 'pointer', width: "100%", mt: { xs: "0.5rem", sm: "0rem" }, ml: 0, mb: { xs: 1, sm: 0 } }}>
                                                  <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: "center", width: { xs: "10%", sm: '18%' } }}>
                                                    <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: '#5a7c82', fontWeight: 400 }}> Status</Typography>
                                                    <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: item?.Expirystatus == "Active" ? "#52AC8C" : item?.Expirystatus == "In Cart" ? "#EA8B24" : item?.Expirystatus == "Expired" ? 'grey' : item?.Expirystatus == "Order confirmed_Failed" ? "#EB4646" : "red", fontWeight: 500, mt: 1 }}>
                                                      {item?.Expirystatus == "Order confirmed_Success" ? "Order Placed" : item?.Expirystatus == "Order confirmed_Failed" ? "Order Confirmation Failed" : item?.Expirystatus == "Order confirmed_Payment Successfully Completed" ? "Payment Successfull" : item?.Expirystatus}
                                                    </Typography>
                                                  </Box>
                                                  {item?.InvestmentAmount ?
                                                    <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', width: { xs: "45%", sm: '28%' } }}>

                                                      <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: '#5a7c82', fontWeight: 400 }}> Amount</Typography>
                                                      <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: "#011E33", fontWeight: 500, mt: 1 }}>
                                                        {/* {fundItem.Aum === "0" || !fundItem.Aum
                                                                        ? "NA"
                                                                        : `₹${currencyConverter(fundItem.Aum)}`} */}
                                                        {/* ₹ 2,06,789 */}
                                                        {formatToIndianCurrency(item?.InvestmentAmount, 0)}
                                                      </Typography>


                                                    </Box>
                                                    : <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', width: { xs: "45%", sm: '28%' } }}>

                                                      <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: '#5a7c82', fontWeight: 400 }}> Units</Typography>
                                                      <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: "#011E33", fontWeight: 500, mt: 1 }}>
                                                        {/* {fundItem.Aum === "0" || !fundItem.Aum
                                                                        ? "NA"
                                                                        : `₹${currencyConverter(fundItem.Aum)}`} */}
                                                        {/* ₹ 2,06,789 */}
                                                        {item?.Units}
                                                      </Typography>


                                                    </Box>
                                                  }
                                                  <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: "center", width: { xs: "25%", sm: '35%' } }}>

                                                    <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: '#5a7c82', fontWeight: 400 }}>Recommendation Date </Typography>
                                                    <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: "#011E33", fontWeight: 500, mt: 1 }}>
                                                      {convertDate(item?.EntryDate)}
                                                    </Typography>

                                                  </Box>


                                                  <Box>
                                                    <InvestNowTooltip title='Add to Cart' TransitionComponent={Zoom}
                                                      TransitionProps={{ timeout: 200 }} >
                                                      <Box sx={{ cursor: 'pointer', ml: { xs: "1rem", sm: "3rem" } }} onClick={(e) => { e.stopPropagation(); if (item?.Expirystatus === "Active") { recommendedBucketSchemes[item?.BucketID]?.length == 1 && handleAddToCartAnchorsEl(item) } }}>
                                                        {item?.Expirystatus === "Active" && recommendedBucketSchemes[item?.BucketID]?.length == 1 ? <InvestNowIcon /> : <InvestNowIconDisabled />}
                                                      </Box>
                                                    </InvestNowTooltip>
                                                    {' '}

                                                  </Box>
                                                  <Box >
                                                  {recommendedBucketSchemes[item?.BucketID]?.length == 1 ?
                                                    <ArrowForwardIosIcon
                                                      onClick={(e) => { e.stopPropagation(); handleSetViewSchemeDetails(true, item); }}
                                                      sx={{ fontSize: 28.5, borderRadius: 1, backgroundColor: '#163869', color: '#ffffff', p: 0.2, mx: { xs: 0, sm: 1.5 }, cursor: 'pointer', ml: { xs: "1rem", sm: "3rem" } }} />:
                                                      <ArrowForwardIosIcon
                                                      sx={{ fontSize: 28.5, borderRadius: 1, backgroundColor: '#163869', color: '#ffffff', p: 0.2, mx: { xs: 0, sm: 1.5 }, cursor: 'pointer', ml: { xs: "1rem", sm: "3rem" },opacity:0.2 }} />}
                                                  </Box>
                                                </Box>
                                              </Box>
                                              <Collapse in={recommendedBucketSchemes[item?.BucketID]?.length == 1 && moreDetails[index]} timeout={300}>
                                                {val_.value == "sip" ?

                                                  <Box sx={{ display: "flex", flexDirection: 'row', flexWrap: "wrap", px: { xs: 0, sm: 3.5 }, py: { xs: 0, sm: 2 }, mx: { xs: 1, sm: 0 } }}>
                                                    <Box sx={{ display: 'flex', flexDirection: 'column', width: { xs: "28%", sm: '20%' }, gap: "0.4rem" }}>
                                                      <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: '#5a7c82', fontWeight: 400 }}>Returns</Typography>
                                                      <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: "#27976F", fontWeight: 500 }}>
                                                        {/* {item?.Aum === "0" || !item?.Aum
                                                                        ? "NA"
                                                                        : `₹${currencyConverter(fundItem.Aum)}`} */}
                                                        {Nanprocessor(roundToTwo(Number(item?.Sch_Return5Yr)))} %
                                                      </Typography>
                                                    </Box>
                                                    <Box sx={{ display: 'flex', flexDirection: 'column', width: { xs: "28%", sm: '20%' }, gap: "0.4rem" }}>
                                                      <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: '#5a7c82', fontWeight: 400, display: "flex" }}>Frequency </Typography>
                                                      <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: "#011E33", fontWeight: 500, display: "flex" }}>
                                                        {item?.Frequency}
                                                      </Typography>
                                                    </Box>
                                                    {item?.Frequency !== 'DAILY' && <Box sx={{ display: 'flex', flexDirection: 'column', width: { xs: "35%", sm: '20%' }, gap: "0.4rem" }}>
                                                      <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: '#5a7c82', fontWeight: 400, display: "flex" }}>No. of Instalments </Typography>
                                                      <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: "#011E33", fontWeight: 500, display: "flex" }}>
                                                        {item?.No_of_Installments}
                                                      </Typography>
                                                    </Box>}

                                                    <Box sx={{ display: 'flex', flexDirection: 'column', width: { xs: "30%", sm: '20%' }, gap: "0.4rem", mt: { xs: "0.4rem", sm: "0rem" } }}>
                                                      <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: '#5a7c82', fontWeight: 400, display: "flex" }}>SIP Date </Typography>
                                                      <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: "#011E33", fontWeight: 500, display: "flex" }}>
                                                        {convertDate(item?.SIP_date.split('T')[0])}
                                                      </Typography>
                                                    </Box>
                                                    {item?.Folio === '' ?
                                                      <Box sx={{ display: 'flex', flexDirection: 'column', width: { xs: "50%", sm: '20%' }, mt: { xs: "0.4rem", sm: "0rem" } }}>
                                                        <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: '#5a7c82', fontWeight: 400, display: "flex" }}>Account Name </Typography>
                                                        <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: "#011E33", fontWeight: 500, display: "flex" }}>{item?.AccountType == "NA" ? "NA" : item?.AccountType?.split("$")[1]}</Typography>
                                                      </Box> :
                                                      <Box sx={{ display: 'flex', flexDirection: 'column', width: { xs: "30%", sm: '20%' }, mt: { xs: "0.3rem", sm: "0rem" } }}>
                                                        <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: '#5a7c82', fontWeight: 400, display: "flex" }}>Folio </Typography>
                                                        <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: "#011E33", fontWeight: 500, display: "flex" }}> {item?.Folio}</Typography>
                                                      </Box>
                                                    }
                                                  </Box>

                                                  :

                                                  <Box sx={{ display: "flex", flexDirection: 'row', px: { xs: 0, sm: 3.5 }, py: { xs: 0, sm: 2 }, mx: { xs: 1, sm: 0 }, flexWrap: "wrap" }}>
                                                    <Box sx={{ display: 'flex', flexDirection: 'column', width: { xs: "35%", sm: '20%' }, gap: "0.4rem" }}>
                                                      <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: '#5a7c82', fontWeight: 400 }}>Returns</Typography>
                                                      <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: "#27976F", fontWeight: 500 }}>
                                                        {/* {item?.Aum === "0" || !item?.Aum
                                                                        ? "NA"
                                                                        : `₹${currencyConverter(fundItem.Aum)}`} */}
                                                        {Nanprocessor(roundToTwo(Number(item?.Sch_Return5Yr)))} %
                                                      </Typography>
                                                    </Box>
                                                    {item?.Folio === '' ?
                                                      <Box sx={{ display: 'flex', flexDirection: 'column', width: { xs: "50%", sm: '20%' }, mt: { xs: "0.3rem", sm: "0rem" } }}>
                                                        <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: '#5a7c82', fontWeight: 400, display: "flex" }}>Account Name </Typography>
                                                        <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: "#011E33", fontWeight: 500, display: "flex" }}>{item?.AccountType == "NA" ? "NA" : item?.AccountType?.split("$")[1]}</Typography>
                                                      </Box> :
                                                      <Box sx={{ display: 'flex', flexDirection: 'column', width: { xs: "30%", sm: '20%' }, mt: { xs: "0.3rem", sm: "0rem" } }}>
                                                        <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: '#5a7c82', fontWeight: 400, display: "flex" }}>Folio </Typography>
                                                        <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: "#011E33", fontWeight: 500, display: "flex" }}> {item?.Folio}</Typography>
                                                      </Box>
                                                    }
                                                  </Box>
                                                }
                                              </Collapse>
                                              {index + 1 < noOfElements && <Divider />}
                                            </Box>
                                          </Box>

                                        })}

                                      </>
                                    }
                                  </TabPanel>
                                )
                              })}
                            </Box>
                          </TabContext>
                        </Box> :
                        //Tab for STP, SWP, Switch and redemption
                        <Box sx={{ height: { xs: "100%", sm: "20rem" }, overflow: "scroll" }}>
                          {filteredRecommendations?.filter((i: any) => {
                            return (i.SchemeType === val.trType || i.SchemeType == val.trType2)
                          }).length === 0 ?
                            <Box sx={{ display: "flex", justifyContent: "center" }}>
                              <Typography sx={{ color: "#5a7c82", fontSize: { xs: 14, sm: 18 }, fontWeight: 500, p: { xs: 1, sm: 2 } }}>No Recommendations</Typography>
                            </Box>
                            :
                            <>
                              {filteredRecommendations?.sort((a: any, b: any) => new Date(b.EntryDate).getTime() - new Date(a.EntryDate).getTime()).filter((i: any) => {
                                return (i.SchemeType === val.trType)
                              }).map((item: RecommendationsType, index: number) => {

                                const storedValue = localStorage.getItem('newRecId');
                                const existingItems = storedValue ? JSON.parse(storedValue) : [];
                                const isNew = existingItems.find((existingItem: any) => existingItem === item.RecID) !== undefined;
                                const noOfElements = filteredRecommendations?.filter((i: any) => {
                                  return (i.SchemeType === val.trType)
                                }).length;
                                return <Box key={index} sx={{ display: 'flex', flexDirection: 'column', alignItems: 'flex', my: '0.7rem' }}>
                                  {isNew ?
                                    <Box sx={{ backgroundColor: "red", color: "white", width: "30px", fontSize: 9, borderRadius: "50%", display: 'flex', justifyContent: 'center', mt: 1, }}>
                                      New
                                    </Box> : null}
                                  <Box sx={{ display: 'flex', justifyContent: 'space-between', flexDirection: { xs: "column", sm: 'row' }, alignItems: 'flex-start', mx: { xs: 2, sm: 2 }, p: { xs: 0, sm: 1 }, cursor: 'pointer' }} onClick={() => handleMoreDetailsClick(index)}>
                                    <Box sx={{ display: 'flex', flexDirection: 'column', width: { xs: '100%', sm: "55%" } }}>

                                      <Box sx={{ display: 'flex', flexDirection: 'row', justifyContent: 'flex-start', pt: { xs: 1, sm: 0 } }}>
                                        <Box sx={{ width: { xs: "100%", sm: "75%" } }}><Typography sx={{ fontSize: 12.5, fontWeight: 500, mb: 0.5, }}>
                                          {item?.SchemeName}
                                        </Typography>
                                        </Box>
                                        {item?.Expirystatus === "Active" ?
                                          <Box sx={{ width: "fit-content", borderRadius: '15px', height: '20px', bgcolor: 7 - item?.NoOfDays >= 5 ? "#52AC8C" : 7 - item?.NoOfDays > 2 && item?.NoOfDays < 5 ? "#EA8B24" : "#EB4646", display: "inline-block", margin: "0px", marginLeft: "2px" }}>

                                            <Typography sx={{ color: '#ffffff', fontSize: '9.5px', fontWeight: '0', p: 0.5 }} >{`${7 - Number(item?.NoOfDays)}`}{`${7 - Number(item?.NoOfDays)}` === '1' ? ' day left' : ' days left'}</Typography>

                                          </Box> : ''
                                        }
                                      </Box>
                                      <Box sx={{ display: 'flex', mt: { xs: 0, sm: 1 }, width: "100%", flexWrap: "wrap" }}>
                                        {/* {!!fundItem.AssetClassName && ( */}
                                        <Bubble text={item?.AssetClassName} />
                                        {/* )} */}
                                        {/* {!!fundItem.Sub_AssetclassName && ( */}
                                        <Bubble text={item?.Sub_AssetclassName} />
                                        {/* )} */}
                                        <Bubble text={item?.PlanName} />

                                      </Box>
                                    </Box>
                                    <Box sx={{ display: "flex", justifyContent: { xs: "flex-start", }, px: 0, py: { xs: 1, sm: 0 }, width: "100%" }}>
                                      <Box sx={{ display: "flex", justifyContent: "space-between", width: { xs: "75%", sm: "85%" }, flexWrap: "wrap" }}>
                                        <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: "center", width: { xs: "15%", sm: '25%' } }}>
                                          <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: '#5a7c82', fontWeight: 400 }}> Status</Typography>
                                          <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: item?.Expirystatus == "Active" ? "#52AC8C" : item?.Expirystatus == "In Cart" ? "#EA8B24" : item?.Expirystatus == "Expired" ? 'grey' : item?.Expirystatus == "Order confirmed_Failed" ? "#EB4646" : "red", fontWeight: 500, mt: 1 }}>
                                            {item?.Expirystatus == "Order confirmed_Success" ? "Order Placed" : item?.Expirystatus == "Order confirmed_Failed" ? "Order Confirmation Failed" : item?.Expirystatus == "Order confirmed_Payment Successfully Completed" ? "Payment Successfull" : item?.Expirystatus}
                                          </Typography>
                                        </Box>

                                        {item.Units <= 0 ?
                                          <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: "center", width: { xs: "30%", sm: '25%' } }}>
                                            <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: '#5a7c82', fontWeight: 400 }}> Amount</Typography>
                                            <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: "#011E33", fontWeight: 500, mt: 1 }}>
                                              {/* {fundItem.Aum === "0" || !fundItem.Aum
                                                    ? "NA"
                                                    : `₹${currencyConverter(fundItem.Aum)}`} */}
                                              {/* ₹ 2,06,789 */}
                                              {formatToIndianCurrency(item?.InvestmentAmount, 0)}
                                            </Typography>

                                          </Box>
                                          : <Box sx={{ display: 'flex', flexDirection: 'column', width: { xs: "30%", sm: '10%' } }}>
                                            <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: '#5a7c82', fontWeight: 400 }}> Units</Typography>
                                            <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: "#011E33", fontWeight: 500, mt: 1 }}>
                                              {/* {fundItem.Aum === "0" || !fundItem.Aum
                                                  ? "NA"
                                                  : `₹${currencyConverter(fundItem.Aum)}`} */}
                                              {/* ₹ 2,06,789 */}
                                              {item.Units}
                                            </Typography>

                                          </Box>}
                                        {(item.SchemeType === "Swt" || item.SchemeType === "STP") && <Box sx={{ display: 'flex', flexDirection: 'column', width: { xs: "50%", sm: '35%' }, pr: 1.5 }}>
                                          <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: '#5a7c82', fontWeight: 400 }}>To Scheme</Typography>
                                          <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: "#011E33", fontWeight: 500, mt: 1 }}>

                                            {item?.ToschemeName}
                                          </Typography>
                                        </Box>
                                        }
                                        <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: "center", width: { xs: "40%", sm: '40%' }, }}>
                                          <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: '#5a7c82', fontWeight: 400 }}>Recommendation Date </Typography>
                                          <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: "#011E33", fontWeight: 500, mt: 1 }}>
                                            {convertDate(item?.EntryDate)}
                                          </Typography>
                                        </Box>


                                      </Box>
                                      <Box sx={{ display: "flex", justifyContent: "space-between", width: "15%" }}>
                                        <InvestNowTooltip title='Add to Cart' TransitionComponent={Zoom}
                                          TransitionProps={{ timeout: 200 }} >
                                          <Box sx={{ cursor: 'pointer', ml: { xs: "0.5em", sm: "0rem" } }} onClick={(e) => { e.stopPropagation(); item?.Expirystatus === "Active" && handleAddToCartAnchorsEl(item) }}>
                                            {item?.Expirystatus === "Active" ? <InvestNowIcon /> : <InvestNowIconDisabled />}
                                          </Box>
                                        </InvestNowTooltip>
                                        <Box >
                                          <ArrowForwardIosIcon
                                            onClick={() => { handleSetViewSchemeDetails(true, item); }}
                                            sx={{ fontSize: 28, borderRadius: 1, backgroundColor: '#163869', color: '#ffffff', p: 0.2, ml: { xs: "1rem", sm: "0rem" }, cursor: 'pointer' }} />
                                        </Box>
                                      </Box>
                                    </Box>
                                  </Box>
                                  <Collapse in={modalMoreDetails[index]} timeout={300}>

                                    {value == "Red" || value == "Swt" ?

                                      <Box sx={{ display: "flex", flexDirection: 'row', flexWrap: "wrap", py: { xs: 1, sm: 2.5 }, mx: { xs: 2, sm: 3 }, }}>
                                        <Box sx={{ display: 'flex', flexDirection: "column", width: { xs: "30%", sm: '20%' }, gap: "0.4rem" }}>
                                          <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: '#5a7c82', fontWeight: 400 }}>Returns</Typography>
                                          <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: "green", fontWeight: 500 }}>
                                            {/* {item?.Aum === "0" || !item?.Aum
                                                    ? "NA"
                                                    : `₹${currencyConverter(fundItem.Aum)}`} */}
                                            {Nanprocessor(roundToTwo(Number(item?.Sch_Return5Yr)))} %
                                          </Typography>
                                        </Box>
                                        <Box sx={{ display: 'flex', flexDirection: "column", width: { xs: "30%", sm: '33%' }, gap: "0.4rem" }}>
                                          <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: '#5a7c82', fontWeight: 400 }}>{value == "Red" ? "Redemption Type" : "Switch Type "}</Typography>
                                          <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: "#011E33", fontWeight: 500 }}>
                                            {item?.PFFlag === "F" ? 'Full' : 'Partial'}
                                          </Typography>
                                        </Box>

                                        <Box sx={{ display: 'flex', flexDirection: "column", width: { xs: "30%", sm: '33%' }, gap: "0.4rem" }}>
                                          <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: '#5a7c82', fontWeight: 400 }}>Folio  </Typography>
                                          <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: "#011E33", fontWeight: 500 }}>
                                            {item?.Folio}
                                          </Typography>
                                        </Box>
                                      </Box>
                                      :
                                      <Box sx={{ display: "flex", flexDirection: 'row', flexWrap: "wrap", px: { xs: 0, sm: 3.5 }, py: 2.5, mx: { xs: 2, sm: 0 } }}>
                                        <Box sx={{ display: 'flex', flexDirection: "column", width: { xs: "30%", sm: '20%' }, gap: "0.4rem" }}>
                                          <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: '#5a7c82', fontWeight: 400 }}>Returns</Typography>
                                          <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: "green", fontWeight: 500 }}>
                                            {/* {item?.Aum === "0" || !item?.Aum
                                                    ? "NA"
                                                    : `₹${currencyConverter(fundItem.Aum)}`} */}
                                            {Nanprocessor(roundToTwo(Number(item?.Sch_Return5Yr)))} %
                                          </Typography>
                                        </Box>
                                        <Box sx={{ display: 'flex', flexDirection: "column", width: { xs: "25%", sm: '20%' }, gap: "0.4rem" }}>
                                          <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: '#5a7c82', fontWeight: 400, }}>Frequency </Typography>
                                          <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: "#011E33", fontWeight: 500, }}>
                                            {item?.Frequency}
                                          </Typography>
                                        </Box>
                                        {item?.Frequency !== 'DAILY' && <Box sx={{ display: 'flex', flexDirection: "column", width: { xs: "40%", sm: '20%' }, gap: "0.4rem" }}>
                                          <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: '#5a7c82', fontWeight: 400 }}>No. of Instalments </Typography>
                                          <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: "#011E33", fontWeight: 500 }}>
                                            {item?.No_of_Installments}
                                          </Typography>
                                        </Box>}

                                        <Box sx={{ display: 'flex', flexDirection: "column", width: { xs: "35%", sm: '20%' }, gap: "0.4rem", mt: { xs: "0.3rem", sm: "0rem" } }}>
                                          <Typography sx={{ fontSize: 12.5, color: '#5a7c82', fontWeight: 400 }}>{value == "STP" ? "STP Date " : value == "SWP" ? "SWP Date " : "SIP Date "} </Typography>
                                          <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: "#011E33", fontWeight: 500 }}>
                                            {convertDate(item?.SIP_date.split('T')[0])}
                                          </Typography>
                                        </Box>
                                        <Box sx={{ display: 'flex', flexDirection: "column", width: { xs: "35%", sm: '20%' }, gap: "0.4rem", mt: { xs: "0.3rem", sm: "0rem" } }}>
                                          <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: '#5a7c82', fontWeight: 400 }}>Folio </Typography>
                                          <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: "#011E33", fontWeight: 500 }}>
                                            {item?.Folio}
                                          </Typography>
                                        </Box>
                                      </Box>

                                    }
                                  </Collapse>
                                  {index + 1 < noOfElements && <Divider />}
                                </Box>

                              })}
                            </>
                          }
                        </Box>}

                    </TabPanel>

                  )}

                </Box>

              </TabContext>
            </Box>
            <Modal
              open={schemeModalOpen}
              onClose={handleCloseSchemeModal}
              aria-labelledby="modal-modal-title"
              aria-describedby="modal-modal-description"
            >
 
              <Box sx={style}>
                <Box sx={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                  <Typography sx={{ fontWeight: 500, ml: 1, mb: 1 }}>Recommendation Details</Typography>
                  <Box sx={{ cursor: 'pointer' }} onClick={handleCloseSchemeModal} >
                    <CloseIcon />
                  </Box>
                </Box>
                <Divider />
                <div style={{ height: "16.5rem", overflowX: "hidden", }}>
                  {groupedSchemes.map((item: any, index: number) => {
                    const storedValue = localStorage.getItem('newRecId');
                    const existingItems = storedValue ? JSON.parse(storedValue) : [];
                    const isNew = existingItems.find((existingItem: any) => existingItem === item.RecID) !== undefined;

                    return <Box key={index}>
                      <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'flex', my: '0.7rem' }}>

                        {isNew ?
                          <Box sx={{ backgroundColor: "red", color: "white", width: "30px", fontSize: 9, borderRadius: "50%", display: 'flex', justifyContent: 'center', mt: 1 }}>
                            New
                          </Box> : null}

                        <Box sx={{ display: 'flex', justifyContent: 'space-between', flexDirection: { xs: "column", sm: 'row' }, alignItems: 'flex-start', mx: { xs: 1, sm: 2 }, p: { xs: 0, sm: 1 }, cursor: 'pointer', }} onClick={() => handleMoreDetailsClickModal(index)}>
                          <Box sx={{ display: 'flex', flexDirection: 'column', width: { xs: '100%', sm: "75%" } }}>

                            <Box sx={{ display: 'flex', flexDirection: 'row', justifyContent: 'flex-start', pt: { xs: 1, sm: 0 } }}>
                              <Box sx={{ width: { xs: "100%", sm: '80%' } }}><Typography sx={{ fontSize: 12.5, fontWeight: 500, mb: 0.5 }}>
                                {item?.SchemeName}
                              </Typography>
                              </Box>
                              {item?.Expirystatus === "Active" ?
                                <Box sx={{ width: "fit-content", borderRadius: '15px', height: '20px', bgcolor: 7 - item?.NoOfDays >= 5 ? "#52AC8C" : 7 - item?.NoOfDays > 2 && item?.NoOfDays < 5 ? "#EA8B24" : "#EB4646", display: "inline-block", margin: "0px", marginLeft: "2px" }}>

                                  <Typography sx={{ color: '#ffffff', fontSize: '9.5px', fontWeight: '0', p: 0.5 }} >{`${7 - Number(item?.NoOfDays)}`}{`${7 - Number(item?.NoOfDays)}` === '1' ? ' day left' : ' days left'}</Typography>

                                </Box> : ''
                              }
                            </Box>
                            <Box sx={{ display: 'flex', mt: { xs: 0, sm: 1 }, width: "100%", flexWrap: "wrap" }}>
                              {/* {!!fundItem.AssetClassName && ( */}
                              <Bubble text={item?.AssetClassName} />
                              {/* )} */}
                              {/* {!!fundItem.Sub_AssetclassName && ( */}
                              <Bubble text={item?.Sub_AssetclassName} />
                              {/* )} */}
                              <Bubble text={item?.PlanName} />

                            </Box>
                          </Box>
                          <Box sx={{ display: "flex", alignItems: 'flex-start', justifyContent: "space-between", cursor: 'pointer', width: "100%", mt: { xs: "0.5rem", sm: "0rem" }, ml: 0, mb: { xs: 1, sm: 0 } }}>
                            <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: "center", width: { xs: "10%", sm: '28%' } }}>
                              <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: '#5a7c82', fontWeight: 400 }}> Status</Typography>
                              <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: item?.Expirystatus == "Active" ? "#52AC8C" : item?.Expirystatus == "In Cart" ? "#EA8B24" : item?.Expirystatus == "Expired" ? 'grey' : item?.Expirystatus == "Order confirmed_Failed" ? "#EB4646" : "red", fontWeight: 500, mt: 1 }}>
                                {item?.Expirystatus == "Order confirmed_Success" ? "Order Placed" : item?.Expirystatus == "Order confirmed_Failed" ? "Order Confirmation Failed" : item?.Expirystatus == "Order confirmed_Payment Successfully Completed" ? "Payment Successfull" : item?.Expirystatus}
                              </Typography>
                            </Box>
                            {item?.InvestmentAmount ?
                              <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', width: { xs: "45%", sm: '28%' } }}>

                                <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: '#5a7c82', fontWeight: 400 }}> Amount</Typography>
                                <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: "#011E33", fontWeight: 500, mt: 1 }}>
                                  {/* {fundItem.Aum === "0" || !fundItem.Aum
                                            ? "NA"
                                            : `₹${currencyConverter(fundItem.Aum)}`} */}
                                  {/* ₹ 2,06,789 */}
                                  {formatToIndianCurrency(item?.InvestmentAmount, 0)}
                                </Typography>


                              </Box>
                              : <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', width: { xs: "45%", sm: '28%' } }}>

                                <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: '#5a7c82', fontWeight: 400 }}> Units</Typography>
                                <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: "#011E33", fontWeight: 500, mt: 1 }}>
                                  {/* {fundItem.Aum === "0" || !fundItem.Aum
                                            ? "NA"
                                            : `₹${currencyConverter(fundItem.Aum)}`} */}
                                  {/* ₹ 2,06,789 */}
                                  {item?.Units}
                                </Typography>


                              </Box>
                            }
                            <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: "center", width: { xs: "25%", sm: '35%' } }}>

                              <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: '#5a7c82', fontWeight: 400 }}>Recommendation Date </Typography>
                              <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: "#011E33", fontWeight: 500, mt: 1 }}>
                                {convertDate(item?.EntryDate)}
                              </Typography>

                            </Box>
                          </Box>
                        </Box>
                        <Collapse in={modalMoreDetails[index]} timeout={300}>
                          {subVal == "sip" ?

                            <Box sx={{ display: "flex", flexDirection: 'row', flexWrap: "wrap", px: { xs: 0, sm: 3.5 }, py: { xs: 0, sm: 2 }, mx: { xs: 1, sm: 0 } }}>
                              <Box sx={{ display: 'flex', flexDirection: 'column', width: { xs: "28%", sm: '20%' }, gap: "0.4rem" }}>
                                <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: '#5a7c82', fontWeight: 400 }}>Returns</Typography>
                                <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: "#27976F", fontWeight: 500 }}>
                                  {/* {item?.Aum === "0" || !item?.Aum
                                            ? "NA"
                                            : `₹${currencyConverter(fundItem.Aum)}`} */}
                                  {Nanprocessor(roundToTwo(Number(item?.Sch_Return5Yr)))} %
                                </Typography>
                              </Box>
                              <Box sx={{ display: 'flex', flexDirection: 'column', width: { xs: "28%", sm: '20%' }, gap: "0.4rem" }}>
                                <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: '#5a7c82', fontWeight: 400, display: "flex" }}>Frequency </Typography>
                                <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: "#011E33", fontWeight: 500, display: "flex" }}>
                                  {item?.Frequency}
                                </Typography>
                              </Box>
                              {item?.Frequency !== 'DAILY' && <Box sx={{ display: 'flex', flexDirection: 'column', width: { xs: "35%", sm: '20%' }, gap: "0.4rem" }}>
                                <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: '#5a7c82', fontWeight: 400, display: "flex" }}>No. of Instalments </Typography>
                                <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: "#011E33", fontWeight: 500, display: "flex" }}>
                                  {item?.No_of_Installments}
                                </Typography>
                              </Box>}

                              <Box sx={{ display: 'flex', flexDirection: 'column', width: { xs: "30%", sm: '20%' }, gap: "0.4rem", mt: { xs: "0.4rem", sm: "0rem" } }}>
                                <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: '#5a7c82', fontWeight: 400, display: "flex" }}>SIP Date </Typography>
                                <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: "#011E33", fontWeight: 500, display: "flex" }}>
                                  {convertDate(item?.SIP_date.split('T')[0])}
                                </Typography>
                              </Box>
                              {item?.Folio === '' ?
                                <Box sx={{ display: 'flex', flexDirection: 'column', width: { xs: "50%", sm: '20%' }, mt: { xs: "0.4rem", sm: "0rem" } }}>
                                  <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: '#5a7c82', fontWeight: 400, display: "flex" }}>Account Name </Typography>
                                  <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: "#011E33", fontWeight: 500, display: "flex" }}>{item?.AccountType == "NA" ? "NA" : item?.AccountType?.split("$")[1]}</Typography>
                                </Box> :
                                <Box sx={{ display: 'flex', flexDirection: 'column', width: { xs: "30%", sm: '20%' }, mt: { xs: "0.3rem", sm: "0rem" } }}>
                                  <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: '#5a7c82', fontWeight: 400, display: "flex" }}>Folio </Typography>
                                  <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: "#011E33", fontWeight: 500, display: "flex" }}> {item?.Folio}</Typography>
                                </Box>
                              }
                            </Box>

                            :

                            <Box sx={{ display: "flex", flexDirection: 'row', px: { xs: 0, sm: 3.5 }, py: { xs: 0, sm: 2 }, mx: { xs: 1, sm: 0 }, flexWrap: "wrap" }}>
                              <Box sx={{ display: 'flex', flexDirection: 'column', width: { xs: "35%", sm: '15%' }, gap: "0.4rem" }}>
                                <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: '#5a7c82', fontWeight: 400 }}>Returns</Typography>
                                <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: "#27976F", fontWeight: 500 }}>
                                  {/* {item?.Aum === "0" || !item?.Aum
                                            ? "NA"
                                            : `₹${currencyConverter(fundItem.Aum)}`} */}
                                  {Nanprocessor(roundToTwo(Number(item?.Sch_Return5Yr)))} %
                                </Typography>
                              </Box>
                              {item?.Folio === '' ?
                                <Box sx={{ display: 'flex', flexDirection: 'column', width: { xs: "50%", sm: '30%' }, mt: { xs: "0.3rem", sm: "0rem" } }}>
                                  <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: '#5a7c82', fontWeight: 400, display: "flex" }}>Account Name </Typography>
                                  <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: "#011E33", fontWeight: 500, display: "flex" }}>{item?.AccountType == "NA" ? "NA" : item?.AccountType?.split("$")[1]}</Typography>
                                </Box> :
                                <Box sx={{ display: 'flex', flexDirection: 'column', width: { xs: "30%", sm: '20%' }, mt: { xs: "0.3rem", sm: "0rem" } }}>
                                  <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: '#5a7c82', fontWeight: 400, display: "flex" }}>Folio </Typography>
                                  <Typography sx={{ fontSize: { xs: 11, sm: 12.5 }, color: "#011E33", fontWeight: 500, display: "flex" }}> {item?.Folio}</Typography>
                                </Box>
                              }
                            </Box>
                          }
                        </Collapse>
                        <Divider />
                      </Box>
                    </Box>
                  })}
                </div>
                {groupedSchemes[0]?.Expirystatus === "Active" && 
                <Button sx={{ "&.MuiButtonBase-root:hover": { bgcolor: "#163869" }, bgcolor: "#163869", color: "white", p: "0.2rem 2.5rem", position: "relative", left: "50%", bottom: "0%", transform: "translate(-50%,0%)", mt: 2, width: "15rem" }} onClick={() => { handleSubmit(groupedSchemes); setLoading(true) }}>
                  {loading ? <Box sx={{ display: 'flex' }}>
                    <CircularProgress style={{ color: "white" }} size="1.8rem" />
                  </Box> :
                    "Place Order"}
                </Button>
                }
              </Box>
            </Modal>
          </Box>
        }
        <Dialog
          open={openDialog}
          onClose={() => {
            setFailedOrderList([])
            setSuccessOrderList([])
            setOpenDialog(false)
          }}
          aria-labelledby="alert-dialog-title"
          aria-describedby="alert-dialog-description"
          fullWidth
          maxWidth="md"
          sx={{ height: { xs: "30rem", sm: "auto" }, margin: "auto" }}
        >
          <DialogContent>
            {failedOrderList.map((value: any, index: any) => {
              return <Box key={index} sx={{ display: 'flex', flexDirection: { xs: "column", sm: "row" }, justifyContent: 'space-between', alignItems: 'center', cursor: 'pointer', my: { xs: 3, sm: 3.5 }, mx: { xs: 0, sm: 2 }, mb: 0, borderLeft: "10px solid red", borderRight: "10px solid red" }}>
                <Box sx={{ display: "flex", width: { xs: "100%" } }}>
                  <Box sx={{ display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center", width: "30%", }}>
                    <CancelOutlinedIcon fontSize="large" />
                    <Typography sx={{ color: "red", fontWeight: 600, fontSize: 12 }}>Failed</Typography>
                  </Box>
                  <Box sx={{ marginRight: { xs: 0, sm: 15 }, display: 'flex', flexDirection: 'column', justifyContent: "center", width: { xs: "100%", sm: "50%" }, ml: "2rem" }}>
                    <Typography sx={{ fontSize: { xs: 12, sm: 14 }, fontWeight: 500, mb: 0.5, mr: { xs: 1, sm: 0 } }}>
                      {value.name}
                    </Typography>
                    <Box sx={{ display: 'flex', mt: { xs: 1, sm: 2 }, flexWrap: "wrap" }}>
                      <Bubble text={value.AssetClassName} />
                      <Bubble text={value.Sub_AssetclassName} />
                      <Bubble text={value.Schemeoption.charAt(0).toUpperCase() + value.Schemeoption.substr(1).toLowerCase()} />
                    </Box>
                  </Box>
                </Box>
                <Box sx={{ width: { xs: "100%", sm: "50%" }, display: 'flex', flexDirection: { xs: "row", sm: 'column' }, alignItems: 'center', justifyContent: "center", mr: { xs: 0, sm: 4 }, ml: { xs: 1, sm: 0 } }}>
                  <Typography sx={{ fontSize: { xs: 11, sm: 13 }, color: '#011E33', fontWeight: 400, mt: { xs: 2, sm: 0 } }}>Failure Reason</Typography>
                  <Typography sx={{ fontSize: { xs: 10, sm: 13 }, color: "#011E33", fontWeight: 500, mt: 1 }}>
                    {value.failure_reason.substring(7)}
                  </Typography>
                </Box>
              </Box>
            })}

            {successOrderList.map((value: any, index: any) => {
              return <Box key={index} sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', cursor: 'pointer', my: 2.5, mx: { xs: 0, sm: 2 }, borderLeft: "10px solid green", borderRight: "10px solid green" }}>
                <Box sx={{ display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center", width: "30%", }}>
                  <CheckCircleOutlineOutlinedIcon fontSize="large" />
                  <Typography sx={{ color: "green", fontWeight: 600, fontSize: 12 }}>Success</Typography>
                </Box>
                <Box sx={{ marginRight: { xs: 0, sm: 15 }, display: 'flex', flexDirection: 'column', justifyContent: "center", width: { xs: "100%", sm: "45%" }, ml: "2rem" }}>
                  <Typography sx={{ fontSize: { xs: 12, sm: 14 }, fontWeight: 500, mb: 0.5 }}>
                    {value.name}
                  </Typography>
                  <Box sx={{ display: 'flex', mt: { xs: 1, sm: 2 }, flexWrap: "wrap" }}>
                    <Bubble text={value.AssetClassName} />
                    <Bubble text={value.Sub_AssetclassName} />
                    <Bubble text={value.Schemeoption.charAt(0).toUpperCase() + value.Schemeoption.substr(1).toLowerCase()} />
                  </Box>
                </Box>
                <Box sx={{ width: "50%", display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                </Box>
              </Box>
            })}
          </DialogContent>

          <DialogActions>
            <Button onClick={() => {
              setFailedOrderList([])
              setSuccessOrderList([])
              setOpenDialog(false)
            }}>Ok</Button>
          </DialogActions>
        </Dialog>
      </>}

    {/* Component for add to cart drawer - this is the drawer that opens when invest now is clicked */}
    {(addToCartAnchorsEl && investScheme != undefined) && (
      (value == "Add" || value == "New") ?
        //This drawer is used only for new and additional purchase tab as it can add to cart only SIP and lumpsum
        <AddToCartDrawer
          anchorEl={addToCartAnchorsEl}
          handleClose={handleAddToCartAnchorsElClose}
          schemeName={`${investScheme?.SchemeName}`}
          recommendedSchemeData={investScheme}
          recommendedDate={investScheme?.EntryDate}
          type={value}
          tab={subVal}
          AmcID={investScheme?.AmcID}
        /> :
        //This drawer is used for STP/SWP/Switch/Redeem
        <AddToCartRecommendation
          anchorEl={addToCartAnchorsEl}
          handleClose={handleAddToCartAnchorsElClose}
          schemeName={`${investScheme?.SchemeName}`}
          recommendedSchemeData={investScheme}
          recommendedDate={investScheme?.EntryDate}
          tabName={value}
        />
    )}
  </>)
}