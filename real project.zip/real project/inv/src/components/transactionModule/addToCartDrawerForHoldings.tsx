import { Box, CardMedia, Divider, Drawer, IconButton, Tab, Typography } from "@mui/material";
import { memo, useState } from "react";
import { TabContext, TabList, TabPanel } from "@mui/lab";
import { PortfolioType } from "./transaction.context";
import './styles.css';
import { bseCodePayload, createTransactionPayload } from "./investor-transaction-helper";
import { Lumpsum_Form, Redeemtion_Form, SIP_Form, STP_Form, SWP_Form, SWT_Form } from "./addToCartForms";
import { CloseIcon } from "../customSVGs";
import Swal from "sweetalert2";
import { useLoginContext } from "../login/data/login.context";
import { useNavigate } from 'react-router';

export const AddToCartHoldings = memo(({
    anchorEl,
    handleClose,
    schemeName,
    selectedSchemeData,
    getBSECode,
    createTransaction,

}: { anchorEl: boolean; handleClose: () => void; schemeName: string, selectedSchemeData: PortfolioType, getBSECode: (requestOptions: bseCodePayload) => Promise<any>, createTransaction: (requestOptions: createTransactionPayload) => Promise<any> }): JSX.Element => {
    const [modalState, setModalState] = useState(false);
    const [value, setValue] = useState<string>('sip');
    const navigate=useNavigate();
    const { getCartCount } = useLoginContext();
    const [schemeParams, setSchemeParams] = useState<any>({
        SchemeID: selectedSchemeData?.productid ? Number(selectedSchemeData.productid) : 0,
        SchemeName: schemeName,
        ToSchemeName: "",
        ToSchemeID: "",
        AUM: selectedSchemeData?.AUM ? selectedSchemeData.AUM : null,
        Units: selectedSchemeData?.Units ? selectedSchemeData.Units : null,
        Sch_Return5Yr: "",
        minPurchase: selectedSchemeData.MinimumPurchaseAmount,
        maxPurchase: selectedSchemeData.MaximumPurchaseAmount,
        instalmentAmount: "",
        invAmount: "",
        error: false,
        errorInstalment: false,
        errorSIPDay: false,
        errorSIPFrequency: false,
        errorInstalmentAmount: false,
        errorMessage: "",
        errorMessageInstalment: "",
        errorMessageSIPDay: "",
        errorMessageSIPFrequency: "",
        errorMessageInstalmentAmount: "",
        // AssetClassName: selectedSchemeData?.AssetClassName ? selectedSchemeData.AssetClassName : "",
        // Sub_AssetclassName: selectedSchemeData?.Sub_AssetclassName ? selectedSchemeData.Sub_AssetclassName : "",
        // Dividendfrequency: selectedSchemeData?.Dividendfrequency ? selectedSchemeData.Dividendfrequency : "",selected
        // Growthoption: selectedSchemeData?.Growthoption ? selectedSchemeData?.Growthoption : 0,
        Dividendreinvestment: selectedSchemeData?.DividendReinvestment ? selectedSchemeData.DividendReinvestment : 0,
        // DividendPayout: selectedSchemeData?.DividendPayout ? selectedSchemeData.DividendPayout : 0,
        instalments: "",
        SIPDay: "",
        STPDay: "",
        SWPDay: "",
        mandate: "",
        sipFrequency: "",
        stpFrequency: "",
        swpFrequency: "",
        switchValue: { value: "", type: "INR" },
        switchType: "Partial",
        redeemValue: { value: "", type: "INR" },
        redeemType: "Partial",
        // frequency: SchemeData && 'Frequency' in SchemeData ? (SchemeData?.Frequency).toUpperCase() : "",
        SCh: selectedSchemeData?.SCh ? selectedSchemeData.SCh : "",
    });

    const _handleModalState = () => {
        handleClose();
        setModalState(modalState);
    };

    const handleChange = (event: any, value: any) => {
        setValue(value);
        setSchemeParams({
            ...schemeParams,
            SchemeName: "",
            ToSchemeName: "",
            Sch_Return5Yr: "",
            minPurchase: selectedSchemeData.MinimumPurchaseAmount,
            maxPurchase: selectedSchemeData.MaximumPurchaseAmount,
            instalmentAmount: "",
            invAmount: "",
            error: false,
            errorInstalment: false,
            errorSIPDay: false,
            errorSIPFrequency: false,
            errorInstalmentAmount: false,
            errorMessage: "",
            errorMessageInstalment: "",
            errorMessageSIPDay: "",
            errorMessageSIPFrequency: "",
            errorMessageInstalmentAmount: "",
            Dividendreinvestment: "",
            instalments: "",
            SIPDay: "",
            STPDay: "",
            SWPDay: "",
            mandate: "",
            sipFrequency: "",
            stpFrequency: "",
            swpFrequency: "",
            switchValue: { value: "", type: "INR" },
            switchType: "Partial",
            redeemValue: { value: "", type: "INR" },
            redeemType: "Partial",
            SCh: "",
        });
    }


    const handleSubmit = (payload: any) => {
        createTransaction(payload).then((response) => {
            if (response.transaction_created != "" && response.transaction_created != null) {
                getCartCount();
                handleClose();
                Swal.fire({
                  title: "Added to cart!!",
                  icon: "success",
                  customClass: {
                    confirmButton: 'sweet-alert-button'
                  }
                }).then(()=>{
                    navigate("/cart",{state:{"value":payload.TrType,"subValue":value}});
                });
            }
        })
    }

    return (
        <Box>
            <Drawer anchor={'right'} open={anchorEl} onClose={_handleModalState} sx={{ overflowX: "hidden", }}>
                <Box sx={{ width: { xs: "100%", sm: '500px', } }}>
                    <Box sx={{ display: "flex", justifyContent: 'space-between', alignItems: 'center', px: '1rem', py: '1rem', width: { xs: "100vw", sm: "100%" }, position: "sticky", top: 0, zIndex: 10, bgcolor: "white" }}>
                        <Box sx={{ display: 'flex', alignItems: 'center' }}>
                            <span style={{ width: '12px', height: '12px', borderRadius: '50%', marginRight: '0.8rem', backgroundColor: '#1EB1F3' }}></span>
                            <Typography sx={{ fontSize: 18, fontWeight: 500 }}>{schemeName}</Typography>
                        </Box>
                        <Box sx={{ cursor: 'pointer' }} onClick={handleClose} >
                            <CloseIcon />
                        </Box>
                    </Box>

                    <Divider />
                    <Box
                        sx={{
                            width: '100%',
                            '& .MuiTabPanel-root': {
                                py: 2,
                                px: 0
                            },
                            '& .MuiTab-root': {
                                color: '#A1A2A2',
                                opacity: 0.8,
                                fontSize: { xs: 11, sm: 14 },
                                lineHeight: '18px',
                                textTransform: 'capitalize',
                                px: { xs: 0, md: 2, lg: 4 },
                                // mx:{xs:0,sm:2},
                                minWidth: { xs: "3rem", sm: "5rem" },
                                '&.Mui-selected': {
                                    color: '#1EB1F3',
                                    border: 'none'
                                },
                            },
                            ' & .MuiTab': {
                                backgroundColor: 'yellow'
                            },
                            '& .MuiTabs-indicator': {
                                height: 2,
                                background: '#1EB1F3'
                            },
                            '& .MuiButtonBase-root': {
                                p: 0,
                            },
                            '& .MuiTabs-flexContainer': {
                                display: "flex",
                                justifyContent: "space-between",
                                width: "100%",
                                // flexWrap: "wrap",
                                py: 0,
                            }
                        }}>
                        <TabContext value={value} >
                            <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
                                <TabList

                                    onChange={handleChange}>
                                    <Tab label="SIP" value="sip" />
                                    <Tab label="Lumpsum" value="lumpsum" />
                                    <Tab label="STP" value="STP" />
                                    <Tab label="SWP" value="SWP" />
                                    <Tab label="Switch" value="Switch" />
                                    <Tab label="Redeem" value="Redeem" />

                                </TabList>
                            </Box>
                            
                            <TabPanel value="sip">
                                <SIP_Form
                                    schemeParams={schemeParams}
                                    setSchemeParams={setSchemeParams}
                                    selectedSchemeData={selectedSchemeData as PortfolioType}
                                    addSchemeToCart={(payload) => {
                                        handleSubmit(payload)
                                    }}
                                    getBSECode={getBSECode}
                                />
                            </TabPanel>


                            <TabPanel value="lumpsum">
                                <Lumpsum_Form
                                    schemeParams={schemeParams}
                                    setSchemeParams={setSchemeParams}
                                    selectedSchemeData={selectedSchemeData as PortfolioType}
                                    addSchemeToCart={(payload) => {
                                        handleSubmit(payload)
                                    }}
                                    getBSECode={getBSECode}
                                />
                            </TabPanel>

                            <TabPanel value="STP">
                                <STP_Form
                                    schemeParams={schemeParams}
                                    setSchemeParams={setSchemeParams}
                                    selectedSchemeData={selectedSchemeData as PortfolioType}
                                    addSchemeToCart={(payload) => {
                                        handleSubmit(payload)
                                    }}
                                    getBSECode={getBSECode}
                                />
                            </TabPanel>

                            <TabPanel value="SWP">

                                <SWP_Form
                                    schemeParams={schemeParams}
                                    setSchemeParams={setSchemeParams}
                                    selectedSchemeData={selectedSchemeData as PortfolioType}
                                    addSchemeToCart={(payload) => {
                                        handleSubmit(payload)
                                    }}
                                    getBSECode={getBSECode}
                                />

                            </TabPanel>


                            <TabPanel value="Switch">
                                <SWT_Form
                                    schemeParams={schemeParams}
                                    setSchemeParams={setSchemeParams}
                                    selectedSchemeData={selectedSchemeData as PortfolioType}
                                    addSchemeToCart={(payload) => {
                                        handleSubmit(payload)
                                    }}
                                    getBSECode={getBSECode}
                                />
                            </TabPanel>


                            <TabPanel value="Redeem">

                                <Redeemtion_Form
                                    schemeParams={schemeParams}
                                    setSchemeParams={setSchemeParams}
                                    selectedSchemeData={selectedSchemeData as PortfolioType}
                                    addSchemeToCart={(payload) => {
                                        handleSubmit(payload)
                                    }}
                                    getBSECode={getBSECode}
                                />

                            </TabPanel>

                        </TabContext>
                    </Box>
                </Box>
            </Drawer >
        </Box >
    )
})