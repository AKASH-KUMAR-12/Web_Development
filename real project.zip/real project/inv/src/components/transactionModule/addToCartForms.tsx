import { Box, Button, Checkbox, CircularProgress, FormControl, FormControlLabel, FormLabel, MenuItem, OutlinedInput, Radio, RadioGroup, Select, Typography } from "@mui/material";
import { useEffect, useState } from "react";
import { AssetclassMapping, errorStateLumpsumInitialData, errorStateRedeemInitialData, errorStateSIPInitialData, errorStateSTPInitialData, errorStateSWPInitialData, errorStateSWTInitialData, errorStatesLumpsum, errorStatesRedeem, errorStatesSIP, errorStatesSTP, errorStatesSWP, errorStatesSWT, frequencyMapping, schemParams_Holdings } from "./transactionType";
import { PortfolioType, ValidationForSIP, redeemValidationType, useGetTotalData } from "./transaction.context";
import { useNavigate } from 'react-router';
import { bseCodePayload } from "./investor-transaction-helper";
import { SchemeType } from "../../api/transaction";
import DatePicker, { registerLocale } from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';

export const SIP_Form = (
    { schemeParams,
        setSchemeParams,
        selectedSchemeData,
        addSchemeToCart,
        getBSECode
    }:
        {
            schemeParams: schemParams_Holdings,
            setSchemeParams: React.Dispatch<React.SetStateAction<schemParams_Holdings>>,
            selectedSchemeData: PortfolioType,
            addSchemeToCart: (payload: any) => void,
            getBSECode: (requestOptions: bseCodePayload) => Promise<any>
        }
) => {

    const navigate = useNavigate();

    //state variables
    const { validation, getValidationDetails, getclientmandateIdsDetails } = useGetTotalData();
    const [schemeValidation, setSchemeValidation] = useState<ValidationForSIP[]>();
    const [selectedFrquencyValidations, SetSelectedFrquencyValidations] = useState<ValidationForSIP | undefined>();
    const [mandateselect, setMandateselect] = useState<string>('');
    const [mandateIDs, setMandateIDs] = useState<any>();
    const [checked, setChecked] = useState(false);
    const [error, setError] = useState<errorStatesSIP>(errorStateSIPInitialData);
    const [selectedDate, setSelectedDate] = useState<Date | null>(null);
    const [loading, setLoading] = useState(false);

    //To set validation data in local state variable
    useEffect(() => {
        setSchemeValidation(validation);
    }, [validation, selectedSchemeData])

    //To fetch Validation data
    useEffect(() => {
        try {
            if (selectedSchemeData && selectedSchemeData.SCh) {
                getValidationDetails({ sch: selectedSchemeData.SCh, TrType: "SIP" });
            } else {
                console.log("recommendedSchemeData or recommendedSchemeData.Sch is undefined");
            }
        } catch (error) {
            console.error("Error ", error);
        }
    }, [selectedSchemeData]);

    useEffect(() => {
        (async function () {
            try {
                let mandateIds_reponse: any = await getclientmandateIdsDetails()
                console.log("mandateIds_reponse value", mandateIds_reponse[0])
                setMandateIDs(mandateIds_reponse[0])

            } catch (e) {
                console.error(e);
            }
        })();
    }, [])

    const changeValidationsOnFrequencyChange = (FrequencyVal: any) => {
        SetSelectedFrquencyValidations(schemeValidation?.filter((item: any) => item.SIPFREQUENCY === FrequencyVal)[0]);
    }

    const isDateDisabled = (date: Date): boolean => {

        const currentDate = new Date();
        currentDate.setHours(0, 0, 0, 0);
        if (date < currentDate) {
            return false;
        }

        let foundValue: any = schemeValidation?.find((val: any) => val.SIPFREQUENCY == schemeParams.sipFrequency);
        let datesArray: any = foundValue?.SIPDATES.split(',');

        if (datesArray.includes(date.getDate().toString())) {
            return true;
        } else {
            return false;
        }
    };

    const handleSubmit = () => {
        if (!validateFormData()) {
            return;
        }
        else {
            setLoading(true);
        }
        let payload: any = {}
        getBSECode({
            "TrType": "XSIP",
            "Amount": schemeParams.instalmentAmount.toString(),
            "Growthoption": selectedSchemeData?.Growthoption,
            "DividendReinvestment": selectedSchemeData?.DividendReinvestment,
            "RTACODE": selectedSchemeData?.SCh
        }).then(({ bse_code }) => {
            payload = {
                "StartDate": schemeParams.SIPDay.split("-").reverse().join('/'),
                "Installments": schemeParams.instalments,
                "InstallmentsAmt": schemeParams.instalmentAmount.toString(),
                "MandateId": "",
                "MandateType": "",
                "FirstOrderToday": checked == true ? "Y" : "N",
                "Frequency": frequencyMapping[schemeParams.sipFrequency],
                "AmcId": selectedSchemeData?.AmcID,
                "Sch": selectedSchemeData?.SCh,
                "TrType": "XSIP",
                "Growthoption": selectedSchemeData?.Growthoption,
                "DividendReinvestment": selectedSchemeData?.DividendReinvestment,
                "BSE_SchemeCode": bse_code[0][0].BSE_ProductCod,
                "RecId": 0,
                "AccNo": selectedSchemeData?.I_Accno
            }
            addSchemeToCart(payload);
        })
    }

    //This function validates the values entered in the form
    const validateFormData = () => {

        let valid = true;

        if (schemeParams.sipFrequency == null || schemeParams.sipFrequency === "") {
            if (schemeParams.sipFrequency == null || schemeParams.sipFrequency === "") {
                setError((prevParams) => ({ ...prevParams, errorSIPFrequency: true, errorSIPFrequencyMsg: "Frequency can not be empty" }));
                valid = false;
            }
            else {
                setError((prevParams) => ({ ...prevParams, errorSIPFrequency: false }));
            }
            return valid;
        }
        if (!(schemeParams.sipFrequency == null || schemeParams.sipFrequency === "")) {
            setError((prevParams) => ({ ...prevParams, errorSIPFrequency: false }));
            if (schemeParams.instalmentAmount === null || Number(schemeParams.instalmentAmount) === 0) {
                setError((prevParams) => ({ ...prevParams, errorSIPAmount: true, errorSIPAmountMsg: "Instalment Amount can not be empty" }));
                valid = false;
            }
            else if (schemeParams.instalmentAmount && (Number(schemeParams.instalmentAmount) < Number(selectedFrquencyValidations?.SIPMINIMUMINSTALLMENTAMOUNT) || Number(schemeParams.instalmentAmount) > Number(selectedFrquencyValidations?.SIPMAXIMUMINSTALLMENTAMOUNT))) {
                setError((prevParams) => ({
                    ...prevParams,
                    errorSIPAmount: true,
                    errorSIPAmountMsg: `Please enter amount greater than ${selectedFrquencyValidations?.SIPMINIMUMINSTALLMENTAMOUNT} or less than ${selectedFrquencyValidations?.SIPMAXIMUMINSTALLMENTAMOUNT}`
                }));
                valid = false;
            }
            else {
                setError((prevParams) => ({ ...prevParams, errorSIPAmount: false }));
            }

            if (schemeParams.instalments == null || Number(schemeParams.instalments) === 0) {
                setError((prevParams) => ({ ...prevParams, errorSIPNoOfInstalment: true, errorSIPNoOfInstalmentMsg: "No. of Instalments can not be empty" }));
                valid = false;
            }
            else if (schemeParams.instalments && (Number(schemeParams.instalments) < Number(selectedFrquencyValidations?.SIPMINIMUMINSTALLMENTNUMBERS) || Number(schemeParams.instalments) > Number(selectedFrquencyValidations?.SIPMAXIMUMINSTALLMENTNUMBERS))) {
                setError((prevParams) => ({
                    ...prevParams, errorSIPNoOfInstalment: true,
                    errorSIPNoOfInstalmentMsg: `Please enter amount greater than ${selectedFrquencyValidations?.SIPMINIMUMINSTALLMENTNUMBERS} or less than ${selectedFrquencyValidations?.SIPMAXIMUMINSTALLMENTNUMBERS}`
                }));
                valid = false;
            }
            else {
                setError((prevParams) => ({ ...prevParams, errorSIPNoOfInstalment: false }));
            }

            if (schemeParams.SIPDay == "") {
                setError((prevParams) => ({ ...prevParams, errorSIPDay: true, errorSIPDayMsg: "SIP Day can not be empty" }));
                valid = false;
            }
            else {
                setError((prevParams) => ({ ...prevParams, errorSIPDay: false }));
            }
        }

        return valid;
    }

    return (
        <Box sx={{ mx: { xs: 3, sm: 6 } }}>

            {/* Frequency */}
            <Box sx={{ my: 1.5 }}>
                <Typography>Frequency</Typography>
                <FormControl sx={{ width: "100%" }} >

                    <Select
                        labelId="demo-simple-select-label"
                        id="demo-simple-select"
                        value={schemeParams?.sipFrequency}
                        onChange={(e) => {
                            // setSipFrequency(e.target.value as string)
                            const objectToUpdate = schemeParams;
                            if (objectToUpdate) {
                                objectToUpdate.sipFrequency = e.target.value;
                                setSchemeParams(objectToUpdate);
                            }
                            // setSchemeParams({...schemeParams,sipFrequeny: e.target.value })
                            changeValidationsOnFrequencyChange(e.target.value);
                        }}
                        defaultValue={schemeParams?.sipFrequency}
                        inputProps={{ 'aria-label': 'Without label' }}
                    >
                        {schemeValidation?.map((item: any, index: any) => (
                            <MenuItem key={index} value={item.SIPFREQUENCY}>{item.SIPFREQUENCY}</MenuItem>
                        ))}
                    </Select>
                </FormControl>
                {error.errorSIPFrequency && <Typography sx={{ fontSize: 10, color: 'red', mb: 0.5 }}> {error.errorSIPFrequencyMsg} </Typography>}
            </Box>
            {(schemeParams.sipFrequency != "") ?

                <Box>
                    {/* // Mandate  */}
                    <Box>
                        <Typography>Mandates</Typography>

                        <FormControl sx={{ width: "100%", my: 1 }} >
                            <Select
                                labelId="demo-simple-select-label"
                                id="demo-simple-select"
                                value={mandateselect}

                                onChange={(e) => { setMandateselect((e.target.value) as string) }}
                                displayEmpty
                                inputProps={{ 'aria-label': 'Without label' }}
                            >
                                {mandateIDs?.map((data: any) => {
                                    return <MenuItem value={data.Details}>{data.Details}</MenuItem>
                                })}

                            </Select>
                        </FormControl>
                        {error.errorMandates && <Typography sx={{ fontSize: 10, color: 'red', mb: 0.5 }}> {error.errorMandateMsg} </Typography>}

                        <Typography>
                            <span>Not available ? </span>
                            <a onClick={() => navigate('/add-mandate')} style={{ cursor: "pointer", color: "#0090FF" }}>Add Mandate</a>
                        </Typography>
                    </Box>
                    {/* SIP Day */}
                    <Box sx={{ my: 1.5, }}>
                        <Typography>SIP Day</Typography>
                        <DatePicker
                            className="custom-datepicker"
                            // ref={datePickerRef}
                            selected={selectedDate}
                            onChange={(date: Date) => {
                                setSelectedDate(date)
                                const mapToDoubleDigit = (number: number): string => {
                                    return number < 9 ? `0${number + 1}` : `${number + 1}`;
                                };
                                const mapDayToDoubleDigit = (number: any): string => {
                                    return number <= 9 ? `0${number}` : `${number}`;
                                };
                                setSchemeParams((prevParams) => ({ ...prevParams, SIPDay: `${mapDayToDoubleDigit(date?.getDate())}/${mapToDoubleDigit(date?.getMonth())}/${date?.getFullYear()}` }));
                            }}
                            dateFormat="dd-MM-yyyy"
                            filterDate={isDateDisabled}
                            placeholderText={'dd-mm-yyyy'}
                        // customInput={<CustomInput />}

                        />
                        {error.errorSIPDay && <Typography sx={{ fontSize: 10, color: 'red', mb: 0.5 }}> {error.errorSIPDayMsg} </Typography>}
                    </Box>

                    {/* No. of installments */}
                    <Box sx={{ my: 1.5 }}>
                        <Typography>No. of Installments</Typography>
                        <input type="text" className='investmentAmount2' placeholder={`Enter Number ${selectedFrquencyValidations?.SIPMINIMUMINSTALLMENTNUMBERS} - ${selectedFrquencyValidations?.SIPMAXIMUMINSTALLMENTNUMBERS}`} value={schemeParams.instalments}
                            onChange={(e) => {
                                let newValue = e.target.value;

                                newValue = newValue.replace(/[^0-9]/g, '');

                                if (newValue.length < schemeParams.instalments.toString().length) {
                                    newValue = newValue.slice(0, -1);
                                }

                                setSchemeParams({ ...schemeParams, instalments: newValue });
                            }}
                        >
                        </input>
                        {error.errorSIPNoOfInstalment && <Typography sx={{ fontSize: 10, color: 'red', mb: 0.5 }}> {error.errorSIPNoOfInstalmentMsg} </Typography>}
                    </Box>

                    {/* First Order Today */}
                    <Box sx={{ display: 'flex', flexDirection: 'row', my: 1.5 }}>
                        <Checkbox
                            checked={checked}
                            onChange={(e) => { setChecked(!checked) }}
                            inputProps={{ 'aria-label': 'controlled' }}
                            sx={{ p: 0, m: 0 }}
                        />
                        <Typography sx={{ mx: 2 }} >First Order Today</Typography>

                    </Box>

                    {/* Amount */}
                    <Box sx={{ my: 1.5 }}>
                        <Typography>Amount <span style={{ fontSize: '12px', color: 'grey' }}> {`Minimum- ₹${selectedFrquencyValidations?.SIPMINIMUMINSTALLMENTAMOUNT}`}</span></Typography>
                        <input type="text" className='investmentAmount2' value={schemeParams?.instalmentAmount}
                            onChange={(e) => {
                                let newValue = e.target.value;

                                newValue = newValue.replace(/[^0-9]/g, '');

                                if (newValue.length < schemeParams.instalmentAmount.toString().length) {
                                    newValue = newValue.slice(0, -1);
                                }

                                setSchemeParams({ ...schemeParams, instalmentAmount: newValue });
                            }}>
                        </input>
                        {error.errorSIPAmount && <Typography sx={{ fontSize: 10, color: 'red', mb: 0.5 }}> {error.errorSIPAmountMsg} </Typography>}
                        <Box sx={{ display: 'flex', flexDirection: 'row', justifyContent: 'space-between', mt: 3 }}>
                            {[2000, 5000, 10000].map((item: any, index: number) =>
                                <Button key={index} sx={{ border: '0.5px solid #dfdfdf', color: '#dfdfdf', boxShadow: '0px 0px 0.5px 0.5px', height: '35px', borderRadius: '10px', width: '30%' }}
                                    onClick={() => {
                                        setSchemeParams({ ...schemeParams, instalmentAmount: Number(schemeParams.instalmentAmount) + item });
                                    }}
                                >+ {item}</Button>
                            )}
                        </Box>

                    </Box>
                </Box>
                : <></>}

            <Box sx={{ mt: 2 }}>
                <Typography sx={{ fontSize: '9px', color: 'green' }}>NOTE:</Typography>
                <Typography sx={{ fontSize: '9px', color: 'grey' }}>SIP: Systematic Investment Plan</Typography>
                <Typography sx={{ fontSize: '9px', color: 'grey' }}>Lumpsum: One time payment</Typography>
            </Box>
            <Box sx={{ display: 'flex', flexDirection: 'column', mt: 3 }}>
                <i style={{ fontSize: '11px', fontWeight: 500, justifyContent: 'center', width: '70%', margin: '0% 0% 0% 15%' }}>
                    By continuing, I agree with <span style={{ color: 'green' }}> Disclaimers</span> and <span style={{ color: 'green' }}> Terms and Conditions </span> of Kfin Technologies Limited
                </i>
                <Button sx={{ background: 'linear-gradient(90deg,  #36DAE9 ,#0090FF)', height: "2.5rem", width: "100%", color: '#ffffff', borderRadius: '8px', mt: 3 }} onClick={handleSubmit}>
                    {loading ? <Box sx={{ display: 'flex' }}>
                        <CircularProgress style={{ color: "white" }} size="1.8rem" />
                    </Box> :
                        "Add To Cart"}
                </Button>
            </Box>
        </Box>
    )
}

export const Lumpsum_Form = (
    { schemeParams,
        setSchemeParams,
        selectedSchemeData,
        addSchemeToCart,
        getBSECode
    }:
        {
            schemeParams: schemParams_Holdings,
            setSchemeParams: React.Dispatch<React.SetStateAction<schemParams_Holdings>>,
            selectedSchemeData: PortfolioType,
            addSchemeToCart: (payload: any) => void,
            getBSECode: (requestOptions: bseCodePayload) => Promise<any>
        }
) => {
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<errorStatesLumpsum>(errorStateLumpsumInitialData);
    // useEffect(() => {
    //     console.log("schemeParams-->", schemeParams);
    // }, [])

    const handleSubmit = () => {
        if (!validateFormData()) {
            return;
        }
        else {
            setLoading(true);
        }
        let payload: any = {}
        getBSECode({
            "TrType": "Add",
            "Amount": schemeParams.invAmount.toString(),
            "Growthoption": selectedSchemeData?.Growthoption,
            "DividendReinvestment": selectedSchemeData?.DividendReinvestment,
            "RTACODE": selectedSchemeData?.SCh
        }).then(({ bse_code }) => {
            payload = {
                "RecId": 0,
                "AccNo": selectedSchemeData?.I_Accno,
                "AmcId": selectedSchemeData?.AmcID,
                "Amount": schemeParams.invAmount.toString(),
                "BSE_SchemeCode": bse_code[0][0]?.BSE_ProductCod,
                "DividendReinvestment": selectedSchemeData?.DividendReinvestment,
                "Growthoption": selectedSchemeData.Growthoption,
                "Sch": selectedSchemeData?.SCh,
                "TrType": "Add"
            }
            addSchemeToCart(payload);
        })
    }

    //This function validates the values entered in the form
    const validateFormData = () => {

        let valid = true;

        if (schemeParams.invAmount === null || Number(schemeParams.invAmount) === 0) {
            setError((prevParams) => ({ ...prevParams, errorLumpsumAmount: true, errorLumpsumAmountMsg: "Instalment Amount can not be empty" }));
            valid = false;
        }
        else if (schemeParams.invAmount && (Number(schemeParams.invAmount) < Number(schemeParams.minPurchase) || Number(schemeParams.instalmentAmount) > Number(schemeParams.maxPurchase))) {
            setError((prevParams) => ({
                ...prevParams,
                errorLumpsumAmount: true,
                errorLumpsumAmountMsg: `Please enter amount greater than ${schemeParams.minPurchase} or less than ${schemeParams.maxPurchase}`
            }));
            valid = false;
        }
        else {
            setError((prevParams) => ({ ...prevParams, errorLumpsumAmount: false }));
        }

        return valid;
    }

    return (
        <Box sx={{ mx: { xs: 3, sm: 6 } }}>
            {/* Amount */}
            <Box sx={{ my: 1.5 }}>
                <Typography>Amount <span style={{ fontSize: '12px', color: 'grey', }}> {`Minimum- ₹${schemeParams.minPurchase}`}</span></Typography>
                <input type="text" className='investmentAmount2' value={schemeParams?.invAmount}
                    onChange={(e) => {
                        let newValue = e.target.value;

                        newValue = newValue.replace(/[^0-9]/g, '');

                        if (newValue.length < schemeParams.invAmount.toString().length) {
                            newValue = newValue.slice(0, -1);
                        }

                        setSchemeParams({ ...schemeParams, invAmount: newValue });
                    }}>
                </input>
                {error.errorLumpsumAmount && <Typography sx={{ fontSize: 10, color: 'red', mb: 0.5 }}> {error.errorLumpsumAmountMsg} </Typography>}
                <Box sx={{ display: 'flex', flexDirection: 'row', justifyContent: 'space-between', mt: 3 }}>
                    {[2000, 5000, 10000].map((item: any, index: number) =>
                        <Button key={index} sx={{ border: '0.5px solid #dfdfdf', color: '#dfdfdf', boxShadow: '0px 0px 0.5px 0.5px', height: '35px', borderRadius: '10px', width: '30%' }}
                            onClick={() => {
                                setSchemeParams({ ...schemeParams, invAmount: Number(schemeParams.invAmount) + item });
                            }}
                        >+ {item}</Button>
                    )}
                </Box>

            </Box>
            <Box sx={{ mt: 2 }}>
                <Typography sx={{ fontSize: '9px', color: 'green' }}>NOTE:</Typography>
                <Typography sx={{ fontSize: '9px', color: 'grey' }}>SIP: Systematic Investment Plan</Typography>
                <Typography sx={{ fontSize: '9px', color: 'grey' }}>Lumpsum: One time payment</Typography>
            </Box>
            <Box sx={{ display: 'flex', flexDirection: 'column', mt: 3 }}>
                <i style={{ fontSize: '11px', fontWeight: 500, justifyContent: 'center', width: '70%', margin: '0% 0% 0% 15%' }}>
                    By continuing, I agree with <span style={{ color: 'green' }}> Disclaimers</span> and <span style={{ color: 'green' }}> Terms and Conditions </span> of Kfin Technologies Limited
                </i>
                <Button
                    sx={{
                        background: 'linear-gradient(90deg, #36DAE9, #0090FF)',
                        width: "100%",
                        height: "2.5rem",
                        color: '#ffffff',
                        borderRadius: '8px',
                        mt: 3
                    }}
                    onClick={handleSubmit}
                >
                    {loading ? <Box sx={{ display: 'flex' }}>
                        <CircularProgress style={{ color: "white" }} size="1.8rem" />
                    </Box> :
                        "Add To Cart"}
                </Button>
            </Box>
        </Box>
    )
}

export const STP_Form = (
    { schemeParams,
        setSchemeParams,
        selectedSchemeData,
        addSchemeToCart,
        getBSECode
    }:
        {
            schemeParams: schemParams_Holdings,
            setSchemeParams: React.Dispatch<React.SetStateAction<schemParams_Holdings>>,
            selectedSchemeData: PortfolioType,
            addSchemeToCart: (payload: any) => void,
            getBSECode: (requestOptions: bseCodePayload) => Promise<any>
        }
) => {

    const { schemeData, getSchemeData, getValidationDetails, validation, setSchemeData } = useGetTotalData();
    const [schemeValidation, setSchemeValidation] = useState<ValidationForSIP[]>();
    const [selectedFrquencyValidations, SetSelectedFrquencyValidations] = useState<ValidationForSIP | undefined>();
    const [error, setError] = useState<errorStatesSTP>(errorStateSTPInitialData);
    const [selectedAssetClass, setSelectedAssetClass] = useState<String>("");
    const [newSchemeSch, setNewSchemeSch] = useState<string>("");
    const [selectedDate, setSelectedDate] = useState<Date | null>(null);
    const [checked, setChecked] = useState(false);
    const [loading, setLoading] = useState(false);


    useEffect(() => {
        try {
            {selectedAssetClass!="" &&
            getSchemeData(
                {
                    "AstId": AssetclassMapping[selectedAssetClass as keyof typeof AssetclassMapping],
                    "AmcId": `${selectedSchemeData.AmcID}`
                }, "STPFLAG"
            )
        }
        {selectedAssetClass=="" && setSchemeData([])}
    }
        catch (error) {
            console.error("Error ", error);
        }
    }, [selectedAssetClass]);

    useEffect(() => {
        setSchemeValidation(validation);
    }, [validation, newSchemeSch, selectedSchemeData])

    useEffect(() => {
        try {
            if (newSchemeSch != "") {
                getValidationDetails({ sch: newSchemeSch, TrType: "STP" });

            } else {
                console.log("newSchemeSch is undefined");
            }
        } catch (error) {
            console.error("Error ", error);
        }
    }, [newSchemeSch, selectedSchemeData]);

    const changeValidationsOnFrequencyChange = (FrequencyVal: any) => {
        SetSelectedFrquencyValidations(schemeValidation?.filter((item: any) => item.SIPFREQUENCY === FrequencyVal)[0]);
    }

    const isDateDisabled = (date: Date): boolean => {

        const currentDate = new Date();
        currentDate.setHours(0, 0, 0, 0);
        if (date < currentDate) {
            return false;
        }

        let foundValue: any = schemeValidation?.find((val: any) => val.SIPFREQUENCY == schemeParams.stpFrequency);
        let datesArray: any = foundValue?.SIPDATES.split(',');

        if (datesArray.includes(date.getDate().toString())) {
            return true;
        } else {
            return false;
        }
    };


    const handleSubmit = () => {
        if (!validateFormData()) {
            return;
        }
        else {
            setLoading(true);
        }
        let payload: any = {}
        getBSECode({
            "TrType": "STP",
            "Amount": schemeParams.instalmentAmount.toString(),
            "Growthoption": selectedSchemeData?.Growthoption,
            "DividendReinvestment": selectedSchemeData?.DividendReinvestment,
            "RTACODE": selectedSchemeData?.SCh
        }).then(async ({ bse_code }) => {

            let response: any = await getBSECode({
                "TrType": "STP",
                "Amount": schemeParams?.instalmentAmount.toString(),
                "Growthoption": schemeParams.ToSchemeID.split('~')[1] === 'G' ? 1 : 2,
                "DividendReinvestment": schemeParams.ToSchemeID.split('~')[1] !== 'G' ? 1 : 2,
                "RTACODE": newSchemeSch
            })
            payload = {
                "RecId": 0,
                "AccNo": selectedSchemeData?.I_Accno,
                "AmcId": selectedSchemeData?.AmcID,
                "BSE_SchemeCode": bse_code[0][0]?.BSE_ProductCod,
                "DividendReinvestment": selectedSchemeData?.DividendReinvestment,
                // "EndDate": "15/08/2026",
                "FirstOrderToday": checked == true ? "Y" : "N",
                "Frequency": frequencyMapping[schemeParams.stpFrequency],
                "Growthoption": selectedSchemeData.Growthoption,
                "Installments": frequencyMapping[schemeParams.stpFrequency] == '1' ? '' : schemeParams?.instalments,
                "InstallmentsAmt": schemeParams?.instalmentAmount.toString(),
                "Sch": selectedSchemeData.SCh,
                "StartDate": schemeParams?.STPDay != null ? schemeParams?.STPDay.slice(0, 10).split("-").reverse().join('/') : new Date().toJSON().slice(0, 10).split("-").reverse().join('/'),
                "ToBSE_SchemeCode": response?.bse_code[0][0]?.BSE_ProductCod,
                "ToSch": newSchemeSch,
                "TrType": "STP",
                "TransTypeDate": new Date().toJSON().slice(0, 10).split("-").reverse().join('/')
            }

            addSchemeToCart(payload);
            setSelectedAssetClass("");
            setSchemeData([]);
        })
    }

    //This function validates the values entered in the form
    const validateFormData = () => {
        let valid = true;
        setError(errorStateSTPInitialData);
        //To scheme
        if (newSchemeSch === "" || newSchemeSch === undefined) {
            if (newSchemeSch === "" || newSchemeSch === undefined) {
                setError((prevParams) => ({ ...prevParams, errorToSchemeID: true, errorToSchemeIDMsg: "Please select any Scheme" }));
                valid = false;
            }
            else {
                setError((prevParams) => ({ ...prevParams, errorToSchemeID: false, errorToSchemeIDMsg: "Please select any Scheme" }));
            }
            return valid;
        }

        //STP frequency
        if (!(newSchemeSch === "" || newSchemeSch === undefined) && (schemeParams.stpFrequency === "" || schemeParams.stpFrequency === null)) {
            if (schemeParams.stpFrequency === "" || schemeParams.stpFrequency === null) {
                setError((prevParams) => ({ ...prevParams, errorFrequency: true, errorFrequencyMsg: "Frequency can not be empty" }));
                valid = false;
            }
            else {
                setError((prevParams) => ({ ...prevParams, errorFrequency: false, errorFrequencyMsg: "Frequency can not be empty" }));
            }
            return valid;
        }

        if (!(schemeParams.stpFrequency === "" || schemeParams.stpFrequency === null)) {
            //STP amount
            if (schemeParams.instalmentAmount === "" || schemeParams.instalmentAmount === "0") {
                setError((prevParams) => ({ ...prevParams, errorSTPAmount: true, errorSTPAmountMsg: "Amount can not be empty" }));
                valid = false;
            }
            else if (Number(schemeParams.instalmentAmount) < Number(selectedFrquencyValidations?.SIPMINIMUMINSTALLMENTAMOUNT) ||
                Number(schemeParams.instalmentAmount) > Number(selectedFrquencyValidations?.SIPMAXIMUMINSTALLMENTAMOUNT)) {
                setError((prevParams) => ({ ...prevParams, errorSTPAmount: true, errorSTPAmountMsg: `Please enter amount greater than ${selectedFrquencyValidations?.SIPMINIMUMINSTALLMENTAMOUNT} and less than ${selectedFrquencyValidations?.SIPMAXIMUMINSTALLMENTAMOUNT}` }));
                valid = false;
            }
            else {
                setError((prevParams) => ({ ...prevParams, errorSTPAmount: false }));
            }

            // STP installment
            if (schemeParams.instalments === "" || schemeParams.instalments === "0") {
                setError((prevParams) => ({ ...prevParams, errorSTPNoOfInstalment: true, errorSTPNoOfInstalmentMsg: "Number of installments can not be empty" }));
                valid = false;
            }
            else if (Number(schemeParams.instalments) < Number(selectedFrquencyValidations?.SIPMINIMUMINSTALLMENTNUMBERS) ||
                Number(schemeParams.instalments) > Number(selectedFrquencyValidations?.SIPMAXIMUMINSTALLMENTNUMBERS)) {
                setError((prevParams) => ({ ...prevParams, errorSTPNoOfInstalment: true, errorSTPNoOfInstalmentMsg: `Please enter number greater than ${selectedFrquencyValidations?.SIPMINIMUMINSTALLMENTNUMBERS} and less than ${selectedFrquencyValidations?.SIPMAXIMUMINSTALLMENTNUMBERS}` }));
                valid = false;
            }
            else {
                setError((prevParams) => ({ ...prevParams, errorSTPNoOfInstalment: false }));
            }

            //STP Day
            if (schemeParams.STPDay === null || schemeParams.STPDay === "") {
                setError((prevParams) => ({ ...prevParams, errorSTPDay: true, errorSTPDayMsg: "STP Date can not be empty" }));
                valid = false;
            }
            else {
                setError((prevParams) => ({ ...prevParams, errorSTPDay: false }));
            }
        }
        return valid;
    }

    return (
        <Box sx={{ mx: { xs: 3, sm: 6 } }}>
                <Box sx={{ my: 1.5 }}>
                    <Typography>Asset Class</Typography>
                    <FormControl sx={{ width: "100%" }} >

                        <Select
                            labelId="demo-simple-select-label"
                            id="demo-simple-select"
                            value={selectedAssetClass}
                            onChange={(e) => {
                                setSelectedAssetClass(e.target.value as string)
                            }}
                            inputProps={{ 'aria-label': 'Without label' }}
                        >
                            {Object.keys(AssetclassMapping).map((val: String, index: number) =>
                            (
                                <MenuItem
                                onClick={() => {
                                    setSelectedAssetClass(val);
                                }}
                                key={index}
                                    value={val.toString()}
                                >
                                    {val}
                                </MenuItem>
                            ))
                            }
                        </Select>
                    </FormControl>
                </Box>
                <Box sx={{ my: 1.5 }}>
                    <Typography>To Scheme</Typography>
                    <FormControl sx={{ width: "100%" }} >
                        <Select
                            labelId="demo-simple-select-label"
                            id="demo-simple-select"
                            value={schemeParams.ToSchemeName}
                            onChange={(e) => {
                                setSchemeParams({ ...schemeParams, ToSchemeName: e.target.value as string })
                            }}
                            defaultValue={schemeParams?.ToSchemeName}
                            inputProps={{ 'aria-label': 'Without label' }}
                        >
                            {schemeData?.map((val: SchemeType, index: any) =>
                            (              
                                <MenuItem
                                    onClick={() => {
                                        setNewSchemeSch(val.Productcode_RTA);
                                        const tempSchemeParams = schemeParams;
                                        tempSchemeParams.ToSchemeID = val.Sch_ID as string;
                                        setSchemeParams(tempSchemeParams);
                                    }}
                                    key={index}
                                    value={val.Sch_Desc}

                                >
                                    {val.Sch_Desc}
                                </MenuItem>
                            ))
                            }
                        </Select>
                    </FormControl>
                    {error.errorToSchemeID && <Typography sx={{ fontSize: 10, color: 'red', mb: 0.5 }}> {error.errorToSchemeIDMsg} </Typography>}
                </Box>

                {newSchemeSch &&
                    <Box sx={{ my: 1.5 }}>
                        <Typography>Frequency</Typography>
                        <FormControl sx={{ width: '100%' }} >

                            <Select
                                labelId="demo-simple-select-label"
                                id="demo-simple-select"
                                value={schemeParams?.stpFrequency}
                                onChange={(e) => {
                                    // setSipFrequency(e.target.value as string)
                                    const objectToUpdate = schemeParams;
                                    if (objectToUpdate) {
                                        objectToUpdate.stpFrequency = e.target.value;
                                        setSchemeParams(objectToUpdate);
                                    }
                                    changeValidationsOnFrequencyChange(e.target.value);
                                }}
                                defaultValue={schemeParams?.stpFrequency}
                                inputProps={{ 'aria-label': 'Without label' }}
                            >
                                {schemeValidation?.map((item: any, index: any) => (
                                    <MenuItem key={index} value={item.SIPFREQUENCY}>{item.SIPFREQUENCY}</MenuItem>
                                ))}
                            </Select>
                        </FormControl>
                        {error.errorFrequency && <Typography sx={{ fontSize: 10, color: 'red', mb: 0.5 }}> {error.errorFrequencyMsg} </Typography>}
                    </Box>
                }

                {schemeParams.stpFrequency !== "" ?
                    <>
                        {/* STP Day */}
                        <Box sx={{ my: 1.5 }}>
                            <Typography>STP Day</Typography>
                            <DatePicker
                                className="custom-datepicker"
                                // ref={datePickerRef}
                                selected={selectedDate}
                                onChange={(date: Date) => {
                                    setSelectedDate(date)
                                    const mapToDoubleDigit = (number: number): string => {
                                        return number < 9 ? `0${number + 1}` : `${number + 1}`;
                                    };
                                    const mapDayToDoubleDigit = (number: any): string => {
                                        return number <= 9 ? `0${number}` : `${number}`;
                                    };
                                    setSchemeParams((prevParams) => ({ ...prevParams, STPDay: `${mapDayToDoubleDigit(date?.getDate())}/${mapToDoubleDigit(date?.getMonth())}/${date?.getFullYear()}` }));
                                }}
                                dateFormat="dd-MM-yyyy"
                                filterDate={isDateDisabled}
                                placeholderText={'dd-mm-yyyy'}
                            // customInput={<CustomInput />}

                            />
                            {error.errorSTPDay && <Typography sx={{ fontSize: 10, color: 'red', mb: 0.5 }}> {error.errorSTPDayMsg} </Typography>}
                        </Box>

                        {/* No. of installments */}
                        <Box sx={{ my: 1.5 }}>
                            <Typography>No. of Installments</Typography>
                            <input type="text" className='investmentAmount2' placeholder={`Enter Number ${selectedFrquencyValidations?.SIPMINIMUMINSTALLMENTNUMBERS} - ${selectedFrquencyValidations?.SIPMAXIMUMINSTALLMENTNUMBERS}`} value={schemeParams.instalments}
                                onChange={(e) => {
                                    let newValue = e.target.value;

                                    newValue = newValue.replace(/[^0-9]/g, '');

                                    if (newValue.length < schemeParams.instalments.toString().length) {
                                        newValue = newValue.slice(0, -1);
                                    }

                                    setSchemeParams({ ...schemeParams, instalments: newValue });
                                }}
                            >
                            </input>
                            {error.errorSTPNoOfInstalment && <Typography sx={{ fontSize: 10, color: 'red', mb: 0.5 }}> {error.errorSTPNoOfInstalmentMsg} </Typography>}
                        </Box>

                        {/* First Order Today */}
                        <Box sx={{ display: 'flex', flexDirection: 'row', my: 1.5 }}>
                            <Checkbox
                                checked={checked}
                                onChange={(e) => { setChecked(!checked) }}
                                inputProps={{ 'aria-label': 'controlled' }}
                                sx={{ p: 0, m: 0 }}
                            />
                            <Typography sx={{ mx: 2 }} >First Order Today</Typography>

                        </Box>

                        {/* Amount */}
                        <Box sx={{ my: 1.5 }}>
                            <Typography>Monthly Amount <span style={{ fontSize: '12px', color: 'grey' }}> {`Minimum- ₹${selectedFrquencyValidations?.SIPMINIMUMINSTALLMENTAMOUNT}`}</span></Typography>
                            <input type="text" className='investmentAmount2' value={schemeParams?.instalmentAmount}
                                onChange={(e) => {
                                    let newValue = e.target.value;

                                    newValue = newValue.replace(/[^0-9]/g, '');

                                    if (newValue.length < schemeParams.instalmentAmount.toString().length) {
                                        newValue = newValue.slice(0, -1);
                                    }

                                    setSchemeParams({ ...schemeParams, instalmentAmount: newValue });
                                }}>
                            </input>
                            {error.errorSTPAmount && <Typography sx={{ fontSize: 10, color: 'red', mb: 0.5 }}> {error.errorSTPAmountMsg} </Typography>}
                        </Box>
                    </> :
                    <></>}
                <Button
                    sx={{
                        background: 'linear-gradient(90deg, #36DAE9, #0090FF)',
                        height: "2.5rem",
                        width: "100%",
                        color: '#ffffff',
                        borderRadius: '8px',
                        mt: 3
                    }}
                    onClick={handleSubmit}
                >
                    {loading ? <Box sx={{ display: 'flex' }}>
                        <CircularProgress style={{ color: "white" }} size="1.8rem" />
                    </Box> :
                        "Add To Cart"}
                </Button>
            </Box>
    )
}

export const SWP_Form = (
    { schemeParams,
        setSchemeParams,
        selectedSchemeData,
        addSchemeToCart,
        getBSECode
    }:
        {
            schemeParams: schemParams_Holdings,
            setSchemeParams: React.Dispatch<React.SetStateAction<schemParams_Holdings>>,
            selectedSchemeData: PortfolioType,
            addSchemeToCart: (payload: any) => void,
            getBSECode: (requestOptions: bseCodePayload) => Promise<any>
        }
) => {

    const { getValidationDetails, validation } = useGetTotalData();
    const [schemeValidation, setSchemeValidation] = useState<ValidationForSIP[]>();
    const [selectedFrquencyValidations, SetSelectedFrquencyValidations] = useState<ValidationForSIP | undefined>();
    const [error, setError] = useState<errorStatesSWP>(errorStateSWPInitialData);
    const [selectedDate, setSelectedDate] = useState<Date | null>(null);
    const [checked, setChecked] = useState(false);
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        setSchemeValidation(validation);
    }, [validation, selectedSchemeData])

    useEffect(() => {
        try {
            if (selectedSchemeData && selectedSchemeData.SCh) {
                getValidationDetails({ sch: selectedSchemeData.SCh, TrType: "SWP" });

            } else {
                console.log("selectedSchemeData or selectedSchemeData.SCh is undefined");
            }
        } catch (error) {
            console.error("Error ", error);
        }
    }, [selectedSchemeData]);

    const changeValidationsOnFrequencyChange = (FrequencyVal: any) => {
        SetSelectedFrquencyValidations(schemeValidation?.filter((item: any) => item.SIPFREQUENCY === FrequencyVal)[0]);
    }

    const isDateDisabled = (date: Date): boolean => {

        const currentDate = new Date();
        currentDate.setHours(0, 0, 0, 0);
        if (date < currentDate) {
            return false;
        }

        let foundValue: any = schemeValidation?.find((val: any) => val.SIPFREQUENCY == schemeParams.swpFrequency);
        let datesArray: any = foundValue?.SIPDATES.split(',');

        if (datesArray?.includes(date.getDate().toString())) {
            return true;
        } else {
            return false;
        }
    };

    const handleSubmit = () => {
        if (!validateFormData()) {
            return;
        }
        else {
            setLoading(true);
        }
        let payload: any = {}
        getBSECode({
            "TrType": "SWP",
            "Amount": schemeParams.instalmentAmount.toString(),
            "Growthoption": selectedSchemeData?.Growthoption,
            "DividendReinvestment": selectedSchemeData?.DividendReinvestment,
            "RTACODE": selectedSchemeData?.SCh
        }).then(async ({ bse_code }) => {

            payload = {
                "RecId": 0,
                "AccNo": selectedSchemeData?.I_Accno,
                "AmcId": selectedSchemeData?.AmcID,
                "BSE_SchemeCode": bse_code[0][0]?.BSE_ProductCod,
                "DividendReinvestment": selectedSchemeData?.DividendReinvestment,
                // "EndDate": "15/08/2026",
                "FParFul": "p",
                "FUnsAmt": "a",
                "FirstOrderToday": checked == true ? "Y" : "N",
                "Frequency": frequencyMapping[schemeParams.swpFrequency],
                "Growthoption": selectedSchemeData.Growthoption,
                "Installments": frequencyMapping[schemeParams.swpFrequency] == '1' ? '' : schemeParams?.instalments,
                "InstallmentsAmt": schemeParams?.instalmentAmount.toString(),
                "Sch": selectedSchemeData.SCh,
                "StartDate": schemeParams?.SWPDay != null ? schemeParams?.SWPDay.slice(0, 10).split("-").reverse().join('/') : new Date().toJSON().slice(0, 10).split("-").reverse().join('/'),
                "TrType": "SWP",
                "TransTypeDate": new Date().toJSON().slice(0, 10).split("-").reverse().join('/'),
                "Units": "0"
            }
            addSchemeToCart(payload);
        })
    }

    //This function validates the values entered in the form
    const validateFormData = () => {
        let valid = true;
        setError(errorStateSWPInitialData);

        //SWP frequency
        if (schemeParams.swpFrequency === "" || schemeParams.swpFrequency === null) {
            if (schemeParams.swpFrequency === "" || schemeParams.swpFrequency === null) {
                setError((prevParams) => ({ ...prevParams, errorFrequency: true, errorFrequencyMsg: "Frequency can not be empty" }));
                valid = false;
            }
            else {
                setError((prevParams) => ({ ...prevParams, errorFrequency: false, errorFrequencyMsg: "Frequency can not be empty" }));
            }
            return valid;
        }

        if (!(schemeParams.swpFrequency === "" || schemeParams.swpFrequency === null)) {
            //SWP amount
            if (schemeParams.instalmentAmount === "" || schemeParams.instalmentAmount === "0") {
                setError((prevParams) => ({ ...prevParams, errorSWPAmount: true, errorSWPAmountMsg: "Amount can not be empty" }));
                valid = false;
            }
            else if (Number(schemeParams.instalmentAmount) < Number(selectedFrquencyValidations?.SIPMINIMUMINSTALLMENTAMOUNT) ||
                Number(schemeParams.instalmentAmount) > Number(selectedFrquencyValidations?.SIPMAXIMUMINSTALLMENTAMOUNT)) {
                setError((prevParams) => ({ ...prevParams, errorSWPAmount: true, errorSWPAmountMsg: `Please enter amount greater than ${selectedFrquencyValidations?.SIPMINIMUMINSTALLMENTAMOUNT} and less than ${selectedFrquencyValidations?.SIPMAXIMUMINSTALLMENTAMOUNT}` }));
                valid = false;
            }
            else {
                setError((prevParams) => ({ ...prevParams, errorSWPAmount: false }));
            }

            // SWP installment
            if (schemeParams.instalments === "" || schemeParams.instalments === "0") {
                setError((prevParams) => ({ ...prevParams, errorSWPNoOfInstalment: true, errorSWPNoOfInstalmentMsg: "Number of installments can not be empty" }));
                valid = false;
            }
            else if (Number(schemeParams.instalments) < Number(selectedFrquencyValidations?.SIPMINIMUMINSTALLMENTNUMBERS) ||
                Number(schemeParams.instalments) > Number(selectedFrquencyValidations?.SIPMAXIMUMINSTALLMENTNUMBERS)) {
                setError((prevParams) => ({ ...prevParams, errorSWPNoOfInstalment: true, errorSWPNoOfInstalmentMsg: `Please enter number greater than ${selectedFrquencyValidations?.SIPMINIMUMINSTALLMENTNUMBERS} and less than ${selectedFrquencyValidations?.SIPMAXIMUMINSTALLMENTNUMBERS}` }));
                valid = false;
            }
            else {
                setError((prevParams) => ({ ...prevParams, errorSWPNoOfInstalment: false }));
            }

            //SWP Day
            if (schemeParams.SWPDay === null || schemeParams.SWPDay === "") {
                setError((prevParams) => ({ ...prevParams, errorSWPDay: true, errorSWPDayMsg: "SWP Date can not be empty" }));
                valid = false;
            }
            else {
                setError((prevParams) => ({ ...prevParams, errorSWPDay: false }));
            }
        }
        return valid;
    }

    return (
        <Box sx={{ mx: { xs: 3, sm: 6 } }}>
            <Box sx={{ my: 1.5 }}>
                <Typography>Frequency</Typography>
                <FormControl sx={{ width: '100%' }} >

                    <Select
                        labelId="demo-simple-select-label"
                        id="demo-simple-select"
                        value={schemeParams?.swpFrequency}
                        onChange={(e) => {
                            // setSipFrequency(e.target.value as string)
                            const objectToUpdate = schemeParams;
                            if (objectToUpdate) {
                                objectToUpdate.swpFrequency = e.target.value;
                                setSchemeParams(objectToUpdate);
                            }
                            changeValidationsOnFrequencyChange(e.target.value);
                        }}
                        defaultValue={schemeParams?.swpFrequency}
                        inputProps={{ 'aria-label': 'Without label' }}
                    >
                        {schemeValidation?.map((item: any, index: any) => (
                            <MenuItem key={index} value={item.SIPFREQUENCY}>{item.SIPFREQUENCY}</MenuItem>
                        ))}
                    </Select>
                </FormControl>
                {error.errorFrequency && <Typography sx={{ fontSize: 10, color: 'red', mb: 0.5 }}> {error.errorFrequencyMsg} </Typography>}
            </Box>

            {schemeParams.swpFrequency !== "" ?
                <>
                    {/* SWP Day */}
                    <Box sx={{ my: 1.5 }}>
                        <Typography>SWP Day</Typography>
                        <DatePicker
                            className="custom-datepicker"
                            // ref={datePickerRef}
                            selected={selectedDate}
                            onChange={(date: Date) => {
                                setSelectedDate(date)
                                const mapToDoubleDigit = (number: number): string => {
                                    return number < 9 ? `0${number + 1}` : `${number + 1}`;
                                };
                                const mapDayToDoubleDigit = (number: any): string => {
                                    return number <= 9 ? `0${number}` : `${number}`;
                                };
                                setSchemeParams((prevParams) => ({ ...prevParams, SWPDay: `${mapDayToDoubleDigit(date?.getDate())}/${mapToDoubleDigit(date?.getMonth())}/${date?.getFullYear()}` }));
                            }}
                            dateFormat="dd-MM-yyyy"
                            filterDate={isDateDisabled}
                            placeholderText={'dd-mm-yyyy'}
                        // customInput={<CustomInput />}

                        />
                        {error.errorSWPDay && <Typography sx={{ fontSize: 10, color: 'red', mb: 0.5 }}> {error.errorSWPDayMsg} </Typography>}
                    </Box>

                    {/* No. of installments */}
                    <Box sx={{ my: 1.5 }}>
                        <Typography>No. of Installments</Typography>
                        <input type="text" className='investmentAmount2' placeholder={`Enter Number ${selectedFrquencyValidations?.SIPMINIMUMINSTALLMENTNUMBERS} - ${selectedFrquencyValidations?.SIPMAXIMUMINSTALLMENTNUMBERS}`}
                            value={schemeParams.instalments}
                            onChange={(e) => {
                                let newValue = e.target.value;

                                newValue = newValue.replace(/[^0-9]/g, '');

                                if (newValue.length < schemeParams.instalments.toString().length) {
                                    newValue = newValue.slice(0, -1);
                                }

                                setSchemeParams({ ...schemeParams, instalments: newValue });
                            }}
                        >
                        </input>
                        {error.errorSWPNoOfInstalment && <Typography sx={{ fontSize: 10, color: 'red', mb: 0.5 }}> {error.errorSWPNoOfInstalmentMsg} </Typography>}
                    </Box>

                    {/* First Order Today */}
                    <Box sx={{ display: 'flex', flexDirection: 'row', my: 1.5 }}>
                        <Checkbox
                            checked={checked}
                            onChange={(e) => { setChecked(!checked) }}
                            inputProps={{ 'aria-label': 'controlled' }}
                            sx={{ p: 0, m: 0 }}
                        />
                        <Typography sx={{ mx: 2 }} >First Order Today</Typography>

                    </Box>

                    {/* Amount */}
                    <Box sx={{ my: 1.5 }}>
                        <Typography>Monthly Amount <span style={{ fontSize: '12px', color: 'grey' }}> {`Minimum- ₹${selectedFrquencyValidations?.SIPMINIMUMINSTALLMENTAMOUNT}`}</span></Typography>
                        <input type="text" className='investmentAmount2' value={schemeParams?.instalmentAmount}
                            onChange={(e) => {
                                let newValue = e.target.value;

                                newValue = newValue.replace(/[^0-9]/g, '');

                                if (newValue.length < schemeParams.instalmentAmount.toString().length) {
                                    newValue = newValue.slice(0, -1);
                                }

                                setSchemeParams({ ...schemeParams, instalmentAmount: newValue });
                            }}>
                        </input>
                        {error.errorSWPAmount && <Typography sx={{ fontSize: 10, color: 'red', mb: 0.5 }}> {error.errorSWPAmountMsg} </Typography>}
                    </Box>
                </> :
                <></>}
            <Button
                sx={{
                    background: 'linear-gradient(90deg, #36DAE9, #0090FF)',
                    height: "2.5rem",
                    width: "100%",
                    color: '#ffffff',
                    borderRadius: '8px',
                    mt: 3
                }}
                onClick={handleSubmit}
            >
                {loading ? <Box sx={{ display: 'flex' }}>
                    <CircularProgress style={{ color: "white" }} size="1.8rem" />
                </Box> :
                    "Add To Cart"}
            </Button>


        </Box>
    )
}

export const SWT_Form = (
    { schemeParams,
        setSchemeParams,
        selectedSchemeData,
        addSchemeToCart,
        getBSECode
    }:
        {
            schemeParams: schemParams_Holdings,
            setSchemeParams: React.Dispatch<React.SetStateAction<schemParams_Holdings>>,
            selectedSchemeData: PortfolioType,
            addSchemeToCart: (payload: any) => void,
            getBSECode: (requestOptions: bseCodePayload) => Promise<any>
        }
) => {

    const { schemeData, getSchemeData, redeemValidation, redemptionValidation,setSchemeData } = useGetTotalData();
    const [error, setError] = useState<errorStatesSWT>(errorStateSWTInitialData);
    const [newSchemeSch, setNewSchemeSch] = useState<string>("");
    const [schemeValidation, setSchemeValidation] = useState<redeemValidationType>();
    const [loading, setLoading] = useState(false);
    const [selectedAssetClass,setSelectedAssetClass]=useState<String>("");

    //To set validation data in local state variable
    useEffect(() => {
        setSchemeValidation(redeemValidation);
    }, [redeemValidation, selectedSchemeData])

    //To fetch Validation data
    useEffect(() => {
        try {
            if (selectedSchemeData && selectedSchemeData.SCh) {
                redemptionValidation({ AccNo: selectedSchemeData.I_Accno, SchId: selectedSchemeData.I_Scheme });
            } else {
                console.log("selectedSchemeData or selectedSchemeData.SCh is undefined");
            }
        } catch (error) {
            console.error("Error ", error);
        }
    }, [selectedSchemeData]);

    useEffect(() => {
        try {
            {selectedAssetClass!="" &&
            getSchemeData(
                {
                    "AstId": AssetclassMapping[selectedAssetClass as keyof typeof AssetclassMapping],
                    "AmcId": `${selectedSchemeData.AmcID}`
                }, "SwitchFLAG"
            )
        }
        selectedAssetClass=="" && setSchemeData([])
    }catch (error) {
            console.error("Error ", error);
        }
    }, [selectedAssetClass]);


    const handleSubmit = () => {
        if (!validateFormData()) {
            return;
        }
        else {
            setLoading(true);
        }
        let payload: any = {}
        getBSECode({
            "TrType": "Swt",
            "Amount": schemeParams.switchValue.value.toString(),
            "Growthoption": selectedSchemeData?.Growthoption,
            "DividendReinvestment": selectedSchemeData?.DividendReinvestment,
            "RTACODE": selectedSchemeData?.SCh
        }).then(async ({ bse_code }) => {
            let response: any = await getBSECode({
                "TrType": "Swt",
                "Amount": schemeParams.switchValue.value.toString(),
                "Growthoption": schemeParams.ToSchemeID.split('~')[1] === 'G' ? 1 : 2,
                "DividendReinvestment": schemeParams.ToSchemeID.split('~')[1] !== 'G' ? 1 : 2,
                "RTACODE": newSchemeSch
            })

            payload = {
                "RecId": 0,
                "AccNo": selectedSchemeData?.I_Accno,
                "AmcId": selectedSchemeData?.AmcID,
                "BSE_SchemeCode": bse_code[0][0]?.BSE_ProductCod,
                "Amount": schemeParams.switchValue.value,
                "DividendReinvestment": selectedSchemeData?.DividendReinvestment,
                "FParFul": schemeParams.switchType === 'Partial' ? "P" : "F",
                "FUnsAmt": schemeParams.switchValue.type == "INR" ? "a" : "u",
                "Growthoption": selectedSchemeData.Growthoption,
                "Sch": selectedSchemeData.SCh,
                "ToBSE_SchemeCode": response?.bse_code[0][0]?.BSE_ProductCod,
                "ToSch": newSchemeSch,
                "TrType": "Swt",
                "Units": schemeParams.switchValue.value
            }

            addSchemeToCart(payload);
            setSelectedAssetClass("");
            setSchemeData([]);
        })
    }

    //This function validates the values entered in the form
    const validateFormData = () => {
        let valid = true;
        setError(errorStateSWTInitialData);
        const validationAmount = schemeValidation ? schemeValidation.Amount : selectedSchemeData.AUM;
        const validationUnit = schemeValidation ? schemeValidation.Units : selectedSchemeData.Units;
        //To scheme
        if (newSchemeSch === "" || newSchemeSch === undefined) {
            if (newSchemeSch === "" || newSchemeSch === undefined) {
                setError((prevParams) => ({ ...prevParams, errorToSchemeID: true, errorToSchemeIDMsg: "Please select any Scheme" }));
                valid = false;
            }
            else {
                setError((prevParams) => ({ ...prevParams, errorToSchemeID: false, errorToSchemeIDMsg: "Please select any Scheme" }));
            }
            return valid;
        }

        //STP frequency
        if (!(newSchemeSch === "" || newSchemeSch === undefined)) {
            if (schemeParams.switchValue.value === "" || schemeParams.switchValue.value === "0") {
                setError((prevParams) => ({ ...prevParams, errorSwitchValue: true, errorSwitchValueMsg: "Amount can not be empty" }));
                valid = false;
            }
            else if (schemeParams.switchValue.value && (schemeParams.switchType == "Partial" && schemeParams.switchValue.type === "INR" && Number(schemeParams.switchValue.value) > validationAmount)) {
                setError((prevParams) => ({ ...prevParams, errorSwitchValue: true, errorSwitchValueMsg: `Switch Amount cannot exceed ${validationAmount}` }));
                valid = false;
            }
            else if (schemeParams.switchValue.value && (schemeParams.switchType == "Partial" && schemeParams.switchValue.type === "Units" && Number(schemeParams.switchValue.value) > validationUnit)) {
                setError((prevParams) => ({ ...prevParams, errorSwitchValue: true, errorSwitchValueMsg: `Switch Amount cannot exceed ${validationUnit} units` }));
                valid = false;
            }
            else {
                setError((prevParams) => ({ ...prevParams, errorSwitchValue: false }));
            }
        }

        return valid;
    }

    return (
        <Box sx={{ mx: { xs: 3, sm: 6 } }}>
             <Box sx={{ my: 1.5 }}>
                    <Typography>Asset Class</Typography>
                    <FormControl sx={{ width: "100%" }} >
                        <Select
                            labelId="demo-simple-select-label"
                            id="demo-simple-select"
                            value={selectedAssetClass}
                            onChange={(e) => {
                                setSelectedAssetClass(e.target.value as string)
                            }}
                            inputProps={{ 'aria-label': 'Without label' }}
                        >
                            {Object.keys(AssetclassMapping).map((val: String, index: number) =>
                            (
                                <MenuItem
                                onClick={() => {
                                    setSelectedAssetClass(val);
                                }}
                                key={index}
                                    value={val.toString()}
                                >
                                    {val}
                                </MenuItem>
                            ))
                            }
                        </Select>
                    </FormControl>
                </Box>
            <Box sx={{ my: 1.5 }}>
                <Typography>To Scheme</Typography>
                <FormControl sx={{ width: "100%"}} >
                    <Select
                        labelId="demo-simple-select-label"
                        id="demo-simple-select"
                        value={schemeParams.ToSchemeName}
                        onChange={(e) => {
                            setSchemeParams({ ...schemeParams, ToSchemeName: e.target.value as string })
                        }}
                        defaultValue={schemeParams?.ToSchemeName}
                        inputProps={{ 'aria-label': 'Without label' }}
                    >
                        {schemeData?.map((val: SchemeType, index: any) =>
                        (
                            <MenuItem
                                onClick={() => {
                                    setNewSchemeSch(val.Productcode_RTA);
                                    const tempSchemeParams = schemeParams;
                                    tempSchemeParams.ToSchemeID = val.Sch_ID as string;
                                    setSchemeParams(tempSchemeParams);
                                }}
                                key={index}
                                value={val.Sch_Desc}

                            >
                                {val.Sch_Desc}
                            </MenuItem>
                        ))
                        }
                    </Select>
                </FormControl>
                {error.errorToSchemeID && <Typography sx={{ fontSize: 10, color: 'red', mb: 0.5 }}> {error.errorToSchemeIDMsg} </Typography>}
            </Box>

            {newSchemeSch &&
                <>
                    {/* Partial / Full */}
                    <Box sx={{ display: "flex", alignItems: 'center', justifyContent: "space-between", width: 300 }}>
                        <FormLabel id="demo-row-radio-buttons-group-label" sx={{ fontWeight: 500, mt: 3, mb: 1 }}>Switch Type</FormLabel>
                        <RadioGroup sx={{ pt: "1rem" }}
                            row
                            aria-labelledby="demo-row-radio-buttons-group-label"
                            name="row-radio-buttons-group"
                            value={schemeParams.switchType}
                            onChange={(e) => {
                                // setSchemeParams({...schemeParams,ToSchemeName:e.target.value as string})
                                setSchemeParams({ ...schemeParams, switchType: e.target.value, switchValue: { value: e.target.value === "Partial" ? "" : schemeParams.switchValue.type === "INR" ? schemeValidation?.Amount || selectedSchemeData.AUM : schemeValidation?.Units || selectedSchemeData.Units, type: schemeParams.switchValue.type } })

                            }}
                        >
                            <FormControlLabel value="Partial" control={<Radio />} label="Partial" />
                            <FormControlLabel value="Full" control={<Radio />} label="Full" />
                        </RadioGroup>
                    </Box>

                    <Box sx={{ my: 1.5 }}>
                        <Typography>Switch Amount</Typography>
                        <input type="text" className='investmentAmount2'
                            value={schemeParams.switchType === "Partial" ? schemeParams.switchValue.value : schemeParams.switchValue.type === "INR" ? schemeValidation?.Amount : schemeValidation?.Units}
                            onChange={(e) => {
                                let newValue = e.target.value;

                                newValue = newValue.replace(/[^0-9]/g, '');

                                if (newValue.length < schemeParams.switchValue.value.toString().length) {
                                    newValue = newValue.slice(0, -1);
                                }
                                setSchemeParams({ ...schemeParams, switchValue: { ...schemeParams.switchValue, value: newValue } })
                            }}>
                        </input>
                        {error.errorSwitchValue && <Typography sx={{ fontSize: 10, color: 'red', mb: 0.5 }}> {error.errorSwitchValueMsg} </Typography>}
                    </Box>

                    <Box sx={{ display: "flex", flexDirection: "column", alignItems: 'flex-start', justifyContent: "space-between", width: 300 }}>
                        <RadioGroup sx={{ display: "flex", flexDirection: "row", mt: "0.5rem", ml: "0.5rem" }}

                            onChange={(e) => {
                                setSchemeParams({ ...schemeParams, switchValue: { ...schemeParams.switchValue, type: e.target.value } })
                            }}
                            value={schemeParams.switchValue.type}
                        >
                            <FormControlLabel value="INR" control={<Radio />} label="INR" />
                            <FormControlLabel value="Units" control={<Radio />} label="Units" />
                        </RadioGroup>
                    </Box>
                </>
            }

            <Button
                sx={{
                    background: 'linear-gradient(90deg, #36DAE9, #0090FF)',
                    height: "2.5rem",
                    width: "100%",
                    color: '#ffffff',
                    borderRadius: '8px',
                    mt: 3
                }}
                onClick={handleSubmit}
            >
                {loading ? <Box sx={{ display: 'flex' }}>
                    <CircularProgress style={{ color: "white" }} size="1.8rem" />
                </Box> :
                    "Add To Cart"}
            </Button>

        </Box>

    )
}

export const Redeemtion_Form = (
    { schemeParams,
        setSchemeParams,
        selectedSchemeData,
        addSchemeToCart,
        getBSECode
    }:
        {
            schemeParams: schemParams_Holdings,
            setSchemeParams: React.Dispatch<React.SetStateAction<schemParams_Holdings>>,
            selectedSchemeData: PortfolioType,
            addSchemeToCart: (payload: any) => void,
            getBSECode: (requestOptions: bseCodePayload) => Promise<any>
        }
) => {

    const { redeemValidation, redemptionValidation } = useGetTotalData();
    const [error, setError] = useState<errorStatesRedeem>(errorStateRedeemInitialData);
    const [schemeValidation, setSchemeValidation] = useState<redeemValidationType>();
    const [loading, setLoading] = useState(false);

    //To set validation data in local state variable
    useEffect(() => {
        setSchemeValidation(redeemValidation);
    }, [redeemValidation, selectedSchemeData])

    //To fetch Validation data
    useEffect(() => {
        try {
            if (selectedSchemeData && selectedSchemeData.SCh) {
                redemptionValidation({ AccNo: selectedSchemeData.I_Accno, SchId: selectedSchemeData.I_Scheme });
            } else {
                console.log("selectedSchemeData or selectedSchemeData.SCh is undefined");
            }
        } catch (error) {
            console.error("Error ", error);
        }
    }, [selectedSchemeData]);

    const handleSubmit = () => {
        if (!validateFormData()) {
            return;
        }
        else {
            setLoading(true);
        }
        let payload: any = {}
        getBSECode({
            "TrType": "Red",
            "Amount": schemeParams.redeemValue.value.toString(),
            "Growthoption": selectedSchemeData?.Growthoption,
            "DividendReinvestment": selectedSchemeData?.DividendReinvestment,
            "RTACODE": selectedSchemeData?.SCh
        }).then(async ({ bse_code }) => {

            payload = {
                "RecId": 0,
                "AccNo": selectedSchemeData?.I_Accno,
                "AmcId": selectedSchemeData?.AmcID,
                "BSE_SchemeCode": bse_code[0][0]?.BSE_ProductCod,
                "Amount": schemeParams.redeemValue.value,
                "FParFul": schemeParams.redeemType === 'Partial' ? "P" : "F",
                "FUnsAmt": schemeParams.redeemValue.type == "INR" ? "a" : "u",
                "Sch": selectedSchemeData.SCh,
                "TrType": "Red",
                "Units": schemeParams.redeemValue.value
            }

            addSchemeToCart(payload);
        })
    }

    //This function validates the values entered in the form
    const validateFormData = () => {
        let valid = true;
        setError(errorStateRedeemInitialData);
        const validationAmount = schemeValidation ? schemeValidation.Amount : selectedSchemeData.AUM;
        const validationUnit = schemeValidation ? schemeValidation.Units : selectedSchemeData.Units;

        if (schemeParams.redeemValue.value === "" || schemeParams.redeemValue.value === "0") {
            setError((prevParams) => ({ ...prevParams, errorRedeemValue: true, errorRedeemValueMsg: "Amount can not be empty" }));
            valid = false;
        }
        else if (schemeParams.redeemValue.value && (schemeParams.redeemType == "Partial" && schemeParams.redeemValue.type === "INR" && Number(schemeParams.redeemValue.value) > validationAmount)) {
            setError((prevParams) => ({ ...prevParams, errorRedeemValue: true, errorRedeemValueMsg: `Redemption Amount cannot exceed ${validationAmount}` }));
            valid = false;
        }
        else if (schemeParams.redeemValue.value && (schemeParams.redeemType == "Partial" && schemeParams.redeemValue.type === "Units" && Number(schemeParams.redeemValue.value) > validationUnit)) {
            setError((prevParams) => ({ ...prevParams, errorRedeemValue: true, errorRedeemValueMsg: `Redemption Amount cannot exceed ${validationUnit} units` }));
            valid = false;
        }
        else {
            setError((prevParams) => ({ ...prevParams, errorRedeemValue: false }));
        }

        return valid;
    }

    return (
        <Box sx={{ mx: { xs: 3, sm: 6 } }}>
            {/* Partial / Full */}
            <Box sx={{ display: "flex", alignItems: 'center', justifyContent: "space-between", width: 300 }}>
                <FormLabel id="demo-row-radio-buttons-group-label" sx={{ fontWeight: 500, mt: 3, mb: 1 }}>Redemption Type</FormLabel>
                <RadioGroup sx={{ pt: "1rem" }}
                    row
                    aria-labelledby="demo-row-radio-buttons-group-label"
                    name="row-radio-buttons-group"
                    value={schemeParams.redeemType}
                    onChange={(e) => {
                        // setSchemeParams({...schemeParams,ToSchemeName:e.target.value as string})
                        setSchemeParams({ ...schemeParams, redeemType: e.target.value, redeemValue: { value: e.target.value === "Partial" ? "" : schemeParams.redeemValue.type === "INR" ? schemeValidation?.Amount || selectedSchemeData.AUM : schemeValidation?.Units || selectedSchemeData.Units, type: schemeParams.redeemValue.type } })

                    }}
                >
                    <FormControlLabel value="Partial" control={<Radio />} label="Partial" />
                    <FormControlLabel value="Full" control={<Radio />} label="Full" />
                </RadioGroup>
            </Box>

            <Box sx={{ my: 1.5 }}>
                <Typography>Redemption Amount</Typography>
                <input type="text" className='investmentAmount2'
                    value={schemeParams.redeemType === "Partial" ? schemeParams.redeemValue.value : schemeParams.redeemValue.type === "INR" ? schemeValidation?.Amount : schemeValidation?.Units}
                    onChange={(e) => {
                        let newValue = e.target.value;

                        newValue = newValue.replace(/[^0-9]/g, '');

                        if (newValue.length < schemeParams.invAmount.toString().length) { //look into it
                            newValue = newValue.slice(0, -1);
                        }
                        setSchemeParams({ ...schemeParams, redeemValue: { ...schemeParams.redeemValue, value: newValue } })
                    }}>
                </input>
                {error.errorRedeemValue && <Typography sx={{ fontSize: 10, color: 'red', mb: 0.5 }}> {error.errorRedeemValueMsg} </Typography>}
            </Box>

            <Box sx={{ display: "flex", flexDirection: "column", alignItems: 'flex-start', justifyContent: "space-between", width: 300 }}>
                <RadioGroup sx={{ display: "flex", flexDirection: "row", mt: "0.5rem", ml: "0.5rem" }}

                    onChange={(e) => {
                        setSchemeParams({ ...schemeParams, redeemValue: { ...schemeParams.redeemValue, type: e.target.value } })
                    }}
                    value={schemeParams.redeemValue.type}
                >
                    <FormControlLabel value="INR" control={<Radio />} label="INR" />
                    <FormControlLabel value="Units" control={<Radio />} label="Units" />
                </RadioGroup>
            </Box>
            <Button
                sx={{
                    background: 'linear-gradient(90deg, #36DAE9, #0090FF)',
                    height: "2.5rem",
                    width: "100%",
                    color: '#ffffff',
                    borderRadius: '8px',
                    mt: 3
                }}
                onClick={handleSubmit}
            >
                {loading ? <Box sx={{ display: 'flex' }}>
                    <CircularProgress style={{ color: "white" }} size="1.8rem" />
                </Box> :
                    "Add To Cart"}
            </Button>
        </Box>
    )
}