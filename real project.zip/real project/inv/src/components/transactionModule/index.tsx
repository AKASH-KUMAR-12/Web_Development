import { TabContext, TabList, TabPanel } from "@mui/lab";
import { Box, Button, Tab, Typography } from "@mui/material";
import { useEffect, useState } from "react";
import InvestorTransactions from "./investor-transactions";
import DashboardHeader from "../dashboard/dashboard.header";
import { SchemeRecommendations } from "./recommendations";
import Holding from './holding'

import { useLocation } from 'react-router';
import { AddToCartButtons, TopHoldingButtons } from "../commonComponents";
import { useGetTotalData } from "./transaction.context";
import OrdersPage from "./Orders";

export function TransactionIndex() {
  const [value, setValue] = useState<string>("explore");
  const { setInitialFilter } = useGetTotalData()
  const [headerSelected,setHeaderSelected]=useState<String>("Bugle Rock");

  const handleChange = (event: any, value: any) => {
    setValue(value);
    setInitialFilter({})
  };
  const location = useLocation();

  useEffect(() => {
    const tabValue = location.state ? location.state.tab : "explore";
    setValue(tabValue);
  }, [location.state]);

  // const navigate= useNavigate();
  // const handleClickExplore = () => {
  //   // setValue('explore');
  //   navigate("explore");
  // }
  // const handleClickRecommendation = () => {
  //   // setValue('recommend');
  //   navigate("recommendations");
  // }
  // useEffect(() => {
  //   const searchParams = new URLSearchParams(location.search);
  //   const activeTab = searchParams.get("tab");
  //   if (activeTab && (activeTab === "explore" || activeTab === "recommend")) {
  //     setValue(activeTab);
  //   }
  // }, [location.search]);

  // const handleChange = (event: any, newValue: string) => {
  //   setValue(newValue);
  //   navigate(`?tab=${newValue}`);
  // };

  // const handleClickExplore = () => {
  //   setValue('explore');
  //   navigate(".", { replace: true }); // Use "." to navigate to the current route
  // }

  // const handleClickRecommendation = () => {
  //   setValue('recommend');
  //   navigate("./recommendations");
  // }

  return (
    <Box sx={{ mt:0, mx:{xs:1.5,sm:8},pt:{xs:0,sm:3}}}>
      <DashboardHeader  headerOption={""} 
        setHeaderOption={""} />
      <Box
        sx={{
          width: '100%',
          '& .MuiTabPanel-root': { py: 2, px: 0 },
          '& .MuiTab-root': {
            color: '#000000',
            opacity: 0.8,
            fontSize: {xs:11,sm:15},
            lineHeight: '1rem',
            textTransform: 'capitalize',
            borderRadius: '30px',
            border: 'none',
            mx:{xs:0,sm:1},
            my:{xs:1,sm:2},
            minHeight: {xs:30,sm:50},
            height: {xs:16},
            display: 'flex',
            flexDirection: 'row',
            // backgroundColor:'blue',
            px: { xs: 1, md: 3, lg: 5 },
            '&.Mui-selected': {
              color: '#0393FE',
              //   background:'linear-gradient(90deg, #0090FF, #36DAE9)',
              border: '2px solid #0393FE',
            },
          },

          '& .MuiTabs-indicator': {
            height: 3,
            background: 'transparent',
          },
          '& .MuiTabs-flexContainer': {
           display: "flex",
           justifyContent: {xs:"space-between",sm:"flex-start"},
           width: "100%",
       }
        }}>
        <TabContext value={value}>
          <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
            <TabList
            variant="scrollable"
            scrollButtons="auto"
            onChange={handleChange}>
              <Tab label="EXPLORE" value="explore"
              // onClick={handleClickExplore}
              />
              <Tab label="HOLDINGS" value="holding"

              />
              {/* <Tab label="HOLDING" value="holding" />  */}
              <Tab label="RECOMMENDATIONS" value="recommend"
              // onClick={handleClickRecommendation} 
              />
              <Tab label="ORDERS" value="orders" />
            </TabList>
          </Box>

          <TabPanel value="explore"
          //  onClick={handleClickExplore}
          >

            <InvestorTransactions />

          </TabPanel>
          <TabPanel value="holding" >
            <Holding />

          </TabPanel>
          <TabPanel value="recommend" >
            <SchemeRecommendations />
          </TabPanel>
          <TabPanel value="orders">
            <OrdersPage />
          </TabPanel>

        </TabContext>
      </Box>
    </Box>
  )

}