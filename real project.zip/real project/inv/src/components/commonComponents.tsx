export function YearSelecter(props: any) {
    return (
      <div
        style={{
          cursor: "pointer",
          flexGrow: 1,
          flexBasis: 0,
          paddingRight: !props.marginH ? props.marginH : 3,
          paddingLeft: !props.marginH ? props.marginH : 3,
          marginLeft: 2,
          marginRight: 2,
          // marginLeft: !!props.marginH ? props.marginH : 3,
          // marginRight: !!props.marginH ? props.marginH : 3,
          borderRadius: 5,
          paddingTop: !props.paddingV ? props.paddingV : 3,
          paddingBottom: !props.paddingV ? props.paddingV : 3,
          background: props.isSelected ?'linear-gradient(90deg , #0090FF ,#1EB1F3)' : "transparent",
          border: "1px solid #163869",
        }}
        onClick={props.onPress}
      >
        <div>
          <div
            style={{
              display: "flex",
              flexDirection: "column",
              color: props.isSelected ? "#FFFFFF" : "#5A7C82",
              alignItems: "center",
            }}
          >
            {props.text}
          </div>
        </div>
      </div>
    );
  }
  
  export function TopHoldingButtons(props: any) {
    return (
      <div
        style={{
          display: "flex",
          margin: 10,
          marginBottom: 15,
          borderRadius: 18,
          border:
            // props.selected === props.label
            "1px solid #00A4A4",
          background: props.selected === props.label ?'linear-gradient(90deg , #0090FF ,#1EB1F3)' : "#FFFFFF",
          color: props.selected === props.label ? "#FFFFFF" : '#337FC9',
          flexGrow: 1,
          flexBasis: 0,
          padding: 6,
          alignItems: "center",
          justifyContent: "space-between",
          cursor: 'pointer',
        }}
        onClick={props.onPress}
      >
        <div style={{ fontSize: 14, fontWeight: 500 }}>{props.label}</div>
        <div style={{ fontSize: 14, paddingTop: 5 }}>{props.percentage}%</div>
      </div>
    );
  }
  export function AddToCartButtons(props: any) {
    return (
      <div
        style={{
          display: "flex",
          margin: 10,
          marginBottom: 15,
          borderRadius: 18,
          border:
            // props.selected === props.label
            "1px solid #00A4A4",
          background: props.selected === props.label ?'linear-gradient(90deg , #0090FF ,#1EB1F3)' : "#FFFFFF",
          color: props.selected === props.label ? "#FFFFFF" : '#337FC9',
          flexGrow: 1,
          flexBasis: 0,
          padding: 6,
          alignItems: "center",
          justifyContent: "space-between",
          cursor: 'pointer',
        }}
        onClick={props.onPress}
      >
        <div style={{ fontSize: 14, fontWeight: 500 }}>{props.label}</div>
        {/* <div style={{ fontSize: 14, paddingTop: 5 }}>{props.percentage}%</div> */}
      </div>
    );
  }