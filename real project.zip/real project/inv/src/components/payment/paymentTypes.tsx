export type redeemValidationFailureMsgType = {
    schemeId:any,
    schemeName: any,
    failMessage: string,
}