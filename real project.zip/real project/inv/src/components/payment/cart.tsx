import { Box, Button, CardMedia, Checkbox, Dialog, DialogActions, DialogContent, DialogContentText, DialogTitle, Divider, FormControl, Grid, IconButton, InputLabel, LinearProgress, MenuItem, Select, Switch, Tab, Typography } from "@mui/material";
import SideNavResponsive from "../Sidebar/sidebar.responsive";
import DashboardResponsiveHeader from "../dashboard/dashboard.responsive.header";
import { useEffect, useRef, useState } from "react";
import { useRootContext } from "../data/root.context";
import DashboardHeader from "../dashboard/dashboard.header";
import '../transactionModule/styles.css'
import { TabContext, TabList, TabPanel } from "@mui/lab";
import { CutOffTimeDrawer } from "../transactionModule/cut.off.time.modal";
import { useNavigate } from 'react-router';
import { GetCart, usePaymentContext } from "./payment.context";
import Swal from "sweetalert2";
import LoadingButton from '@mui/lab/LoadingButton';
import './cart.css'
import { useLocation } from 'react-router-dom';
import { formatToIndianCurrency } from "../utils/utilityFunctions";
import { CloseIcon, DeleteIcon } from "../customSVGs";
import { useLoginContext } from "../login/data/login.context";
import { redeemValidationFailureMsgType } from "./paymentTypes";
import CancelOutlinedIcon from '@mui/icons-material/CancelOutlined';
import CheckCircleOutlineOutlinedIcon from '@mui/icons-material/CheckCircleOutlineOutlined';


export const tabWithTrtype: Record<string, string> = {
  "Add": "Add",
  "XSIP": "Add",
  "New": "New",
  "ISIP": "New",
  "STP": "STP",
  "SWP": "SWP",
  "Swt": "Swt",
  "Red": "Red"
}

export function Bubble(props: { text: string }) {
  return (
    <div className="bubbleDiv">
      <div className="bubbleText">
        {props.text}
      </div>
    </div>
  );
}
export function RecommendedSchemesModal({ handleModalClose, selectedSchemes, OnSchemeDeSelection }: { handleModalClose: () => void; selectedSchemes: { schemeId: string; }[]; OnSchemeDeSelection: (schemeId: string) => void; }) {
  return (
    <Box>
      <Box sx={{ mb: 3, px: 3, display: 'flex', justifyContent: 'space-between' }}>
        <Typography sx={{ fontSize: 16, fontWeight: 500 }}>
          Recommended Schemes
        </Typography>
        <Box onClick={handleModalClose} sx={{ cursor: 'pointer' }}>
          {/* <CloseIcon /> */}
        </Box>
      </Box>
      <Divider />
    </Box>
  )
}
export default function Cart({ onSchemeSelection, schemeId, OnSchemeDeSelection, handleSetViewSchemeDetails }:
  {
    onSchemeSelection?: (schemeId: string) => void;
    schemeId?: string;
    OnSchemeDeSelection?: (schemeId: string) => void;
    handleSetViewSchemeDetails?: (val: boolean) => void;
  }
) {
  const location = useLocation();
  const [isMobileBreakpoint, setIsMobileBreakpoint] = useState(false);
  const { getCart, getCartDetails, profieData, getUserDetails, userDetails, placeOrder, deleteCart, redemptionValidation } = usePaymentContext();
  const { getCartCount } = useLoginContext();

  const [value, setValue] = useState<string>(tabWithTrtype[location?.state?.value]);
  const [subVal, setSubVal] = useState<string>(location?.state?.subValue);

  const [checkedList, setCheckedList] = useState<string[]>([]);

  //Works for SIP/SWP/STP
  const [selectedValuesSIP, setselectedValuesSIP] = useState<any>([]);

  //Works for Lumpsum/SWT/RED
  const [selectedValuesLump, setselectedValuesLump] = useState<any>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [failedOrderList, setFailedOrderList] = useState<any>([])
  const [successOrderList, setSuccessOrderList] = useState<any>([])
  const [open, setOpen] = useState<any>(false);
  const [trigger, setTrigger] = useState<boolean>(false)
  const [cartList, setCartList] = useState<any>();
  const [isLoadingList, setLoadingList] = useState(true);
  const [redemptionValidationResultMsg, setRedemptionValidationResultMsg] = useState<redeemValidationFailureMsgType[]>([]);

  const handleResize = () => {
    if (window.innerWidth < 900) {
      setIsMobileBreakpoint(true);
    } else {
      setIsMobileBreakpoint(false);
    }
  };

  const handleTabValueChange = (event: any, value: any) => {
    setselectedValuesSIP([]);
    setselectedValuesLump([]);
    setCheckedList([]);
    setSubVal('lumpsum');
    setValue(value);
  };
  const handleSubTabValueChange = (event: any, val: any) => {
    setselectedValuesSIP([]);
    setselectedValuesLump([]);
    setCheckedList([]);
    setSubVal(val);
  }

  const handleCartCheckboxChange = (e: any, selectedData: any) => {
    if ((value == "New" && subVal == "sip") || (value == "Add" && subVal == "sip") || value == "STP" || value == "SWP") {
      if (e.target.checked == true) {
        let temp_array: any = selectedValuesSIP
        let temp_value: any = {
          order_id: selectedData.TE_IHNO.toString(),
          type: "sys"
        }
        temp_array.push(temp_value)
        setselectedValuesSIP(temp_array)
        setCheckedList([...checkedList, selectedData.TE_IHNO.toString()])
        // onSchemeSelection(schemeId);

      }
      else {
        let temp_array: any = selectedValuesSIP
        temp_array.splice(temp_array.findIndex((a: any) => a.order_id === selectedData.TE_IHNO), 1)
        checkedList.splice(checkedList.findIndex((a: any) => a === selectedData.TE_IHNO.toString()), 1)
        setCheckedList([...checkedList])
        setselectedValuesSIP(temp_array)

        // OnSchemeDeSelection(schemeId);
      }
    }
    else {
      if (e.target.checked == true) {
        let temp_array: any = selectedValuesLump
        let temp_value: any = {
          order_id: selectedData.TE_IHNO.toString(),
          type: "Normal"
        }
        temp_array.push(temp_value)
        setselectedValuesLump(temp_array)
        // setCheckedList({...checkedList,[e.target.name]: e.target.checked})
        setCheckedList([...checkedList, selectedData.TE_IHNO.toString()])
        // onSchemeSelection(schemeId);
      }
      else {
        let temp_array: any = selectedValuesLump
        temp_array.splice(temp_array.findIndex((a: any) => a.order_id === selectedData.TE_IHNO), 1)
        setselectedValuesLump(temp_array)
        checkedList.splice(checkedList.findIndex((a: any) => a === selectedData.TE_IHNO.toString()), 1)
        setCheckedList([...checkedList])
        // OnSchemeDeSelection(schemeId);
      }
    }
  }

  useEffect(() => {
    setIsMobileBreakpoint(window.innerWidth < 900);
    window.addEventListener('resize', handleResize);
    // return window.removeEventListener('resize', handleResize);
  }, []);

  const cartDelete = (val: number) => {
    Swal.fire({
      html: '<b>Are you sure you want to remove this item?</b>',
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete.",
      customClass: {
        htmlContainer: 'custom-html-container-class',
      }
    }).then(async (result) => {
      let payload: any;
      if ((value == "New" && subVal == "sip") || (value == "Add" && subVal == "sip") || value == "STP" || value == "SWP") {
        payload = {
          "type": "SYS",
          "IHNO": val
        }
      }
      else {
        payload = {
          "type": "NORMAL",
          "IHNO": val
        }
      }
      if (result.isConfirmed) {
        let cart_delete_response = await deleteCart(payload)
        if (cart_delete_response[0][0]['Status'] == "True") {
          getCartCount();
          Swal.fire({
            title: "Item deleted successfully!",
            icon: "success",
            customClass: {
              confirmButton: 'sweet-alert-button'
            }
          });
          setTrigger(!trigger)
        }
        else {
          Swal.fire({
            icon: "error",
            title: "Oops...",
            text: "Something went wrong!",
          });
        }
      }
    });
  }

  const validation = async () => {
    if (value === "Red" || value == 'Swt') {
      setRedemptionValidationResultMsg([]);
      const ValidationFailMsg: any = [];
      const selectedCartList = cartList.filter((val: any) =>
        selectedValuesLump.some((val2: any) => val.TE_IHNO.toString() == val2.order_id)
      );
      const temp = await Promise.all(
        selectedCartList.map(async (val: any) => {
          const redeemValidation = await redemptionValidation({
            AccNo: val.TE_ACNO,
            SchId: val.TE_SCHID
          });

          //case when no data comes from redeem validation api
          if (redeemValidation == undefined || redeemValidation == null) {
            const failMessage = {
              schemeId: val.TE_SCHID,
              schemeName: val.SchDesc,
              failMessage: `Can not get minimum redeem amount`,
            };

            ValidationFailMsg.push(failMessage);
            // setRedemptionValidationResultMsg([
            //   ...redemptionValidationResultMsg,
            //   failMessage,
            // ]);
            return failMessage
          }

          //to check redeemtion value when it is in amount
          if (val.TE_AMOUNT && val.TE_AMOUNT != 0 && val.TE_AMOUNT > redeemValidation.Amount) {
            const failMessage = {
              schemeId: val.TE_SCHID,
              schemeName: val.SchDesc,
              failMessage: `Can not redeem more than ₹ ${redeemValidation.Amount}`,
            };

            ValidationFailMsg.push(failMessage);
            // setRedemptionValidationResultMsg([
            //   ...redemptionValidationResultMsg,
            //   failMessage,
            // ]);
            return failMessage
          }

          //to check redeemtion value when it is in units
          else if (val.TE_UNITS && val.TE_UNITS > redeemValidation.Units) {
            const failMessage = {
              schemeId: val.TE_SCHID,
              schemeName: val.SchDesc,
              failMessage: `Can not redeem more than ${redeemValidation.Units} Units`,
            };

            ValidationFailMsg.push(failMessage);
            // setRedemptionValidationResultMsg([
            //   ...redemptionValidationResultMsg,
            //   failMessage,
            // ]);
            return failMessage
          }

          return "success";
        })
      );
      setRedemptionValidationResultMsg(temp.filter((ele) => ele != "success"))
      //when there is no failure message then redemtion amount/units are correct
      if (ValidationFailMsg.length === 0) {
        return true;
      } else {
        return false;
      }
    }
    return true;
  };


  const handlePaymentClick = async () => {
    setLoading(true);
    if ((value == "New" && subVal == "sip") || (value == "Add" && subVal == "sip") || value == "STP" || value == "SWP") {
      try {
        if (selectedValuesSIP.length == 0) {
          Swal.fire({
            title: "Scheme Not Selected!",
            icon: "error",
            customClass: {
              confirmButton: 'sweet-alert-button'
            }
          });
          setLoading(false)
        }

        else {
          let placeOrder_response: any = await placeOrder({
            orders: selectedValuesSIP
          })
          setLoading(false);
          let all_success = true;
          for (let i = 0; i < placeOrder_response.length; i++) {
            if (placeOrder_response[i].order_success === false)
              all_success = false;
          }
          if (all_success) {
            getCartCount();
            Swal.fire({
              title: "Order Placed!",
              icon: "success",
              customClass: {
                confirmButton: 'sweet-alert-button'
              }
            });
            setselectedValuesSIP([]);
            setselectedValuesLump([]);
            setCheckedList([])
            let successList: any = []
            placeOrder_response.filter((val: any) => { return (val.order_success == true) }).map((i: any) => {
              let foundValue: any = cartList.find((a: any) => a.TE_IHNO.toString() === i.order_id);
              successList.push({
                name: foundValue.SchDesc,
                amount: foundValue.TE_AMOUNT,
                return: foundValue.Sch_Return1Yr,
                date: foundValue.TE_TRDATE.slice(0, 10),
                AssetClassName: foundValue.AssetClassName,
                Sub_AssetclassName: foundValue.Sub_AssetclassName,
                Schemeoption: foundValue.Schemeoption,
                success_reason: i.order_status
              })
            })
            setSuccessOrderList(successList)
          }
          else {
            getCartCount();
            setOpen(true)
            let failedList: any = []
            placeOrder_response.filter((val: any) => { return (val.order_success == false) }).map((i: any) => {
              let foundValue: any = cartList.find((a: any) => a.TE_IHNO.toString() === i.order_id);
              failedList.push({
                name: foundValue.SchDesc,
                amount: foundValue.TE_AMOUNT,
                return: foundValue.Sch_Return1Yr,
                date: foundValue.TE_TRDATE.slice(0, 10),
                AssetClassName: foundValue.AssetClassName,
                Sub_AssetclassName: foundValue.Sub_AssetclassName,
                Schemeoption: foundValue.Schemeoption,
                failure_reason: i.order_status
              })
            })
            setselectedValuesSIP([]);
            setselectedValuesLump([]);
            setCheckedList([])
            setFailedOrderList(failedList)

          }
        }
      }
      catch (e) {
        console.error(e);
      }
    }
    else {
      try {
        if (selectedValuesLump.length == 0) {
          Swal.fire({
            title: "Scheme Not Selected!",
            icon: "error",
            customClass: {
              confirmButton: 'sweet-alert-button'
            }
          });
          setLoading(false)
        }
        else {
          let placeOrder_response: any = await placeOrder({
            orders: selectedValuesLump
          })
          setLoading(false);

          let all_success = true;
          for (let i = 0; i < placeOrder_response.length; i++) {
            if (placeOrder_response[i].order_success === false)
              all_success = false;
          }
          if (all_success) {
            getCartCount();
            console.log("success");
            Swal.fire({
              title: "Order Placed!",
              icon: "success",
              customClass: {
                confirmButton: 'sweet-alert-button'
              }
            });
            setselectedValuesLump([]);
            setCheckedList([])

            let successList: any = []
            placeOrder_response.filter((val: any) => { return (val.order_success == true) }).map((i: any) => {
              let foundValue: any = cartList.find((a: any) => a.TE_IHNO.toString() === i.order_id);
              successList.push({
                name: foundValue.SchDesc,
                amount: foundValue.TE_AMOUNT,
                return: foundValue.Sch_Return1Yr,
                date: foundValue.TE_TRDATE.slice(0, 10),
                AssetClassName: foundValue.AssetClassName,
                Sub_AssetclassName: foundValue.Sub_AssetclassName,
                Schemeoption: foundValue.Schemeoption,
                success_reason: i.order_status
              })
            })
            setSuccessOrderList(successList)
          }
          else {
            console.log("failure");
            getCartCount();
            setOpen(true)
            let failedList: any = []
            placeOrder_response.filter((val: any) => { return (val.order_success == false) }).map((i: any) => {
              let foundValue: any = cartList.find((a: any) => a.TE_IHNO.toString() === i.order_id);
              failedList.push({
                name: foundValue.SchDesc,
                amount: foundValue.TE_AMOUNT,
                return: foundValue.Sch_Return1Yr,
                date: foundValue.TE_TRDATE.slice(0, 10),
                AssetClassName: foundValue.AssetClassName,
                Sub_AssetclassName: foundValue.Sub_AssetclassName,
                Schemeoption: foundValue.Schemeoption,
                failure_reason: i.order_status
              })
            })
            setselectedValuesLump([]);
            setCheckedList([])
            setFailedOrderList(failedList)
          }
        }
      }
      catch (e) {
        console.error(e);
      }
    }
    setTrigger(!trigger)
    setselectedValuesSIP([]);
    setCheckedList([])
    setselectedValuesLump([]);
  }

  useEffect(() => {
    if (cartList != undefined) {
      setLoadingList(false);
    }
  }, [cartList]);

  useEffect(() => {
    (async function () {
      try {
        let cart_response: any = await getCartDetails()
        setCartList(cart_response);
      } catch (e) {
        console.error(e);
      }
    })();
  }, [trigger, value])


  const tabMap = [
    {
      label: "New Purchase",
      value: "New",
      trType: "New",
      trType2: "ISIP"
    },
    {
      label: "Additional Purchase",
      value: "Add",
      trType: "Add",
      trType2: "XSIP",
    },
    {
      label: "STP",
      value: "STP",
      trType: "STP",
      trType2: "STP"
    },
    {
      label: "SWP",
      value: "SWP",
      trType: "SWP",
      trType2: "SWP"
    },
    {
      label: "Switch",
      value: "Swt",
      trType: "Swt",
      trType2: "Swt"
    },
    {
      label: "Redemption",
      value: "Red",
      trType: "Red",
      trType2: "Red"
    }
  ]

  return (
    <Box>
      <Grid container sx={{ width: '100%', }}>
        <Box sx={{ marginTop: { xs: '0vh', sm: '5vh' }, width: '100%', px: '2vw' }}>
          <DashboardHeader  headerOption={""} 
        setHeaderOption={""} />
          <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <Typography sx={{ mt: { xs: '0vh', sm: '0vh' }, fontSize: '20px', fontWeight: 500 }}>
              CART
            </Typography>
            {/* <Box sx={{ cursor: 'pointer', mt: '5vh',mr:'1.5vh' }}
            // onClick={handleClose}
            >
              <CloseIcon />
            </Box> */}
          </Box>
          {(isLoadingList) ? (
            <LinearProgress sx={{ mt: 2.5 }} />
          ) :
            <Box sx={{ boxShadow: '0px 0px 20px #dfdfdf', '& .MuiTabPanel-root': { py: 1, px: 1 }, bgcolor: 'white', mt: { xs: '2vh', sm: '3vh' }, borderRadius: '10px' }}>
              <TabContext value={tabWithTrtype[value]}>
                <Box sx={{
                  width: '100%',
                  '& .MuiTabPanel-root': { py: 2, px: 0 },
                  '& .MuiTab-root': {
                    color: '#A1A2A2',
                    opacity: 0.8,
                    fontSize: { xs: 12, sm: 14 },
                    lineHeight: '24px',
                    textTransform: 'capitalize',
                    px: { xs: 2, md: 3, lg: 4 },
                    '&.Mui-selected': {
                      color: '#0393FE',
                    },
                  },
                  '& .MuiTabs-indicator': {
                    height: 3,
                    background: '#0393FE',
                  },
                }}>
                  <TabList
                    onChange={handleTabValueChange}
                    aria-label="product tabs"
                    variant="scrollable"
                    scrollButtons="auto"
                  >
                    {tabMap.map((val, idx) => {
                      return (
                        <Tab key={idx} label={`${val.label} (${cartList?.filter((i: any) => {
                          return (i.TE_TRTYPE == val.trType || i.TE_TRTYPE == val.trType2)
                        }).length})`} value={val.value} />
                      )
                    })}
                  </TabList>
                </Box>
                <Divider />
                <Box>
                  {tabMap.map((val) =>

                    <TabPanel value={val.value} key={val.value}>
                      {val.value == "New" || val.value == "Add" ?
                        //Tab for New and Additional purchase
                        <>
                          <TabContext value={subVal}>
                            <Box
                              sx={{
                                width: '100%',
                                '& .MuiTabPanel-root': { px: 0 },
                                '& .MuiTab-root': {
                                  color: '#A1A2A2',
                                  opacity: 0.8,
                                  fontSize: 12,
                                  lineHeight: '15px',
                                  textTransform: 'capitalize',
                                  px: { xs: 1, md: 2, lg: 4 },

                                  '&.Mui-selected': {
                                    color: '#0393FE',
                                  },
                                },
                                '& .MuiTabs-indicator': {
                                  height: 3,
                                  background: '#0393FE',
                                },
                              }}>
                              <TabList
                                onChange={handleSubTabValueChange}
                                aria-label="product tabs"
                                variant="scrollable"
                                scrollButtons="auto"
                              >
                                {[{ label: "SIP", value: "sip" }, { label: "Lumpsum", value: "lumpsum" }].map((val_, idx) => {
                                  return (
                                    <Tab key={idx} label={`${val_.label} (${cartList?.filter((i: any) => {
                                      return (val_.value == 'sip' ? i.TE_TRTYPE === val.trType2 : i.TE_TRTYPE == val.trType)
                                    }).length})`} value={val_.value} />
                                  )
                                })}
                              </TabList>
                            </Box>
                            <Divider />
                            <Box>
                              {[{ label: "SIP", value: "sip" }, { label: "Lumpsum", value: "lumpsum" }].map((val_) => {
                                return (
                                  <TabPanel value={val_.value} key={val_.value}>
                                    {cartList?.filter((i: any) => {
                                      return (val_.value == 'sip' ? i.TE_TRTYPE === val.trType2 : i.TE_TRTYPE == val.trType)
                                    }).length == 0 ?
                                      <Box sx={{ display: "flex", justifyContent: "center" }}>
                                        <Typography sx={{ color: "lightgrey", fontSize: 18, fontWeight: 500 }}>No schemes </Typography>
                                      </Box> :
                                      <div style={{height:"18.5rem",overflow:"scroll"}}>
                                        {cartList?.filter((i: any) => {
                                          return (val_.value == 'sip' ? i.TE_TRTYPE === val.trType2 : i.TE_TRTYPE == val.trType)
                                        }).map((ele: any, idx: number) => {
                                          return <><Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', cursor: 'pointer', my: { xs: 0, sm: 2.5 }, mx: { xs: 0, sm: 2 }, flexDirection: { xs: "column", sm: "row" }}}>

                                            <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", width: { xs: "100%", sm: "40%" } }}>
                                              <Box sx={{ width: '10%', mr: { xs: 3, sm: 5 } }}>
                                                <Checkbox sx={{ color: '#337FC9', mx: { xs: 0, sm: 2.5 } }}
                                                  onChange={(e: any) => { handleCartCheckboxChange(e, ele) }}
                                                  checked={checkedList.indexOf(ele.TE_IHNO.toString()) == -1 ? false : true}
                                                />
                                              </Box>
                                              <Box sx={{ marginRight: { xs: 0, sm: 4 }, display: 'flex', flexDirection: 'column', width: { xs: "80%", sm: "63%" }, ml: { xs: "1rem", sm: "2rem" } }}>

                                                <Typography sx={{ fontSize: { xs: 13, sm: 14 }, fontWeight: 500, mb: 0.5 }}>
                                                  {ele.SchDesc}
                                                </Typography>
                                                <Box sx={{ display: 'flex', mt: { xs: 1, sm: 2 }, width: "100%", flexWrap: "wrap" }}>
                                                  <Bubble text={ele.AssetClassName} />
                                                  <Bubble text={ele.Sub_AssetclassName} />
                                                  <Bubble text={ele.Schemeoption.charAt(0).toUpperCase() + ele.Schemeoption.substr(1).toLowerCase()} />
                                                </Box>
                                              </Box>
                                            </Box>
                                            <Box sx={{ display: "flex", alignItems: { xs: 'flex-start', sm: "center" }, justifyContent: "space-between", cursor: 'pointer', width: { xs: "100%", sm: "60%" }, mt: { xs: "0.5rem", sm: "0rem" }, ml: 0, mr: { xs: 2, sm: 0 } }}>
                                              <Box sx={{ width: { xs: "30%", sm: "35%" }, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                                                <Typography sx={{ fontSize: { xs: 12, sm: 14 }, color: 'grey', fontWeight: 400 }}>Amount</Typography>
                                                <Typography sx={{ fontSize: { xs: 12, sm: 16 }, color: "#011E33", fontWeight: 500, mt: 2 }}>

                                                  {`${formatToIndianCurrency(ele.TE_AMOUNT, ele.TE_AMOUNT < 10000 ? 0 : 1)}`}
                                                </Typography>
                                              </Box>
                                              <Box sx={{ width: { xs: "30%", sm: "20%" }, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                                                <Typography sx={{ fontSize: { xs: 12, sm: 14 }, color: 'grey', fontWeight: 400 }}>Date</Typography>
                                                <Typography sx={{ fontSize: { xs: 12, sm: 16 }, color: "#011E33", fontWeight: 500, mt: 2 }}>

                                                  {ele.TE_TRDATE.slice(0, 10)}
                                                </Typography>
                                              </Box>
                                              <Box sx={{ width: { xs: "30%", sm: "25%" }, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                                                <Typography sx={{ fontSize: { xs: 12, sm: 14 }, color: 'grey', fontWeight: 400 }}>Returns</Typography>
                                                <Typography sx={{ fontSize: { xs: 12, sm: 16 }, color: "green", fontWeight: 500, mt: 2 }}>

                                                  {`${Number(ele.Sch_Return1Yr).toFixed(2)}%`}
                                                </Typography>


                                              </Box>
                                              {/* <Box sx={{ width: "7%", display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                          <div
                          // onClick={() => { OnSchemeDeSelection(val.schemeId); }}
                          > <CardMedia
                              component="img"
                              src="/images/delete-icon.svg"
                              alt="delete"
                              sx={{ width: 34 }}
                            /></div>
                        </Box> */}
                                              <Divider />

                                              <Box sx={{ width: "7%", mr: { xs: 0, sm: "1rem" } }}>
                                                <div onClick={() => cartDelete(ele.TE_IHNO)}><DeleteIcon /></div>
                                              </Box>
                                            </Box>
                                          </Box>
                                            <Divider sx={{ my: { xs: 2, sm: 0 } }} />
                                          </>
                                        })}
                                      </div>}
                                  </TabPanel>
                                )
                              })}
                            </Box>
                          </TabContext>
                        </> :
                        //Tab for STP, SWP, Switch and redemption
                        <Box>
                          {cartList?.filter((i: any) => {
                            return (i.TE_TRTYPE == val.trType || i.TE_TRTYPE == val.trType2)
                          }).length === 0 ?
                            <Box sx={{ display: "flex", justifyContent: "center" }}>
                              <Typography sx={{ color: "lightgrey", fontSize: 18, fontWeight: 500 }}>No schemes</Typography>
                            </Box>
                            :
                            <>
                              {cartList?.filter((i: any) => {
                                return (i.TE_TRTYPE === val.trType || i.TE_TRTYPE == val.trType2)
                              }).map((ele: any) => {
                                return <><Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', cursor: 'pointer', my: { xs: 0, sm: 2.5 }, mx: { xs: 0, sm: 2 }, flexDirection: { xs: "column", sm: "row" } }}>

                                  <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between", width: { xs: "100%", sm: "40%" } }}>
                                    <Box sx={{ width: '10%', mr: { xs: 3, sm: 5 } }}>
                                      <Checkbox sx={{ color: '#337FC9', mx: { xs: 0, sm: 2.5 } }}
                                        checked={checkedList.indexOf(ele.TE_IHNO.toString()) == -1 ? false : true}
                                        // name={ele.TE_IHNO?.toString()} checked={checkedList?.ele.TE_IHNO?.toString() || false}
                                        // checked={((value == "New" && subVal == "sip") || (value == "Add" && subVal == "sip") || value == "STP" || value == "SWP") ?
                                        //   selectedValuesSIP.includes({
                                        //     order_id: ele.TE_IHNO.toString(),
                                        //     type: "sys"
                                        //   }) : selectedValuesLump.includes({
                                        //     order_id: ele.TE_IHNO.toString(),
                                        //     type: "Normal"
                                        //   })}
                                        onChange={(e: any) => { handleCartCheckboxChange(e, ele) }} />
                                    </Box>
                                    <Box sx={{ marginRight: { xs: 0, sm: 4 }, display: 'flex', flexDirection: 'column', width: { xs: "80%", sm: "63%" }, ml: { xs: "1rem", sm: "2rem" } }}>
                                      <Box sx={{ display: 'flex', flexDirection: 'column', }}>
                                        <Typography sx={{ fontSize: { xs: 13, sm: 14 }, fontWeight: 500, mb: 0.5 }}>
                                          {ele.SchDesc}
                                        </Typography>
                                      </Box>
                                      <Box sx={{ display: 'flex', mt: { xs: 1, sm: 2 }, width: "100%", flexWrap: "wrap" }}>
                                        {/* {!!fundItem.AssetClassName && ( */}
                                        <Bubble text={ele.AssetClassName} />
                                        {/* )} */}
                                        {/* {!!fundItem.Sub_AssetclassName && ( */}
                                        <Bubble text={ele.Sub_AssetclassName} />
                                        {/* )} */}
                                        {/* {!!plan && <Bubble text={plan} />}
            {subPlan.length !== 0 && <Bubble text={subPlan} />}
            {!!subPlan&&!!fundItem.Dividendfrequency && ( */}
                                        <Bubble text={ele.Schemeoption.charAt(0).toUpperCase() + ele.Schemeoption.substr(1).toLowerCase()} />
                                        {/* )} */}
                                      </Box>
                                    </Box>
                                  </Box>
                                  <Box sx={{ display: "flex", alignItems: { xs: 'flex-start', sm: "center" }, justifyContent: "space-between", cursor: 'pointer', width: { xs: "100%", sm: "60%" }, mt: { xs: "0.5rem", sm: "0rem" }, ml: 0, mr: { xs: 3, sm: 0 } }}>
                                    {ele.TE_AMOUNT ?
                                      <Box sx={{ width: { xs: "30%", sm: "35%" }, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                                        <Typography sx={{ fontSize: { xs: 11, sm: 14 }, color: 'grey', fontWeight: 400 }}>Amount</Typography>
                                        <Typography sx={{ fontSize: { xs: 11, sm: 16 }, color: "#011E33", fontWeight: 500, mt: 2 }}>

                                          {`${formatToIndianCurrency(ele.TE_AMOUNT, ele.TE_AMOUNT < 10000 ? 0 : 1)}`}
                                        </Typography>
                                      </Box>
                                      :
                                      <Box sx={{ width: { xs: "30%", sm: "35%" }, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                                        <Typography sx={{ fontSize: { xs: 11, sm: 14 }, color: 'grey', fontWeight: 400 }}>Units</Typography>
                                        <Typography sx={{ fontSize: { xs: 11, sm: 16 }, color: "#011E33", fontWeight: 500, mt: 2 }}>

                                          {ele.TE_UNITS}
                                        </Typography>
                                      </Box>
                                    }
                                    {val.trType === 'SWP' ?
                                      <Box sx={{ width: { xs: "30%", sm: "20%" }, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                                        <Typography sx={{ fontSize: { xs: 11, sm: 14 }, color: 'grey', fontWeight: 400 }}>Start Date</Typography>
                                        <Typography sx={{ fontSize: { xs: 11, sm: 16 }, color: "#011E33", fontWeight: 500, mt: 2 }}>

                                          {ele.TE_TRDATE.slice(0, 10)}
                                        </Typography>
                                      </Box>
                                      : <Box sx={{ width: { xs: "30%", sm: "20%" }, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                                        <Typography sx={{ fontSize: { xs: 11, sm: 14 }, color: 'grey', fontWeight: 400 }}>Date</Typography>
                                        <Typography sx={{ fontSize: { xs: 11, sm: 16 }, color: "#011E33", fontWeight: 500, mt: 2 }}>

                                          {ele.TE_TRDATE.slice(0, 10)}
                                        </Typography>
                                      </Box>
                                    }
                                    <Box sx={{ width: { xs: "30%", sm: "30%" }, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                                      <Typography sx={{ fontSize: { xs: 11, sm: 14 }, color: 'grey', fontWeight: 400 }}>Returns</Typography>
                                      <Typography sx={{ fontSize: { xs: 11, sm: 16 }, color: "green", fontWeight: 500, mt: 2 }}>

                                        {`${Number(ele.Sch_Return1Yr).toFixed(2)}%`}
                                      </Typography>

                                    </Box>
                                    <Box sx={{ width: "7%", mr: { xs: 0, sm: "1rem" } }}>
                                      <div onClick={() => cartDelete(ele.TE_IHNO)}><DeleteIcon /></div>
                                    </Box>

                                  </Box>
                                </Box>
                                  <Divider sx={{ my: { xs: 2, sm: 0 } }} />
                                </>
                              })}
                            </>
                          }

                        </Box>}

                    </TabPanel>

                  )}

                </Box>
              </TabContext>

              {/* Submit Button */}
              {/* <Divider sx={{ width: '90%', display: 'flex', margin: '0% 0% 0% 5%' }} /> */}
              <Box sx={{
                display: 'flex', justifyContent: 'center',
              }}>
                <LoadingButton
                  sx={{
                    background: 'linear-gradient(90deg,#0090FF,#1EB1F3,#0090FF)', fontSize: { xs: 12, sm: '16px' }, fontWeight: '600', mt: { xs: 0, sm: 0 }, mb: 2, width: '30%', p: { xs: 0.4, sm: 1.2 }, borderRadius: '10px', '& .MuiLoadingButton-loadingIndicator': {
                      color: "white",
                    }
                  }}
                  onClick={async () => {
                    const isValid = await validation();
                    if (isValid) {
                      handlePaymentClick()
                    }
                  }}

                  loading={loading}
                  variant="contained"
                >
                  Place Order
                </LoadingButton>
              </Box>
            </Box>}
          {/* <Grid
            item
            xs={12}
            md
            sx={{
              minHeight: '100vh',
              overflow: ['hidden', 'hidden', 'auto'],
              maxWidth: { md: showSidebar ? '100vw' : 'unset' },
            }}
          >
            {showSidebar && isMobileBreakpoint ? (
              <>
                <SideNavResponsive />

              </>
            ) : (
              <>
                <DashboardResponsiveHeader />

                <Box
                  sx={{
                    width: '100%',
                    height: '100%',
                    paddingTop: ['4rem', '4rem', 0],
                  }}
                >
                  <Outlet />
                </Box>
              </>
            )}

          </Grid> */}

        </Box>
      </Grid>

      {/* Dialogue to show failed orders */}
      <Dialog
        open={open}
        onClose={() => {
          setFailedOrderList([])
          setSuccessOrderList([])
          setOpen(false)
        }}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
        fullWidth
        maxWidth="md"
        sx={{height:{xs:"30rem",sm:"auto"},margin:"auto"}}
      >
        <DialogContent>
          {failedOrderList.map((value: any, index: any) => {
            return <Box key={index} sx={{ display: 'flex',flexDirection:{xs:"column",sm:"row"}, justifyContent: 'space-between', alignItems: 'center', cursor: 'pointer', my: {xs:3,sm:3.5}, mx: { xs: 0, sm: 2 }, mb: 0, borderLeft: "10px solid red", borderRight: "10px solid red" }}>
              <Box sx={{display:"flex",width:{xs:"100%"}}}>
              <Box sx={{ display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center", width: "30%", }}>
                <CancelOutlinedIcon fontSize="large" />
                <Typography sx={{ color: "red", fontWeight: 600, fontSize: 12 }}>Failed</Typography>
              </Box>
              <Box sx={{ marginRight: { xs: 0, sm: 15 }, display: 'flex', flexDirection: 'column', justifyContent: "center", width: { xs: "100%", sm: "45%" }, ml: "2rem" }}>
                <Typography sx={{ fontSize: { xs: 12, sm: 14 }, fontWeight: 500, mb: 0.5,mr:{xs:1,sm:0} }}>
                  {value.name}
                </Typography>
                <Box sx={{ display: 'flex', mt: { xs: 1, sm: 2 }, flexWrap: "wrap" }}>
                  <Bubble text={value.AssetClassName} />
                  <Bubble text={value.Sub_AssetclassName} />
                  <Bubble text={value.Schemeoption.charAt(0).toUpperCase() + value.Schemeoption.substr(1).toLowerCase()} />
                </Box>
              </Box>
              </Box>
              <Box sx={{ width: {xs:"100%",sm:"50%"}, display: 'flex', flexDirection: {xs:"row",sm:'column'}, alignItems: 'center',justifyContent:"center", mr: {xs:0,sm:4},ml:{xs:1,sm:0} }}>
                <Typography sx={{ fontSize: { xs: 11, sm: 13 }, color: '#011E33', fontWeight: 400 ,mt:{xs:2,sm:0}}}>Failure Reason</Typography>
                <Typography sx={{ fontSize: { xs: 10, sm: 13 }, color: "#011E33", fontWeight: 500, mt: 2 }}>
                  {value.failure_reason}
                </Typography>
              </Box>
            </Box>
          })}

          {successOrderList.map((value: any, index: any) => {
            return <Box key={index} sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', cursor: 'pointer', my: 2.5, mx: { xs: 0, sm: 2 }, borderLeft: "10px solid green", borderRight: "10px solid green" }}>
              <Box sx={{ display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center", width: "30%", }}>
                <CheckCircleOutlineOutlinedIcon fontSize="large" />
                <Typography sx={{ color: "green", fontWeight: 600, fontSize: 12 }}>Success</Typography>
              </Box>
              <Box sx={{ marginRight: { xs: 0, sm: 15 }, display: 'flex', flexDirection: 'column', justifyContent: "center", width: { xs: "100%", sm: "45%" }, ml: "2rem" }}>
                <Typography sx={{ fontSize: { xs: 12, sm: 14 }, fontWeight: 500, mb: 0.5 }}>
                  {value.name}
                </Typography>
                <Box sx={{ display: 'flex', mt: { xs: 1, sm: 2 }, flexWrap: "wrap" }}>
                  <Bubble text={value.AssetClassName} />
                  <Bubble text={value.Sub_AssetclassName} />
                  <Bubble text={value.Schemeoption.charAt(0).toUpperCase() + value.Schemeoption.substr(1).toLowerCase()} />
                </Box>
              </Box>
              <Box sx={{ width: "50%", display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
              </Box>
            </Box>
          })}
        </DialogContent>

        <DialogActions>
          <Button onClick={() => {
            setFailedOrderList([])
            setSuccessOrderList([])
            setOpen(false)
          }}>Ok</Button>
        </DialogActions>
      </Dialog>

      {/* Dialogue to validation result for redeem orders */}
      <Dialog
        open={redemptionValidationResultMsg.length != 0}
        onClose={() => {
          setRedemptionValidationResultMsg([]);
        }}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
        fullWidth
        maxWidth="sm"
      >
        <DialogContent>
          {redemptionValidationResultMsg.map((value: redeemValidationFailureMsgType, index: any) => {
              return <Box key={index} sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', cursor: 'pointer', my: 2.5, mx: 2,mb:0 }}>
                <Box sx={{ display: 'flex', flexDirection: 'row', width: "100%" }}>
                  <Typography sx={{ fontSize: 15, fontWeight: 500, mb: 0.5 }}>
                    {`${value.schemeName} :`}
                  </Typography>
                  <Typography sx={{ fontSize: 14, fontWeight: 300, mb: 0.5, ml: 1 }}>
                    {value.failMessage}
                  </Typography>
                </Box>
                <Divider />
              </Box>
          })}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => {
            setRedemptionValidationResultMsg([]);
            setselectedValuesLump([])
            setCheckedList([])
          }}>Ok</Button>
        </DialogActions>
      </Dialog>
    </Box>
  )
}
