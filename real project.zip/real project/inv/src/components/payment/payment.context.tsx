import { createContext, ReactElement, useContext, useState } from 'react';
import { useRootContext } from '../data/root.context';
import { get_cart, get_profile_data, get_user_details, insert_tansaction_otp, place_order, tansactionOTPPayload, placeOrderPayload, register_mandate, registerMandatePayload, delete_cart, deleteCartPayload, redeem_validation, redeemValidationPayload } from '../../api/payment';

export type GetCartType = {
    cart_details: [GetCart[]];
}

export type GetPofileDataType = {
    profile_data: GetProfileData
}

export type GetUserDetailsType = {
    user_details: GetUserDetails
}

export type InsertTansactionOTP = {
    message: string
}

export type placeOrderResponse = {
    bse_order: orderDetails[]
}

export type registerMandateResponse = {
    imandate_details : any
}

export type deleteCartResponse = {
    deleteCart: any
}

export type orderDetails = {
    order_id: string,
    order_status: string,
    order_success: boolean,
    bse_order_id: string,
    type: string,
    order_data_params: any
}

export type GetProfileData = {
    basic_details: any,
    jh_details: any,
    nominee_details: any,
    bank_details: any,
    bank_credit_details: any,
    guardian_details: any,
}

export type GetUserDetails = {
    clientId: string,
    authenticated: boolean,
    name: string,
    isHead: boolean,
    familyName: null,
    familyData: any,
    purpose: string,
    ID: number,
    is_email_verified: boolean,
    is_phone_verified: boolean,
    login_date: string,
    login_pin: null,
    password: string,
    pan: string,
    email_id: string,
    phone_number: string,
    client_regid: string,
    is_kyc_verified: boolean,
    risk_score: null,
    risk_status: null,
    profile_pic: null,
    CAccountNo: string,
    cancel_cheque: null,
    signature: null,
    kyc_id: null,
    otp_session_id: string,
    is_user_onboarded: true,
    email_otp_token: null,
    onboarding_status: string,
    device_token: null,
    cigr_percentage: null,
    aum: string,
    is_head_family: boolean,
    is_child: boolean,
    complete_percentage: number,
    family: null,
    family_status: number,
    risk_analysed_on: null,
    is_notification_send: null,
    is_active: null,
    otp: string,
    family_name: null,
    force_pwd_change: false,
    AccountID: string,
    iat: number,
    exp: number,
    status: string
}

export type GetCart = {
    TE_IHNO: number,
    TE_CMID: string,
    InvName: string,
    RegRefNo: number,
    TE_SCHID: number,
    SchDesc: string,
    ToSchDesc: string,
    TE_ACNO: string,
    TE_TRDATE: string,
    TE_TRTYPE: string,
    TE_UNITS: string,
    TE_AMOUNT: number,
    TE_BRKAMT: number,
    TE_SERVICETAX: number,
    TE_ApplNo: string,
    TE_Active: string,
    TE_EntryBy: string,
    TE_ImagePath: string,
    TE_ToSchId: string,
    Schemeoption: string,
    AssetClassName: string,
    Sub_AssetclassName: string,
    RMID: string,
    AMCID: number,
    AMCCODE: string,
    USERCODE: string,
    IMG_NAME: string,
    IMG_PATH: string,
    CLIENTCODE: string,
    GCGFlag: string,
    RevFeedFlag: string,
    TailWindRec: string,
    FirstOrderToday: string,
    Approve: string,
    Sch_Return1Yr: string,
    Installments: string,
    InvIdeaID: number,
    Idea: string,
    GoalID: number,
    GoalName: string
}

export type redeemValidationType = {
    msg: string,
    Acno: string,
    Schid: number,
    SchName: string,
    Units: number,
    Nav: number,
    Amount: number,
    ProductRTACode: string,
    Option: string,
    ErrorCode: string
}
export type redeemValidationResponse = {
   redVal: [[redeemValidationType]]
}

const Payment = createContext<{
    getCart?: GetCart[];
    getCartDetails(): void;
    profieData(): void,
    getUserDetails?: GetUserDetails,
    userDetails(): void,
    transactionOTP(requestOptions: tansactionOTPPayload): Promise<any>
    placeOrder(requestOptions: placeOrderPayload): Promise<any>,
    registerMandate(requestOptions: registerMandatePayload): Promise<any>,
    deleteCart(requestOptions: deleteCartPayload): Promise<any>
    redemptionValidation(requestOptions: redeemValidationPayload): Promise<any>

}>({
    getCart: undefined,
    getCartDetails: () => { },
    profieData: () => { },
    getUserDetails: undefined,
    userDetails: () => { },
    transactionOTP: () => new Promise(() => { }),
    placeOrder: () => new Promise(() => { }),
    registerMandate: () => new Promise(() => { }),
    deleteCart: () => new Promise(() => { }),
    redemptionValidation: () => new Promise(()=>{})
});

export function usePaymentContext() {
    return useContext(Payment);
}

export const PaymentContext = ({ children }: { children: any }) => {
    const [getCart, setGetCart] = useState<GetCart[]>()
    const [getUserDetails, setUserDetails] = useState<GetUserDetails>()
    const { showToast } = useRootContext();


    async function getCartDetails() {
        return get_cart()
            .then(({ cart_details: cartValues }) => {
                setGetCart(cartValues[0])
                return cartValues[0]
            })
            .catch((e) => {
                showToast((e?.messasge || 'Not found'), 'error');
            })
            .finally(() => { });
    }

    async function profieData() {
        return get_profile_data()
            .then(({ profile_data: profile }) => {
                // console.log("profie data", profile)
                return profile
            })
            .catch((e) => {
                showToast((e?.messasge || 'Not found'), 'error');
            })
            .finally(() => { });
    }

    async function userDetails() {
        return get_user_details()
            .then(({ user_details: userData }) => {
                // console.log("userData value", userData)
                // setProfieData(profile)
                return userData
            })
            .catch((e) => {
                showToast((e?.messasge || 'Not found'), 'error');
            })
            .finally(() => { });
    }

    async function transactionOTP(payload: tansactionOTPPayload) {
        return insert_tansaction_otp(payload)
            .then(({ message: response }) => {
                return response
            })
            .catch((e) => {
                showToast((e?.messasge || 'Not found'), 'error');
            })
            .finally(() => { });
    }

    async function placeOrder(payload: placeOrderPayload) {
        return place_order(payload)
            .then(({ bse_order: response }) => {
                return response
            })
            .catch((e) => {
                showToast((e?.messasge || 'Not found'), 'error');
            })
            .finally(() => { });
    }

    async function registerMandate(payload: registerMandatePayload) {
        return register_mandate(payload)
            .then(({imandate_details : response }) => {
                // console.log("response for register mandate", response)
                return response
            })
            .catch((e) => {
                showToast((e?.messasge || 'Not found'), 'error');
            })
            .finally(() => { });
    }

    async function deleteCart(payload: deleteCartPayload) {
        return delete_cart(payload)
            .then(({ deleteCart: response }) => {
                // console.log("response for delete_cart", response)
                return response
            })
            .catch((e) => {
                showToast((e?.messasge || 'Not found'), 'error');
            })
            .finally(() => { });
    }

    async function redemptionValidation(payload: redeemValidationPayload) {
        return redeem_validation(payload)
            .then(({redVal:response}) => {
                return response[0][0]
            })
            .catch((e) => {
                showToast((e?.messasge || 'Not found'), 'error');
            })
            .finally(() => { });
    }

    return (
        <Payment.Provider
            value={{
                getCart, getCartDetails, profieData, getUserDetails, userDetails, transactionOTP, placeOrder, registerMandate, deleteCart, redemptionValidation
            }}>
            {children}
        </Payment.Provider>
    );
}


