import { createContext, ReactElement, useContext, useState } from 'react';

import { profileRequest } from '../../../api/profile';
import { useRootContext } from '../../data/root.context';

type ProfilePersonalDetails = {
  fullName: string;
  fatherSpouseName: string;
  maritalStatus: string;
  gender: string;
  occupationType: string;
  status: string;
};

type ContactInfo = {
  fullName: string;
  emailBelongsTo: string;
  mobile: string;
  mobileBelongsTo: string;
  relationship: any;
  kraMobileNumber: string;
  phoneOffice: string;
  phoneResidential: string;
};
type PermanentAddressDetails = {
  addrLine1: string;
  addrLine2: string;
  addrLine3: any;
  pincode: any;
  city: any;
  state: any;
  country: any;
};

type ContactDetails = {
  contactInfo: ContactInfo;
  correspondenceAddr: any;
  permanentAddr: PermanentAddressDetails;
};

type BankDetails = {
  ifscCode: string;
  acNum: string;
  micrCode: string;
  bankType: string;
  bankName: string;
  branchName: string;
  address: any;
};

export type Profile = {
  additionalKyc: any;
  bankDetails: BankDetails;
  personalInformation?: ProfilePersonalDetails;
  contactDetails: ContactDetails;
  fatcaDeclaration: any;
  riskProfileDetails: {
    riskProfile: string;
  };
  nomineeDetails: any;
  guardianDetails: any;
};

const ProfileData = createContext<{
  loading: boolean;
  profile?: Profile;
  getProfileDetails(clientId: string): void;
}>({
  loading: true,
  profile: undefined,
  getProfileDetails: () => {},
});

export function useProfileData() {
  return useContext(ProfileData);
}
export function ProfileDataProvider({ children }: { children: ReactElement }) {
  const [profile, setProfile] = useState<Profile>();
  const [loading, setLoading] = useState(true);
  const { showToast } = useRootContext();

  async function getProfileDetails(clientId: string) {
    return profileRequest(clientId)
      .then(({ profileDetails: profile }) => setProfile(profile))
      .catch((e) => {
        showToast('User details: ' + (e?.messasge || 'Not found'), 'error');
      })
      .finally(() => setLoading(false));
  }
  return (
    <ProfileData.Provider value={{ profile, loading, getProfileDetails }}>
      {children}
    </ProfileData.Provider>
  );
}
