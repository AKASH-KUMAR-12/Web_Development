import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import {
  Box,
  Divider,
  FormControl,
  FormControlLabel,
  LinearProgress,
  Paper,
  Radio,
  RadioGroup,
  Stack,
  styled,
  Typography,
} from '@mui/material';
import Menu, { MenuProps } from '@mui/material/Menu';
import { Form, Formik, FormikProps, useField, useFormikContext } from 'formik';
import { useEffect, useRef, useState } from 'react';
import { Outlet, useMatch } from 'react-router-dom';

import { AnimatedBox, SectionLinkItem } from '../common';
import { useLoginContext } from '../login/data/login.context';
import { useProfileData } from './data/profile-context';
import AdditionalKYC from './icons/additional-kyc';
import BankDetailsIcon from './icons/bank-details';
import ContactDetailsIcon from './icons/contact-details';
import DocumentsIcon from './icons/documents';
import FatcaDeclarationIcon from './icons/fatca-declaration';
import NomineeDetailsIcon from './icons/nominee-details';
import PersonDetailsIcon from './icons/person-details';
import PersonalInfoIcon from './icons/personal-info';
// import RiskProfileIcon from './icons/risk-profile';
import UpdatePasswordIcon from './icons/update-password';

export const ProfileLeftLayout = styled(Box)(({ theme }) => ({
  width: '50%',
  padding: theme.spacing(0, 3),
  [theme.breakpoints.down('md')]: {
    display: 'none',
  },
}));

const StyledMenu = styled(Menu)(({ theme }) => ({
  marginTop: theme.spacing(2),
  '& .MuiMenu-list': {
    margin: theme.spacing(1, 6, 4, 1),
    padding: `${theme.spacing(2, 4)}`,
  },
}));

const ProfileMenuLabel = styled(Stack)(({ theme }) => ({
  backgroundColor: theme.palette.primary.light,
  boxShadow: theme.shadows[24],
  borderRadius: 40,
  padding: theme.spacing(1, 2),
}));

const HeaderText = styled(Typography)(({ theme }) => ({
  fontSize: 14,
  fontWeight: 400,
  textTransform: 'uppercase',
  letterSpacing: '0.01em',
  padding: theme.spacing(0.6, 2.5),
  cursor: 'pointer',
}));

const ProfileMenu = ({
  name,
  options,
  onClose,
  ...props
}: MenuProps & { name: string; options: Array<{ label: string; value: string }> }) => {
  const [field, meta, { setValue }] = useField(name);
  const errorText = meta.error && meta.touched ? meta.error : '';
  const { submitForm } = useFormikContext();
  const hasError = !!errorText;

  const handleClose = (e: any) => {
    submitForm();
    onClose && onClose(e, 'backdropClick');
  };

  return (
    <StyledMenu
      {...props}
      onClose={handleClose}
      transformOrigin={{ horizontal: 'right', vertical: 'top' }}
      anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
      PaperProps={{
        sx: {
          background: 'primary.light',
          boxShadow: '0px -1px 34px rgba(13, 13, 32, 0.33)',
          borderRadius: '10px',
          fontWeight: '400',
          fontSize: '14px',
          lineHeight: '16px',
          letterSpacing: '0.01em',
          textTransform: 'uppercase',
        },
      }}
    >
      <FormControl error={hasError}>
        <RadioGroup
          value={field.value}
          onChange={(e) => {
            setValue(e.target.value);
            handleClose(e);
          }}
        >
          {options.map(({ value, label }: any) => (
            <FormControlLabel
              key={value}
              value={value}
              label={label}
              control={<Radio size="small" />}
            />
          ))}
        </RadioGroup>
      </FormControl>
    </StyledMenu>
  );
};

export default function ProfileLayout() {
  const { loading, getProfileDetails } = useProfileData();
  const { userDetails: user } = useLoginContext();

  let options: { label: string; value: string }[] = [
    { label: 'Initial', value: 'initial' },
  ];
  if (user?.familyData) {
    options =
      user?.familyData.map(({ InvName, clientId }) => ({
        value: clientId,
        label: InvName,
      })) || [];
  }

  const [selectedFamilyMember, setSelectedFamilyMember] = useState<string>(
    user?.clientId || '',
  );

  const menuLabelRef = useRef(null);
  const [profileMenuAnchorEl, setProfileMenuAnchorEl] = useState<null | HTMLElement>(
    menuLabelRef.current,
  );
  const profileMenuOpen = Boolean(profileMenuAnchorEl);

  const [transitionClassName, setTransitionClassName] = useState('');
  const match = useMatch('profile/*');
  const leadingPath = match?.params['*']?.split('/').pop();

  useEffect(() => {
    if (selectedFamilyMember) {
      getProfileDetails(selectedFamilyMember);
    }
  }, [selectedFamilyMember]);

  useEffect(() => {
    setTransitionClassName('slideInUp');
    const timeoutId = setTimeout(() => {
      setTransitionClassName('');
    }, 300);
    return () => {
      clearTimeout(timeoutId);
    };
  }, [leadingPath]);

  if (loading) {
    return <LinearProgress />;
  }

  return (
    <>
      {/* UI for profile start*/}
      <Box
        sx={{
          width: ['96%', '96%', '88%'],
          margin: 'auto',
          pt: ['12px', '12px', 5],
          pb: ['12px', '12px', '60px'],
          boxSizing: 'border-box',
        }}
      >
        <Stack
          direction="row"
          justifyContent="space-between"
          alignItems="flex-end"
          sx={{ mb: 3.5, display: ['none', 'none', 'flex'] }}
        >
          <Typography
            sx={{
              color: 'text.secondary',
              fontSize: '22px',
              fontWeight: 500,
              lineHeight: '26px',
              letterSpacing: '0.06em',
            }}
          >
            PROFILE
          </Typography>
          {user?.isHead && user?.familyData?.length ? (
            <Formik
              initialValues={{ selectedFamilyMember: selectedFamilyMember }}
              onSubmit={({ selectedFamilyMember }: { selectedFamilyMember: string }) => {
                setSelectedFamilyMember(selectedFamilyMember);
              }}
            >
              <Form>
                <ProfileMenuLabel
                  ref={menuLabelRef}
                  direction="row"
                  justifyContent="space-between"
                  alignItems="center"
                  onClick={(e) => {
                    setProfileMenuAnchorEl(e.currentTarget);
                  }}
                >
                  <img src="/images/family-group.svg" alt="family group" />
                  <HeaderText>
                    {
                      options.find((option) => option.value === selectedFamilyMember)
                        ?.label
                    }
                  </HeaderText>
                  <ExpandMoreIcon />
                </ProfileMenuLabel>
                <ProfileMenu
                  name="selectedFamilyMember"
                  open={profileMenuOpen}
                  options={options}
                  anchorEl={profileMenuAnchorEl}
                  onClose={() => setProfileMenuAnchorEl(null)}
                />
              </Form>
            </Formik>
          ) : null}
        </Stack>
        <Paper
          sx={{
            p: 3,
            backgroundColor: 'primary.light',
            boxShadow: 24,
            borderRadius: '10px',
            mt: [1, 1, 0],
          }}
        >
          <Stack direction="row" sx={{ width: '100%' }}>
            <ProfileLeftLayout>
              <SectionLinkItem
                to="personal-information"
                title="Personal Information"
                icon={<PersonalInfoIcon />}
              />
              <SectionLinkItem
                to="nominee"
                title="Details of Related Person"
                icon={<PersonDetailsIcon />}
              />
              <SectionLinkItem
                to="contact-details"
                title="Contact Details"
                icon={<ContactDetailsIcon />}
              />
              <SectionLinkItem
                to="additional-kyc"
                title="Additional KYC"
                icon={<AdditionalKYC />}
              />
              <SectionLinkItem
                to="nominee-details"
                title="Nominee Details"
                icon={<NomineeDetailsIcon />}
              />
              <SectionLinkItem
                to="fatca-declaration"
                title="FATCA Declaration"
                icon={<FatcaDeclarationIcon />}
              />
              {/* <SectionLinkItem
                to="risk-profile"
                title="Risk profile"
                icon={<RiskProfileIcon />}
              /> */}
              <SectionLinkItem
                to="bank-details"
                title="Bank details"
                icon={<BankDetailsIcon />}
                isLast
              />
              {/* <SectionLinkItem
                to="documents"
                title="Documents"
                icon={<DocumentsIcon />}
              />
              <SectionLinkItem
                to="update-password"
                title="Update Password"
                icon={<UpdatePasswordIcon />}
              /> */}
            </ProfileLeftLayout>
            <Divider
              orientation="vertical"
              light
              sx={{
                borderWidth: '1px',
                borderColor: 'text.dividerLight',
                mr: 1,
                ml: 2,
                display: ['none', 'none', 'flex'],
              }}
              flexItem
            />
            <AnimatedBox
              sx={{ width: '100%', px: [0, 0, 3], pt: [0, 0, 3], pb: 3 }}
              className={transitionClassName}
            >
              <Outlet />
            </AnimatedBox>
          </Stack>
        </Paper>
      </Box>
      {/* UI for profile end */}
    </>
  );
}
