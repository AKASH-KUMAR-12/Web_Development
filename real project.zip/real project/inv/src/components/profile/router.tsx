import { Navigate, Route, Routes } from 'react-router-dom';

import { ProfileDataProvider } from './data/profile-context';
import ProfileLayout from './layout';
import AdditionalKYC from './sections/additional-kyc';
import BankDetails from './sections/bank-details';
import ContactDetails from './sections/contact-details';
import Documents from './sections/documents';
import FatcaDeclaration from './sections/fatca-declaration';
import Nominee from './sections/nominee';
import NomineeDetails from './sections/nominee-details';
import PersonalDetails from './sections/personal-information';
import UpdatePassword from './sections/update-password';
// import RiskProfile from './sections/risk-profile';

export default function ProfileRoutes() {
  return (
    <ProfileDataProvider>
      <Routes>
        <Route path="" element={<ProfileLayout />}>
          <Route index element={<Navigate to="personal-information" />} />
          <Route path="personal-information" element={<PersonalDetails />} />
          <Route path="nominee" element={<Nominee />} />
          <Route path="contact-details" element={<ContactDetails />} />
          <Route path="additional-kyc" element={<AdditionalKYC />} />
          <Route path="nominee-details" element={<NomineeDetails />} />
          <Route path="fatca-declaration" element={<FatcaDeclaration />} />
          {/* <Route path="risk-profile" element={<RiskProfile />} /> */}
          <Route path="bank-details" element={<BankDetails />} />
          <Route path="documents" element={<Documents />} />
          <Route path="update-password" element={<UpdatePassword />} />
        </Route>
      </Routes>
    </ProfileDataProvider>
  );
}
