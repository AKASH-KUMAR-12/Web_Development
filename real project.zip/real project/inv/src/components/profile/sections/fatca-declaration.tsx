import { useProfileData } from '../data/profile-context';
import { ProfileItem, SectionDetails, SectionHeading, SectionTitle } from './common';

export default function FatcaDeclaration() {
  const { profile } = useProfileData();
  const info = profile?.fatcaDeclaration;
  return (
    <>
      <SectionTitle text="FATCA DECLARATION" />
      <SectionHeading text="FATCA Details of First/Sole Applicant" />
      <SectionDetails>
        <ProfileItem
          title="Type of Address Provided At KRA *"
          description={info?.address_type || 'N/A'}
        />
        <ProfileItem
          title="Tax Resident of any country other than India *"
          description={info?.other_than_india.toUpperCase() || 'N/A'}
        />
        <ProfileItem title="Place of Birth *" description={info?.birth_place || 'N/A'} />
        <ProfileItem
          title="Country of Birth *"
          description={info?.birth_country || 'N/A'}
        />
        <ProfileItem
          title="Country of Nationality *"
          description={info?.nationality || 'N/A'}
        />
      </SectionDetails>
    </>
  );
}
