import { Box, Stack, Typography } from '@mui/material';
import { useEffect, useState } from 'react';

import RiskoMeterGaugeChart from '../components/RiskoMeter';
import { useProfileData } from '../data/profile-context';
import { SectionTitle } from './common';

export default function RiskProfile() {
  const { profile } = useProfileData();
  const {
    riskProfileDetails: { riskProfile },
  } = profile!;

  const getRiskLevel = (value: string) => {
    switch (value) {
      case 'Aggressive':
        return 4;
      case 'Balanced':
        return 2;
      case 'Cautious':
        return 1;
      case 'Conservative':
        return 0;
      default:
        return 3;
    }
  };

  return (
    <>
      <SectionTitle text="RISK PROFILE" />
      <Stack alignItems={'center'}>
        <RiskoMeterGaugeChart level={getRiskLevel(riskProfile)} />
      </Stack>
      <Box
        sx={{
          bgcolor: 'background.default',
          borderRadius: '10px',
          py: 1,
          px: 2,
          textAlign: 'center',
          width: '50%',
          margin: '20px auto',
        }}
      >
        <Typography sx={{ fontSize: 18, color: 'text.riskLabelText' }}>
          Your risk profile :{' '}
          <span style={{ color: 'error.light', fontWeight: 500 }}>{riskProfile}</span>
        </Typography>
      </Box>
    </>
  );
}
