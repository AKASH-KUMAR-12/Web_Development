import { Box, Stack, styled, Typography } from '@mui/material';

const labelHeadText = {
  color: '#4F4F4F',
  fontSize: '14px',
  fontWeight: 400,
  letterSpacing: '0.05em',
};
const labelBodyText = {
  ...labelHeadText,
  fontWeight: 600,
};
const labelCaptionText = {
  ...labelBodyText,
  fontSize: '12px',
  fontWeight: 500,
};

export function ProfileItem({
  title,
  description,
  caption,
}: {
  title: string;
  description: string;
  caption?: string;
}) {
  return (
    <Stack spacing={0.5}>
      <Typography sx={labelHeadText}>{title}</Typography>
      <Typography sx={labelBodyText}>{description}</Typography>
      <Typography sx={labelCaptionText}>{caption}</Typography>
    </Stack>
  );
}

export function SectionTitle({ text }: { text: string }) {
  return (
    <Typography
      sx={{
        color: 'text.secondary',
        fontSize: '16px',
        fontWeight: 500,
        lineHeight: '19px',
        letterSpacing: '0.06em',
        ml: 2.5,
        display: ['none', 'none', 'block'],
      }}
    >
      {text}
    </Typography>
  );
}

export function SectionHeading({ text }: { text: string }) {
  return (
    <Box
      sx={{
        py: '14px',
        px: [2, 2, 2.5],
        bgcolor: ['primary.light', 'primary.light', 'background.default'],
        mt: [0, 0, 3],
        mb: [0, 0, 3],
      }}
    >
      <Typography
        sx={{
          color: 'text.sectionLabel',
          fontSize: '14px',
          fontWeight: 600,
          letterSpacing: '0.9625px',
        }}
      >
        {text}
      </Typography>
    </Box>
  );
}

export const SectionDetails = styled(Box)(({ theme }) => ({
  display: 'grid',
  gridTemplateColumns: '1fr 1fr',
  gridColumnGap: '4rem',
  gridRowGap: '2rem',
  padding: theme.spacing(1, 3),
  [theme.breakpoints.down('md')]: {
    gridTemplateColumns: '1fr',
    padding: theme.spacing(2),
  },
}));
