import { useProfileData } from '../data/profile-context';
import { ProfileItem, SectionDetails, SectionHeading, SectionTitle } from './common';

export default function NomineeDetails() {
  const { profile } = useProfileData();
  const nominee = profile?.nomineeDetails;
  return (
    <>
      <SectionTitle text="Nominee Details" />
      <SectionHeading text="Nominee Name 1" />
      <SectionDetails>
        <ProfileItem
          title="Nominee Name 1"
          description={nominee?.nominee_name_1 || 'N/A'}
        />
        <ProfileItem
          title="Nominee Relationship"
          description={nominee?.nominee_relationship || 'N/A'}
        />
        <ProfileItem title="Date of Birth" description={nominee?.dob || 'N/A'} />
        <ProfileItem
          title="Nominee %"
          description={nominee?.nominee_percentage || 'N/A'}
        />
      </SectionDetails>
    </>
  );
}
