import { Box } from '@mui/material';
import { Form, Formik } from 'formik';

import SubmitButton from '../../forms/FormSubmitButton';
import { FormPasswordInput } from '../../forms/FormTextInput';
import { SectionTitle } from './common';

function UpdatePassword() {
  return (
    <>
      <SectionTitle text="UPDATE PASSWORD" />
      <Box
        sx={{
          bgcolor: 'background.default',
          borderRadius: '10px',
          marginTop: 2,
          padding: ['2rem', '2rem', '4rem'],
          height: ['auto', 'auto', '80%'],
        }}
      >
        <Box sx={{ width: ['100%', '100%', '80%'] }}>
          <Formik initialValues={{ currentPassword: '' }} onSubmit={() => {}}>
            <Form>
              <FormPasswordInput
                name="currentPassword"
                label={'Current Password'}
                placeholder="Enter your current password"
              />
              <Box sx={{ mt: 2 }}>
                <SubmitButton label="Change Password" />
              </Box>
            </Form>
          </Formik>
        </Box>
      </Box>
    </>
  );
}

export default UpdatePassword;
