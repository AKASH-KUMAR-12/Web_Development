import { useProfileData } from '../data/profile-context';
import { ProfileItem, SectionDetails, SectionHeading, SectionTitle } from './common';

export default function BankDetails() {
  const { profile } = useProfileData();
  const bankDetails = profile?.bankDetails;
  return (
    <>
      <SectionTitle text="BANK DETAILS" />
      <SectionHeading text="First Bank Account Details" />
      <SectionDetails>
        <ProfileItem title="IFSC Code*" description={bankDetails?.ifscCode || 'N/A'} />
        <ProfileItem
          title="Bank Account Number*"
          description={bankDetails?.acNum || 'N/A'}
        />
        <ProfileItem title="IMCR Code" description={bankDetails?.micrCode || 'N/A'} />
        <ProfileItem title="Bank type" description={bankDetails?.bankType || 'N/A'} />
        <ProfileItem title="Bank name" description={bankDetails?.bankName || 'N/A'} />
        <ProfileItem title="Branch name" description={bankDetails?.branchName || 'N/A'} />
        <ProfileItem title="Bank Address" description={bankDetails?.address || 'N/A'} />
      </SectionDetails>
    </>
  );
}
