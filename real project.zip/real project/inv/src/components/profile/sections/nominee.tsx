import { useProfileData } from '../data/profile-context';
import { ProfileItem, SectionDetails, SectionHeading, SectionTitle } from './common';

export default function Nominee() {
  const { profile } = useProfileData();
  const nominee = profile?.guardianDetails;
  return (
    <>
      <SectionTitle text="DETAILS OF RELATED PERSON" />
      <SectionHeading text="Details of Related Person of First/Sole Applicant" />
      <SectionDetails>
        <ProfileItem title="Full Name*" description={nominee?.full_name || 'N/A'} />
        <ProfileItem
          title="Relationship Type*"
          description={nominee?.relationship_type || 'N/A'}
        />
        <ProfileItem title="Date of Birth*" description={nominee?.dob || 'N/A'} />
        <ProfileItem title="PAN" description={nominee?.PAN || 'N/A'} />
      </SectionDetails>
    </>
  );
}
