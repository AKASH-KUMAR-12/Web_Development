import { useProfileData } from '../data/profile-context';
import { ProfileItem, SectionDetails, SectionHeading, SectionTitle } from './common';

export default function PersonalDetails() {
  const { profile } = useProfileData();
  const info = profile?.personalInformation;
  return (
    <>
      <SectionTitle text="PERSONAL INFORMATION" />
      <SectionHeading text="Personal Details of First/Sole Applicant" />
      <SectionDetails>
        <ProfileItem title="Full Name*" description={info?.fullName || 'N/A'} />
        <ProfileItem
          title="Father/Spouse Name*"
          description={info?.fatherSpouseName || 'N/A'}
        />
        <ProfileItem
          title="Marital Status *"
          description={info?.maritalStatus || 'N/A'}
        />
        <ProfileItem title="Gender" description={info?.gender || 'N/A'} />
        <ProfileItem
          title="Occupation Type *"
          description={info?.occupationType || 'N/A'}
        />
        <ProfileItem title="Status*" description={info?.status || 'N/A'} />
      </SectionDetails>
    </>
  );
}
