import { capitalizeFirstLetter, numberToWords } from '../../../lib/helper';
import { useProfileData } from '../data/profile-context';
import { ProfileItem, SectionDetails, SectionHeading, SectionTitle } from './common';

export default function AdditionalKYC() {
  const { profile } = useProfileData();
  const kyc = profile?.additionalKyc;
  return (
    <>
      <SectionTitle text="ADDITIONAL KYC" />
      <SectionHeading text="Additional KYC Details of First/Sole Applicant" />
      <SectionDetails>
        <ProfileItem
          title="Gross Annual Income (in INR) *"
          description={kyc?.gross_income || 'N/A'}
        />
        <ProfileItem
          title="Gross Annual income as on date*"
          description={kyc?.gross_income_as_on_date || 'N/A'}
        />
        <ProfileItem
          title="Net-worth (in INR)*"
          description={kyc?.net_worth || 'N/A'}
          caption={capitalizeFirstLetter(numberToWords(kyc?.net_worth || 'N/A'))}
        />
        <ProfileItem
          title="Net worth as on date*"
          description={kyc?.net_worth_as_on_date || 'N/A'}
        />
        <ProfileItem
          title="Politically Exposed Person (PEP) Status *"
          description={kyc?.pep_status || 'N/A'}
        />
        <ProfileItem title="CKYC Number" description={kyc?.CKYC_number || 'N/A'} />
      </SectionDetails>
    </>
  );
}
