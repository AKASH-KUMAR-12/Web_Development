import { Box, Button, Stack, Typography } from '@mui/material';
import { Form, Formik } from 'formik';

import FormMultiSelect from '../../forms/FormMultiSelect';
import { SectionTitle } from './common';

export default function Documents() {
  return (
    <>
      <SectionTitle text="DOCUMENTS" />
      <Box
        sx={{
          borderRadius: 1,
          padding: '1rem 3rem',
          mt: 2,
          bgcolor: 'background.default',
        }}
      >
        <Stack>
          <Typography
            sx={{
              color: 'text.primary',
              fontSize: '14px',
              fontWeight: 400,
              lineHeight: '22px',
              letterSpacing: '0.01em',
            }}
          >
            You are requesting onboarding form
          </Typography>
          {/* <Formik onSubmit={() => {}} initialValues={{ documents: [] }}>
            <Form>
              <FormMultiSelect
                name={'documents'}
                options={[
                  { label: 'OVERALL FAMILY', value: 'family' },
                  { label: 'Neha Thapar', value: 'neha-thapar' },
                  { label: 'Vinay Thapar', value: 'vinay-thapar' },
                  { label: 'Vijayendra Thapar', value: 'vijayendra-thapar' },
                ]}
                placeholder={'Select Investor'}
                sx={{ width: '25rem' }}
              />
            </Form>
          </Formik> */}
        </Stack>
      </Box>
      <Stack justifyContent="center" alignItems="center" sx={{ m: 2 }}>
        <Button
          variant="contained"
          color="primary"
          sx={{
            padding: '10px 20px',
            boxShadow: 23,
            borderRadius: '8px',
            color: 'primary.light',
            textTransform: 'capitalize',
            fontSize: 16,
            fontWeight: 600,
            width: '303px',
          }}
        >
          Download
        </Button>
      </Stack>
    </>
  );
}
