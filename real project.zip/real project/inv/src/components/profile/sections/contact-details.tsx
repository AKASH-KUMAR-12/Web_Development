import { useProfileData } from '../data/profile-context';
import { ProfileItem, SectionDetails, SectionHeading, SectionTitle } from './common';

export default function ContactDetails() {
  const { profile } = useProfileData();
  const contact = profile?.contactDetails;
  const {
    contactInfo: info,
    correspondenceAddr: address,
    permanentAddr: permanentAddress,
  } = {
    contactInfo: contact?.contactInfo,
    correspondenceAddr: contact?.correspondenceAddr,
    permanentAddr: contact?.permanentAddr,
  };
  return (
    <>
      <SectionTitle text="CONTACT DETAILS" />
      <SectionHeading text="Contact details of First/Sole Applicant" />
      <SectionDetails>
        <ProfileItem title="Full Name*" description={info?.fullName || 'N/A'} />
        <ProfileItem
          title="Whom does the email id belongs to? *"
          description={info?.emailBelongsTo || 'N/A'}
        />
        <ProfileItem title="Mobile*" description={info?.mobile || 'N/A'} />
        <ProfileItem
          title="Whom does the mobile number belongs ?*"
          description={info?.mobileBelongsTo || 'N/A'}
        />
        <ProfileItem
          title="Please Specify Relationship *"
          description={info?.relationship || 'N/A'}
        />
        <ProfileItem
          title="KRA mobile number"
          description={info?.kraMobileNumber || 'N/A'}
        />
        <ProfileItem title="Phone (office)" description={info?.phoneOffice || 'N/A'} />
        <ProfileItem
          title="Phone (Residential)"
          description={info?.phoneResidential || 'N/A'}
        />
      </SectionDetails>
      <SectionHeading text="Correspondence Address of First/Sole Applicant" />
      <SectionDetails>
        <ProfileItem title="Address Line1*" description={address?.addr_line1 || 'N/A'} />
        <ProfileItem title="Address Line2*" description={address?.addr_line1 || 'N/A'} />
        <ProfileItem title="Pincode*" description={address?.pincode || 'N/A'} />
        <ProfileItem title="City*" description={address?.city || 'N/A'} />
        <ProfileItem title="State*" description={address?.state || 'N/A'} />
        <ProfileItem title="Country*" description={address?.country || 'N/A'} />
      </SectionDetails>
      <SectionHeading text="Permanent Address of First/Sole Applicant" />
      <SectionDetails>
        <ProfileItem
          title="Address Line1*"
          description={permanentAddress?.addrLine1 || 'N/A'}
        />
        <ProfileItem
          title="Address Line2*"
          description={permanentAddress?.addrLine2 || 'N/A'}
        />
        <ProfileItem
          title="Address Line3*"
          description={permanentAddress?.addrLine3 || 'N/A'}
        />
        <ProfileItem title="Pincode*" description={permanentAddress?.pincode || 'N/A'} />
        <ProfileItem title="City*" description={permanentAddress?.city || 'N/A'} />
        <ProfileItem title="State*" description={permanentAddress?.state || 'N/A'} />
        <ProfileItem title="Country*" description={permanentAddress?.country || 'N/A'} />
      </SectionDetails>
    </>
  );
}
