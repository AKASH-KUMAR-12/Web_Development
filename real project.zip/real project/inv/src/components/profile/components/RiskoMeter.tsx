import { arc } from 'd3-shape';
import { ReactNode, useMemo } from 'react';

function SVGTextElement({
  children,
  spanWidth,
  spanHeight,
  ...props
}: {
  children: ReactNode;
  spanWidth: number;
  spanHeight: number;
  transform: string;
}) {
  return (
    <g {...props}>
      <rect
        width={spanWidth}
        height={spanHeight}
        stroke="transparent"
        strokeWidth="0.5"
        fill="transparent"
      />
      <text
        style={{ fontSize: '12px' }}
        x={spanWidth / 2}
        y={spanHeight / 2}
        textAnchor="middle"
        alignmentBaseline="middle"
      >
        {children}
      </text>
    </g>
  );
}

export default function RiskoMeterGaugeChart({
  level = 4,
  width = 400,
  bottomPadding = 30,
  colors = ['#3f8f4e', '#4fd95b', '#f1eb47', '#f0ae2f', '#cd362d'],
}) {
  const height = width / 2;
  const spanWidth = width / colors.length;
  const spanHeight = spanWidth / 2;
  const Needle = useMemo(() => {
    const angle = ((level + 0.5) * 180) / colors.length;
    return (
      <g>
        <path
          d={`M${width / 2} ${height - bottomPadding - 6}L${width / 2} ${
            height - bottomPadding + 6
          }L${width / 4} ${height - bottomPadding}Z`}
          fill="#303030"
          transform={`rotate(${angle} ${width / 2} ${height - bottomPadding})`}
        />
        <circle cx={width / 2} cy={height - bottomPadding} r="14" fill="#0797FD" />
      </g>
    );
  }, [width, level]);
  const DoughnutChart = useMemo(() => {
    const count = 5;
    const angle = Math.PI / count;
    const radius = width / 3;
    return (
      <g transform={`translate(${width / 2}, ${height - bottomPadding})`}>
        {new Array(count).fill(0).map((_, i) => (
          <g key={colors[i]}>
            <path
              fill={colors[i]}
              d={
                arc<undefined>()
                  .innerRadius((radius * 3) / 5)
                  .outerRadius(radius)
                  .padAngle(0.05)
                  .startAngle(-Math.PI / 2 + i * angle)
                  .endAngle(-Math.PI / 2 + i * angle + angle)(undefined)!
              }
            />
          </g>
        ))}
      </g>
    );
  }, [width]);
  return (
    <svg width={width} height={height}>
      <g>{DoughnutChart}</g>
      {Needle}
      <SVGTextElement
        transform={`translate(0, ${spanHeight * 2.5})`}
        spanWidth={spanWidth}
        spanHeight={spanHeight}
      >
        Conservative
      </SVGTextElement>
      <SVGTextElement
        transform={`translate(${spanWidth / 2}, ${spanHeight * 0.75})`}
        spanWidth={spanWidth}
        spanHeight={spanHeight}
      >
        Cautious
      </SVGTextElement>
      <SVGTextElement
        transform={`translate(${2 * spanWidth}, 0)`}
        spanWidth={spanWidth}
        spanHeight={spanHeight}
      >
        Balanced
      </SVGTextElement>
      <SVGTextElement
        transform={`translate(${(7 * spanWidth) / 2}, ${spanHeight * 0.75})`}
        spanWidth={spanWidth}
        spanHeight={spanHeight}
      >
        <tspan>Moderately</tspan>
        <tspan dy="15" dx="-55">
          Aggressive
        </tspan>
      </SVGTextElement>
      <SVGTextElement
        transform={`translate(${4 * spanWidth}, ${spanHeight * 2.5})`}
        spanWidth={spanWidth}
        spanHeight={spanHeight}
      >
        Aggressive
      </SVGTextElement>
    </svg>
  );
}
