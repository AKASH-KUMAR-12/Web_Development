import { Box, CardMedia } from '@mui/material';

/**
 * @deprecated
 */
export default function ImageBasedRiskGaugeChart({ riskLevel }: { riskLevel: number }) {
  const getNeedlePosition = (level: number) => {
    switch (level) {
      case 5:
        return {
          right: '25%',
          bottom: '10%',
        };
      case 4:
        return {
          right: '28%',
          bottom: '19%',
          transform: 'rotate(-35deg)',
        };
      case 3:
        return {
          right: '34%',
          bottom: '23%',
          transform: 'rotate(-70deg)',
        };
      case 2:
        return {
          right: '39%',
          bottom: '23%',
          transform: 'rotate(-115deg)',
        };
      case 1:
        return {
          right: '44%',
          bottom: '15%',
          transform: 'rotate(-150deg)',
        };
    }
  };
  return (
    <Box sx={{ py: 4, position: 'relative', width: '350px', margin: 'auto' }}>
      <CardMedia
        component="img"
        src="/images/guage-chart-sections-with-labels.svg"
        alt="guage chart"
        sx={{ width: '350px', margin: 'auto' }}
      />

      <CardMedia
        component="img"
        src="/images/gauge-chart-needle.svg"
        alt="guage chart"
        sx={{
          position: 'absolute',
          width: '100px',

          //! Needle Angle & Position
          ...getNeedlePosition(riskLevel + 1),
        }}
      />
    </Box>
  );
}
