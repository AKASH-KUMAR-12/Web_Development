import { Box, Typography } from '@mui/material';
import { Outlet } from 'react-router';

function LoginLayout() {
  return (
    <Box
      sx={{
        width: '100%',
        height: '100vh',
        overflow: 'auto',
        pb: 12,
        pt: [18, 18, 12],
        background: [
          'url("/images/bg-blue-mobile.png") fixed no-repeat top 20px center',
          'url("/images/bg-blue-mobile.png") fixed no-repeat top 20px center',
          'unset',
          'url("/images/login-bg-circle.png") local no-repeat bottom 10px right -70%',
        ],
      }}
    >
      <Box
        sx={{
          width: ['96%', '96%', '70%'],
          maxWidth: '700px',
          mx: 'auto',
          boxSizing: 'border-box',
          bgcolor: 'primary.light',
          borderRadius: 5,
          px: [3.5, 3.5, 20],
          pt: [3.5, 3.5, 5],
          pb: [3.5, 3.5, 10],
          display: 'flex',
          flexDirection: 'column',
        }}
      >
        <img
          src="/images/kfintech-logo.svg"
          alt="Kfintech logo"
          style={{ width: '58px', height: '50px', marginBottom: '34px' }}
        />
        <Box sx={{ flex: 1 }}>
          <Outlet />
        </Box>
      </Box>
      <Typography
        sx={{
          textAlign: 'center',
          width: ['96%', '96%', '70%'],
          margin: '50px auto',
          fontSize: ['10px', '10px', '14px'],
          color: 'text.themePrimary',
        }}
      >
        CIN: U67120KA2008PTC047749 | SEBI Reg. No’s: PMS:INP000005430 | NSE(Cash & FNO),
        BSE(Cash): INZ000291332 | <br /> CDSL:IN-DP-CDSL-533-2010 | RIA INA200012674 | ARN
        no. 79196 <br /> For queries or grievances:
        <a href="mailto:helpdesk@o3securities.com" style={{ color: '#16A8F7' }}>
          helpdesk@o3securities.com
        </a>
      </Typography>
    </Box>
  );
}

export default LoginLayout;
