import { LinearProgress } from '@mui/material';
import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useRootContext } from '../data/root.context';
import { useLoginContext } from './data/login.context';

function RmRedirect() {
  const { rmAutoLogin: login } = useLoginContext();
  const navigate = useNavigate();
  const { showToast } = useRootContext();

  useEffect(() => {
    const queryString: string = window.location.search;
    console.log(queryString);
    const urlParams: any = new URLSearchParams(queryString);
    const token: string = urlParams.get('token');
    console.log(token);

    login(token)
      .then(({ userDetails }) => {
        if (userDetails) {
          showToast('Logged in successfully', 'success');
          navigate('/dashboard');
        } else {
          navigate('/login');
        }
      })
      .catch((error) => {
        navigate('/login');
      });
  }, []);

  return (
    <div>
      <LinearProgress />
      <p>Redirecting..</p>
    </div>
  );
}

export default RmRedirect;
