import { createContext, ReactElement, useContext, useEffect, useState } from 'react';

import {
  forgotPasswordRequest,
  loginRequest,
  resetPasswordRequest,
  rmDetailsRequest,
  rmRedirectRequest,
} from '../../../api/auth';
import { useRootContext } from '../../data/root.context';
import { get_cart } from '../../../api/payment';

type FamilyPersonDetails = {
  FamilyName: string;
  InvName: string;
  clientId: string;
};

type TransformedFamilyData = { label: string; value: string };

type UserDetails = {
  clientId: string;
  familyData: Array<FamilyPersonDetails>;
  familyName: string;
  name: string;
  isFirstTime: boolean;
  isHead: boolean;
};

type RMDetails = {
  rmEmail: string;
  rmMobile: string;
  rmName: string;
};

const LoginContext = createContext<{
  userDetails?: UserDetails;
  rmDetails?: RMDetails;
  familyData?: Array<TransformedFamilyData>;
  error: string;
  sessionId?: string;
  maskedEmail?: string;
  maskedMobile?: string;
  verifyLogin(pan: string, password: string): Promise<any>;
  rmAutoLogin(token: string): Promise<any>;
  resetPassword(password: string): Promise<any>;
  forgotPassword(password: string): Promise<any>;
  logout(): void;
  otp: string;
  setOtp: React.Dispatch<React.SetStateAction<string>>;
  cartItemCount: number;
  getCartCount(): Promise<any>
}>({
  userDetails: undefined,
  rmDetails: undefined,
  error: '',
  verifyLogin: () => new Promise(() => {}),
  rmAutoLogin: () => new Promise(() => {}),
  resetPassword: () => new Promise(() => {}),
  forgotPassword: () => new Promise(() => {}),
  logout: () => {},
  otp: '',
  setOtp: () => {},
  cartItemCount: 0,
  getCartCount: () => new Promise(() => {})
});

export function useLoginContext() {
  return useContext(LoginContext);
}

const SESSION_KEY_TOKEN = 'token';
const SESSION_KEY_USER_DETAILS = 'userDetails';

export function LoginContextProvider({ children }: { children: ReactElement }) {
  const [userDetails, setUserDetails] = useState<UserDetails>();
  const [rmDetails, setRmDetails] = useState<RMDetails>();
  const [otp, setOtp] = useState('');
  const [familyData, setFamilyData] = useState<TransformedFamilyData[]>();
  const [sessionId, setSessionId] = useState<string | undefined>();
  const [maskedEmail, setMaskedEmail] = useState<string | undefined>();
  const [maskedMobile, setMaskedMobile] = useState<string | undefined>();
  const [error, setError] = useState<string>('');
  const [cartItemCount, setCartItemCount] = useState<number>(0);
  const { showToast, setSelectedFamilyMembers, resetSelectedFamilyMembers } =
    useRootContext();

  useEffect(() => {
    const details = sessionStorage.getItem(SESSION_KEY_USER_DETAILS);
    if (details) {
      setUserDetails(JSON.parse(details));
    }
  }, []);

  useEffect(()=>{
    if(sessionStorage.getItem(SESSION_KEY_TOKEN) !== null)
    {
    getCartCount();

  }

  }, []);

  useEffect(() => {
    const data = userDetails?.familyData;
    if (data?.length && userDetails?.isHead) {
      const transformedFamilyData = data.map((member) => {
        return {
          label: member.InvName,
          value: member.clientId,
        };
      });
      setFamilyData(transformedFamilyData);
    } else {
      userDetails?.clientId && setSelectedFamilyMembers([userDetails?.clientId]);
    }
    getRmDetails();
  }, [userDetails]);

  const verifyLogin = (username: string, password: string) => {
    return loginRequest(username, password)
      .then((response) => {
        const { userDetails } = response;
        // eslint-disable-next-line no-unused-vars
        const { token, purpose, authenticated, ...rest } = userDetails;
        setSessionId(userDetails?.sessionId);
        if (token) {
          sessionStorage.setItem(SESSION_KEY_TOKEN, token);
          sessionStorage.setItem(SESSION_KEY_USER_DETAILS, JSON.stringify(rest));
        }
        setUserDetails(rest);
        return response;
      })
      .catch((e) => {
        showToast('Invalid username and password', 'error');
        throw new Error('Invalid', e);
      });
  };

  const getRmDetails = () => {
    if (userDetails)
      return rmDetailsRequest(userDetails?.clientId)
        .then((res) => {
          setRmDetails(res);
        })
        .catch((e) => {
          console.error('Error getting RM details', e);
        });
  };

  const rmAutoLogin = (token: string) => {
    return rmRedirectRequest(token)
      .then((response) => {
        const { userDetails } = response;
        // eslint-disable-next-line no-unused-vars
        const { token, purpose, authenticated, ...rest } = userDetails;
        setSessionId(userDetails?.sessionId);
        if (token) {
          sessionStorage.setItem(SESSION_KEY_TOKEN, token);
          sessionStorage.setItem(SESSION_KEY_USER_DETAILS, JSON.stringify(rest));
        }
        setUserDetails(rest);
        return response;
      })
      .catch((e) => {
        showToast('Invalid token', 'error');
        return null;
        //throw new Error('Invalid', e);
      });
  };

  const resetPassword = (password: string) => {
    return resetPasswordRequest(otp, password, sessionId)
      .then((res) => {
        showToast('Password Reset successful', 'success');
        return res;
      })
      .catch((e) => {
        showToast(e?.message || 'Something went wrong, please try again', 'error');
        throw new Error('Something went wrong', e);
      });
  };

  const forgotPassword = (pan: string) => {
    return forgotPasswordRequest(pan)
      .then((res) => {
        const { details }: any = res;
        setMaskedEmail(details?.email);
        setMaskedMobile(details?.mobile);
        setSessionId(details?.sessionId);
        return res;
      })
      .catch((e) => {
        showToast('User not found.', 'error');
        throw new Error('User not found', e);
      });
  };

  async function getCartCount() {
    return get_cart()
    .then(({ cart_details: cartValues }) => {
      setCartItemCount(cartValues[0].length)
        return cartValues[0].length
    })
    .catch((e) => {
        showToast((e?.messasge || 'Not found'), 'error');
    })
    .finally(() => { });
}

  const logout = () => {
    resetSelectedFamilyMembers();
    setSessionId(undefined);
    sessionStorage.clear();
  };

  return (
    <LoginContext.Provider
      value={{
        userDetails,
        rmDetails,
        familyData,
        verifyLogin,
        rmAutoLogin,
        resetPassword,
        forgotPassword,
        logout,
        sessionId,
        maskedEmail,
        maskedMobile,
        error,
        otp,
        setOtp,
        cartItemCount,
        getCartCount
      }}
    >
      {children}
    </LoginContext.Provider>
  );
}
