import {
  Box,
  FormControl,
  FormControlLabel,
  RadioGroup,
  Stack,
  Typography,
} from '@mui/material';
import { DatePicker, LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import dayjs, { Dayjs } from 'dayjs';
import { Form, Formik } from 'formik';
import { useEffect } from 'react';

import { useRootContext } from '../../data/root.context';
import SubmitButton from '../../forms/FormSubmitButton';
import { useLoginContext } from '../../login/data/login.context';
import {
  BpRadio,
  DatePickerInput,
  DownloadButton,
  ReportSectionContainer,
  ReportsRightLayout,
} from '../common';
import { useReportsContext } from '../data/reports.context';

// const assetOptions = [
//   { label: 'All', value: 'all' },
//   { label: 'Mutual Funds', value: 'mutual-funds' },
//   {
//     label: 'Direct Equity',
//     value: 'direct-equity',
//   },
//   {
//     label: 'PMS',
//     value: 'PMS',
//   },
//   {
//     label: 'AIF',
//     value: 'AIF',
//   },
//   {
//     label: 'Fixed Deposit',
//     value: 'fixed-deposit',
//   },
//   {
//     label: 'Bonds',
//     value: 'bonds',
//   },
// ];

const PortfolioSummary = () => {
  const { getPortfolioSummaryReport } = useReportsContext();
  const { selectedFamilyMembers, resetSelectedFamilyMembers } = useRootContext();
  const { userDetails: user } = useLoginContext();

  return (
    <ReportsRightLayout>
      <Typography
        sx={{
          color: 'text.secondary',
          fontSize: '16px',
          fontWeight: 500,
          lineHeight: '19px',
          letterSpacing: '0.06em',
          textTransform: 'uppercase',
          display: ['none', 'none', 'block'],
        }}
      >
        Portfolio Summary
      </Typography>
      <Formik
        initialValues={{
          date: dayjs(new Date().setDate(new Date().getDate() - 1)),
          // selectedAssets: [],
          // selectedInvestors: [],
          // option: 'o3-capital',
          fileType: 'pdf',
        }}
        onSubmit={({ date }: { date: Dayjs }) => {
          return getPortfolioSummaryReport({
            clientId:
              user?.isHead && !(selectedFamilyMembers[0] === 'overall-family')
                ? selectedFamilyMembers
                : [user?.clientId || ''],
            toDate: date.format('DD/MM/YYYY'),
          });
        }}
      >
        {({ values, setFieldValue }) => (
          <Form>
            <ReportSectionContainer>
              <Stack>
                <Typography
                  sx={{
                    fontSize: '14px',
                    fontWeight: 400,
                    lineHeight: '22px',
                    letterSpacing: '0.01em',
                  }}
                >
                  You are requesting portfolio summary
                </Typography>
                <LocalizationProvider dateAdapter={AdapterDayjs}>
                  <DatePicker
                    mask="__/__/____"
                    maxDate={dayjs(new Date())}
                    value={values.date}
                    onChange={(newValue: any) => setFieldValue('date', newValue)}
                    renderInput={(params: any) => (
                      <DatePickerInput
                        {...params}
                        sx={{ width: ['100%', '100%', '300px'] }}
                      />
                    )}
                  />
                </LocalizationProvider>
                {selectedFamilyMembers[0] === 'overall-family' && (
                  <Typography variant="caption" sx={{ color: 'error.main' }}>
                    Overall family portfolio summary cannot be downloaded. Please select
                    any family member.
                  </Typography>
                )}

                {
                  //! Disabled option temporarily
                  /* <Box>
                  <Typography
                    sx={{
                      fontSize: '14px',
                      fontWeight: 400,
                    }}
                  >
                    Select Asset Class
                  </Typography>
                  <FormMultiSelect
                    name={'selectedAssets'}
                    fullWidth={false}
                    placeholder={'Select here'}
                    options={assetOptions}
                    sx={{ width: '300px' }}
                  />
                </Box> */
                }
                {/* <Box>
                  <Typography
                    sx={{
                      fontSize: '14px',
                      fontWeight: 400,
                    }}
                  >
                    Select Investor
                  </Typography>
                  <FormMultiSelect
                    name={'selectedInvestors'}
                    fullWidth={false}
                    options={[
                      { label: 'All', value: 'all' },
                      { label: 'Neha Thapar', value: 'neha-thapar' },
                      {
                        label: 'Vinay Thapar',
                        value: 'vinay-thapar',
                      },
                      {
                        label: 'Vijayendra Thapar',
                        value: 'vijayendra-thapar',
                      },
                    ]}
                    sx={{ width: '300px' }}
                    placeholder={'Select here'}
                  />
                </Box> */}
                {
                  //! Disabled option temporarily
                  /* <Typography
                  sx={{
                    fontSize: '14px',
                    fontWeight: 400,
                    lineHeight: '22px',
                    letterSpacing: '0.01em',
                    pt: 2,
                    pb: 1,
                  }}
                >
                  Select Option
                </Typography>
                <Box>
                  <FormControl>
                    <RadioGroup
                      name={'option'}
                      value={values.option}
                      onChange={(event) => {
                        setFieldValue('option', event.currentTarget.value);
                      }}
                      sx={{
                        display: 'grid',
                        gridTemplateColumns: '1fr 1fr 1fr',
                        gridColumnGap: '1rem',
                        gridRowGap: '1rem',
                      }}
                    >
                      <FormControlLabel
                        value="o3-capital"
                        control={<BpRadio />}
                        label="O3 Capital"
                      />
                      <FormControlLabel
                        value="held-away"
                        control={<BpRadio />}
                        label="Held Away"
                      />
                      <FormControlLabel
                        value="combined"
                        control={<BpRadio />}
                        label="Combined"
                      />
                    </RadioGroup>
                  </FormControl> 
                </Box> */
                }
                {
                  //! Disabled option temporarily
                  /*

                  
                <Typography
                  sx={{
                    fontSize: '14px',
                    fontWeight: 400,
                    lineHeight: '22px',
                    letterSpacing: '0.01em',
                    pt: 2,
                    pb: 1,
                  }}
                >
                  Download As
                </Typography>
                <Box>
                  <FormControl>
                    <RadioGroup
                      name={'fileType'}
                      value={values.fileType}
                      onChange={(event) => {
                        setFieldValue('fileType', event.currentTarget.value);
                      }}
                      sx={{
                        display: 'flex',
                        flexDirection: 'row',
                        gap: 1,
                      }}
                    >
                      <FormControlLabel value="pdf" control={<BpRadio />} label="PDF" />
                      <FormControlLabel
                        value="excel"
                        control={<BpRadio />}
                        label="Excel"
                      />
                    </RadioGroup>
                  </FormControl>
                </Box>
                */
                }
              </Stack>
            </ReportSectionContainer>
            <Stack justifyContent="center" alignItems="center" sx={{ m: 2 }}>
              <SubmitButton
                label="Download"
                disabled={selectedFamilyMembers[0] === 'overall-family'}
              />
            </Stack>
          </Form>
        )}
      </Formik>
    </ReportsRightLayout>
  );
};

export default PortfolioSummary;
