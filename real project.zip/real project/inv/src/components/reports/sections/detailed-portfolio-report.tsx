import { Stack, Typography } from '@mui/material';
import { DatePicker, LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import dayjs, { Dayjs } from 'dayjs';
import React, { useEffect } from 'react';
import { useRootContext } from '../../data/root.context';
import { useLoginContext } from '../../login/data/login.context';

import {
  DatePickerInput,
  DownloadButton,
  ReportSectionContainer,
  ReportsRightLayout,
} from '../common';

const DetailedPortfolioReport = () => {
  const [value, setValue] = React.useState<Dayjs | null>(null);
  const { userDetails: user } = useLoginContext();
  const { resetSelectedFamilyMembers } = useRootContext();

  return (
    <ReportsRightLayout>
      <Typography
        sx={{
          color: 'text.secondary',
          fontSize: '16px',
          fontWeight: 500,
          lineHeight: '19px',
          letterSpacing: '0.06em',
          textTransform: 'uppercase',
        }}
      >
        Detailed Portfolio Report
      </Typography>
      <ReportSectionContainer>
        <Stack>
          <Typography
            sx={{
              fontSize: '14px',
              fontWeight: 400,
              lineHeight: '22px',
              letterSpacing: '0.01em',
            }}
          >
            You are requesting Detailed Portfolio Report
          </Typography>
          <LocalizationProvider dateAdapter={AdapterDayjs}>
            <DatePicker
              mask="__/__/____"
              maxDate={dayjs(new Date())}
              value={value}
              onChange={(newValue: any) => setValue(newValue)}
              renderInput={(params: any) => (
                <DatePickerInput {...params} sx={{ width: ['100%', '100%', '300px'] }} />
              )}
            />
          </LocalizationProvider>
        </Stack>
      </ReportSectionContainer>
      <Stack justifyContent="center" alignItems="center" sx={{ m: 2 }}>
        <DownloadButton variant="contained" color="primary">
          Download
        </DownloadButton>
      </Stack>
    </ReportsRightLayout>
  );
};

export default DetailedPortfolioReport;
