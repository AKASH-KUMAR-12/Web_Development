import { Box, FormControl, Stack, Typography } from '@mui/material';
import { DatePicker, LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import dayjs from 'dayjs';
import { Form, Formik } from 'formik';
import { useEffect } from 'react';

import { useRootContext } from '../../data/root.context';
import SubmitButton from '../../forms/FormSubmitButton';
import { useLoginContext } from '../../login/data/login.context';
import {
  DatePickerInput,
  DownloadButton,
  ReportSectionContainer,
  ReportsRightLayout,
} from '../common';
import { useReportsContext } from '../data/reports.context';

const TransactionStatement = () => {
  const { getTransactionStatementReport } = useReportsContext();
  const { selectedFamilyMembers, resetSelectedFamilyMembers } = useRootContext();
  const { userDetails: user } = useLoginContext();

  return (
    <ReportsRightLayout>
      <Typography
        sx={{
          color: 'text.secondary',
          fontSize: '16px',
          fontWeight: 500,
          lineHeight: '19px',
          letterSpacing: '0.06em',
          textTransform: 'uppercase',
          display: ['none', 'none', 'block'],
        }}
      >
        Transaction Statement
      </Typography>
      <Formik
        initialValues={{
          fromDate: dayjs(new Date().setDate(new Date().getDate() - 1)),
          toDate: dayjs(new Date().setDate(new Date().getDate() - 1)),
        }}
        onSubmit={({ fromDate, toDate }) => {
          return getTransactionStatementReport({
            clientId:
              user?.isHead && !(selectedFamilyMembers[0] === 'overall-family')
                ? selectedFamilyMembers
                : [user?.clientId || ''],
            fromDate: fromDate.format('DD/MM/YYYY'),
            toDate: toDate.format('DD/MM/YYYY'),
          });
        }}
      >
        {({ values, setFieldValue }) => (
          <Form>
            <ReportSectionContainer>
              <Typography
                sx={{
                  fontSize: '14px',
                  fontWeight: 400,
                  lineHeight: '22px',
                  letterSpacing: '0.01em',
                  pt: 1,
                  pb: 1,
                }}
              >
                Choose duration of statement -
              </Typography>
              <Box>
                <FormControl sx={{ width: '100%' }}>
                  <>
                    <Typography
                      sx={{
                        fontSize: '14px',
                        fontWeight: 400,
                        lineHeight: '22px',
                        letterSpacing: '0.01em',
                        pt: 1,
                        pb: 1,
                      }}
                    >
                      From Date
                    </Typography>
                    <LocalizationProvider dateAdapter={AdapterDayjs}>
                      <DatePicker
                        mask="__/__/____"
                        maxDate={values.toDate || dayjs(new Date())}
                        value={values.fromDate}
                        onChange={(newValue: any) => setFieldValue('fromDate', newValue)}
                        renderInput={(params: any) => (
                          <DatePickerInput
                            {...params}
                            sx={{ width: ['100%', '100%', '300px'] }}
                          />
                        )}
                      />
                    </LocalizationProvider>
                    <Typography
                      sx={{
                        fontSize: '14px',
                        fontWeight: 400,
                        lineHeight: '22px',
                        letterSpacing: '0.01em',
                        pt: 1,
                        pb: 1,
                      }}
                    >
                      To Date
                    </Typography>
                    <LocalizationProvider dateAdapter={AdapterDayjs}>
                      <DatePicker
                        mask="__/__/____"
                        maxDate={dayjs(new Date())}
                        value={values.toDate}
                        onChange={(newValue: any) => {
                          setFieldValue('toDate', newValue);
                          dayjs(newValue).isBefore(values.fromDate) &&
                            setFieldValue('fromDate', newValue);
                        }}
                        renderInput={(params: any) => (
                          <DatePickerInput
                            {...params}
                            sx={{ width: ['100%', '100%', '300px'] }}
                          />
                        )}
                      />
                    </LocalizationProvider>
                  </>
                  {selectedFamilyMembers[0] === 'overall-family' && (
                    <Typography variant="caption" sx={{ color: 'error.main' }}>
                      Overall family transaction statement cannot be downloaded. Please
                      select any family member.
                    </Typography>
                  )}
                </FormControl>
              </Box>
            </ReportSectionContainer>
            <Stack justifyContent="center" alignItems="center" sx={{ m: 2 }}>
              <SubmitButton
                label="Download"
                disabled={selectedFamilyMembers[0] === 'overall-family'}
              />
            </Stack>
          </Form>
        )}
      </Formik>
    </ReportsRightLayout>
  );
};

export default TransactionStatement;
