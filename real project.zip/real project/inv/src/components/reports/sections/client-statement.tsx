import {
  FormControl,
  FormControlLabel,
  FormGroup,
  Stack,
  Typography,
} from '@mui/material';
import { DatePicker, LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import dayjs, { Dayjs } from 'dayjs';
import { Form, Formik } from 'formik';
import React, { useEffect } from 'react';

import Checkbox from '../../common/checkbox';
import { useRootContext } from '../../data/root.context';
import FormMultiSelect from '../../forms/FormMultiSelect';
import SubmitButton from '../../forms/FormSubmitButton';
import { useLoginContext } from '../../login/data/login.context';
import {
  DatePickerInput,
  DownloadButton,
  ReportSectionContainer,
  ReportsRightLayout,
} from '../common';
import * as Yup from 'yup';

import { useReportsContext } from '../data/reports.context';

const validationSchema = Yup.object({
  reportOptions: Yup.array().min(1, 'Select atleast one option'),
});

const ClientStatement = () => {
  const { reportsOptions: options, getClientStatementReport } = useReportsContext();
  const { selectedFamilyMembers, resetSelectedFamilyMembers } = useRootContext();
  const { userDetails: user } = useLoginContext();

  return (
    <>
      <ReportsRightLayout>
        <Typography
          sx={{
            color: 'text.secondary',
            fontSize: '16px',
            fontWeight: 500,
            lineHeight: '19px',
            letterSpacing: '0.06em',
            textTransform: 'uppercase',
            display: ['none', 'none', 'block'],
          }}
        >
          Client Statement
        </Typography>
        <Formik
          onSubmit={({
            reportOptions,
            date,
            redeemedSchemesFlg,
            transactionHistoryFlg,
          }: {
            reportOptions: number[];
            date: Dayjs;
            redeemedSchemesFlg: number;
            transactionHistoryFlg: number;
          }) => {
            const allIdValue = options.find(
              (option: { label: string; value: string }) =>
                option.label.toLowerCase() === 'all',
            ).value;
            return getClientStatementReport({
              clientId:
                user?.isHead && !(selectedFamilyMembers[0] === 'overall-family')
                  ? selectedFamilyMembers
                  : [user?.clientId || ''],
              reportOptions:
                reportOptions.indexOf(allIdValue) !== -1 ? [0] : reportOptions,
              level:
                selectedFamilyMembers[0] === 'overall-family' ? 'family' : 'individual',
              date: date.format('DD/MM/YYYY'),
              redeemedSchemesFlg: redeemedSchemesFlg.toString(),
              transactionHistoryFlg: transactionHistoryFlg.toString(),
            });
          }}
          validationSchema={validationSchema}
          initialValues={{
            reportOptions: [],
            date: dayjs(new Date().setDate(new Date().getDate() - 1)),
            redeemedSchemesFlg: 1,
            transactionHistoryFlg: 0,
          }}
        >
          {({
            values,
            setFieldValue,
          }: {
            values: {
              reportOptions: number[];
              date: Dayjs;
              redeemedSchemesFlg: number;
              transactionHistoryFlg: number;
            };
            setFieldValue: (
              field: string,
              value: any,
              shouldValidate?: boolean | undefined,
            ) => void;
          }) => (
            <Form>
              <ReportSectionContainer>
                <Stack>
                  <Typography
                    sx={{
                      fontSize: '14px',
                      fontWeight: 400,
                      lineHeight: '22px',
                      letterSpacing: '0.01em',
                    }}
                  >
                    You are requesting client statement
                  </Typography>
                  <LocalizationProvider dateAdapter={AdapterDayjs}>
                    <DatePicker
                      mask="__/__/____"
                      maxDate={dayjs(new Date())}
                      value={values.date}
                      onChange={(newValue: any) => setFieldValue('date', newValue)}
                      renderInput={(params: any) => (
                        <DatePickerInput
                          {...params}
                          sx={{ width: ['100%', '100%', '300px'] }}
                        />
                      )}
                    />
                  </LocalizationProvider>
                </Stack>
              </ReportSectionContainer>
              <ReportSectionContainer>
                <Stack>
                  <Typography
                    sx={{
                      fontSize: '14px',
                      fontWeight: 400,
                      lineHeight: '22px',
                      letterSpacing: '0.01em',
                    }}
                  >
                    Report Selection
                  </Typography>

                  <FormMultiSelect
                    name={'reportOptions'}
                    onChange={(e) => {
                      let value = e.target.value as Array<number>;
                      const allIdValue: number = options.find(
                        (option: { label: string; value: string }) =>
                          option.label.toLowerCase() === 'all',
                      ).value;
                      if (
                        value.length < values.reportOptions.length &&
                        value.indexOf(allIdValue) !== -1
                      ) {
                        value.splice(value.indexOf(allIdValue), 1);
                        setFieldValue('reportOptions', value);
                      } else if (value.indexOf(allIdValue) !== -1) {
                        setFieldValue(
                          'reportOptions',
                          options.map((each: any) => each.value),
                        );
                      } else if (
                        value.length === options.length - 1 &&
                        values.reportOptions.indexOf(allIdValue) === -1
                      ) {
                        setFieldValue('reportOptions', [...value, allIdValue]);
                      } else if (
                        value.indexOf(allIdValue) === -1 &&
                        values.reportOptions.indexOf(allIdValue) !== -1
                      ) {
                        setFieldValue('reportOptions', []);
                      } else {
                        setFieldValue('reportOptions', value);
                      }
                    }}
                    options={options}
                    placeholder={'Select here'}
                  />
                  <Stack>
                    <FormControl component="fieldset">
                      <FormGroup aria-label="position">
                        <FormControlLabel
                          value={Boolean(values.redeemedSchemesFlg)}
                          checked={Boolean(values.redeemedSchemesFlg)}
                          onChange={(_, checked) => {
                            setFieldValue('redeemedSchemesFlg', Number(checked));
                          }}
                          control={<Checkbox />}
                          label="Redeemed Schemes"
                          labelPlacement="end"
                        />
                        <FormControlLabel
                          value={Boolean(values.transactionHistoryFlg)}
                          checked={Boolean(values.transactionHistoryFlg)}
                          onChange={(_, checked) => {
                            setFieldValue('transactionHistoryFlg', Number(checked));
                          }}
                          control={<Checkbox />}
                          label="Transaction History (since inception)"
                          labelPlacement="end"
                        />
                      </FormGroup>
                    </FormControl>
                  </Stack>
                </Stack>
              </ReportSectionContainer>
              <Stack justifyContent="center" alignItems="center" sx={{ m: 2 }}>
                <SubmitButton label="Download" />
              </Stack>
            </Form>
          )}
        </Formik>
      </ReportsRightLayout>
    </>
  );
};

export default ClientStatement;
