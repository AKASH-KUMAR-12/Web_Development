import {
  Box,
  FormControl,
  FormControlLabel,
  RadioGroup,
  Stack,
  Typography,
} from '@mui/material';
import { DatePicker, LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import dayjs from 'dayjs';
import { Form, Formik } from 'formik';
import { useEffect } from 'react';

import { useRootContext } from '../../data/root.context';
import SubmitButton from '../../forms/FormSubmitButton';
import { useLoginContext } from '../../login/data/login.context';
import {
  BpRadio,
  DatePickerInput,
  ReportSectionContainer,
  ReportsRightLayout,
} from '../common';
import { useReportsContext } from '../data/reports.context';

//! Radio Options
const options = [
  // { label: 'Today', value: 'today' },
  // { label: 'Yesterday', value: 'yesterday' },
  { label: 'Previous FY', value: 'previous-fy' },
  { label: 'Current FY', value: 'current-fy' },
  { label: 'Custom Date', value: 'custom' },
];
const CGStatement = () => {
  const { getCGStatementReport } = useReportsContext();
  const { selectedFamilyMembers, resetSelectedFamilyMembers } = useRootContext();
  const { userDetails: user } = useLoginContext();

  const getFromToDates = (value: string): { fromDate: string; toDate: string } => {
    const today = new Date();
    switch (value) {
      case 'previous-fy':
        if (today.getMonth() + 1 <= 3) {
          return {
            fromDate: `01/04/${today.getFullYear() - 2}`,
            toDate: `31/03/${today.getFullYear() - 1}`,
          };
        } else {
          return {
            fromDate: `01/04/${today.getFullYear() - 1}`,
            toDate: `31/03/${today.getFullYear()}`,
          };
        }

      case 'current-fy':
        if (today.getMonth() + 1 <= 3) {
          return {
            fromDate: `01/04/${today.getFullYear() - 1}`,
            toDate: `31/03/${today.getFullYear()}`,
          };
        } else {
          return {
            fromDate: `01/04/${today.getFullYear()}`,
            toDate: `31/03/${today.getFullYear() + 1}`,
          };
        }
      default:
        return {
          fromDate: '',
          toDate: '',
        };
    }
  };

  return (
    <ReportsRightLayout>
      <Typography
        sx={{
          color: 'text.secondary',
          fontSize: '16px',
          fontWeight: 500,
          lineHeight: '19px',
          letterSpacing: '0.06em',
          textTransform: 'uppercase',
          display: ['none', 'none', 'block'],
        }}
      >
        CG Statement
      </Typography>

      <Formik
        initialValues={{
          duration: options[0].value,
          fromDate: dayjs(new Date().setDate(new Date().getDate() - 1)),
          toDate: dayjs(new Date().setDate(new Date().getDate() - 1)),
          fileType: 'pdf',
        }}
        onSubmit={({ fileType, fromDate, toDate, duration }) => {
          var { fromDate: from, toDate: to } = getFromToDates(duration);
          return getCGStatementReport({
            clientId:
              user?.isHead && !(selectedFamilyMembers[0] === 'overall-family')
                ? selectedFamilyMembers
                : [user?.clientId || ''],
            fileType,
            fromDate: from || fromDate.format('DD/MM/YYYY'),
            toDate: to || toDate.format('DD/MM/YYYY'),
          });
        }}
      >
        {({ values, setFieldValue }) => (
          <Form>
            <ReportSectionContainer>
              <Typography
                sx={{
                  fontSize: '14px',
                  fontWeight: 400,
                  lineHeight: '22px',
                  letterSpacing: '0.01em',
                  pt: 1,
                  pb: 1,
                }}
              >
                Choose duration of statement -
              </Typography>
              <Box>
                <FormControl sx={{ width: '100%' }}>
                  <RadioGroup
                    name={'duration'}
                    value={values.duration}
                    onChange={(event) => {
                      setFieldValue('duration', event.currentTarget.value);
                    }}
                    sx={{
                      display: 'grid',
                      gridTemplateColumns: ['1fr 1fr', '1fr 1fr 1fr'],
                      gridColumnGap: 8,
                      gridRowGap: '1rem',
                    }}
                  >
                    {options.map(({ label, value }) => (
                      <FormControlLabel
                        key={value}
                        value={value}
                        control={<BpRadio />}
                        label={label}
                      />
                    ))}
                  </RadioGroup>
                  {values.duration === 'custom' && (
                    <>
                      <Typography
                        sx={{
                          fontSize: '14px',
                          fontWeight: 400,
                          lineHeight: '22px',
                          letterSpacing: '0.01em',
                          pt: 1,
                          pb: 1,
                        }}
                      >
                        From Date
                      </Typography>
                      <LocalizationProvider dateAdapter={AdapterDayjs}>
                        <DatePicker
                          mask="__/__/____"
                          maxDate={values.toDate || dayjs(new Date())}
                          value={values.fromDate}
                          onChange={(newValue: any) =>
                            setFieldValue('fromDate', newValue)
                          }
                          renderInput={(params: any) => (
                            <DatePickerInput
                              {...params}
                              sx={{ width: ['100%', '100%', '300px'] }}
                            />
                          )}
                        />
                      </LocalizationProvider>
                      <Typography
                        sx={{
                          fontSize: '14px',
                          fontWeight: 400,
                          lineHeight: '22px',
                          letterSpacing: '0.01em',
                          pt: 1,
                          pb: 1,
                        }}
                      >
                        To Date
                      </Typography>
                      <LocalizationProvider dateAdapter={AdapterDayjs}>
                        <DatePicker
                          mask="__/__/____"
                          maxDate={dayjs(new Date())}
                          value={values.toDate}
                          onChange={(newValue: any) => {
                            setFieldValue('toDate', newValue);
                            dayjs(newValue).isBefore(values.fromDate) &&
                              setFieldValue('fromDate', newValue);
                          }}
                          renderInput={(params: any) => (
                            <DatePickerInput
                              {...params}
                              sx={{ width: ['100%', '100%', '300px'] }}
                            />
                          )}
                        />
                      </LocalizationProvider>
                    </>
                  )}
                </FormControl>
              </Box>
              <Typography
                sx={{
                  fontSize: '14px',
                  fontWeight: 400,
                  lineHeight: '22px',
                  letterSpacing: '0.01em',
                  pt: 2,
                  pb: 1,
                }}
              >
                Report download options
              </Typography>

              <FormControl>
                <RadioGroup
                  name={'fileType'}
                  value={values.fileType}
                  onChange={(event) => {
                    setFieldValue('fileType', event.currentTarget.value);
                  }}
                  sx={{
                    display: 'flex',
                    flexDirection: 'row',
                    gap: 1,
                  }}
                >
                  <FormControlLabel value="pdf" control={<BpRadio />} label="PDF" />
                  <FormControlLabel value="xlsx" control={<BpRadio />} label="Excel" />
                </RadioGroup>
                {selectedFamilyMembers[0] === 'overall-family' && (
                  <Typography variant="caption" sx={{ color: 'error.main' }}>
                    Overall family CG statement cannot be downloaded. Please select any
                    family member.
                  </Typography>
                )}
              </FormControl>
            </ReportSectionContainer>
            <Stack justifyContent="center" alignItems="center" sx={{ m: 2 }}>
              <SubmitButton
                label="Download"
                disabled={selectedFamilyMembers[0] === 'overall-family'}
              />
            </Stack>
          </Form>
        )}
      </Formik>
    </ReportsRightLayout>
  );
};

export default CGStatement;
