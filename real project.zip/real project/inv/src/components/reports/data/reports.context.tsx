import { createContext, ReactElement, useContext, useEffect, useState } from 'react';

import {
  CGStatementRequestOptions,
  ClientStatementRequestOptions,
  getCGStatementReportRequest,
  getClientStatementReportRequest,
  getPortfolioSummaryReportRequest,
  getReportsOptions,
  getTransactionStatementReportRequest,
  PortfolioSummaryRequestOptions,
  TransactionStatementRequestOptions,
} from '../../../api/reports';
import { useRootContext } from '../../data/root.context';

const ReportsContext = createContext<{
  reportsOptions: any;
  getClientStatementReport(requestOptions: ClientStatementRequestOptions): void;
  getTransactionStatementReport(requestOptions: TransactionStatementRequestOptions): void;
  getPortfolioSummaryReport(requestOptions: PortfolioSummaryRequestOptions): void;
  getCGStatementReport(requestOptions: CGStatementRequestOptions): void;
}>({
  reportsOptions: {},
  getClientStatementReport: () => {},
  getTransactionStatementReport: () => {},
  getPortfolioSummaryReport: () => {},
  getCGStatementReport: () => {},
});

export function useReportsContext() {
  return useContext(ReportsContext);
}
export function ReportsContextProvider({ children }: { children: ReactElement }) {
  const [reportsOptions, setReportsOptions] = useState([]);
  const { showToast } = useRootContext();

  useEffect(() => {
    reportsOptionsRequest();
  }, []);

  const reportsOptionsRequest = () => {
    return getReportsOptions()
      .then((res) => {
        const transformedRes = res.map((obj: any) => {
          return {
            label: obj.Name,
            value: obj.ID,
          };
        });
        setReportsOptions(transformedRes);
      })
      .catch((e) => {
        throw new Error('Error getting report options', e);
      });
  };

  const getClientStatementReport = (requestOptions: ClientStatementRequestOptions) => {
    return getClientStatementReportRequest(requestOptions)
      .then(() => showToast('File(s) downloaded successfully.', 'success'))
      .catch((e) => {
        showToast('No reports available for the selected date', 'error');
      });
  };

  const getTransactionStatementReport = (
    requestOptions: TransactionStatementRequestOptions,
  ) => {
    return getTransactionStatementReportRequest(requestOptions)
      .then(() => showToast('File(s) downloaded successfully.', 'success'))
      .catch((e) => {
        showToast('No reports available for the selected date', 'error');
      });
  };

  const getPortfolioSummaryReport = (requestOptions: PortfolioSummaryRequestOptions) => {
    return getPortfolioSummaryReportRequest(requestOptions)
      .then(() => showToast('File(s) downloaded successfully.', 'success'))
      .catch((e) => {
        showToast('No reports available for the selected date', 'error');
      });
  };

  const getCGStatementReport = (requestOptions: CGStatementRequestOptions) => {
    return getCGStatementReportRequest(requestOptions)
      .then(() => showToast('File(s) downloaded successfully.', 'success'))
      .catch((e) => {
        showToast('No reports available for the selected date', 'error');
      });
  };

  return (
    <ReportsContext.Provider
      value={{
        reportsOptions,
        getClientStatementReport,
        getTransactionStatementReport,
        getPortfolioSummaryReport,
        getCGStatementReport,
      }}
    >
      {children}
    </ReportsContext.Provider>
  );
}
