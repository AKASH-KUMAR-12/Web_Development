import { Box, Divider, Paper, Stack, Typography } from '@mui/material';
import { useEffect, useState } from 'react';
import { Outlet, useMatch } from 'react-router-dom';

import { AnimatedBox, SectionLinkItem } from '../common';
import MultiSelectDropDown from '../dashboard/multiselect.dropdown';
import { useLoginContext } from '../login/data/login.context';
import { ReportLeftLayout } from './common';
import CGStatementIcon from './icons/cg-statement';
import ClientStatementIcon from './icons/client-statement';
//import DetailedPortfolioReportIcon from './icons/detailed-portfolio-report';
import PortfolioSummaryIcon from './icons/portfolio-summary';
import TransactionStatementIcon from './icons/transaction-statement';

const ReportsLayout = () => {
  const { userDetails: user } = useLoginContext();
  const [transitionClassName, setTransitionClassName] = useState('');
  const match = useMatch('reports/*');
  const leadingPath = match?.params['*']?.split('/').pop();
  useEffect(() => {
    setTransitionClassName('slideInUp');
    const timeoutId = setTimeout(() => {
      setTransitionClassName('');
    }, 300);
    return () => {
      clearTimeout(timeoutId);
    };
  }, [leadingPath]);
  return (
    <>
      <Box
        sx={{
          width: ['100%', '100%', '88%'],
          margin: 'auto',
          pt: [0, 0, 5],
          pb: [0, 0, '60px'],
          boxSizing: 'border-box',
        }}
      >
        <Stack
          direction="row"
          justifyContent="space-between"
          alignItems="flex-end"
          sx={{ mb: 3.5, display: ['none', 'none', 'flex'] }}
        >
          <Typography
            sx={{
              color: 'text.secondary',
              fontSize: '22px',
              fontWeight: 500,
              lineHeight: '26px',
              letterSpacing: '0.06em',
            }}
          >
            REPORTS
          </Typography>
          {user?.isHead && user?.familyData?.length ? <MultiSelectDropDown /> : null}
        </Stack>
        <Paper
          sx={{
            p: 3,
            backgroundColor: 'primary.light',
            boxShadow: [0, 0, 24],
            borderRadius: [0, 0, '10px'],
            height: ['100vh', '100vh', 'auto'],
          }}
        >
          <Stack direction="row" sx={{ width: '100%' }}>
            <ReportLeftLayout>
              <SectionLinkItem
                to={'/reports/client-statement'}
                end
                title={'Client Statement'}
                icon={<ClientStatementIcon />}
              />
              <SectionLinkItem
                to={'/reports/transaction-statement'}
                end
                title={'Transaction Statement'}
                icon={<TransactionStatementIcon />}
              />
              <SectionLinkItem
                to={'/reports/portfolio-summary'}
                end
                title={'Portfolio Summary'}
                icon={<PortfolioSummaryIcon />}
              />
              {/* <SectionLinkItem
                to={'/reports/detailed-portfolio-report'}
                end
                title={'Detailed Portfolio Report'}
                icon={<DetailedPortfolioReportIcon />}
              /> */}
              <SectionLinkItem
                to={'/reports/cg-statement'}
                end
                title={'CG Statement'}
                icon={<CGStatementIcon />}
              />
            </ReportLeftLayout>
            <Divider
              orientation="vertical"
              sx={{
                borderWidth: '1px',
                borderColor: 'text.dividerLight',
                mr: 1,
                ml: 2,
                display: ['none', 'none', 'flex'],
              }}
              flexItem
            />
            <AnimatedBox sx={{ width: '100%' }} className={transitionClassName}>
              <Outlet />
            </AnimatedBox>
          </Stack>
        </Paper>
      </Box>
    </>
  );
};

export default ReportsLayout;
