import { SvgIcon, SvgIconProps } from '@mui/material';

export default function ClientStatement(props: SvgIconProps) {
  return (
    <SvgIcon
      sx={{
        height: 36,
        width: 36,
      }}
      height="36"
      width="36"
      viewBox="0 0 36 36"
      fill="currentColor"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <rect
        opacity="0.3"
        x="1"
        y="1"
        width="34"
        height="34"
        rx="8"
        fill="#E3E6F8"
        stroke="#435B6F"
        strokeOpacity="0.14"
        strokeWidth="0.5"
      />
      <path
        d="M23.8432 15.975L20.025 12.1568C19.9211 12.0555 19.7815 11.9992 19.6364 12H13.0909C12.8016 12 12.5241 12.1149 12.3195 12.3195C12.1149 12.5241 12 12.8016 12 13.0909V25.0909C12 25.3802 12.1149 25.6577 12.3195 25.8623C12.5241 26.0669 12.8016 26.1818 13.0909 26.1818H22.9091C23.1984 26.1818 23.4759 26.0669 23.6805 25.8623C23.8851 25.6577 24 25.3802 24 25.0909V16.3636C24.0008 16.2185 23.9445 16.0789 23.8432 15.975ZM20.1818 13.8614L22.1386 15.8182H20.1818V13.8614ZM22.9091 25.0909H13.0909V13.0909H19.0909V16.3636C19.0909 16.5083 19.1484 16.647 19.2507 16.7493C19.353 16.8516 19.4917 16.9091 19.6364 16.9091H22.9091V25.0909Z"
        fill="#4B5F70"
        strokeWidth={'0.5'}
      />
    </SvgIcon>
  );
}
