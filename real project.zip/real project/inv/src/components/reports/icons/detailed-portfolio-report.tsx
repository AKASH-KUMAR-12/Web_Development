import { SvgIcon, SvgIconProps } from '@mui/material';

export default function DetailedPortfolioReport(props: SvgIconProps) {
  return (
    <SvgIcon
      sx={{
        height: 36,
        width: 36,
      }}
      height="36"
      width="36"
      viewBox="0 0 36 36"
      fill="currentColor"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <rect
        opacity="0.3"
        x="1"
        y="1"
        width="34"
        height="34"
        rx="8"
        fill="#E3E6F8"
        stroke="#435B6F"
        strokeOpacity="0.14"
        strokeWidth="0.5"
      />
      <path
        d="M25.0727 17.2636L21.1909 13.3818C21 13.1273 20.6818 13 20.3636 13H15.2727C14.5727 13 14 13.5727 14 14.2727V25.7273C14 26.4273 14.5727 27 15.2727 27H24.1818C24.8818 27 25.4545 26.4273 25.4545 25.7273V18.1545C25.4545 17.8364 25.3273 17.5182 25.0727 17.2636ZM20.3636 14.2727L24.1182 18.0909H20.3636V14.2727ZM15.2727 25.7273V14.2727H19.0909V18.0909C19.0909 18.7909 19.6636 19.3636 20.3636 19.3636H24.1818V25.7273H15.2727Z"
        fill="#011E33"
        fillOpacity="0.7"
      />
      <path
        d="M12.125 19H11V11.125C11 10.5062 11.5062 10 12.125 10H20V11.125H12.125V19Z"
        fill="#011E33"
        fillOpacity="0.7"
      />
    </SvgIcon>
  );
}
