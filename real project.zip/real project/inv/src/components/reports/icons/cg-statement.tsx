import { SvgIcon, SvgIconProps } from '@mui/material';

export default function CGStatement(props: SvgIconProps) {
  return (
    <SvgIcon
      sx={{
        height: 36,
        width: 36,
      }}
      height="36"
      width="36"
      viewBox="0 0 36 36"
      fill="currentColor"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <rect
        opacity="0.3"
        x="1"
        y="1"
        width="34"
        height="34"
        rx="8"
        fill="#E3E6F8"
        stroke="#435B6F"
        strokeOpacity="0.14"
        strokeWidth="0.5"
      />
      <path
        d="M23.9999 22.5L23.2929 21.793L22 23.086V19H21V23.086L19.707 21.793L19 22.5L21.5 24.9999L23.9999 22.5Z"
        fill="#011E33"
        fillOpacity="0.7"
        strokeWidth={'0.5'}
      />
      <path
        d="M17.9999 24H13V12.0002H16.9999V15.0001C17.0007 15.2651 17.1063 15.519 17.2937 15.7063C17.4811 15.8937 17.735 15.9993 17.9999 16.0001H20.9999V17.5001H21.9999V15.0001C22.0016 14.9344 21.9891 14.8691 21.9633 14.8087C21.9374 14.7483 21.8987 14.6942 21.8499 14.6501L18.3499 11.1502C18.3059 11.1013 18.2518 11.0626 18.1914 11.0367C18.131 11.0109 18.0656 10.9984 17.9999 11.0002H13C12.735 11.001 12.4811 11.1066 12.2938 11.2939C12.1064 11.4813 12.0008 11.7352 12 12.0002V24C12.0008 24.265 12.1064 24.5189 12.2938 24.7062C12.4811 24.8936 12.735 24.9992 13 25H17.9999V24ZM17.9999 12.2002L20.7999 15.0001H17.9999V12.2002Z"
        fill="#011E33"
        stroke={'none'}
        strokeWidth={'0.2'}
        fillOpacity="0.7"
      />
    </SvgIcon>
  );
}
