import { Navigate, Route, Routes } from 'react-router-dom';
import { ReportsContextProvider } from './data/reports.context';

import ReportsLayout from './layout';
import CGStatement from './sections/cg-statement';
import ClientStatement from './sections/client-statement';
import DetailedPortfolioReport from './sections/detailed-portfolio-report';
import PortfolioSummary from './sections/portfolio-summary';
import TransactionStatement from './sections/transaction-statement';

export default function ReportsRouter() {
  return (
    <ReportsContextProvider>
      <Routes>
        <Route path="" element={<ReportsLayout />}>
          <Route index element={<Navigate to="client-statement" />} />
          <Route path="client-statement" element={<ClientStatement />} />
          <Route path="transaction-statement" element={<TransactionStatement />} />
          <Route path="portfolio-summary" element={<PortfolioSummary />} />
          <Route path="detailed-portfolio-report" element={<DetailedPortfolioReport />} />
          <Route path="cg-statement" element={<CGStatement />} />
        </Route>
      </Routes>
    </ReportsContextProvider>
  );
}
