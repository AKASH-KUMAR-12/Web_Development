import { LoadingButton } from '@mui/lab';
import { Box, Radio, RadioProps, styled, TextField } from '@mui/material';

export const ReportsRightLayout = styled(Box)(({ theme }) => ({
  width: '100%',
  padding: theme.spacing(2, 9),
  [theme.breakpoints.down('md')]: {
    padding: theme.spacing(0),
  },
}));

export const DatePickerInput = styled(TextField)(({ theme }) => ({
  marginTop: '16px',
  marginBottom: '16px',
  backgroundColor: theme.palette.primary.light,
  borderRadius: 10,
  '& .MuiOutlinedInput-notchedOutline': {
    borderWidth: '0px',
    border: 'none',
    boxShadow: theme.shadows[24],
  },
  '& .MuiInputBase-input': {
    borderRadius: 10,
    position: 'relative',
    backgroundColor: theme.palette.primary.light,
    border: 'none',
    fontWeight: 400,
    fontSize: '1rem',
    // height: '20px',
    padding: theme.spacing(2, 2, 2, 2),
    transition: theme.transitions.create([
      'border-color',
      'background-color',
      'box-shadow',
    ]),
    '&::placeholder': {
      fontSize: '16px',
      fontWeight: '400',
    },
  },
}));

export const DownloadButton = styled(LoadingButton)(({ theme }) => ({
  padding: '10px 20px',
  boxShadow: theme.shadows[23],
  borderRadius: '8px',
  color: theme.palette.primary.light,
  textTransform: 'capitalize',
  fontSize: 16,
  fontWeight: 600,
  width: '303px',
}));

export const ReportLeftLayout = styled(Box)(({ theme }) => ({
  width: '50%',
  padding: theme.spacing(0, 3),
  [theme.breakpoints.down('md')]: {
    display: 'none',
  },
}));

const BpIcon = styled('span')(({ theme }) => ({
  borderRadius: '50%',
  width: 16,
  height: 16,
  boxShadow:
    theme.palette.mode === 'dark'
      ? '0 0 0 1px rgb(16 22 26 / 40%)'
      : 'inset 0 0 0 1px rgba(16,22,26,.2), inset 0 -1px 0 rgba(16,22,26,.1)',
  backgroundColor: theme.palette.mode === 'dark' ? '#394b59' : '#f5f8fa',
  // backgroundImage:
  //   theme.palette.mode === 'dark'
  //     ? 'linear-gradient(180deg,hsla(0,0%,100%,.05),hsla(0,0%,100%,0))'
  //     : 'linear-gradient(180deg,hsla(0,0%,100%,.8),hsla(0,0%,100%,0))',
}));

export const BpCheckedIcon = styled(BpIcon)({
  backgroundColor: '#2AC9EE',
  boxShadow: 'none',
  backgroundImage: 'linear-gradient(180deg,hsla(0,0%,100%,.1),hsla(0,0%,100%,0))',
  '&:before': {
    display: 'block',
    width: 16,
    height: 16,
    backgroundImage: 'radial-gradient(#fff,#fff 28%,transparent 32%)',
    content: '""',
  },
  'input:hover ~ &': {
    backgroundColor: '#2AC9EE',
  },
});

// Inspired by blueprintjs
export function BpRadio(props: RadioProps) {
  return (
    <Radio
      disableRipple
      color="default"
      checkedIcon={<BpCheckedIcon />}
      icon={<BpIcon />}
      {...props}
    />
  );
}

export const ReportSectionContainer = styled(Box)(({ theme }) => ({
  backgroundColor: theme.palette.background.default,
  borderRadius: theme.shape.borderRadius,
  padding: '1rem 2rem',
  marginTop: theme.spacing(2),
  [theme.breakpoints.down('md')]: {
    padding: theme.spacing(2),
  },
}));
