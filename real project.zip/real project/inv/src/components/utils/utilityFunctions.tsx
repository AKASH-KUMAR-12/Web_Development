import { withStyles } from "@material-ui/core/styles";
import { Tooltip } from "@mui/material";

export const formatToIndianCurrency = (value?: number | string | null, amountUnit?: number | null): string => {
  value = Number(value);
  amountUnit = amountUnit ? amountUnit : 0;
  const options = { style: 'currency', currency: 'INR' };
  if (value !== (undefined || null) && !isNaN(value)) {
    if (amountUnit == 0) {
      return new Intl.NumberFormat('en-IN', options).format(value);
    }
    else if (amountUnit == 1 && value >= 10000000) {
      value = value / 10000000;
      return new Intl.NumberFormat('en-IN', options).format(value) + ' Cr';
    }
    else {
      value = value / 100000;
      return new Intl.NumberFormat('en-IN', options).format(value) + ' Lakhs';
    }
  }
  return '';
};

export const convertDate = (date: string) => {
  if (!date) {
    return '';
  }
  const date_value = new Date(date);
  const options: any = { day: 'numeric', month: 'short', year: 'numeric' };
  const formattedDateParts = date_value.toLocaleDateString('en-US', options).split(' ');
  const month = formattedDateParts[0];
  const day = formattedDateParts[1].slice(0, -1);
  const year = formattedDateParts[2];
  const formattedDate = `${day}-${month}-${year}`;
  return formattedDate
}

export const InvestNowTooltip = withStyles({
    tooltip: {
      color: "grey",
      fontSize: '13px',
      backgroundColor: "#ffffff",
      height: '25px',
      border: '0.5px solid grey',
      borderRadius: '8px'
    }
  })(Tooltip);

export function roundToTwo(num: number) {
    const num2 = num + "e+2";

    return +(Math.round(Number(num2)) + "e-2");
  }

export const Nanprocessor = function (entry: any) {
    if (entry) {
      return entry;
    } else {
      return 0;
    }
  }