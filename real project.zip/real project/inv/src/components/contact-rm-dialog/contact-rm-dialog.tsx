import { Close as CloseIcon } from '@mui/icons-material';
import {
  Box,
  Button,
  Dialog,
  DialogContent,
  DialogTitle as MuiDialogTitle,
  IconButton,
  styled,
  Typography,
} from '@mui/material';

import ContactRmIcon from './icons/contact-rm';
import MailIcon from './icons/mail';
import PhoneIcon from './icons/phone';
import { useLoginContext } from '../login/data/login.context';


const DialogTitle = styled(Typography)(({ theme }) => ({
  fontFamily: 'Roboto' + theme.typography.fontFamily,
  fontSize: '22px',
  fontWeight: 500,
  letterSpacing: '0.06em',
  textAlign: 'center',
  textTransform: 'uppercase',
  flex: 1,
}));

const IconContainer = styled(Box)({
  width: '100%',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
});

const Title = styled(Typography)(({ theme }) => ({
  fontFamily: 'Poppins' + theme.typography.fontFamily,
  fontSize: '24px',
  fontWeight: 600,
  color: theme.palette.text.dialogTitle,
  [theme.breakpoints.down('sm')]: {
    fontSize: '20px',
  },
}));

const ButtonsContainer = styled(Box)({
  display: 'flex',
  flexDirection: 'column',
  gap: '1em',
});

const CustomButton = styled(Button)(({ theme }) => ({
  borderRadius: '40px',
  padding: 'inherit 1.5em',
  textTransform: 'unset',
  [theme.breakpoints.down('md')]: {
    fontSize: '16px',
  },
}));

const ContactRmDialog = ({
  open,
  handleClose,
  width
}: {
  open: boolean;
  handleClose(): void;
  width:boolean;
}) => {
  const { rmDetails } = useLoginContext();
  return (
    <Dialog onClose={handleClose} open={open} fullScreen={width} >
      <MuiDialogTitle>
        <DialogTitle>Contact RM</DialogTitle>
        <IconButton
          aria-label="close"
          onClick={handleClose}
          sx={{
            position: 'absolute',
            right: 10,
            top: 8,
            color: (theme) => theme.palette.grey[500],
          }}
        >
          <CloseIcon />
        </IconButton>
      </MuiDialogTitle>
      <DialogContent>
        <Box
          sx={{
            display: 'flex',
            flexDirection: 'column',
            gap: '1em',
            alignItems: 'center',
            justifyContent: 'center',
            // width: ['min-content', 'min-content', {xs:"100%",sm:'35vw'}],
            width:{xs:"100%",sm:'35vw'},
            height: 'min-content',
          }}
        >
          <IconContainer>
            <ContactRmIcon
              sx={{ width: '100%', height: ['150px', '150px', '200px', '250px'] }}
            />
          </IconContainer>
          {rmDetails?.rmName && <Title>{rmDetails?.rmName}</Title>}
          <ButtonsContainer>
            {rmDetails?.rmEmail && (
              <CustomButton
                variant="outlined"
                color="primary"
                onClick={(e) => {
                  e.preventDefault();
                  window.location.href = 'mailto:raghav.singh1976@xyz.com';
                }}
                startIcon={<MailIcon />}
                fullWidth
                sx={{ color: 'text.dialogMailText' }}
              >
                {rmDetails?.rmEmail}
              </CustomButton>
            )}
            {rmDetails?.rmMobile && (
              <CustomButton
                variant="contained"
                onClick={(e) => {
                  e.preventDefault();
                  window.location.href = 'tel:+919666691139';
                }}
                color="primary"
                startIcon={<PhoneIcon />}
              >
                (91) {rmDetails?.rmMobile}
              </CustomButton>
            )}
          </ButtonsContainer>
        </Box>
      </DialogContent>
    </Dialog>
  );
};

export default ContactRmDialog;
