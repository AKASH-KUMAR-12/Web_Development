import { LinearProgress } from '@mui/material';
import { styled } from '@mui/system';
import CssBaseline from '@mui/material/CssBaseline';
import { SnackbarProvider } from 'notistack';
import { lazy, Suspense } from 'react';
import { Navigate, useRoutes } from 'react-router-dom';

import { AppThemeContextProvider } from './AppTheme';
import { DashboardContextProvider } from './components/dashboard/data/dashboard.context';
import RootContextProvider from './components/data/root.context';
import DashboardLayout from './components/layouts/dashboard.layout';
import { LoginContextProvider } from './components/login/data/login.context';
import RequireAuth from './components/require-auth/require-auth';
import Cart from './components/payment/cart';
import MakePayment from './components/transactionModule/make-payment';
import OtpPage from './components/transactionModule/otp-page';
import InvestorTransactions from './components/transactionModule/investor-transactions';
import { GetTotalDataProvider } from './components/transactionModule/transaction.context';
import { TransactionIndex } from './components/transactionModule';
import { SchemeRecommendations } from './components/transactionModule/recommendations';
import { PaymentContext } from './components/payment/payment.context';
import AddMandate from './components/transactionModule/add-mandate';
import { MaterialDesignContent } from 'notistack';
import NotificationsIcon from '@mui/icons-material/Notifications';

const Dashboard = lazy(() => import('./components/dashboard/dashboard.component'));
const LoginRouter = lazy(() => import('./components/login/router'));
// const ProfileRouter = lazy(() => import('./components/profile/router'));
const ReportsRouter = lazy(() => import('./components/reports/router'));
const TransactionRouter = lazy(() => import('./components/transactionModule/router'));

const StyledMaterialDesignContent = styled(MaterialDesignContent)(() => ({
  '&.notistack-MuiContent-info': {
    backgroundColor: '#203e94',
    cursor: 'pointer'
  },
}));

function App() {
  return (
    <>
      <AppThemeContextProvider>
        <CssBaseline />
        <SnackbarProvider maxSnack={3} 
        Components={{
          info: StyledMaterialDesignContent,
        }}
        iconVariant={{
          info: <NotificationsIcon />,
        }}>
          <RootContextProvider>
            <LoginContextProvider>
              <AppRoutes />
            </LoginContextProvider>
          </RootContextProvider>
        </SnackbarProvider>
      </AppThemeContextProvider>
    </>
  );
}

const routes = (isLoggedIn: boolean) => [
  {
    path: '/login/*',
    element: isLoggedIn ? <Navigate to="/dashboard" /> : <LoginRouter />,
  },
  {
    element: <RequireAuth />,
    children: [
      {
        path: '/',
        element: <DashboardLayout />,
        children: [
          { index: true, element: <Navigate to="dashboard" /> },
          {
            path: 'dashboard/*',
            element: (
              <DashboardContextProvider>
                <Dashboard />
              </DashboardContextProvider>
            ),
          },
          { path: 'reports/*', element: <ReportsRouter /> },
          { path: 'invest/*', element: <GetTotalDataProvider><TransactionIndex/></GetTotalDataProvider> },
          { path: 'cart/*', element: <PaymentContext><Cart/></PaymentContext> },
          {path: 'make-payment/*', element: <MakePayment />}, 
          {path: "otp-page/*", element: <OtpPage/>},
          {path: 'add-mandate/*', element: <PaymentContext><AddMandate/></PaymentContext>}
          // {path: 'recommendations/*', element: <TransactionProvider><SchemeRecommendations /></TransactionProvider>}
          // { path: 'profile/*', element: <ProfileRouter /> },
        ],
      },
    ],
  },
];

function AppRoutes() {
  const isLoggedIn = Boolean(sessionStorage.getItem('token'));
  const routing = useRoutes(routes(isLoggedIn));
  return <Suspense fallback={<LinearProgress />}>{routing}</Suspense>;
}

export default App;