#!/bin/bash

# Uncomment the below 2 commands only when want to dockerize 2nd time on same day, as an image will be present with same day so need to delete the container and image first

# docker container rm -f o3capital_frontend # Remove container
# docker image rm o3capital_frontend:imageDate #remove image

docker build -t o3capital_frontend:$1 .
docker rm -f o3capital_frontend
docker run -d -p 3008:3008 --restart=always --name=o3capital_frontend o3capital_frontend:$1
docker logs -f o3capital_frontend