const AUM = {
    InvestorCategory: {
        Donut: {
            data: [
                {
                    label: "Non-Retail",
                    value: "1000",
                },
                {
                    label: "Retail",
                    value: "500",

                }
            ]
        },
        list: {
            data: ["Retail AUM has grown(YoY) by 980 Cr AUM", "Non-retail AUM has grown(YoY) by 1590 Cr AUM"]
        }
    },
    AssetClass: {
        Donut: {
            data: [
                {
                    label: "Hybrid",
                    value: "1000",

                },
                {
                    label: "Debt",
                    value: "500",

                },
                {
                    label: "Equity",
                    value: "400",

                }
            ]
        },
        list: {
            data: [
                "Equity AUM has grown(YoY) by 13,231 Cr.",
                "Dept AUM has grown(YoY) by 645 Cr.",
                "Hybrid AUM has grown(YoY) by 848 Cr."
            ]
        }
    },
    AssetCategory: {
        VerticalBarChart: {

        },
    },
    PlanMode: {
        Donut: {
            data:[
                {
                    label:"Direct",
                    value:"58"
                },
                {
                    label:"Regular",
                    value:"42"
                }
            ]
        },
    },
    T30: {
        Donut: {
            data:[
                {
                    label:"B30",
                    value:"58"
                },
                {
                    label:"T30",
                    value:"42"
                }
            ]
        },

    },
    DistributorCategory: {
        ColumnChart: {
            data :[
                {
                    label: "MFD(IFA)",
                    value: "41"
                },
                {
                    label: "ND",
                    value: "50"
                },
                {
                    label: "BANK",
                    value: "32"
                }
            ]
        }
    },
    InvestorDemography: {
        VerticalBarChart: {
            data : [
                {
                  label: "<18",
                  value: "9"
                },
                {
                  label: "18-25",
                  value: "30"
                },
                {
                  label: "25-35",
                  value: "57"
                },
                {
                  label: "35-45",
                  value: "95"
                },
                {
                  label: "45-55",
                  value: "22"
                },
                {
                  label: "55-65",
                  value: "35"
                },
                {
                  label: ">65",
                  value: "88"
                }
              ]
        },
    },
    TrendGraph: {
        LineChart: {
            data: [{
                value: "25"
              },
              {
          
                value: "32"
              },
              {
          
                value: "43"
              },
              {
          
                value: "34"
              },
              {
          
                value: "44"
              },
              {
          
                value: "40"
              },
              {
          
                value: "55"
              },
              {
          
                value: "58",
          
              },
              {
          
                value: "65",
          
              }]
        }
    },
}
const assetClassData = [
    {
        "label": "Hybrid",
        "value": "33"
    },
    {
        "label": "Debt",
        "value": "33"
    },
    {
        "label": "Equity",
        "value": "33"
    },

]
const planModelistArray = [
    "Direct SIP book has grown by 172 Cr SIP book",
    "Regular SIP book has grown by 278 Cr SIP book",
    "Contribution of direct SIP Book has grown up by 7%"
]
const data = [
    {
        label: "MFD(IFA)",
        value: "41"
    },
    {
        label: "ND",
        value: "50"
    },
    {
        label: "DIRECT",
        value: "30"
    },
    {
        label: "RIA",
        value: "35"
    },
    {
        label: "BANK",
        value: "32"
    }
]
const SIPAgeingData = [
    {
        label: "0-1",
        "value": "700000"
    },
    {
        label: "1-2",
        "value": "250000"
    },
    {
        label: "2-3",
        "value": "550000"
    },
    {
        label: "3-4",
        "value": "470000"
    },
    {
        label: "4-5",
        "value": "660000"
    },
    {
        label: ">5",
        "value": "370000"
    },
]
const revenueData = {
    data1: [
        {
            value: "60"
        },
        {
            value: "63"
        },
        {
            value: "65"
        },
        {
            value: "68"
        },
        {
            value: "75"
        },
        {
            value: "80"
        },

        {
            value: "89"
        },
        {
            value: "98"
        },
        {
            value: "120"
        },

    ],
    data2: [
        {
            value: "62"
        },
        {
            value: "64"
        },
        {
            value: "64"
        },
        {
            value: "66"
        },
        {
            value: "78"
        },
        {
            value: "82"
        },
        {
            value: "87"
        },
        {
            value: "97"
        },
        {
            value: "121"
        },
        {
            value: "125"
        },
        {
            value: "126"
        },
        {
            value: "132"
        },
    ],

}

export { revenueData, SIPAgeingData, data, planModelistArray, assetClassData }