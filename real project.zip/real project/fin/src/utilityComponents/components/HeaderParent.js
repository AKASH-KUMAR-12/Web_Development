import React from 'react'
import { FormControl, FormControlLabel, Grid, Radio, RadioGroup } from '@mui/material'
import HoverableDropdown from '../subcomponents/Dropdown';
const HeaderParent = (props) => {
    const { type, height, heading, radioList, radioValue, setRadioValue, dropdownOptions, dropdownValue, setDropdownValue, legendArray, capsuleBtn, capsuleBtnValue, setCapsuleBtnValue, xs, xs1, xs2, xs3 } = props.headerProps;
    // console.log(heading, ">>>>>>", capsuleBtnValue)
    // console.log("*******************************************************************************", props);

    return (

        <Grid container sx={{
            mt: .5,
            backgroundColor: 'white',
            // boxShadow: 6,
            // borderRadius: "8px",
            borderBottom: "1px solid #969696",
            display: "flex",
            justifyContent: "space-between",
            marginBottom: "1px",
            alignItems: "center",
            height: height
        }}>
            <Grid item xs={xs1 || 4} style={{
                padding: '10px 12px 9px 22px',
                fontSize: '16px',
                fontWeight: 'bold',
                textAlign: 'left',
            }}>{heading}</Grid>
            {legendArray && <Grid item xs={xs2 || 4} display={"flex"} alignItems={"center"} justifyContent={"center"}>
                {legendArray.map((ele, index) =>
                    <p key={index} style={{ height: "1rem", borderLeft: "1rem solid #2057A6", borderColor: `${ele.color}`, fontSize: ".8rem", margin: "0rem 0.2rem", padding: "0rem .5rem" }}>{ele.label}</p>
                )}
            </Grid>
            }
            {capsuleBtn && <Grid item xs={xs2 || 4} display={"flex"} alignItems={"center"} justifyContent={"center"}>
                <button
                    onClick={(e) => setCapsuleBtnValue(capsuleBtn[0])}
                    style={{
                        cursor: "pointer",
                        padding: "7px 40px",
                        marginLeft: "10px",
                        borderRadius: "20px 0px 0px 20px",
                        border: "1px solid #2057A6",
                        fontSize: '.8rem',
                        backgroundColor: capsuleBtnValue === capsuleBtn[0] ? "#2057A6" : "#fff",
                        color: capsuleBtnValue === capsuleBtn[0] ? "#fff" : "",
                    }}
                >
                    {capsuleBtn[0]}
                </button>
                <button
                    onClick={(e) => setCapsuleBtnValue(capsuleBtn[1])}
                    style={{
                        cursor: "pointer",
                        padding: "7px 40px",
                        borderRadius: "0px 20px 20px 0px",
                        border: "1px solid #2057A6",
                        backgroundColor: capsuleBtnValue !== capsuleBtn[0] ? "#2057A6" : "#fff",
                        color: capsuleBtnValue !== capsuleBtn[0] ? "#fff" : "",
                        fontSize: '.8rem',
                    }}
                >
                    {capsuleBtn[1]}
                </button>
            </Grid>
            }
            {radioList &&
                <Grid item xs={xs3 || 4} style={{ justifySelf: "end", display: "flex", justifyContent: "end" }}>
                    <FormControl>
                        <RadioGroup
                            sx={{
                                '& .MuiTypography-root': {
                                    fontSize: '.8rem',
                                },
                                '& .MuiSvgIcon-root': {
                                    fontSize: "1rem",
                                },
                            }}
                            row
                            aria-labelledby="demo-controlled-radio-buttons-group"
                            name="controlled-radio-buttons-group"
                            value={radioValue}
                            // defaultValue={radioList[0]}
                            onChange={(event) => {
                                // console.log(">>>>>>>>>>>", event.target.value)
                                setRadioValue(event.target.value)
                            }
                            }>
                            {radioList.map((value, key) => (
                                <FormControlLabel key={key}
                                    value={value}
                                    control={<Radio size='small' />}
                                    label={value}
                                />
                            ))}
                        </RadioGroup>
                    </FormControl>
                </Grid>}
            {
                dropdownOptions &&
                <Grid item xs={xs3 || 4} style={{ justifySelf: "end", display: "flex", justifyContent: "end", paddingInline: ".5rem" }}>
                    <HoverableDropdown dropdownOptions={dropdownOptions} dropdownValue={dropdownValue} setDropdownValue={setDropdownValue} />
                </Grid>
            }
        </Grid>
    )

}

export default HeaderParent