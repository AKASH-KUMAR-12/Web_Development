import React, { useEffect, useState } from 'react';
import ReactFC from 'react-fusioncharts';
import FusionCharts from 'fusioncharts';
import FusionMaps from 'fusioncharts/fusioncharts.maps';
import India from 'fusionmaps/maps/fusioncharts.india';
import Odisha from 'fusionmaps/maps/fusioncharts.odisha';
import Maharashtra from 'fusionmaps/maps/fusioncharts.maharashtra';
import AndraPradesh from 'fusionmaps/maps/fusioncharts.andhrapradesh';
import arunachalpradesh from 'fusionmaps/maps/fusioncharts.arunachalpradesh';
import Rajasthan from 'fusionmaps/maps/fusioncharts.rajasthan';
import Bihar from 'fusionmaps/maps/fusioncharts.bihar';
import Assam from 'fusionmaps/maps/fusioncharts.assam';
import Nagaland from 'fusionmaps/maps/fusioncharts.nagaland';
import Punjab from 'fusionmaps/maps/fusioncharts.punjab';
import gujarat from 'fusionmaps/maps/fusioncharts.gujarat';
import delhi from 'fusionmaps/maps/fusioncharts.delhi';
import chandigarh from 'fusionmaps/maps/fusioncharts.chandigarh';
import chhattisgarh from 'fusionmaps/maps/fusioncharts.chhattisgarh';
import goa from 'fusionmaps/maps/fusioncharts.goa';
import haryana from 'fusionmaps/maps/fusioncharts.haryana';
import himachalpradesh from 'fusionmaps/maps/fusioncharts.himachalpradesh';
import jammuandkashmir from 'fusionmaps/maps/fusioncharts.jammuandkashmir';
import jharkhand from 'fusionmaps/maps/fusioncharts.jharkhand';
import karnataka from 'fusionmaps/maps/fusioncharts.karnataka';
import kerala from 'fusionmaps/maps/fusioncharts.kerala';
import madhyapradesh from 'fusionmaps/maps/fusioncharts.madhyapradesh';
import manipur from 'fusionmaps/maps/fusioncharts.manipur';
import meghalaya from 'fusionmaps/maps/fusioncharts.meghalaya';
import mizoram from 'fusionmaps/maps/fusioncharts.mizoram';
import puducherry from 'fusionmaps/maps/fusioncharts.puducherry';
import sikkim from 'fusionmaps/maps/fusioncharts.sikkim';
import tamilnadu from 'fusionmaps/maps/fusioncharts.tamilnadu';
import lakshadweep from 'fusionmaps/maps/fusioncharts.lakshadweep';
import uttarakhand from 'fusionmaps/maps/fusioncharts.uttarakhand';
import uttarpradesh from 'fusionmaps/maps/fusioncharts.uttarpradesh';
import westbengal from 'fusionmaps/maps/fusioncharts.westbengal';
import telangana from 'fusionmaps/maps/fusioncharts.telangana';
import dadraandnagarhaveli from 'fusionmaps/maps/fusioncharts.dadraandnagarhaveli';
import damananddiu from 'fusionmaps/maps/fusioncharts.damananddiu';
import andamanandnicobar from 'fusionmaps/maps/fusioncharts.andamanandnicobar';
import tripura from 'fusionmaps/maps/fusioncharts.tripura';
import FusionTheme from 'fusioncharts/themes/fusioncharts.theme.fusion';
import MapTable from './MapTable';
import { Box, CircularProgress, FormControlLabel, Grid, Radio, RadioGroup } from '@mui/material';
import HeaderParent from "../../utilityComponents/components/HeaderParent";
import { useDispatch, useSelector } from 'react-redux';
import axios from 'axios';
import { clearAumFilterData, clearFilterData, setAssetCategoryData, setAssetClassData, setAumData, setFilterSelected, setStateData, setZoneData } from '../../reduxStore/filterReducer';
import { ArrowBack } from '@mui/icons-material';
import { clearFlowFilterData, setFlowData } from '../../reduxStore/flowReducer';
import { useLocation } from 'react-router-dom';
import ChevronLeftRoundedIcon from '@mui/icons-material/ChevronLeftRounded';
ReactFC.fcRoot(FusionCharts, FusionMaps, India,
    Odisha,
    Maharashtra,
    jharkhand,
    AndraPradesh,
    Rajasthan,
    Bihar,
    Assam,
    Nagaland,
    Punjab,
    arunachalpradesh,
    gujarat,
    dadraandnagarhaveli,
    damananddiu,
    delhi,
    chandigarh,
    chhattisgarh,
    goa,
    haryana,
    himachalpradesh,
    jammuandkashmir,
    jharkhand,
    karnataka,
    kerala,
    madhyapradesh,
    manipur,
    meghalaya,
    mizoram,
    puducherry,
    sikkim,
    tamilnadu,
    uttarakhand,
    uttarpradesh,
    westbengal,
    telangana,
    tripura,
    lakshadweep,
    andamanandnicobar,
    FusionTheme);

const mapData = [
    { "id": "001", "value": 2834, fontColor: "#96967F" },
    { "id": "002", "value": 3182, },
    { "id": "003", "value": 2280, },
    { "id": "004", "value": 2911, },
    { "id": "005", "value": 2292, },
    { "id": "006", "value": 530, },
    { "id": "007", "value": 1515, },
    { "id": "008", "value": 2515, },
    { "id": "009", "value": 728, },
    { "id": "010", "value": 974, },
    { "id": "011", "value": 1848, fontColor: "#96967F" },
    { "id": "012", "value": 1278, },
    { "id": "013", "value": 463, },
    { "id": "014", "value": 198, },
    { "id": "015", "value": 378, },
    { "id": "016", "value": 2610, },
    { "id": "017", "value": 3200, },
    { "id": "018", "value": 3820, },
    { "id": "019", "value": 940, },
    { "id": "020", "value": 1416, },
    { "id": "021", "value": 1004, },
    { "id": "022", "value": 2604, },
    { "id": "023", "value": 4011, },
    { "id": "024", "value": 2203, },
    { "id": "025", "value": 2775, },
    { "id": "026", "value": 2721, },
    { "id": "027", "value": 3417, fontColor: "#96967F" },
    { "id": "028", "value": 347, },
    { "id": "029", "value": 1530, },
    { "id": "030", "value": 2530, },
    { "id": "031", "value": 3530, },
    { "id": "032", "value": 2530, },
    { "id": "033", "value": 530, },
    { "id": "034", "value": 120, },
    { "id": "035", "value": 2520, },
    { "id": "036", "value": 3530, },
    { "id": "037", "value": 520, },
]
const ChartConfig = {
    "chart": {
        "animation": "1",
        "showLabels": "1",
        "entityFillColor": "#A8A8A8",
        "entityFillHoverColor": "#E5E5E9",
        "theme": "fusion",
        "showBorder": "1",
        "bordercolor": "#FFFFFF",
        "entityborderThickness": "1",
        "fillColor": "#19a6f8",
        "fillAlpha": 100,
        "nullEntityColor": "#19a6f8",
        "showlegend": "0",
    }
}
const LinkData = [{
    "id": "AP",
    "linkedchart": ChartConfig
}
]
const colorrange = {
    "minvalue": "0",
    "startlabel": "Low",
    "endlabel": "High",
    "code": "#2c46f2",
    "gradient": "0",
    "color": [
        { "maxvalue": "2000", "code": "#4990F0" },
        { "maxvalue": "3000", "code": "#8ED8B7" },
        { "maxvalue": "1000", "code": "#7CD4DE" },
        { "maxvalue": "4000", "code": "#BA87ED" },
    ]
};





const MapChart = ({ fetchAPI, fetchMapAPI, fetchPayload, cardSelected, tableColumn, headerProps }) => {
    const [mapType, setMapType] = useState("maps/india");
    const [showBackBtn, setShowBackBtn] = useState(false);
    const [apiMapData, setApiMapData] = useState([]);
    const [apiData, setApiData] = useState([]);
    const [mapBgColor, setMapBgColor] = useState("#c2c2bc");
    const [loading, setLoading] = useState(false);

    const dispatch = useDispatch();

    const page = useLocation().pathname;
    let reducerName = "filterData";
    let setReducerData = setAumData;
    let clearFilterData = clearAumFilterData;
    switch (page) {
        case "/app/aum": {
            reducerName = "filterData"
            setReducerData = setAumData;
            clearFilterData = clearAumFilterData;
            break;
        }
        case "/app/flow": {
            reducerName = "flowFilterData"
            setReducerData = setFlowData;
            clearFilterData = clearFlowFilterData;
            break;
        }
    }


    const reducerState = useSelector((state) => state[reducerName])

    const stateID = {
        "KARNATAKA": "017",
        "DAMAN AND DIU": "009",
        "OTHERS": "000",
        "DELHI": "010",
        "LADAKH": "",
        "RAJASTHAN": "029",
        "MANIPUR": "022",
        "ANDHRA PRADESH": "002",
        "WEST BENGAL": "035",
        "MADHYA PRADESH": "020",
        "KERALA": "018",
        "GUJARAT": "012",
        "TELANGANA": "036",
        "ANDAMAN AND NICOBAR": "001",
        "BIHAR": "005",
        "GOA": "011",
        "CHANDIGARH": "006",
        "TRIPURA": "032",
        "DADRA AND NAGAR HAVELI": "008",
        "NAGALAND": "025",
        "JHARKHAND": "016",
        "ASSAM": "004",
        "PUNJAB": "028",
        "JAMMU AND KASHMIR": "015",
        "PUDUCHERRY": "027",
        "ODISHA": "026",
        "MEGHALAYA": "023",
        "MIZORAM": "024",
        "MAHARASHTRA": "021",
        "ARUNACHAL PRADESH": "003",
        "CHHATTISGARH": "007",
        "TAMIL NADU": "031",
        "SIKKIM": "030",
        "LAKSHADWEEP": "019",
        "HARYANA": "013",
        "UTTAR PRADESH": "033",
        "UTTARAKHAND": "034",
        "HIMACHAL PRADESH": "014"
    }
    const stateZone = {
        "KARNATAKA": "South",
        "ANDHRA PRADESH": "South",
        "PUDUCHERRY": "South",
        "KERALA": "South",
        "TELANGANA": "South",
        "TAMIL NADU": "South",
        "LAKSHADWEEP": "South",

        "MAHARASHTRA": "West",
        "DAMAN AND DIU": "West",
        "GUJARAT": "West",
        "RAJASTHAN": "West",
        "GOA": "West",
        "MADHYA PRADESH": "West",
        "DADRA AND NAGAR HAVELI": "West",

        "DELHI": "North",
        "JAMMU AND KASHMIR": "North",
        "PUNJAB": "North",
        "HARYANA": "North",
        "UTTARAKHAND": "North",
        "HIMACHAL PRADESH": "North",
        "UTTAR PRADESH": "North",
        "LADAKH": "North",
        "CHANDIGARH": "North",

        "WEST BENGAL": "East",
        "CHHATTISGARH": "East",
        "ANDAMAN AND NICOBAR": "East",
        "BIHAR": "East",
        "MANIPUR": "East",
        "TRIPURA": "East",
        "NAGALAND": "East",
        "JHARKHAND": "East",
        "ASSAM": "East",
        "ODISHA": "East",
        "MEGHALAYA": "East",
        "MIZORAM": "East",
        "ARUNACHAL PRADESH": "East",
        "SIKKIM": "East",

        "OTHERS": "None",
    }
    const colorCode = {
        "North": "#61c99b",
        "South": "#ba87ed",
        "East": "#5abec7",
        "West": "#4990f0"
    }
    //Labels that should have black font
    const darkFontID = ["001", "011", "019", "027"]
    let pageArr = ["/app/aum", "/app/flow"]
    useEffect(() => {
        // if (!pageArr.includes(page)) { setApiMapData(mapData) }
        const fetchdata = async () => {
            if (fetchMapAPI) { setApiMapData(await fetchMapAPI({ ...fetchPayload, "demographyColumn": "final_state" }, { cardSelected })) }
        }
        fetchdata();
    },
        [reducerState, cardSelected, page])

    useEffect(() => {
        let newPayload;
        switch (headerProps.radioValue) {
            case "Region": {
                newPayload = { ...fetchPayload, "demographyColumn": "zone" }
                break
            }
            case "State": {
                newPayload = { ...fetchPayload, "demographyColumn": "final_state" }
                break
            }
            case "City": {
                newPayload = { ...fetchPayload, "demographyColumn": "final_city" }
                break
            }
        }
        const fetchdata = async () => {
            setLoading(true);
            if (fetchAPI) { setApiData(await fetchAPI(newPayload, { radioValue: headerProps.radioValue, cardSelected })) }
            setLoading(false)
        }
        fetchdata();
    },
        [reducerState, headerProps.radioValue, cardSelected])

    useEffect(() => {
        if (!reducerState.filterSelected) {
            setMapBgColor("#c2c2bc")
            setMapType("maps/india")
            setShowBackBtn(false);
        }
    }, [reducerState.filterSelected])
    // console.log(`Investor-Base-${headerProps.capsuleBtnValue?.substring(0, 3)}`)

    const chartConfigs = {
        type: mapType,
        width: '98%',
        height: '500',
        dataFormat: 'json',
        dataSource: {
            "chart": {
                chartLeftMargin: "40",
                chartRightMargin: "0",
                chartTopMargin: "0",
                chartBottomMargin: "0",
                showLabels: "1",
                includeNameInLabels: "1",
                useSNameInLabels: "0",
                baseFontColor: "#ffffff",
                baseFontSize: 10,
                borderColor: "#FFFFFF",
                borderAlpha: "100",
                "animation": "0",
                "showbevel": "0",
                "usehovercolor": "1",
                "showlegend": "0",
                toolTipBgColor: "#000000",
                "showBorder": "1",
                "entityborderThickness": "1.5",
                nullEntityColor: mapBgColor,
                nullEntityAlpha: "100",
                "entityFillHoverColor": "#5AC1FD",
                labelConnectorColor: "#000000",
                labelConnectorAlpha: "100",
                // bgColor: "#9feeef,#5ac1fd",
                // "hovercolor": "#E5E5E9",
                "theme": "fusion"
            },
            connectors: {
                thickness: 10,
                color: "#ffffff"
            },
            // "colorrange": colorrange,
            "data": apiMapData,
            "linkeddata": LinkData
        },
        "events": {
            // "renderComplete": function (e) {
            //     e.sender.configureLink({
            //         "type": "maps/india"
            //     }, 0);

            //     e.sender.addEventListener("entityClick", function (eventObj, dataObj) {
            //         const clickedRegion = dataObj.id;

            //         console.log(">>>>>>>>>>>>>>>>>>>>", dataObj)
            //         const regionToChartType = {
            //             "001": "maps/andamanandnicobar",
            //             "002": "maps/andhrapradesh",
            //             "003": "maps/arunachalpradesh",
            //             "004": "maps/assam",
            //             "005": "maps/bihar",
            //             "006": "maps/chandigarh",
            //             "007": "maps/chhattisgarh",
            //             "008": "maps/dadraandnagarhaveli",
            //             "009": "maps/damananddiu",
            //             "010": "maps/delhi",
            //             "011": "maps/goa",
            //             "012": "maps/gujarat",
            //             "013": "maps/haryana",
            //             "014": "maps/himachalpradesh",
            //             "015": "maps/jammuandkashmir",
            //             "016": "maps/jharkhand",
            //             "017": "maps/karnataka",
            //             "018": "maps/kerala",
            //             "019": "maps/lakshadweep",
            //             "020": "maps/madhyapradesh",
            //             "021": "maps/maharashtra",
            //             "022": "maps/manipur",
            //             "023": "maps/meghalaya",
            //             "024": "maps/mizoram",
            //             "025": "maps/nagaland",
            //             "026": "maps/odisha",
            //             "027": "maps/puducherry",
            //             "028": "maps/punjab",
            //             "029": "maps/rajasthan",
            //             "030": "maps/sikkim",
            //             "031": "maps/tamilnadu",
            //             "032": "maps/tripura",
            //             "033": "maps/uttarpradesh",
            //             "034": "maps/uttarakhand",
            //             "035": "maps/westbengal",
            //             "036": "maps/telangana",
            //             "037": "maps/jammuandkashmir",
            //         };
            //         const linkedChartType = regionToChartType[clickedRegion];
            //         // if (linkedChartType) {
            //         //     e.sender.configureLink({
            //         //         "type": linkedChartType
            //         //     }, 0);
            //         // }
            //         if (localStorage.getItem("Finstax:AssetClassCategoryData")) {
            //             const localData = JSON.parse(localStorage.getItem("Finstax:AssetClassCategoryData"));
            //             dispatch(setAssetClassData({ assetclass: localData["AssetClass"] }))
            //             dispatch(setAssetCategoryData({ assetcategory: localData["AssetCategory"] }))
            //         }
            //         dispatch(setFilterSelected({ filterSelected: true }))
            //         dispatch(setStateData({ state: [dataObj.label] }))
            //     });

            // }
            "entityClick": function (e, dataObj) {
                const regionToChartType = {
                    "001": "maps/andamanandnicobar",
                    "002": "maps/andhrapradesh",
                    "003": "maps/arunachalpradesh",
                    "004": "maps/assam",
                    "005": "maps/bihar",
                    "006": "maps/chandigarh",
                    "007": "maps/chhattisgarh",
                    "008": "maps/dadraandnagarhaveli",
                    "009": "maps/damananddiu",
                    "010": "maps/delhi",
                    "011": "maps/goa",
                    "012": "maps/gujarat",
                    "013": "maps/haryana",
                    "014": "maps/himachalpradesh",
                    "015": "maps/jammuandkashmir",
                    "016": "maps/jharkhand",
                    "017": "maps/karnataka",
                    "018": "maps/kerala",
                    "019": "maps/lakshadweep",
                    "020": "maps/madhyapradesh",
                    "021": "maps/maharashtra",
                    "022": "maps/manipur",
                    "023": "maps/meghalaya",
                    "024": "maps/mizoram",
                    "025": "maps/nagaland",
                    "026": "maps/odisha",
                    "027": "maps/puducherry",
                    "028": "maps/punjab",
                    "029": "maps/rajasthan",
                    "030": "maps/sikkim",
                    "031": "maps/tamilnadu",
                    "032": "maps/tripura",
                    "033": "maps/uttarpradesh",
                    "034": "maps/uttarakhand",
                    "035": "maps/westbengal",
                    "036": "maps/telangana",
                    "037": "maps/jammuandkashmir",
                };

                if (reducerState.zone.includes(stateZone[dataObj.label.toUpperCase()].toUpperCase())) {
                    setMapType(regionToChartType[dataObj.id])
                    setMapBgColor(colorCode[stateZone[dataObj.label.toUpperCase()]])
                    setShowBackBtn(true);
                    dispatch(setReducerData({ title: "state", value: [dataObj.label.toUpperCase()] }))
                    dispatch(setReducerData({ title: "filterSelected", value: true }))

                }
            }
        }
    };
    console.log(apiData)
    return (
        <Grid item xs={12} sx={{
            bgcolor: "#fff",
            borderRadius: "8px",
            boxShadow: 6,
            marginTop: "20px",
            paddingTop: ".1rem",
            alignItems: "center",
            height: "auto",
        }}>
            <HeaderParent
                headerProps={headerProps}
            />
            <Box sx={{ display: 'flex', justifyContent: "center", alignItems: "center", flexWrap: "wrap", width: "100%", paddingBlock: "2%" }}>
                <Box sx={{ position: "relative", width: { lg: "60%", xs: "70%" }, padding: ".5rem", bgcolor: "white", height: 500 }} >
                    <button onClick={() => {
                        dispatch(clearFilterData("state"));
                        setMapBgColor("#c2c2bc")
                        setMapType("maps/india")
                        setShowBackBtn(false);
                    }}
                        style={{ position: "absolute", zIndex: 5, left: 2, height: "fit-content", borderRadius: "0.5rem", display: showBackBtn ? "block" : "none", cursor: "pointer", borderColor: "#fff", background: "#2057A6", color: "#fff", paddingInline: ".3rem", }}><ChevronLeftRoundedIcon fontSize='medium' /></button>


                    <ReactFC style={{ position: "absolute", top: "50%", left: "50%" }}  {...chartConfigs} />
                </Box>
                <Box sx={{
                    width: {
                        lg: "35%", xs: "70%"
                    },
                }} >
                    <Box sx={{ display: "flex" }}>
                        {Object.keys(colorCode).map((ele) => {
                            return (
                                <p style={{ borderLeft: `1rem solid ${colorCode[ele]}`, height: "0.9rem", margin: "0.5rem 1rem 0 1rem", fontSize: "0.8rem", padding: "0.1rem 0 0 0.5rem" }}>{ele}</p>
                            )
                        })}
                        {/* <p style={{ borderLeft: "1rem solid #7CD4DE", height: "0.9rem", margin: "0.5rem 1rem 0 1rem", fontSize: "0.8rem", padding: "0.1rem 0 0 0.5rem" }}>North</p>
                        <p style={{ borderLeft: "1rem solid #BA87ED", height: "0.9rem", margin: "0.5rem 1rem 0 1rem", fontSize: "0.8rem", padding: "0.1rem 0 0 0.5rem" }}>South</p>
                        <p style={{ borderLeft: "1rem solid #4990F0", height: "0.9rem", margin: "0.5rem 1rem 0 1rem", fontSize: "0.8rem", padding: "0.1rem 0 0 0.5rem" }}>West</p>
                        <p style={{ borderLeft: "1rem solid #8ED8B7", height: "0.9rem", margin: "0.5rem 1rem 0 1rem", fontSize: "0.8rem", padding: "0.1rem 0 0 0.5rem" }}>East</p> */}
                    </Box>
                    <RadioGroup
                        sx={{
                            '& .MuiSvgIcon-root': {
                                fontSize: "0.9rem",
                            },
                            '& .MuiTypography-root': {
                                fontSize: ".8rem"
                            },
                            padding: 2

                        }}
                        row
                        aria-labelledby="demo-controlled-radio-buttons-group"
                        name="controlled-radio-buttons-group"
                        value={headerProps.radioValue}
                        onChange={(event) => {
                            headerProps.setRadioValue(event.target.value)
                        }}

                    >
                        <FormControlLabel value="Region" sx={{}} control={<Radio />} label="Region" />
                        <FormControlLabel value="State" sx={{}} control={<Radio />} label="State" />
                        <FormControlLabel value="City" sx={{}} control={<Radio />} label="City" />
                    </RadioGroup>
                    {loading ?

                        <Box sx={{ height: "16rem", borderRadius: ".5rem", boxShadow: 6, display: "flex", justifyContent: "center", alignItems: "center" }}>
                            <CircularProgress color="inherit" />
                        </Box>
                        :
                        <MapTable
                            rows={apiData}
                            columns={tableColumn || ["Region", "AUM", "Pan Count"]}
                        />
                    }
                </Box>
            </Box>

        </Grid >
    );
}


export default MapChart
