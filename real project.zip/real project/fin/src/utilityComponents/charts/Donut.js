
import React, { useEffect, useState } from 'react'
import FusionCharts from "fusioncharts";
import charts from "fusioncharts/fusioncharts.charts";
import ReactFusioncharts from "react-fusioncharts";
import { Box, CircularProgress, Grid } from '@mui/material';
import HeaderParent from '../components/HeaderParent';
import { useDispatch, useSelector } from 'react-redux';
import ChevronLeftRoundedIcon from '@mui/icons-material/ChevronLeftRounded';
import { clearAumFilterData, resetAumFilter, setAumData } from '../../reduxStore/filterReducer';
import { clearFlowFilterData, resetFlowFilter, setFlowData } from '../../reduxStore/flowReducer';
import { useLocation } from 'react-router-dom';
import "./donut.css"

charts(FusionCharts);

const Donut = ({ data, count, listData, cardTitle, cardSelected, fetchAPI, fetchPayload, headerProps, xs, md }) => {
  // console.log(props)
  const page = useLocation().pathname;
  let reducerName = "filterData";
  let setReducerData = setAumData;
  let clearFilterData = clearAumFilterData;
  switch (page) {
    case "/app/aum": {
      reducerName = "filterData"
      setReducerData = setAumData;
      clearFilterData = clearAumFilterData;
      break;
    }
    case "/app/flow": {
      reducerName = "flowFilterData"
      setReducerData = setFlowData;
      clearFilterData = clearFlowFilterData;
      break;
    }
  }
  let texts;
  let pantext = `<b>$label</b> <br/><b>$value </b>`
  let aumtext = `<b>$label</b> <br/><b>₹$value Cr</b>`
  let datas
  if (count == 'AUM') {
    datas = data.map((item) => ({
      label: item.label,
      value: (parseFloat(item.value) / 10000000).toFixed(2)
    }))
    texts = aumtext
  }

  else {
    datas = data;
    texts = pantext
  }

  const [apiData, setApiData] = useState({});
  const [loading, setLoading] = useState(false);

  const [showBackBtn, setShowBackBtn] = useState(false);
  const dispatch = useDispatch();
  // const investorData = useSelector((state) => state.filterData?.investor)
  // const zoneData = useSelector((state) => state.filterData?.zone)
  // const stateData = useSelector((state) => state.filterData?.state)
  // const assetclassData = useSelector((state) => state.filterData?.assetclass)
  // const assetcategoryData = useSelector((state) => state.filterData?.assetcategory)
  // const distributorData = useSelector((state) => state.filterData?.distributor)
  // // const filterSelected = useSelector((state) => state.filterData?.filterSelected)
  // const flowFilterSelected = useSelector((state) => state.flowFilterData?.filterSelected)
  // const flowPageFilters = useSelector((state) => state.flowFilterData?.flowPageFilters)
  // console.log("*******************************************************************************", apiData);
  let pageArr = ["/app/aum", "/app/flow"]
  const reducerState = useSelector((state) => state[reducerName]);
  console.log({ ...reducerState })
  useEffect(() => {
    console.log(pageArr.includes(page), page)
    if (!fetchAPI) { setApiData(data) }
    fetchingAPI();
  },
    [reducerState, headerProps.radioValue, cardSelected])
  //To hide the back btn when we reset filters
  useEffect(() => {
    !reducerState.filterSelected && setShowBackBtn(false);
  }, [reducerState.filterSelected])

  const fetchingAPI = async () => {
    if (fetchAPI) {
      setLoading(true);
      setApiData(await fetchAPI(fetchPayload, { radioValue: headerProps.radioValue, cardSelected }))
      setLoading(false)
    }
  }
  console.log(headerProps.heading, ">>>>", apiData)

  // const fetchInvCatData = async () => {
  //   const payload =
  //   {
  //     "fund": "RMF",
  //     "zone": zoneData,
  //     "investor": investorData,
  //     "query_name": "aum-InvestorCategory",
  //     "state": stateData,
  //     "assetclass": assetclassData,
  //     "assetcategory": assetcategoryData,
  //     "comment": filterSelected ? "" : "-- "
  //   }
  //   const response = await fetchData(payload);
  //   let donutData;
  //   if (headerProps.radioValue == "AUM") {

  //     donutData = response.data.map((ele) => {
  //       return { label: ele.investor_category, value: parseFloat(ele.aggregate_aum).toFixed(2) }
  //     })
  //   }
  //   else if (headerProps.radioValue == "PAN Count") {
  //     donutData = response.data.map((ele) => {
  //       return { label: ele.investor_category, value: ele.aggregate_count }
  //     })
  //   }
  //   setApiData(donutData);
  //   return donutData;

  // }

  // const fetchAssetClassData = async () => {
  //   const payload =
  //   {
  //     "fund": "RMF",
  //     "zone": zoneData,
  //     "investor": investorData,
  //     "query_name": "aum-AssetClass",
  //     "state": stateData,
  //     "assetclass": assetclassData,
  //     "assetcategory": assetcategoryData,
  //     "comment": filterSelected ? "" : "-- "
  //   }
  //   const response = await fetchData(payload);
  //   let donutData;
  //   // console.log(">>>>>>>>>>>>>>>>>>>>>>>", response.data)
  //   donutData = response.data.map((ele) => {
  //     return { label: ele.assetclassnewmcr, value: parseFloat(ele.aggregate_aum).toFixed(2) }
  //   })

  //   setApiData(donutData);
  //   return donutData;

  // }

  // const fetchPlanModeData = async () => {
  //   // console.log("??????????????????????????????????????????????????????")
  //   const payload =
  //   {
  //     "fund": "RMF",
  //     "zone": zoneData,
  //     "investor": investorData,
  //     "query_name": "aum-PlanMode",
  //     "state": stateData,
  //     "assetclass": assetclassData,
  //     "assetcategory": assetcategoryData,
  //     "comment": filterSelected ? "" : "-- "
  //   }
  //   const response = await fetchData(payload);
  //   console.log("plan Mode response Data", response.data);
  //   let donutData;
  //   if (headerProps.radioValue == "AUM") {
  //     donutData = response.data.map((ele) => {
  //       return { label: ele.planmode, value: parseFloat(ele.aggregate_aum).toFixed(2) }
  //     })
  //   }
  //   else if (headerProps.radioValue == "PAN Count") {
  //     donutData = response.data.map((ele) => {
  //       return { label: ele.planmode, value: ele.aggregate_count }
  //     })
  //   }
  //   setApiData(donutData);
  //   return donutData;


  // }

  // const fetchTB30Data = async () => {
  //   // console.log("??????????????????????????????????????????????????????")
  //   const payload =
  //   {
  //     "fund": "RMF",
  //     "zone": zoneData,
  //     "investor": investorData,
  //     "query_name": "aum-TerFlag",
  //     "state": stateData,
  //     "assetclass": assetclassData,
  //     "assetcategory": assetcategoryData,
  //     "comment": filterSelected ? "" : "-- "
  //   }
  //   const response = await fetchData(payload);
  //   console.log("plan Mode response Data", response.data);
  //   let donutData;
  //   if (headerProps.radioValue == "AUM") {
  //     donutData = response.data.map((ele) => {
  //       return { label: ele.terflagfolio, value: parseFloat(ele.aggregate_aum).toFixed(2) }
  //     })
  //   }
  //   else if (headerProps.radioValue == "PAN Count") {
  //     donutData = response.data.map((ele) => {
  //       return { label: ele.terflagfolio, value: ele.aggregate_count }
  //     })
  //   }
  //   setApiData(donutData);
  //   return donutData;


  // }



  // if(count=='AUM'){
  //   texts=aumtext
  // }
  // else{
  //   texts=pantext
  // }
  const dataSource = {
    chart: {
      theme: "candy",
      chartTopMargin: 80,
      chartLeftMargin: -70,
      chartBottomMargin: 10,
      plottooltext: texts,
      // chartRightMargin: 0,
      use3DLighting: false,
      showShadow: false,
      doughnutRadius: 70,
      pieRadius: 90,
      showToolTip: "1",
      interactiveLegend: "1",
      legendBorderColor: "#ffffff",
      xAxisNameFontColor: "#909090",
      yAxisNameFontColor: "#909090",
      "legendItemFont": "Roboto",
      drawCustomLegendIcon: "1",
      legendIconSides: "4",
      legendPosition: window.innerWidth <= 640 ? "bottom" : "right-bottom",
      legendIconStartAngle: "45",
      bgcolor: "#ffffff",
      showLegend: "1",
      showborder: "0",
      palettecolors: "#2057A6,#69B8F4,#8ED8B7,#82C7ED,#8FABD3,#BA87ED",
      legendPosition: "bottom-right",
      "legendBgColor": "#fff",
      "legendBorderAlpha": "0",
      legendWidth: "200",
      // legendShadow: 0,
      showValues: 0,
      legendNumRows: 6,
      valuePosition: "inside",
      minAngleForValue: "20",
      labelDisplay: "wrap",

    },
    data: apiData,

  };
  return (

    <Grid item xs={xs || 12} md={md || 12} sx={{
      bgcolor: "#fff",
      marginTop: "20px",
      borderRadius: '8px',
      alignItems: "center",
      borderRadius: "8px",
      paddingTop: ".1rem",
      boxShadow: 6
    }}>
      <HeaderParent
        headerProps={headerProps}
      />
      <Grid container sx={{ bgcolor: "white", height: "auto", borderRadius: "8px" }} >
        <Grid item xs={12} md={listData ? 6 : 12} sx={{ position: "relative", padding: ".5rem", margin: ".5rem", marginRight: 0, paddingRight: 0, height: "16rem" }}>
          <button

            onClick={() => {
              // dispatch(setAssetClassData({assetclass:[]}))
              // dispatch(setAssetCategoryData({assetcategory:[]}))
              // if (page == "/app/flow") {

              //   switch (headerProps.heading) {
              //     case 'Transaction Type': {
              //       dispatch(clearFlowFilterData("transactionType"))
              //       // dispatch(setFlowPageFilters({ ...flowPageFilters, transactionType: false }))
              //       break
              //     }
              //     case "Asset Class": {
              //       dispatch(clearFlowFilterData("assetClass"))
              //       // dispatch(setFlowPageFilters({ ...flowPageFilters, assetClass: false }))
              //       break
              //     }
              //   }
              // }
              // else {
              //   dispatch(clearFilterData())
              //   dispatch(setFilterSelected({ filterSelected: false }))
              // }
              dispatch(clearFilterData(cardTitle))
              setShowBackBtn(false);
            }}
            style={{ position: "absolute", zIndex: 5, left: 2, height: "fit-content", borderRadius: "0.5rem", display: showBackBtn ? "block" : "none", cursor: "pointer", borderColor: "#fff", background: "#2057A6", color: "#fff", paddingInline: ".3rem", }}><ChevronLeftRoundedIcon fontSize='medium' /></button>
          <ReactFusioncharts
            sx={{ position: "absolute", top: "50%", left: "50%" }}
            type="doughnut2d"
            width="98%"
            height="90%"
            dataFormat="JSON"
            dataSource={dataSource}
            events={{

              'slicingStart': function (eventObj, args) {
                // if (page == "/app/flow") {
                //   if (localStorage.getItem("Finstax:FlowDefaultFilter")) {
                // console.log(page);
                // const localData = JSON.parse(localStorage.getItem("Finstax:FlowDefaultFilter"));
                // console.log(localData)
                // dispatch(setFlowAssetClassData({ assetClass: localData["assetClass"] }))
                // dispatch(setFlowAssetCategoryData({ assetCategory: localData["assetCategory"] }))
                // dispatch(setFlowSchemeNameData({ schemeName: localData["schemeName"] }))
                // dispatch(setFlowTransactionSourceData({ transactionSource: localData["transactionSource"] }))
                // dispatch(setFlowTransactionTypeData({ transactionType: localData["transactionType"] }))
                // }

                {
                  loading ?

                    <Box sx={{ height: "100%", display: "flex", justifyContent: "center", alignItems: "center" }}>
                      <CircularProgress />
                    </Box>
                    :
                    <ReactFusioncharts
                      style={{ position: "absolute", top: "50%", left: "50%", cursor: "pointer" }}
                      type="doughnut2d"
                      width="98%"
                      height="90%"
                      dataFormat="JSON"
                      dataSource={dataSource}
                      events={{
                        'slicingStart': function (eventObj, args) {
                          // if (page == "/app/flow") {
                          //   if (localStorage.getItem("Finstax:FlowDefaultFilter")) {
                          // console.log(page);
                          // const localData = JSON.parse(localStorage.getItem("Finstax:FlowDefaultFilter"));
                          // console.log(localData)
                          // dispatch(setFlowAssetClassData({ assetClass: localData["assetClass"] }))
                          // dispatch(setFlowAssetCategoryData({ assetCategory: localData["assetCategory"] }))
                          // dispatch(setFlowSchemeNameData({ schemeName: localData["schemeName"] }))
                          // dispatch(setFlowTransactionSourceData({ transactionSource: localData["transactionSource"] }))
                          // dispatch(setFlowTransactionTypeData({ transactionType: localData["transactionType"] }))
                          // }

                          // switch (headerProps.heading) {
                          //   case 'Transaction Type': {
                          // dispatch(setFlowTransactionTypeData({ transactionType: [args.data.id] }))
                          // dispatch(setFlowPageFilters({ ...flowPageFilters, transactionType: true }))
                          //   break
                          // }
                          // case "Asset Class": {
                          // dispatch(setFlowAssetClassData({ assetClass: [args.data.id] }))
                          // dispatch(setFlowPageFilters({ ...flowPageFilters, assetClass: true }))
                          //       break
                          //     }
                          //   }
                          // }
                          // else {
                          //   if (localStorage.getItem("Finstax:AssetClassCategoryData")) {
                          //     const localData = JSON.parse(localStorage.getItem("Finstax:AssetClassCategoryData"));
                          //     dispatch(setAssetClassData({ assetclass: localData["AssetClass"] }))
                          //     dispatch(setAssetCategoryData({ assetcategory: localData["AssetCategory"] }))
                          //   }
                          //   dispatch(setFilterSelected({ filterSelected: true }))

                          //   switch (headerProps.heading) {
                          //     case 'Investor Category': {
                          //       dispatch(setInvestorData({ investor: [args.data.id] }))
                          //       break
                          //     }
                          //     case "Asset Class": {
                          //       dispatch(setAssetClassData({ assetclass: [args.data.id] }))
                          //       break
                          //     }
                          //   }

                          // }
                          console.log(eventObj)
                          // alert(args.data.categoryLabel)
                          if (cardTitle) {
                            dispatch(setReducerData({ title: cardTitle, value: [args.data.id] }))
                            dispatch(setReducerData({ title: "filterSelected", value: true }))
                            setShowBackBtn(true);
                          }
                        },
                      }}
                    />
                    }
                  }}}/>
        </Grid>

        {listData &&
          <Grid item md={5.6} xs={12} sx={{ margin: ".5rem auto", height: "16rem" }}>
            <Box sx={{ height: "70%", width: "90%", padding: "1rem", margin: "1rem auto", display: "flex", alignItems: "center", justifyContent: "center", borderLeft: { xs: "0px", md: "2px solid #b9b9b9" } }}>
              <Box sx={{
                height: 'auto',
                borderRadius: '8px',
                display: 'flex',
                width: '85%',
                background: "linear-gradient(170.95deg, rgba(105, 184, 244, 0.1) 1.31%, rgba(255, 255, 255, 0.1) 67.68%)",
                padding: '2rem 1.2rem 2rem 1.2rem',
                // marginLeft: "1rem",
                boxShadow: 4,
              }}>
                <ul>
                  {
                    listData.map((listEle, key) => (

                      <li key={key} style={{
                        fontFamily: 'Roboto',
                        fontSize: "0.85rem",
                        fontWeight: '400',
                        lineHeight: '28px',
                        letterSpacing: '0em',
                        textAlign: 'left',
                        color: '#333333CC',
                      }}>{listEle}</li>
                    ))
                  }
                </ul>
              </Box>
            </Box>

          </Grid>}
      </Grid>
    </Grid>
  )
}

export default Donut;