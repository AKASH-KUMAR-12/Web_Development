import ReactFC from "react-fusioncharts";
import Column2D from "fusioncharts/fusioncharts.charts";
import FusionTheme from "fusioncharts/themes/fusioncharts.theme.fusion";
import FusionCharts from "fusioncharts";
import { Box, CircularProgress, Grid } from "@mui/material";
import HeaderParent from "../components/HeaderParent";
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import ChevronLeftRoundedIcon from '@mui/icons-material/ChevronLeftRounded';

import axios from "axios";
import { clearAumFilterData, clearFilterData, setAssetCategoryData, setAssetClassData, setAumData, setFilterSelected } from "../../reduxStore/filterReducer";
import { ArrowBack } from "@mui/icons-material";
import { useLocation } from "react-router-dom";
import { clearFlowFilterData, setFlowData } from "../../reduxStore/flowReducer";
import "./barchart.css"
// import "../../services/Flow/Flow.css"

ReactFC.fcRoot(FusionCharts, Column2D, FusionTheme);

const VerticalBarChart = ({ data, xAxisName, yAxisName, cardTitle, cardSelected, fetchAPI, fetchPayload, headerProps, xs, md, hoverText }) => {
  // console.log("The requires data >>", data);


  const page = useLocation().pathname;
  let reducerName = "filterData";
  let setReducerData = setAumData;
  let clearFilterData = clearAumFilterData;
  switch (page) {
    case "/app/aum": {
      reducerName = "filterData"
      setReducerData = setAumData;
      clearFilterData = clearAumFilterData;
      break;
    }
    case "/app/flow": {
      reducerName = "flowFilterData"
      setReducerData = setFlowData;
      clearFilterData = clearFlowFilterData;
      break;
    }
  }

  const [apiData, setApiData] = useState([]);
  const [loading, setLoading] = useState(false);

  const [showBackBtn, setShowBackBtn] = useState(false);
  const reducerState = useSelector((state) => state[reducerName]);
  const dispatch = useDispatch();

  // console.log("*******************************************************************************", apiData);
  let pageArr = ["/app/aum", "/app/flow"]
  useEffect(() => {
    if (!fetchAPI) { setApiData(data) }

    fetchingAPI();
  }, [reducerState, headerProps.radioValue, headerProps.capsuleBtnValue, cardSelected])

  //To hide the back btn when we reset filters
  useEffect(() => {
    !reducerState.filterSelected && setShowBackBtn(false);
  }, [reducerState.filterSelected])

  const fetchingAPI = async () => {
    if (fetchAPI) {
      setLoading(true);
      setApiData(await fetchAPI(fetchPayload, { radioValue: headerProps.radioValue, capsuleBtnValue: headerProps.capsuleBtnValue, cardSelected }));
      setLoading(false)
    }
  }

  // console.log(`Investor-Base-${headerProps.capsuleBtnValue?.substring(0, 3)}`)

  const chartConfigs = {
    type: "column2d",
    width: "99%",
    height: "95%",
    dataFormat: "json",
    dataSource: {
      chart: {
        xAxisName: xAxisName,
        yAxisName: yAxisName,
        xAxisNameFont: "Roboto",
        yAxisNameFont: "Roboto",
        xAxisNameFontSize: "12",
        yAxisNameFontSize: "12",
        // "applyCssTransform": "1",
        yAxisNameFontBold: 0,
        xAxisNameFontBold: 0,
        labelFontSize: "9",
        yAxisValueFontSize: "10",
        showXAxisLine: "1",
        xAxisNameFontColor: "#909090",
        yAxisNameFontColor: "#909090",
        palettecolors: "#2057A6,#69B8F4,#8ED8B7,#82C7ED,#8FABD3,#BA87ED",
        showYAxisLine: "1",
        theme: "fusion",
        showValues: "0",
        bgColor: "#FFFFFF",
        showBorder: "0",
        chartBottomMargin: "20",
        showCanvasBorder: "0",
        showPlotBorder: "0",
        plotFillRatio: "100",
        showAlternateHGridColor: "0",
        divLineColor: "#cdd4cf",
        plottooltext: hoverText,
        chartLeftMargin: 10,
        chartBottomMargin: 10,
        // "showValues": "1",
        labelDisplay: 'AUTO',

      },
      data: apiData,
    },
    "events": {

      "dataplotClick": function (eventObj, dataObj) {
        // console.log(dataObj.id);
        // if (localStorage.getItem("Finstax:AssetClassCategoryData")) {
        //   const localData = JSON.parse(localStorage.getItem("Finstax:AssetClassCategoryData"));
        //   dispatch(setAssetClassData({ assetclass: localData["AssetClass"] }))
        //   dispatch(setAssetCategoryData({ assetcategory: localData["AssetCategory"] }))
        // }
        // dispatch(setFilterSelected({ filterSelected: true }))
        // setShowBackBtn(true);

        // switch (headerProps.heading) {
        //   case 'Investor Demography': {
        //     // dispatch(setInvestorData({ investor: [args.data.id] }))
        //     break
        //   }
        //   case "Asset Category": {
        //     dispatch(setAssetCategoryData({ assetcategory: [dataObj.id] }))
        //     break
        //   }
        // }
        if (cardTitle) {
          dispatch(setReducerData({ title: cardTitle, value: [dataObj.id] }))
          dispatch(setReducerData({ title: "filterSelected", value: true }))
          setShowBackBtn(true);
        }
      }
    }

  };


  return (
    <>
      <Grid item xs={xs || 12} md={md || 12} sx={{
        bgcolor: "#fff",
        marginTop: "20px",
        borderRadius: '8px',
        alignItems: "center",
        borderRadius: "8px",
        paddingTop: ".1rem",
        boxShadow: 6
      }}>
        <HeaderParent
          headerProps={headerProps}
        />

        <Box sx={{ position: "relative", padding: ".5rem", bgcolor: "white", height: "16rem", borderRadius: "8px" }} >
          <button onClick={() => {
            dispatch(clearFilterData(cardTitle))
            setShowBackBtn(false);
          }}
            style={{ height: "fit-content", display: showBackBtn ? "block" : "none", cursor: "pointer", borderColor: "#fff", paddingInline: ".4rem", marginLeft: ".5rem", borderRadius: "0.5rem", background: "#2057A6", color: "#fff", paddingInline: ".3rem", position: "absolute", left: "-5px", top: "10px", zIndex: "2" }}>
            <ChevronLeftRoundedIcon fontSize='medium' />

          </button>
          {loading ?

            <Box sx={{ height: "100%", display: "flex", justifyContent: "center", alignItems: "center" }}>
              <CircularProgress />
            </Box>
            :
            <ReactFC style={{ position: "absolute", top: "50%", left: "50%" }} {...chartConfigs} />}
        </Box>
      </Grid>


    </>
  );
};

export default VerticalBarChart;
