import FusionCharts from "fusioncharts";
import charts from "fusioncharts/fusioncharts.charts";
import ReactFusioncharts from "react-fusioncharts";
import React, { useState } from "react";
import { Box, CircularProgress, Grid } from "@mui/material";
import HeaderParent from "../components/HeaderParent";
import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { clearAumFilterData, setAumData } from "../../reduxStore/filterReducer";
import { clearFlowFilterData, setFlowData } from "../../reduxStore/flowReducer";
import { useLocation } from "react-router-dom";
import "./barchart.css"

// Resolves charts dependancy


const BarChart = ({ data, xAxisName, yAxisName, cardSelected, cardTitle, count, fetchAPI, fetchPayload, height, md, xs, headerProps, sx }) => {
  const page = useLocation().pathname;
  let reducerName = "filterData";
  let setReducerData = setAumData;
  let clearFilterData = clearAumFilterData;
  switch (page) {
    case "/app/aum": {
      reducerName = "filterData"
      setReducerData = setAumData;
      clearFilterData = clearAumFilterData;
      break;
    }
    case "/app/flow": {
      reducerName = "flowFilterData"
      setReducerData = setFlowData;
      clearFilterData = clearFlowFilterData;
      break;
    }
  }
  const dispatch = useDispatch();
  const [apiData, setApiData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [showBackBtn, setShowBackBtn] = useState(false);
  const reducerState = useSelector((state) => state[reducerName]);
  let pageArr = ["/app/aum", "/app/flow"]
  useEffect(() => {
    if (!fetchAPI) { setApiData(data) }
    fetchingAPI();
    console.log("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<first>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>", cardTitle)
  }, [reducerState, headerProps.radioValue, cardSelected])

  //To hide the back btn when we reset filters
  useEffect(() => {
    !reducerState.filterSelected && setShowBackBtn(false);
  }, [reducerState.filterSelected])

  const fetchingAPI = async () => {
    if (fetchAPI) {
      setLoading(true);
      setApiData(await fetchAPI(fetchPayload, { radioValue: headerProps.radioValue, cardSelected }));
      setLoading(false)
    }
  }
  console.log(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>", apiData)
  let texts;
  let pantext = `$label: $value`
  let aumtext = `$label: ₹$value Cr`
  let datas
  // if (count == 'AUM') {
  datas = apiData.map((item) => {
    if (item.value < 0) {
      return ({
        color: "#F88787",
        label: item.label,
        value: (parseFloat(item.value)).toFixed(2)

      })
    }
    else {
      return ({
        label: item.label,
        value: (parseFloat(item.value)).toFixed(2)

      })
    }
  })
  //   texts = aumtext
  // }

  // else {
  //   datas = data;
  //   texts = pantext
  // }

  console.log(datas)
  charts(FusionCharts);
  const dataSource = {

    chart: {
      "theme": "fusion",
      xAxisName: xAxisName,
      yAxisName: yAxisName,
      xAxisNameFont: "Roboto",
      yAxisNameFont: "Roboto",
      xAxisNameFontSize: "12",
      yAxisNameFontSize: "12",
      xAxisLineColor: "#969696",
      yAxisLineColor: "#969696",
      labelFontSize: "10",
      "showZeroPlane": "0",
      yAxisValueFontSize: "10",
      plotSpacePercent: 50,
      plottooltext: texts,
      bgcolor: "#FFFFFF",
      "showxaxisline": "0",
      "showyaxisline": "1",
      color: "#FFFFFF",
      patterBgColor: "#FFFFFF",
      theme: 'fusion',
      barCategoryGap: 1,
      "chartBottomMargin": "10",
      pallete: 5,
      divLineColor: "#00080a",
      animation: 0,
      drawCrossLine: 1,
      crossLineAnimation: 0,
      // plottooltext: "$label: $value Cr",
      divLineColor: "#00080a",
      showBorder: false,
      palettecolors: "#2057A6,#69B8F4,#8ED8B7,#82C7ED,#8FABD3,#BA87ED",
      toolTipFontSize: 6,
      labelDisplay: "wrap",

      // ||"stagger"||"rotate",

    },
    "data": apiData,
    "events": {

      "dataplotClick": function (eventObj, dataObj) {
        console.log("clicked")
        if (cardTitle) {
          dispatch(setReducerData({ title: cardTitle, value: [dataObj.id] }))
          dispatch(setReducerData({ title: "filterSelected", value: true }))
          setShowBackBtn(true);
        }
      }
    }
  }

  return (
    <Grid item xs={xs || 12} md={md || 12} sx={{
      bgcolor: "#fff",
      marginTop: "20px",
      borderRadius: '8px',
      alignItems: "center",
      borderRadius: "8px",
      paddingTop: ".1rem",
      boxShadow: 6,
      ...sx
    }}>
      <HeaderParent
        headerProps={headerProps}
      />
      <button onClick={() => {
        dispatch(clearFilterData(cardTitle))
        setShowBackBtn(false);
      }}
        style={{ height: "fit-content", display: showBackBtn ? "block" : "none", cursor: "pointer", borderColor: "#fff", paddingInline: ".4rem", marginLeft: ".5rem" }}>

      </button>
      <Box sx={{ position: "relative", padding: ".5rem", bgcolor: "white", height: height || "16rem", borderRadius: "8px" }} >
        {loading ?

          <Box sx={{ height: "100%", display: "flex", justifyContent: "center", alignItems: "center" }}>
            <CircularProgress />
          </Box>
          :
          <ReactFusioncharts style={{ position: "absolute", top: "50%", left: "50%" }}
            type="bar2d"
            width="98%"
            height="95%"
            dataFormat="JSON"
            dataSource={dataSource}
          />}
      </Box>
    </Grid>

  );
}

export default BarChart