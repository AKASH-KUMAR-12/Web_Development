import { Grid } from '@mui/material'
import React, { useEffect, useState } from 'react'
import InfoCard from './InfoCard'
import { useSelector, useDispatch } from 'react-redux';
import axios from 'axios';

const Card = () => {
  let response;
  const [cardData, setCardData] = useState({});
  const [loading, setLoading] = useState(true);
  const investorData = useSelector((state) => state.filterData?.investor)
  const zoneData = useSelector((state) => state.filterData?.zone)
  const stateData = useSelector((state) => state.filterData?.state)
  const assetclassData = useSelector((state) => state.filterData?.assetClass)
  const assetcategoryData = useSelector((state) => state.filterData?.assetCategory)
  const filterSelected = useSelector((state) => state.filterData?.filterSelected)


  useEffect(() => {

    fetchData();

  },
    [investorData, zoneData, stateData, assetclassData, assetcategoryData])
  // [])

  const fetchData = async () => {
    setLoading(true);
    const payload =
    {
      "fund": "RMF",
      "zone": zoneData,
      "investor": investorData,
      "query_name": filterSelected ? "aum-Top-4-Cards" : "Top-4-Cards-First",
      "state": stateData,
      "assetclass": assetclassData,
      "assetcategory": assetcategoryData,
      "comment": filterSelected ? "" : "-- "
    }
    // const payload = {
    //   fund: "RMF",
    //   query_name: "Top-4-Cards-First"
    // }
    response = await axios.post("/api/getaumData", payload)
    // console.log("card response Data", response.data);
    if (!filterSelected) {
      setCardData(
        {
          "aggregate_aum": response.data[2].value,
          "aggregate_folios": response.data[0].value,
          "aggregate_investor": response.data[1].value
        }
      )
    }
    else {
      setCardData(response.data[0])
    }
    setLoading(false);
    return response;

  }
  console.log(cardData);
  const data = [
    {
      heading: "Total AUM",
      value: filterSelected ?
        `${parseFloat(cardData.aggregate_aum / 10000000).toFixed(2)} Cr` : `${parseFloat(cardData.aggregate_aum)} Cr`,
      description: "Total AUM month Sept.....",
      desc1: "Total AUM month Sept 23 is ₹287 Cr.",
      desc2: "SIP Book has Increased by ₹14 Cr (2.71%) from last month.",
      desc3: "Total AUM month Sept Decreased by ₹39 Cr(10.53%) in current Financial year.",
    },
    {
      heading: "Total Investor Count",
      value: `${parseFloat(cardData.aggregate_investor)}`,
      description: "Investor Insights for Sep-23",
      desc1: "23124 new investors added in Sep 23",
      desc2: "18.56L investors have invested in more than 2 schemes",
      desc3: "Flexi Cap fund had biggest gainer in Sep 23",
    },
    {
      heading: "Total Folio Count",
      value: `${parseFloat(cardData.aggregate_folios)}`,
      description: "Folio Insights for Sep-23",
      desc1: "27235 new Folios added in Sep 23",
      desc2: "Gen Z(age 18-26) has a Folio count contribution of 15% in Sep 23 which is highest in FY 23-24 so far",
      desc3: "Bhilai city has highest no. of folios created from B30 city category in Sep 23",
    },
    // {
    //   heading: "Total Distributor Count",
    //   value: "32,989",
    //   description: "Distributor insights for Sep-23",
    //   desc1: "2451 new distributors got added in Sep 23",
    //   desc2: "Flexi cap has highest inflow from distributors across all schemes in Sep 23",
    //   desc3: "SS Wealth has highest netflow among all distributers (₹2.8 Cr) in Sep 23",
    // },
  ];
  return (
    <div className='main_container'>
      <Grid container spacing={0} sx={{
        // borderTop: "3px solid #010C43",
        backgroundColor: "white", margin: { sm: "0 0rem", xs: "0 0.5rem" },
        padding: "0.5rem", fontFamily: "Roboto, sans-serif", borderRadius: "0.5rem", boxShadow: 6
      }} >
        {data.map((data) => (
          <Grid item xs={12} lg={4} md={4} >
            <InfoCard data={data} loading={loading} />
          </Grid>
        ))}
      </Grid></div>
  )
}

export default Card