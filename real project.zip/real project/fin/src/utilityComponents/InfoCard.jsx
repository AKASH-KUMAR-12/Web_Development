import { Box, CircularProgress } from '@mui/material';
import React, { useState } from 'react'

const InfoCard = ({ data, loading }) => {
    const [changeValue, setValue] = useState('View more');

    const font_size = window.innerWidth <= 1200 ? "1rem" : "0.8rem";
    const change = () => {
        if (changeValue == 'View more') {
            setValue('View less');
        }
        else {
            setValue('View more');
        }
    }
    return (
        <div className='card'>
            {changeValue == 'View more' ?
                (
                    <>
                        <div className='display' >
                            {loading ?

                                <Box sx={{ display: "flex", justifyContent: "center", alignItems: "center" }}>
                                    <CircularProgress color="inherit" />
                                </Box>
                                : <>
                                    <p>{data.heading}</p>
                                    <h2 style={{ wordBreak: "break-all" }}>{data.value}</h2>
                                </>
                            }
                        </div>
                        <div className='content'>
                            <ul className='before'>
                                <li style={{
                                    width: "100%",
                                    whiteSpace: 'nowrap',
                                    overflow: 'hidden',
                                    textOverflow: 'ellipsis'
                                }}>{data.desc1}</li>
                            </ul>
                            <a className='click' onClick={change}><u>{changeValue}</u></a>
                        </div>
                    </>
                ) : (
                    <>
                        <div className='content_after'>
                            <hr width="100%" size="10" color="#3bb4e9" noshade style={{ borderRadius: "1rem", marginTop: "0.2rem" }} />
                            <div style={{ height: "70%", }}>
                                <ul>
                                    <li style={{ fontSize: font_size }}>{data.desc1}</li>
                                    <li style={{ fontSize: font_size }}>{data.desc2}</li>
                                    <li style={{ fontSize: font_size }}>{data.desc3}</li>
                                </ul>
                            </div>
                        </div>
                        <div style={{ display: "flex", justifyContent: "flex-end" }}>
                            <a onClick={change} style={{ fontSize: "0.7rem", cursor: "pointer", color: "#527cba", padding: "0 1rem 0rem 0", marginBottom: "0.3rem" }}><u>{changeValue}</u></a>
                        </div>
                    </>
                )
            }
        </div>
    )
}

export default InfoCard