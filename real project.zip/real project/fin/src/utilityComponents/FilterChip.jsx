import React, { useEffect, useState } from 'react';
import Chip from '@mui/material/Chip';
import Stack from '@mui/material/Stack';
import { Box, Button, Collapse, Grid, Typography } from '@mui/material';
import { useDispatch, useSelector } from 'react-redux';
import { clearFilterData, resetAumFilter, setAumData, setAumLocalData, setInvestorData, setZoneData } from '../reduxStore/filterReducer';
import { useLocation } from 'react-router-dom';
import { resetFlowFilter, setFlowData, setFlowLocalData } from '../reduxStore/flowReducer';



export default function FilterChip() {
    const page = useLocation().pathname;
    let reducerName = "filterData";
    let setReducerData = setAumData;
    let resetFilter = resetAumFilter;
    let setLocalFilter = setAumLocalData;
    switch (page) {
        case "/app/aum": {
            reducerName = "filterData"
            setReducerData = setAumData;
            resetFilter = resetAumFilter;
            setLocalFilter = setAumLocalData;
            break;
        }
        case "/app/flow": {
            reducerName = "flowFilterData"
            setReducerData = setFlowData;
            resetFilter = resetFlowFilter;
            setLocalFilter = setFlowLocalData;
            break;
        }
    }
    const [newFilterData, setNewFilterData] = useState({ investor: [], zone: [] });
    // const [newZoneData, setNewZoneData] = useState([]);
    const [chipEdited, setChipEdited] = useState(false);

    const investorData = useSelector((state) => state[reducerName]?.investor)
    const zoneData = useSelector((state) => state[reducerName]?.zone)
    // const filterSelected = useSelector((state) => state[reducerName]?.filterSelected)


    const dispatch = useDispatch();
    console.log("Investor Data>>>", investorData);
    console.log("Zone Data>>>", zoneData);
    console.log("New Filter>>>", newFilterData);
    useEffect(() => {
        setNewFilterData({ "investor": investorData, "zone": zoneData })
    }, [investorData, zoneData])

    const handleDelete = (title, key) => {
        setChipEdited(true);
        console.log(key)
        let tempArr = newFilterData[title]
        console.log(tempArr)
        setNewFilterData({ ...newFilterData, [title]: tempArr.filter((ele) => ele != tempArr[key]) });
    };
    console.log(newFilterData)
    const handleApply = () => {
        setChipEdited(false);

        if (newFilterData["investor"] == 0 || newFilterData["zone"] == 0) {
            alert("Please select one filter atleast")
        }
        else {
            dispatch(setReducerData({ title: "investor", value: newFilterData["investor"] }));
            dispatch(setReducerData({ title: "zone", value: newFilterData["zone"] }));
        }
    };

    return (<>
        <Grid item xs={12}>
            <Collapse in={investorData.length > 0 || zoneData.length > 0}>
                <Box
                    sx={{
                        boxShadow: 6,
                        background: "#fff",
                        padding: "0.4rem",
                        borderRadius: "9px",
                        margin: ".5rem 0 1rem 0",
                        paddingLeft: "1rem",
                        display: "flex",
                        flexWrap: 'wrap',
                        justifyContent: "space-between",
                        alignItems: "center",
                        // bgcolor: "blue",
                        position:"relative",
                        paddingRight:"1rem"
                    

                    }}
                >

                    <Box sx={{ display: "flex", alignItems: "center", flexWrap: 'wrap',width:"85%" }}>
                        <Typography variant="overline" display="block" sx={{ fontSize: { md: '.8rem', xs: '.6rem' }, fontWeight: 600 }} >
                            {investorData.length > 0 && "Investor:"}
                        </Typography>
                        {newFilterData["investor"].map((ele, key) => (
                            <Chip size='small' sx={{ fontSize: { md: '.8rem', xs: '.6rem' } }} key={key} label={ele} onDelete={() => handleDelete("investor", key)} variant="outlined"
                            />
                        ))}

                        <Typography variant="overline" display="block" sx={{ fontSize: { md: '.8rem', xs: '.6rem' }, fontWeight: 600, borderLeft: "0px solid grey", paddingLeft: "0.5rem" }} >
                            {zoneData.length > 0 && "Zone:"}
                        </Typography>
                        {newFilterData["zone"].map((ele, key) => (
                            <Chip size='small' sx={{ fontSize: { md: '.8rem', xs: '.6rem' } }} key={key} label={ele} onDelete={() => handleDelete("zone", key)} variant="outlined"
                            />
                        ))}
                    </Box>
                    <Box sx={{position:"absolute",right:"0",width:"13%"}}>
                    {chipEdited ?
                        <Button variant="contained" size="small" sx={{ justifySelf: "center", fontSize: { md: '.8rem', xs: '.6rem' } }} onClick={handleApply} >Apply Filter</Button>
                        : <Button variant="contained" size="small" sx={{ bgcolor: "#16a2ba", justifySelf: "center", fontSize: { md: '.8rem', xs: '.5rem' } }} onClick={() => {
                            dispatch(resetFilter());
                            // dispatch(setReducerData({ title: "filterSelected", "value": false }))
                            dispatch(setLocalFilter())
                            setNewFilterData({ "investor": investorData, "zone": zoneData })
                        }} >Reset Filter</Button>
                    }
                    </Box>
                </Box>

            </Collapse></Grid>
    </>
    );

}