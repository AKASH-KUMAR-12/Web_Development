import { FormControl, FormControlLabel, Radio, RadioGroup } from '@mui/material'
import React from 'react'
const CardRadioHeader = ({ heading, radioList, handleChange, value }) => {
    return (
        <>
            <div style={{
                display: "flex",
                justifyContent: "space-between",
                marginBottom: "1px",
                alignItems: "center"
            }}>
                <div style={{
                    padding: '10px 12px 9px 22px',
                    fontSize: '16px',
                    fontWeight: 'bold',
                    textAlign: 'left',
                }}>{heading}</div>
                {radioList &&
                    <div style={{ justifySelf: "end" }}>
                        <FormControl>
                            <RadioGroup
                                sx={{
                                    '& .MuiTypography-root': {
                                        fontSize: '.8rem',
                                    }
                                }}
                                row
                                aria-labelledby="demo-controlled-radio-buttons-group"
                                name="controlled-radio-buttons-group"
                                value={value}
                                defaultValue={radioList[0]}
                                onChange={(event) => handleChange(event.target.value)}
                            >
                                {radioList.map((value, key) => (
                                    <FormControlLabel key={key}
                                        value={value}
                                        control={<Radio size='small' />}
                                        label={value}
                                    />
                                ))}
                            </RadioGroup>
                        </FormControl>
                    </div>}
            </div>
            <hr />
        </>
    )
}

export default CardRadioHeader