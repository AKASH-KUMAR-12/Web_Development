import React from 'react'
const CardHeader = ({ heading }) => {
  return (
    <div>
      <div style={{
        padding: '9px 12px 9px 22px',
        fontSize: '16px',
        fontWeight: 'bold', textAlign: 'left'
      }}>{heading}</div>
      <hr />
    </div>
  )
}

export default CardHeader