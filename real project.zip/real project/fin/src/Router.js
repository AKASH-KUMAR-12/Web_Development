import React, { useEffect } from 'react'
import { Route, Routes } from 'react-router-dom'
import SecureLS from "secure-ls";
import { useNavigate } from "react-router-dom";

import SIPBookDashBoard from './services/SIP/index'
import AmcAtGlanceDashBoard from './services/AMCAtGlanceComp/AmcAtGlanceDashBoard'
import DashBoardLayout from './layout/DashBoardLayout'
import HomePage from './auth';
import FlowDashboard from './services/Flow/index';
import AUMDashboard from './services/AUM/index';
import NFODashboard from './services/NFO/Index';
import DistributorDashboard from './services/Distributors/index';
import AMCAnalytics from './services/AMCAnalytics';
import Sales from './services/SalesReportComp/Sales';
import Operations from './services/OperationsComp/Operations';
import AMCvsKfinDashboard from './services/AMCvsKfin';
import axios from 'axios';

axios.defaults.baseURL = "http://localhost:59100"
const Router = () => {

  let ls = new SecureLS();
  let navigate = useNavigate();
  let usertoken = ls.get('user-token')
  console.log("user Token", usertoken)
  useEffect(() => {
  }, [usertoken]);



  return (
    <Routes>
      <Route path='/app' element={<DashBoardLayout />} >
        <Route path='AMCAtGlance' element={<AmcAtGlanceDashBoard />} />
        <Route path='sip' element={<SIPBookDashBoard />} />
        <Route path='flow' element={<FlowDashboard />} />
        <Route path='AUM' element={<AUMDashboard />} />
        <Route path='NFO' element={<NFODashboard />} />
        <Route path='Distributor' element={<DistributorDashboard />} />
        <Route path='Report' element={<AMCAnalytics />} />
        <Route path='sales' element={<Sales />} />
        <Route path='operations' element={<Operations />} />
        <Route path='amcvskfin' element={<AMCvsKfinDashboard />} />
        <Route path='*' element={<h1>Page not found</h1>} />
      </Route>
      ( <Route path='/' element={<HomePage />} />)
    </Routes>
  )
}

export default Router