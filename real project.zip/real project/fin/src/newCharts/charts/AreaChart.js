import React from "react";
import FusionCharts from "fusioncharts";
import charts from "fusioncharts/fusioncharts.charts";
import ReactFusioncharts from "react-fusioncharts";


charts(FusionCharts);

const dataSource = {
  chart: {
    xaxisname: "Month",
    yaxisname: "AUM(in Crores)",
    drawcrossline: "1",
    "showxaxisline": "1",
    "showyaxisline": "1",
    numbersuffix: "%",
    theme: "fusion",
    "chartBottomMargin": "10",
  },
  categories: [
    {
      category: [
        {
          label: "JAN"
        },
        {
          label: "FEB"
        },
        {
          label: "MAR"
        },
        {
          label: "APR"
        },
        {
          label: "MAY"
        },
        {
          label: "JUN"
        },
        {
          label: "JUL"
        },
        {
          label: "AUG"
        },
        {
          label: "SEP"
        },
        {
          label: "OCT"
        },
        {
          label: "NOV"
        },
        {
          label: "DEC"
        }
      ]
    }
  ],
  dataset: [
    {
      data: [
        {
          value: "9.2"
        },
        {
          value: "7.9"
        },
        {
          value: "7.5"
        },
        {
          value: "7"
        },
        {
          value: "6.1"
        }
        ,
        {
          value: "6.1"
        }
        ,
        {
          value: "2.3"
        }
        ,
        {
          value: "8.51"
        }
        ,
        {
          value: "9.1"
        }
        ,
        {
          value: "4.1"
        }
        ,
        {
          value: "5.1"
        }
      ]
    },
    {
      data: [
        {
          value: "6.7"
        },
        {
          value: "6.7"
        },
        {
          value: "6.7"
        },
        {
          value: "6.8"
        },
        {
          value: "6.9"
        }
        ,
        {
          value: "6.1"
        }
        ,
        {
          value: "6.1"
        }
        ,
        {
          value: "6.1"
        }
        ,
        {
          value: "6.17"
        }
        ,
        {
          value: "8.9"
        }
        ,
        {
          value: "3.1"
        }
        ,
        {
          value: "7.1"
        }
      ]
    }
  ]
};

const AreaChart=()=> {
    return (
      <ReactFusioncharts
        type="msarea"
        width="100%"
        height="45%"
        dataFormat="JSON"
        dataSource={dataSource}
      />
    );
}

export default AreaChart
