
import React from 'react'
import FusionCharts from "fusioncharts";
import charts from "fusioncharts/fusioncharts.charts";
import ReactFusioncharts from "react-fusioncharts";
charts(FusionCharts);


let finalArray = [];
const Donut = ({ data, count }) => {
  console.log("Dount Data >>>", data)
  let texts;
  let pantext = `<b>$label</b> <br/><b>$value </b>`
  let aumtext = `<b>$label</b> <br/><b>₹$value Cr</b>`
  let datas
  if (count == 'AUM') {
    datas = data.map((item) => ({
      label: item.label,
      value: (parseFloat(item.value) / 10000000).toFixed(2)
    }))
    texts = aumtext
  }

  else {
    datas = data;
    texts = pantext
  }

  // console.log("Datsss",datas)

  // if(count=='AUM'){
  //   texts=aumtext
  // }
  // else{
  //   texts=pantext
  // }
  const dataSource = {
    chart: {
      theme: "candy",
      chartTopMargin: 100,
      chartLeftMargin: -70,
      plottooltext: texts,
      use3DLighting: false,
      showShadow: false,
      doughnutRadius: 70,
      pieRadius: 90,
      showToolTip: "1",
      interactiveLegend: "1",
      legendBorderColor: "#ffffff",
      xAxisNameFontColor: "#909090",
      yAxisNameFontColor: "#909090",
      "legendItemFont": "Roboto",
      drawCustomLegendIcon: "1",
      legendIconSides: "4",
      legendPosition: window.innerWidth <= 640 ? "bottom" : "right-bottom",
      legendIconStartAngle: "45",
      bgcolor: "#ffffff",
      showLegend: "1",
      showborder: "0",
      palettecolors: "#2057A6,#69B8F4,#8ED8B7,#82C7ED,#8FABD3,#BA87ED",
      legendPosition: "bottom-right",
      "legendBgColor": "#fff",
      "legendBorderAlpha": "0",
      legendWidth: "200",
      showValues: 0,
      legendNumRows: 6,
    },
    data: datas
  };
  return (
    <>
      <div>
        <ReactFusioncharts
          type="doughnut2d"
          width="100%"
          height="38%"
          dataFormat="JSON"
          dataSource={dataSource}
        /></div>
    </>
  )
}

export default Donut;