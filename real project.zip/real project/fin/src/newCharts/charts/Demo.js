import FusionCharts from "fusioncharts";
import charts from "fusioncharts/fusioncharts.charts";
import ReactFusioncharts from "react-fusioncharts";
import React from "react";
charts(FusionCharts);

const dataSource = {
  chart: {
   
    bgColor: "#FFFFFF",
    chartRightPadding:"0px",
    pieRadius:100,
    chartTopMargin:100,
    plottooltext:
      "<b>$percentValue</b> of our Android users are on <b>$label</b>",
    centerlabel: "# Users: $value",
    theme: "fusion",
    doughnutRadius: "70%",
    showBorder:false,
    showLegend: "2",
    legendPosition:" bottom-right",
    legendNumRows:"3",
    legendBorderThickness:0,
    legendShadow:0,
    palette:3,
    palettecolors: "#2057A6,#69B8F4,#8ED8B7,#82C7ED,#8FABD3,#BA87ED",
    
    },
  data: [
    {
      label: "Jelly",
      value: "5300"
    },
    {
      label: "Kitkat",
      value: "10500"
    },
  ]
};

class Donut extends React.Component {
  render() {
    return (      
        <div style={{width:"60%",height:"180px",}} >
      <ReactFusioncharts
        type="doughnut2d"
        width="165%"
        height="47%"
        dataFormat="JSON"       
        dataSource={dataSource}
      />
      </div>
    );
  }
}
export default Donut;