import FusionCharts from "fusioncharts";
import charts from "fusioncharts/fusioncharts.charts";
import ReactFusioncharts from "react-fusioncharts";
import React from "react";

const BarChart = ({ data, xAxisName, yAxisName,count }) => {

  let texts;
  let pantext=`<b>$label</b> <br/><b>$value </b>`
  let aumtext=`<b>$label</b> <br/><b>₹$value Cr</b>`
 let datas
  if(count=='AUM'){
    datas=data.map((item)=>({
      label:item.label,
      value:(parseFloat(item.value)/10000000).toFixed(2)
    }))
    texts=aumtext
  }

  else{
    datas=data;
    texts=pantext
  }
 
console.log("Datas in ")
  charts(FusionCharts);
  const dataSource = {

    chart: {
      "theme": "fusion",
      xAxisName: xAxisName,
      yAxisName: yAxisName,
      xAxisNameFont: "Roboto",
      yAxisNameFont: "Roboto",
      xAxisNameFontSize: "12",
      yAxisNameFontSize: "12",
      labelFontSize: "10",
      yAxisValueFontSize: "10",
      plotSpacePercent: 50,
      plottooltext: texts,
      bgcolor: "#FFFFFF",
      "showxaxisline": "1",
      "showyaxisline": "1",
      color: "#FFFFFF",
      patterBgColor: "#FFFFFF",
      theme: 'fusion',
      barCategoryGap: 1,
      "chartBottomMargin": "10",
      pallete: 5,
      divLineColor: "#00080a",
      animation: 0,
      drawCrossLine: 1,
      crossLineAnimation: 0,
      divLineColor: "#00080a",
      showBorder: false,
      palettecolors: "#2057A6,#69B8F4,#8ED8B7,#82C7ED,#8FABD3,#BA87ED",
      toolTipFontSize: 6
    },
    "data": datas
  }

  return (
    <ReactFusioncharts
      type="bar2d"
      width="98%"
      height="37%"
      dataFormat="JSON"
      dataSource={dataSource}
    />
  );
}

export default BarChart