import ReactFC from "react-fusioncharts";
import Column2D from "fusioncharts/fusioncharts.charts";
import FusionTheme from "fusioncharts/themes/fusioncharts.theme.fusion";
import FusionCharts from "fusioncharts";

ReactFC.fcRoot(FusionCharts, Column2D, FusionTheme);

const VerticalBarChart = ({ data, xAxisName, yAxisName, theme, width }) => {
  console.log("The requires data >>", data);

  const datas = data.map((item) => ({
    label: item.assetcategorynewmcr,
    value: (parseFloat(item.aggregate_aum) / 10000000).toFixed(2)
  }))
  const chartConfigs = {
    type: "column2d",
    width: "99%",
    height: "40%",
    dataFormat: "json",
    dataSource: {
      chart: {
        xAxisName: xAxisName,
        yAxisName: yAxisName,
        xAxisNameFont: "Roboto",
        yAxisNameFont: "Roboto",
        xAxisNameFontSize: "12",
        yAxisNameFontSize: "12",
        yAxisNameFontBold: 0,
        xAxisNameFontBold: 0,
        labelFontSize: "10",
        yAxisValueFontSize: "10",
        showXAxisLine: "1",
        xAxisNameFontColor: "#909090",
        yAxisNameFontColor: "#909090",
        palettecolors: "#2057A6,#69B8F4,#8ED8B7,#82C7ED,#8FABD3,#BA87ED",
        showYAxisLine: "1",
        theme: theme,
        showValues: "0",
        bgColor: "#FFFFFF",
        showBorder: "0",
        chartBottomMargin: "20",
        showCanvasBorder: "0",
        showPlotBorder: "0",
        plotFillRatio: "100",
        showAlternateHGridColor: "0",
        divLineColor: "#cdd4cf",
        plottooltext: "Value: ₹ $value Cr",
        chartLeftMargin: 10,
        chartBottomMargin: 10,

      },
      data: datas,
    },
  };

  return (
    <>
      <div >
        <ReactFC {...chartConfigs} />
      </div>
    </>
  );
};

export default VerticalBarChart;
