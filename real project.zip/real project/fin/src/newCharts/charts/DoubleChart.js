import FusionCharts from "fusioncharts";
import charts from "fusioncharts/fusioncharts.charts";
import ReactFusioncharts from "react-fusioncharts";
charts(FusionCharts);


const LineChart = ({ data }) => {


    const dataSource = {
        chart: {
            xaxisname: "Month",
            yaxisname: "Market Share",
            bgColor: "#FFFFFF",
            showBorder: "0",
            xAxisNameFont: "Roboto",
            yAxisNameFont: "Roboto",
            xAxisNameFontSize: "12",
            yAxisNameFontSize: "12",
            yAxisNameFontBold: 0,
            xAxisNameFontBold: 0,
            labelFontSize: "10",
            yAxisValueFontSize: "10",
            "showxaxisline": "1",
            "showyaxisline": "1",
            "lineColor": "#2057a6",
            numDivLines: 5,
            divLineColor: "#d3d4d4",
            setadaptiveymin: "1",
            theme: "gammel",
            "anchorBgColor": "#2057a6",
            "showAlternateHGridColor": "0",
            "showPlotBorder": "1",
            "showLegend": "0",
            showPlotBorder: "0",
            usePlotGradientColor: "0",
            showToolTip: 0
        }, "categories": [
            {
                "category": [
                    {
                        "label": "Jan"
                    },
                    {
                        "label": "Feb"
                    },
                    {
                        "label": "Mar"
                    },
                    {
                        "label": "Apr"
                    },
                    {
                        "label": "May"
                    },
                    {
                        "label": "Jun"
                    },
                    {
                        "label": "Jul"
                    },
                    {
                        "label": "Aug"
                    },
                    {
                        "label": "Sep"
                    },
                    {
                        "label": "Oct"
                    },
                    {
                        "label": "Nov"
                    },
                    {
                        "label": "Dec"
                    }
                ]
            }
        ],
        "dataset": [
            {
                "seriesName": "AUM",
                "showValues": "0",
                "data": [
                    {
                        "value": "1.6",
                        "color": "69B8F4"
                    },
                    {
                        "value": "2.5",
                        "color": "69B8F4"
                    },
                    {
                        "value": "1.8",
                        "color": "69B8F4"
                    },
                    {
                        "value": "1.9",
                        "color": "69B8F4"
                    },
                    {
                        "value": "1.5",
                        "color": "69B8F4"
                    },
                    {
                        "value": "2.1",
                        "color": "69B8F4"
                    },
                    {
                        "value": "1.6",
                        "color": "69B8F4"
                    },
                    {
                        "value": "2.0",
                        "color": "69B8F4"
                    },
                    {
                        "value": "1.7",
                        "color": "69B8F4"
                    },
                    {
                        "value": "2.5",
                        "color": "69B8F4"
                    },
                    {
                        "value": "1.9",
                        "color": "69B8F4"
                    },
                    {
                        "value": "2.3",
                        "color": "69B8F4"
                    }
                ]
            },
            {
                "seriesName": "Flow",
                "renderAs": "line",
                "showValues": "0",
                "data": [
                    {
                        "value": "1.5"
                    },
                    {
                        "value": "2.3"
                    },
                    {
                        "value": "1.7"
                    },
                    {
                        "value": "1.8"
                    },
                    {
                        "value": "2.3"
                    },
                    {
                        "value": "1.9"
                    },
                    {
                        "value": "1.9"
                    },
                    {
                        "value": "1.7"
                    },
                    {
                        "value": "2.0"
                    },
                    {
                        "value": "1.7"
                    },
                    {
                        "value": "2.2"
                    },
                    {
                        "value": "2.3"
                    }
                ]
            },
        ]


    };
    return (
        <ReactFusioncharts
            type="mscombi2d"
            width="100%"
            height="45%"
            dataFormat="JSON"
            dataSource={dataSource}
        />
    );
}

export default LineChart
