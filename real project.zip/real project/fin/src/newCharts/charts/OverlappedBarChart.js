import React from "react";
import ReactFC from "react-fusioncharts";
import FusionCharts from "fusioncharts";
import FusionTheme from "fusioncharts/themes/fusioncharts.theme.fusion";
import Overlappedbar2d from 'fusioncharts/fusioncharts.overlappedbar2d';

ReactFC.fcRoot(FusionCharts, Overlappedbar2d, FusionTheme);


const OverlappedBarChart = ({ xAxisName, yAxisName }) => {
    const chartConfigs = {
        "type": "overlappedBar2d",
        "renderAt": "chart-container",
        "width": "100%",
        "height": "57%",
        "dataFormat": "json",
        "dataSource": {
            "chart": {
                "xAxisName": xAxisName,
                "yAxisName": yAxisName,
                "theme": "fusion",
                xAxisName: xAxisName,
                yAxisName: yAxisName,
                xAxisNameFont: "Roboto",
                yAxisNameFont: "Roboto",
                xAxisNameFontSize: "12",
                yAxisNameFontSize: "12",
                labelFontSize: "10",
                yAxisValueFontSize: "10",
                bgcolor: "#FFFFFF",
                "showxaxisline": "1",
                "showyaxisline": "1",
                color: "#FFFFFF",
                patterBgColor: "#FFFFFF",
                theme: 'fusion',
                barCategoryGap: 1,
                "chartBottomMargin": "10",
                pallete: 5,
                divLineColor: "#00080a",
                animation: 0,
                drawCrossLine: 1,
                crossLineAnimation: 0,
                plottooltext: "$seriesname: $value Cr",
                toolTipWidth: "400px",
                divLineColor: "#00080a",
                showBorder: false,
                palettecolors: "#2057A6,#69B8F4,#8ED8B7,#82C7ED,#8FABD3,#BA87ED",
                toolTipFontSize: 6,
                plotSpacePercent: 30,
                showLegend: 0
            },
            "categories": [{
                "category": [{
                    "label": "Flexi Cap Fund"
                }, {
                    "label": "Mid Cap Fund"
                }, {
                    "label": "Small Cap Fund"
                }, {
                    "label": "Large Cap Fund"
                }, {
                    "label": "Gilt Fund"
                }]
            }],
            "dataset": [{
                "seriesname": "Kfin Share",
                "data": [{
                    "value": "40"
                }, {
                    "value": "36"
                }, {
                    "value": "25"
                }, {
                    "value": "28"
                }, {
                    "value": "32"
                }]
            }, {
                "seriesname": "PMIG Share",
                "data": [{
                    "value": "30"
                }, {
                    "value": "26"
                }, {
                    "value": "15"
                }, {
                    "value": "18"
                }, {
                    "value": "22"
                }]
            }]
        }
    };

    return (
        <ReactFC {...chartConfigs} />
    );

}
export default OverlappedBarChart;
