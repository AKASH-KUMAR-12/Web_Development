import FusionCharts from "fusioncharts";
import charts from "fusioncharts/fusioncharts.charts";
import ReactFusioncharts from "react-fusioncharts";

charts(FusionCharts);


const LineChart = ({ data, xAxisName, yAxisName }) => {


  const dataSource = {
    chart: {
      xaxisname: xAxisName,
      yaxisname: yAxisName,
      xAxisNameFont: "Roboto",
      yAxisNameFont: "Roboto",
      xAxisNameFontSize: "12",
      yAxisNameFontSize: "12",
      xAxisNameFontColor: "#909090",
      yAxisNameFontColor: "#909090",
      labelFontSize: "10",
      yAxisValueFontSize: "10",
      bgColor: "#FFFFFF",
      plotFillColor: "#2057A6",
      "bgAlpha": "50",
      "showcanvasborder": "0",
      "showxaxisline": "1",
      "showyaxisline": "1",
      "lineColor": "#2057a6",
      numDivLines: 11,
      divLineColor: "#d3d4d4",
      setadaptiveymin: "1",
      theme: "fusion",
      "anchorBgColor": "#2057a6",
      "showAlternateHGridColor": "0",
      "showPlotBorder": "1",
      "drawFullAreaBorder": "0",
      "plotBorderThickness": "2",
      chartLeftMargin: 0,
      chartBottomMargin: 10,
      "showValues": "0",
      plottooltext: "$label: $value Cr",
    },
    data: data
  };
  return (
    <ReactFusioncharts
      type="line"
      width="100%"
      height="45%"
      dataFormat="JSON"
      dataSource={dataSource}
    />
  );
}


export default LineChart
