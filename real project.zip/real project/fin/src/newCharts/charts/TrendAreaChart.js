import * as React from "react";
import { styled } from "@mui/material/styles";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell, { tableCellClasses } from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";


const StyledTableCell = styled(TableCell)(({ theme }) => ({
  [`&.${tableCellClasses.head}`]: {
    backgroundColor: "#90caf9",
    color: theme.palette.common.blue
  },
  [`&.${tableCellClasses.body}`]: {
    fontSize: 14,
  },
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
  "&:nth-of-type(even)": {
    backgroundColor: "#e3f2fd",
  },
  "&:last-child td, &:last-child th": {
    border: 0,
  },
}));



export default function TrendArea(data) {

  console.log("data inside Distributor tabel",data.data)
  return (

  
      <TableContainer component={Paper}>
        <Table
          sx={{ minWidth: 200}}
          aria-label="customized table"
          size="medium"
        >
          <TableHead>
            <TableRow>
              <StyledTableCell>Distributor Name</StyledTableCell>
              <StyledTableCell align="right">FreshSIP Count</StyledTableCell>
              
            </TableRow>
          </TableHead>
          <TableBody>
            {data.data?.map((row) => (
              <StyledTableRow key={row.label}>
                <StyledTableCell component="th" scope="row">
                  {row.label}
                </StyledTableCell>
                <StyledTableCell align="right">{row.SIP_Count}</StyledTableCell>
                
              </StyledTableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
  
  );
}