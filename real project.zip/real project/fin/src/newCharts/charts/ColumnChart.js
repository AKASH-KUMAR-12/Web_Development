import FusionCharts from "fusioncharts";
import charts from "fusioncharts/fusioncharts.charts";
import ReactFusioncharts from "react-fusioncharts";

import React from 'react'

const ColumnChart = ({ data }) => {
    charts(FusionCharts);
    const { chartData, chartAxis } = data;
    const dataSource = {
        chart: {
            showXAxisLine: "1",
            showYAxisLine: "1",
            yaxisname: `${chartAxis.yName}`,
            xaxisname: `${chartAxis.xName}`,
            xAxisNameFontColor: "#9aa19c",
            yAxisNameFontColor: "#9aa19c",
            chartTopMargin: "20",
            chartBottomMargin: "10",
            numberPrefix: "₹",
            labelFontSize: "10",
            yAxisValueFontSize: "10",
            theme: "fusion",
            showValues: "0",
            bgColor: "#FFFFFF",
            showBorder: "0",
            showCanvasBorder: "0",
            showPlotBorder: "0",
            plotFillRatio: "100",
            showAlternateHGridColor: "0",
            divLineColor: "#cdd4cf",
            plottooltext: "<b>Value</b>{br}   <b>₹ $value</b>",
            palettecolors: "#2057A6,#69B8F4,#8ED8B7,#82C7ED,#8FABD3,#BA87ED",

        },
        data: chartData
    };

    return (

        <ReactFusioncharts
            type="column2d"
            width="100%"
            height="40%"
            dataFormat="JSON"
            dataSource={dataSource}
        />
    );
}
export default ColumnChart;
