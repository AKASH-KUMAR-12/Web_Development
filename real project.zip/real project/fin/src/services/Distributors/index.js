import React from "react";
import Card from "./components/Card";
import { Box, Grid } from "@mui/material";
import DistributorCategory from "./components/DistributorCategory";
import RegionalDistributorCount from "./components/RegionalDistributorCount";
import { assetClassData, SIPAgeingData, data, planModelistArray, revenueData } from "../../utilityComponents/Database"
import ActiveDistributorCount from "./components/ActiveDistributorCount";
import TrendGraph from "./components/TrendGraph";
import DistributorDetails from "./components/DistributorDetails";
import Donut from "../../utilityComponents/charts/Donut";
import BarChart from "../../utilityComponents/charts/BarChart";
import MultiLineChart from "../../utilityComponents/charts/MultiLineChart";


const DistributorDashboard = () => {

    const regionalData = [
        {
            "label": "South",
            "value": "45"
        },
        {
            "label": "West",
            "value": "75"
        },
        {
            "label": "East",
            "value": "55"
        },
        {
            "label": "North",
            "value": "45"
        },
        {
            "label": "Others",
            "value": "25"
        }

    ]

    const Terflag = [
        {
            "label": "T30",
            "value": "45"
        },
        {
            "label": "B30",
            "value": "75"
        },
    ]
    const DistributorCount = [
        {
            "label": "SEP",
            "value": "95"
        },
        {
            "label": "AUG",
            "value": "75"
        },
        {
            "label": "JUL",
            "value": "55"
        },
        {
            "label": "JUN",
            "value": "35"
        },
        {
            "label": "MAY",
            "value": "45"
        },
        {
            "label": "APR",
            "value": "85"
        },
        {
            "label": "MAR",
            "value": "65"
        },
        {
            "label": "FEB",
            "value": "75"
        },
        {
            "label": "JAN",
            "value": "45"
        },
    ]
    return (

        <>
            <Box sx={{ padding: "0", width: "95%", margin: "0px auto" }}>

                <Box
                    sx={{
                        position: "relative",
                        top: "0rem",
                        height: "1.5rem",
                        zIndex: "1",
                        borderRadius: "9px",
                        margin: "0rem 0rem 0rem 1rem",
                    }}
                >
                    <h3 className="box_shadow" style={{ position: "absolute", top: "1.5rem", marginInline: "auto", width: "96.5%", background: "#fff", padding: "0.7rem", borderRadius: "9px", }}>Data as on 30th of September</h3>
                </Box>

                <Grid container xs={12} justifyContent={"space-between"} alignItems={"center"}
                    sx={{ height: { lg: "75vh", md: "75vh", xs: "82vh" }, width: "100%", paddingInline: "1rem", marginTop: "4.5rem", overflow: "scroll", paddingBottom: "3rem" }}>
                    <Card />
                    <BarChart
                        xAxisName={"AUM(in Crores)"}
                        yAxisName={"Category"}
                        data={data}
                        sx={{ marginTop: "0rem" }}
                        headerProps={{
                            heading: "Distributor Category",
                        }}
                    />
                    <Donut
                        md={5.8}
                        data={regionalData}
                        headerProps={{
                            heading: "Regional Distributor Count",
                            xs1: 12
                        }}
                    />
                    <Donut
                        md={5.8}
                        data={Terflag}
                        headerProps={{
                            heading: "Terflag",

                        }}
                    />
                    <BarChart
                        xAxisName={"Months"}
                        yAxisName={"No. of Distributors(in Thousands)"}
                        data={DistributorCount}
                        headerProps={{
                            heading: "Active Distributor Count",
                            xs1: 12
                        }}
                    />
                    <MultiLineChart
                        xAxisName={"Month"}
                        yAxisName={"AUM (in crores)"}
                        // data={revenueData}
                        headerProps={{
                            heading: "Trend Graph",
                            radioList: ["SIP Book", "SIP Count"],
                            radioValue: "AUM"
                        }}
                    />
                    <DistributorDetails />

                </Grid>
            </Box>
        </>

    )
}

export default DistributorDashboard