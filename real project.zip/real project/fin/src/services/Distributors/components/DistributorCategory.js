import { Box, Grid } from '@mui/material'
import React from 'react'
import HeaderParent from '../../../utilityComponents/components/HeaderParent'
import BarChart from '../../../utilityComponents/charts/BarChart';


const DistributorCategory = ({ data }) => {


    return (
        <Grid container xs={12} justifyContent={"space-between"} sx={{
            borderTop: "3px solid #010C43",
            marginTop: "20px",
            borderRadius: '8px',
            alignItems: "center",
            height: "auto",
        }}>
            <Grid item xs={12} sx={{ bgcolor: "#fff", borderRadius: "8px", boxShadow: 6 }}>
                <HeaderParent xs={12} xs3={6}
                    heading="Distributor Category"
                    radioList={["AUM", "PAN Count"]}
                />
                <BarChart
                    data={data}
                />
            </Grid>
        </Grid>
    )
}

export default DistributorCategory