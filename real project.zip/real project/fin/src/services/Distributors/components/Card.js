import { Box } from '@mui/material'
import React from 'react'
import {Grid} from '@mui/material';
const Card_Body = (props) => {
    return (
        <div style={{
            padding:'15px 0 0 18px',
            backgroundColor: "white",
                      height: 'auto',
                      borderRadius: '7px',
                      borderTop: '3.7px solid #2057A6',
                      background: 'linear-gradient(to bottom,rgba(105, 184, 244, 0.1),rgba(255, 255, 255, 0.1))',
                      boxShadow: '0px 2px 8px 0px #00000033',
                      textAlign: 'left'
        }}>
          <div style={{
              fontSize:{md:"1.5rem",xs:"1rem"},
              fontWeight:'700',
          }}>{props.title}</div>
          <Box sx={{
              fontSize:'14px',
              fontWeight:'450',
              color: '#333333',
              padding:'1rem 0 0.5rem 0 '
          }}>{props.value1}</Box>
          <Box sx={{
              fontSize:'14px',
              fontWeight:'600',
              color: '#333333',
              padding:'0 0 0.5rem 0 '
          }}>{props.value2}</Box>
          </div>
    );
}
const Card = () => {
  return (
    <Grid container spacing={2} mb={2}>

    <Grid item xs={4} md={4}>
      <Card_Body title="Total Distributor Count" value1="Value " value2="32,989"/>
    </Grid>
  
    <Grid item xs={4} md={4}>
    <Card_Body title="Total Distributor AUM" value1="Value" value2="₹ 58,391.94 Crs" />
    </Grid>
  
    <Grid item xs={4} md={4}>
    <Card_Body title="Distributors Activated this FY Count" value1="Value" value2="5,610"/>
    </Grid>
 
  </Grid>
    
  )
}

export default Card