import React from "react";
import { Grid } from "@mui/material";
import HeaderParent from "../../../utilityComponents/components/HeaderParent";
import Donut from "../../../utilityComponents/charts/Donut";

const RegionalDistributorCount = ({ data}) => {

    return (
        <Grid container xs={12} gap={2} justifyContent={"space-between"} sx={{
            marginTop: "20px",
            borderRadius: '8px',
            alignItems: "center",
            height: "auto",
        }}>
            <Grid item md={5.8} xs={12} sx={{ bgcolor: "#fff", borderRadius: "8px", boxShadow: 6, borderTop: "3px solid #010C43", }}>
                <HeaderParent xs={12} xs1={12}
                    heading="Regional Distributor Count"
                />
                <Donut
                    data={data}
                />
            </Grid>
            <Grid item md={5.8} xs={12} sx={{ bgcolor: "#fff", borderRadius: "8px", boxShadow: 6, borderTop: "3px solid #010C43", }}>
                <HeaderParent xs={12} xs3={6}
                    heading="City Categories"
                />
                <Donut
                    data={data}
                />
            </Grid>
        </Grid>
    );
}

export default RegionalDistributorCount;