import { Grid } from '@mui/material'
import React, { useEffect, useState } from 'react'
import HeaderParent from '../../../utilityComponents/components/HeaderParent'
import axios from 'axios'
import { useSelector } from 'react-redux'
import MultiLineChart from '../../../utilityComponents/charts/MultiLineChart'


const TrendGraph = ({ data }) => {
    
    return (
        <Grid container xs={12} justifyContent={"space-between"} sx={{
            borderTop: "3px solid #010C43",
            marginBlock: "20px",
            borderRadius: '8px',
            alignItems: "center",
            height: "auto",
        }}>
            <Grid item xs={12} sx={{ bgcolor: "#fff", borderRadius: "8px", boxShadow: 6 }}>
                <HeaderParent xs={12} xs3={4}
                    heading="Trend Graph"
                />
                <MultiLineChart
                    xAxisName={"Month"}
                    yAxisName={"AUM (in crores)"}
                    data={data}

                />
            </Grid>
        </Grid>
    )
}

export default TrendGraph