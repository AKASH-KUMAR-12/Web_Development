import { Grid } from '@mui/material'
import React, { useEffect, useState } from 'react'
import HeaderParent from '../../../utilityComponents/components/HeaderParent'
import ScrollingTable from '../../../utilityComponents/Table'


const DistributorDetails = ({ data }) => {
    const rows = [
        // createData('NJ India Invest Pvt Ltd', '7,79,244', '31,16,976', '₹ 3,105.49 Cr', '₹ 12,421.96 Cr'),
        // createData('ICICI Securities Limited', '3,24,460', '12,97,840', '₹ 775.06 Cr', '₹ 3,100.24 Cr'),
        // createData('Prudent Corporate Advisory Services Ltd', '2,91,248', '11,64,992', '₹ 658.74 Cr', '₹ 2,634.96 Cr'),
        // createData('State Bank of India', '95,615', '3,82,460', '₹ 439.99 Cr', '₹ 1,759.96 Cr'),
        // createData('Axis Bank Limited', '2,64,637', '10,58,548', '₹ 384.04 Cr', '₹ 1,536.16 Cr'),
        // createData('HDFC BANK LIMITED', '88,711', '3,54,844', '₹ 288.43 Cr', '₹ 1,513.72 Cr'),
        // createData('HDFC SECURITIES LTD', '2,55,519', '10,22,076', '₹ 204.16 Cr', '₹ 816.64 Cr'),
        // createData('HMG CAPITAL SERVICES ...', '1,084', '4,336', '₹ 178.35 Cr', '₹ 713.4 Cr'),
        // createData('SLA FINSERV PRIVATE LIMITED', '2,780', '11,120', '₹ 146.93 Cr', '₹ 587.72 Cr'),
        createData('Aditya Birla Finance Limited', 'ARN-118681','East','KOLKATA', '₹ 1.5 Cr', '₹ 9.5 Cr', '₹ 25 Cr', '₹ 10 Cr','103'),
        createData('Kokkuvayil Kumaran Gopalakrishnan', 'ARN-36647','South','THRISSUR',  '₹ 1.2 Cr', '₹ 6 Cr', '₹ 1.3 Cr', '₹ 65 Cr','238'),
        createData('Mata Securities India Pvt. Ltd.', 'ARN-0158','West','MUMBAI',  '₹ 3.5 Cr', '₹ 59.9 Cr', '₹ 10 Cr', '₹ 7 Cr','172'),
        createData('LICHFL Financial Services Ltd.', 'ARN-69252','West','MUMBAI', '₹ 31.9 Cr', '₹ 105.1 Cr', '₹ 2 Cr', '₹ 1.1 Cr','109'),
        createData('ROOPAMONEY INVESTMENT SERVICES LLP', 'ARN-175387','South','ERNAKULAM',  '₹ 0.11 Cr', '₹ 4 Cr', '₹ 3 Cr', '₹ 1.2 Cr','148'),
    ];
    const columns = [
        {
            id: 'Distributor',
            label: 'Distributor Name',
            align: 'center',
            format: (value) => value.toLocaleString('en-US'),
        },
        {
            id: 'ARN_code',
            label: 'ARN Code',
            align: 'center',
            format: (value) => value.toLocaleString('en-US'),
        },

        {
            id: 'Region',
            label: 'Region',
            align: 'center',
            format: (value) => value.toLocaleString('en-US'),
        },
        {
            id: 'Branch_city',
            label: 'Branch/City',
            align: 'center',
            format: (value) => value.toLocaleString('en-US'),
        },
        {
            id: 'GS',
            label: 'GS',
            align: 'center',
            format: (value) => value.toLocaleString('en-US'),
        },
        {
            id: 'AUM',
            label: 'AUM',
            align: 'center',
            format: (value) => value.toLocaleString('en-US'),
        },
        {
            id: 'SIP_Book',
            label: 'SIP Book',
            align: 'center',
            format: (value) => value.toLocaleString('en-US'),
        },
        {
            id: 'SIP_Added',
            label: 'New SIP Added',
            align: 'center',
            format: (value) => value.toLocaleString('en-US'),
        },
        {
            id: 'PAN_Count',
            label: 'PAN Count',
            align: 'center',
            format: (value) => value.toLocaleString('en-US'),
        },
    ];
    function createData(Distributor, ARN_code, Region, Branch_city, GS,AUM,SIP_Book,SIP_Added,PAN_Count) {
        return {Distributor, ARN_code, Region, Branch_city, GS,AUM,SIP_Book,SIP_Added,PAN_Count};
    }
    return (
        <ScrollingTable
        rows={rows}
        columns={columns}
        headerProps={{
            heading: "Distributor Details",
            dropdownOptions: [{ title: "Top 10" }, { title: "Top 20" }, { title: "Top 50" }]
        }}/>
    )
}

export default DistributorDetails