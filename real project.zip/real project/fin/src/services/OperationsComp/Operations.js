import * as QuickSightEmbedding from "amazon-quicksight-embedding-sdk";
import React, { useEffect, createRef, useState, useRef } from "react";
import axios from "axios";
import SecureLS from "secure-ls";
import { Box, Card, CardContent, CardHeader, Grid, IconButton, MenuItem, Select, TextField } from "@mui/material";
import {
    Typography
} from "@mui/material";

var ls = new SecureLS({
    encodingType: "aes",
    isCompression: false,
    encryptionSecret: "my-secret-key",
});
let reportNameMap = {
    "sales": "76b5b7bc-d74b-420d-aece-bf4a7b8582f0",
}

let darkTheme = {
    "MSR": "2c6a27b9-33bf-4dc4-896a-dedf1485f15e",
}
const Operations = () => {
    const [reportName, setType] = useState("MSR")

    const [dashboard, setDashboard] = useState(null)
    var user = ls.get("user");

    const embeddingContainer = useRef(null)
    function onDashboardLoad(payload) {
        console.log("h1")
        var iframe = document.getElementsByClassName('quicksight-embedding-iframe');
        var innerDoc = iframe;
        console.log(innerDoc)
        console.log(document.getElementsByClassName('quicksight-embedding-iframe'))
    }

    useEffect(() => {
    }, [])


    useEffect(() => {
        (async () => {
            embeddingContainer.current.innerHTML = "";
            console.log(embeddingContainer.current)

            await axios
                .get(`https://finstaxdemo.kfintech.com/api/embed?Id=${reportNameMap.sales}`)
                .then((data) => {
                    console.log("url is working");
                    console.log(data)
                    var embedUrl = data.data.EmbedUrl;

                    var options = {
                        url: embedUrl,
                        container: embeddingContainer.current,
                        themeId: "arn:aws:quicksight::aws:theme/MIDNIGHT"
                    };
                    let dashboard;
                    try {
                        dashboard = QuickSightEmbedding.embedDashboard(options)
                        dashboard.on("load", onDashboardLoad)
                    }
                    catch (e) { }

                    setDashboard(dashboard)

                });
        })();


    }, []);

    return (
        <div style={{ overflow: "hidden", whiteSpace: "nowrap" }}>

            <Card
                sx={{ boxShadow: 6, overflow: "hidden", whiteSpace: "nowrap", margin: "20px", height: "88vh", padding: "0px", borderRadius: "8px", display: "flex", flexDirection: "column" }}
            >
                <CardContent sx={{
                    display: "flex",
                    flex: "10",

                }}>
                    <Box sx={{
                        boxShadow: "var(--softUIEffect-1)",
                        flex: "1",
                        boxShadow: 6,
                        borderRadius: "8px"
                    }}>
                        <>
                           <div id="embedding"
                                style={{
                                    paddingTop: "1rem",
                                    justifyItems: "center",
                                    height: "95%",
                                }}
                                ref={embeddingContainer}
                            >
                                { }

                            </div>
                        </>
                    </Box>

                </CardContent>
            </Card>
        </div>

    )
}

export default Operations