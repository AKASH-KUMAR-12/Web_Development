import React, { useEffect, useState } from "react";
import { Box, Grid } from "@mui/material";
// import InvestorCategory from "./components/InvestorCategory";
import Card from "../../utilityComponents/Card";
import FilterChip from "../../utilityComponents/FilterChip";
import "./styles/style.css"
import { assetClassData, SIPAgeingData, data, planModelistArray, revenueData } from "../../utilityComponents/Database"
// import AssetClass from "./components/AssetClass";
// import PlanModeTB30 from "./components/PlanModeTB30";
// import InvestorDemographyMap from "./components/InvestorDemographyMap";
// import AssetCategory from "./components/AssetCategory";
// import DistributorCategory from "./components/DistributorCategory";
// import InvestorDemography from "./components/InvestorDemography";
// import AUMTrendGraph from "./components/AUMTrendGraph";
import SchemeDetails from "./components/SchemeDetails";
// import Donut from "./charts/Donut";
import MapChart from "../../utilityComponents/charts/MapChart";
import VerticalBarChart from "../../utilityComponents/charts/verticalBarChart";
import MultiLineChart from "../../utilityComponents/charts/MultiLineChart";
import { fetchInvCatData, fetchAssetClassData, fetchPlanModeData, fetchTB30Data, fetchMapTableData, fetchMapData, fetchInvestorDemoData, fetchAssetCategoryData, fetchDefaultFilterData } from "./fetchAumApi";
import { useDispatch, useSelector } from "react-redux";
import Donut from "../../utilityComponents/charts/Donut";
import { clearAumFilterData, setAumData } from "../../reduxStore/filterReducer";
const AUMDashboard = () => {
    const dispatch = useDispatch();
    const [invCatRadio, setInvCatRadio] = useState("AUM");
    const [assetCatRadio, setAssetCatRadio] = useState("AUM");
    const [planModeRadio, setPlanModeRadio] = useState("AUM");
    const [tb30Radio, setTB30Radio] = useState("AUM");
    const [invDemoRadio, setInvDemoRadio] = useState("Age");
    const [mapRadio, setMapRadio] = useState("Region");
    const [aumTrendRadio, setAumTrendRadio] = useState("AUM");
    const [capsuleBtnValue, setCapsuleBtnValue] = useState("AUM");

    const investorData = useSelector((state) => state.filterData?.investor)
    const zoneData = useSelector((state) => state.filterData?.zone)
    const stateData = useSelector((state) => state.filterData?.state)
    const assetclassData = useSelector((state) => state.filterData?.assetClass)
    const assetcategoryData = useSelector((state) => state.filterData?.assetCategory)
    const filterSelected = useSelector((state) => state.filterData?.filterSelected)
    // useEffect(() => {

    //     console.log("*******************************************************************************", investorData, zoneData, assetclassData, assetcategoryData);
    // }, [investorData, assetclassData, assetcategoryData, zoneData])
    useEffect(() => {
        const fetchingDefaultFilterData = async () => {

            const response = await fetchDefaultFilterData();
            console.log("called", response)
            localStorage.setItem("Finstax:AumDefaultFilter", JSON.stringify(response));
            dispatch(setAumData({ title: "assetClass", value: response["assetClass"] }))
            dispatch(setAumData({ title: "assetCategory", value: response["assetCategory"] }))

        }
        if (!filterSelected) { fetchingDefaultFilterData() };
    }, [filterSelected])

    const tb30Payload =
    {
        "fund": "RMF",
        "zone": zoneData,
        "investor": investorData,
        "query_name": "aum-TerFlag",
        "state": stateData,
        "assetclass": assetclassData,
        "assetcategory": assetcategoryData,
        "comment": filterSelected ? "" : "-- "
    }
    const planModePayload =
    {
        "fund": "RMF",
        "zone": zoneData,
        "investor": investorData,
        "query_name": "aum-PlanMode",
        "state": stateData,
        "assetclass": assetclassData,
        "assetcategory": assetcategoryData,
        "comment": filterSelected ? "" : "-- "
    }
    const assetClassPayload =
    {
        "fund": "RMF",
        "zone": zoneData,
        "investor": investorData,
        "query_name": "aum-AssetClass",
        "state": stateData,
        "assetclass": assetclassData,
        "assetcategory": assetcategoryData,
        "comment": filterSelected ? "" : "-- "
    }
    const invCatPayload =
    {
        "fund": "RMF",
        "zone": zoneData,
        "investor": investorData,
        "query_name": "aum-InvestorCategory",
        "state": stateData,
        "assetclass": assetclassData,
        "assetcategory": assetcategoryData,
        "comment": filterSelected ? "" : "-- "
    }
    const mapPayload =
    {
        "fund": "RMF",
        "zone": zoneData,
        "investor": investorData,
        "order": "asc",
        "query_name": "aum-InvestorDemography",
        "subCategory": "demography",
        "demographyColumn": "final_state" || "zone" || "final_city",
        "state": stateData,
        "assetclass": assetclassData,
        "assetcategory": assetcategoryData,
        "comment": filterSelected ? "" : "-- "
    }
    const investorDemoPayload = {
        "fund": "RMF",
        "zone": zoneData,
        "investor": investorData,
        "order": "asc",
        "query_name": `Investor-Base-${capsuleBtnValue?.substring(0, 3)}`,
        "subCategory": "Investor-Base",
        "demographyColumn": invDemoRadio,
        "state": stateData,
        "assetclass": assetclassData,
        "assetcategory": assetcategoryData,
        "comment": filterSelected ? "" : "-- "

    }
    const assetCategoryPayload =
    {
        "fund": "RMF",
        "zone": zoneData,
        "investor": investorData,
        "query_name": "aum-AssetCategory",
        "state": stateData,
        "assetclass": assetclassData,
        "assetcategory": assetcategoryData,
        "comment": filterSelected ? "" : "-- "
    }

    return (
        <>
            {/* <Container sx={{ padding: "0", display: 'flex', flexDirection: "column" }}>
                <Box sx={{ zIndex: 1000, height: "fit-content", bgcolor: "#fff", position: "fixed", top: 50, width: "80%" }}>
                    <Box
                        sx={{
                            boxShadow: 6,
                            background: "#fff",
                            padding: "0.7rem",
                            borderRadius: "9px",
                            margin: "1.5rem 0.9rem 1rem 0",
                        }}
                    >
                        <h2>Data as on 30th of September</h2>
                    </Box>
                </Box>

                <div style={{ marginTop: "1.2rem", overflow: "auto", padding: "0rem 1rem" }}> */}

            <Box sx={{ padding: "0", width: "95%", margin: "0px auto" }}>

                <Box
                    sx={{
                        position: "relative",
                        top: "0rem",
                        height: "1.5rem",
                        zIndex: "1",
                        borderRadius: "9px",
                        margin: "0rem 0.2rem 1rem 1rem",
                    }}
                >
                    <h3 className="box_shadow" style={{ position: "absolute", top: "1.5rem", marginInline: "auto", width: "97%", background: "#fff", padding: "0.7rem", borderRadius: "9px", }}>Data as on 30th of September</h3>
                </Box>

                <Grid container xs={12} justifyContent={"space-between"} alignItems={"center"}
                    sx={{ height: { lg: "75vh", md: "75vh", xs: "82vh" }, width: "100%", paddingInline: "1rem", marginTop: "4rem", overflow: "scroll", paddingBottom: "3rem" }}>
                    <FilterChip />
                    <Card />
                    <Donut
                        data={data}
                        listData={planModelistArray}
                        cardTitle={"investor"}
                        fetchAPI={fetchInvCatData}
                        fetchPayload={invCatPayload}
                        // reducerProps={{
                        //     reducerName: "filterData",
                        //     setReducerData: setAumData,
                        //     clearFilterData: clearAumFilterData
                        // }}
                        headerProps={{
                            heading: "Investor Category",
                            radioList: ["AUM", "PAN Count"],
                            radioValue: invCatRadio,
                            setRadioValue: setInvCatRadio
                        }}
                    />

                    <MapChart
                        fetchAPI={fetchMapTableData}
                        fetchMapAPI={fetchMapData}
                        fetchPayload={mapPayload}
                        tableColumn={[mapRadio, "AUM", "PAN Count"]}
                        headerProps={{
                            heading: "Investor Demography - Location",
                            radioValue: mapRadio,
                            setRadioValue: setMapRadio
                        }}
                    />
                    <Donut
                        data={data}
                        listData={planModelistArray}
                        fetchAPI={fetchAssetClassData}
                        fetchPayload={assetClassPayload}
                        cardTitle={"assetClass"}
                        reducerProps={{
                            reducerName: "filterData",
                            setReducerData: setAumData,
                            clearFilterData: clearAumFilterData
                        }}
                        headerProps={{
                            heading: "Asset Class",

                        }}
                    />
                    <VerticalBarChart
                        xAxisName={"Asset Category"}
                        yAxisName={assetCatRadio == "AUM" ? "AUM (in crores)" : "PAN Count"}
                        data={SIPAgeingData}
                        fetchAPI={fetchAssetCategoryData}
                        fetchPayload={assetCategoryPayload}
                        cardTitle={"assetCategory"}
                        headerProps={{
                            heading: "Asset Category",
                            radioList: ["AUM", "PAN Count"],
                            radioValue: assetCatRadio,
                            setRadioValue: setAssetCatRadio,
                        }}
                    />
                    <SchemeDetails />
                    <Donut
                        md={5.8}
                        data={assetClassData}
                        fetchAPI={fetchPlanModeData}
                        fetchPayload={planModePayload}
                        headerProps={{
                            heading: "Plan Mode",
                            xs3: 6,
                            radioList: ["AUM", "PAN Count"],
                            radioValue: planModeRadio,
                            setRadioValue: setPlanModeRadio
                        }}
                    />
                    <Donut
                        md={5.8}
                        data={assetClassData}
                        fetchAPI={fetchTB30Data}
                        fetchPayload={tb30Payload}
                        headerProps={{
                            heading: "T30/B30",
                            xs3: 6,
                            radioList: ["AUM", "PAN Count"],
                            radioValue: tb30Radio,
                            setRadioValue: setTB30Radio
                        }}
                    />
                    {/* <BarChart
                        data={data}
                        headerProps={{
                            heading: "Distributor Category",
                            radioList: ["AUM", "PAN Count"],
                            radioValue: distCatRadio,
                            setRadioValue: setDistCatRadio
                        }}
                    /> */}
                    <VerticalBarChart
                        xAxisName={invDemoRadio}
                        yAxisName={capsuleBtnValue == "AUM" ? "AUM (in crores)" : "PAN Count"}
                        data={data}
                        fetchAPI={fetchInvestorDemoData}
                        fetchPayload={investorDemoPayload}
                        headerProps={{
                            heading: "Investor Demography",
                            radioList: ["Age", "Gender", "Occupation"],
                            radioValue: invDemoRadio,
                            setRadioValue: setInvDemoRadio,
                            capsuleBtn: ["AUM", "PAN Count"],
                            capsuleBtnValue: capsuleBtnValue,
                            setCapsuleBtnValue: setCapsuleBtnValue
                        }}
                    />
                    <MultiLineChart
                        xAxisName={"Month"}
                        yAxisName={aumTrendRadio == "AUM" ? "AUM (in crores)" : "PAN Count"}
                        data={revenueData}
                        headerProps={{
                            heading: "AUM Trend Graph",
                            radioList: ["AUM", "PAN Count"],
                            radioValue: aumTrendRadio,
                            setRadioValue: setAumTrendRadio
                        }}
                    />
                </Grid>

            </Box >

        </>
    );
};

export default AUMDashboard;

{/* <InvestorCategory donutData={assetClassData} listData={planModelistArray} radioList={["AUM", "PAN Count"]} />
                        <InvestorDemographyMap />
                        <AssetClass heading={"Asset Class"} donutData={assetClassData} listData={planModelistArray} />
                        <AssetCategory data={SIPAgeingData} radioList={["AUM", "PAN Count"]} />
                        <PlanModeTB30 data={assetClassData} />
                        <DistributorCategory data={data} />
                        <InvestorDemography data={data} />
                        <AUMTrendGraph data={revenueData} /> */}