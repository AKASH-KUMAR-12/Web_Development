import { Grid } from '@mui/material'
import React, { useEffect, useState } from 'react'
import HeaderParent from '../../../utilityComponents/components/HeaderParent'
import Donut from '../../../utilityComponents/charts/Donut'
import VerticalBarChart from '../../../utilityComponents/charts/verticalBarChart'
import axios from 'axios'
import { useSelector } from 'react-redux'
import ScrollingTable from '../../../utilityComponents/Table'


const SchemeDetails = ({ }) => {
    const [rows, setRows] = useState([])
    const investorData = useSelector((state) => state.filterData?.investor)
    const zoneData = useSelector((state) => state.filterData?.zone)
    const stateData = useSelector((state) => state.filterData?.state)
    const assetclassData = useSelector((state) => state.filterData?.assetClass)
    const assetcategoryData = useSelector((state) => state.filterData?.assetCategory)
    const distributorData = useSelector((state) => state.filterData?.distributor)
    const filterSelected = useSelector((state) => state.filterData?.filterSelected)
    useEffect(() => {
        fetchData();
    }, [investorData, zoneData, stateData, assetclassData, assetcategoryData, distributorData])



    const fetchData = async () => {
        const payload =
        {
            "fund": "RMF",
            "zone": zoneData,
            "investor": investorData,
            "query_name": "aum-SchemeDetails",
            "state": stateData,
            "assetclass": assetclassData,
            "assetcategory": assetcategoryData,
            "comment": filterSelected ? "" : "-- "
        }
        const response = await axios.post("/api/getaumData", payload)

        // console.log("scheme details", response.data);
        setRows(response.data);
        return response;
    }
    // console.log(rows);
    const columns = [
        {
            id: 'schemename',
            label: 'Scheme Name',
            //minWidth: 120,
            align: 'center',
        },
        {
            id: 'aggregate_aum',
            label: 'AUM',
            //minWidth: 120,
            align: 'center',
        },

        {
            id: 'aggregate_count',
            label: 'PAN Count',
            //minWidth: 120,
            align: 'center',
        },
    ];


    return (
        <ScrollingTable
            rows={rows}
            columns={columns}
            headerProps={{
                heading: "Scheme Details",
                // dropdownOptions: [{ title: "Top 10" }, { title: "Top 20" }, { title: "Top 50" }]
            }}
        />

    )
}

export default SchemeDetails