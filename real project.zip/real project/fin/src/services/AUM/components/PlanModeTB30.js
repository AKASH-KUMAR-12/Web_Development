import { Box, Grid } from '@mui/material'
import React from 'react'
import HeaderParent from '../../../utilityComponents/components/HeaderParent'
import Donut from '../../../utilityComponents/charts/Donut'


const PlanModeTB30 = ({ data }) => {


    return (
        <></>
        // <Donut
        //     heading="Plan Mode"
        //     radioList={["AUM", "PAN Count"]}
        //     data={data}
        // />

        // <Donut
        //     heading="T30/B30"
        //     radioList={["AUM", "PAN Count"]}
        //     data={data}
        // />


    )
}

export default PlanModeTB30