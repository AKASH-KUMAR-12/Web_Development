import { Grid } from '@mui/material'
import React from 'react'
import HeaderParent from '../../../utilityComponents/components/HeaderParent'
import Donut from '../../../utilityComponents/charts/Donut'


const InvestorCategory = ({ donutData, listData }) => {


    return (

        <Donut
            data={donutData}
            listData={listData}
            headerProps={{
                heading: "Investor Category"
            }}
        />


    )
}

export default InvestorCategory