import { Grid } from '@mui/material'
import React from 'react'
import HeaderParent from '../../../utilityComponents/components/HeaderParent'
import Donut from '../../../utilityComponents/charts/Donut'


const AssetClass = ({ donutData, listData }) => {


    return (

        <Donut
            data={donutData}
            listData={listData}
            headerProps={{
                heading: "Asset Category",
                radioList: ["AUM", "PAN Count"]
            }}
        />

    )
}

export default AssetClass