import { Grid } from '@mui/material'
import React, { useEffect, useState } from 'react'
import HeaderParent from '../../../utilityComponents/components/HeaderParent'
import Donut from '../../../utilityComponents/charts/Donut'
import VerticalBarChart from '../../../utilityComponents/charts/verticalBarChart'
import axios from 'axios'
import { useSelector } from 'react-redux'


const AssetCategory = ({ data }) => {
    // const [data, setData] = useState([])
    // const investorData = useSelector((state) => state.filterData?.investor)
    // const zoneData = useSelector((state) => state.filterData?.zone)
    // const stateData = useSelector((state) => state.filterData?.state)
    // const assetclassData = useSelector((state) => state.filterData?.assetclass)
    // const assetcategoryData = useSelector((state) => state.filterData?.assetcategory)
    // const distributorData = useSelector((state) => state.filterData?.distributor)

    // useEffect(() => {
    //     fetchData();
    // }, [investorData, zoneData, stateData, assetclassData, assetcategoryData, distributorData])



    // const fetchData = async () => {
    //     const payload =
    //     {
    //         "fund": "101",
    //         "zone": zoneData,
    //         "investor": investorData,
    //         "query_name": "AssetCategory",
    //         "state": stateData,
    //         "assetclass": assetclassData,
    //         "assetcategory": assetcategoryData,
    //         "distributor": distributorData,
    //         "order": "DESC"
    //     }
    //     const response = await axios.post("/api/getaumData", payload)

    //     console.log(response.data);
    //     setData(response.data);
    //     return response;
    // }
    return (


        <VerticalBarChart
            xAxisName={"Asset Category"}
            yAxisName={"AUM (in crores)"}
            data={data}
            headerProps={{
                heading: "Asset Category",
                radioList: ["AUM", "PAN Count"]
            }}
        />

    )
}

export default AssetCategory