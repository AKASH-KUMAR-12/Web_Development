import { Box, Grid } from '@mui/material'
import React from 'react'
import HeaderParent from '../../../utilityComponents/components/HeaderParent'
import BarChart from '../../../utilityComponents/charts/BarChart';


const DistributorCategory = ({ data }) => {


    return (

        <BarChart
            data={data}
            headerProps={{
                heading: "Asset Category",
                radioList: ["AUM", "PAN Count"]
            }}
        />

    )
}

export default DistributorCategory