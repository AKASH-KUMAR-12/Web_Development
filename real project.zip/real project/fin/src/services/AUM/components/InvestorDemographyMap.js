import { Grid } from '@mui/material'
import React from 'react'
import HeaderParent from '../../../utilityComponents/components/HeaderParent'
import MapChart from '../../../utilityComponents/charts/MapChart'



const InvestorDemographyMap = () => {


    return (
        <MapChart
            headerProps={{
                heading: "Investor Demography - Location"

            }}
        />
    )
}

export default InvestorDemographyMap