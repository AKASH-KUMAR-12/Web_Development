
import axios from "axios";
export const fetchData = async (payload) => {
    try {
        let response = await axios.post("/api/getaumData", payload);
        return response;
    }
    catch (e) {
        return e;
    }
}

export const fetchInvCatData = async (payload, { radioValue }) => {

    const response = await fetchData(payload);
    let donutData;
    if (radioValue == "AUM") {

        donutData = response.data.map((ele) => {
            return { label: ele.investor_category, value: parseFloat(ele.aggregate_aum).toFixed(2) }
        })
    }
    else if (radioValue == "PAN Count") {
        donutData = response.data.map((ele) => {
            return { label: ele.investor_category, value: ele.aggregate_count }
        })
    }
    return donutData;

}

export const fetchAssetClassData = async (payload) => {

    const response = await fetchData(payload);
    let donutData;
    donutData = response.data.map((ele) => {
        return { label: ele.assetclassnewmcr, value: parseFloat(ele.aggregate_aum).toFixed(2) }
    })
    return donutData;

}

export const fetchPlanModeData = async (payload, { radioValue }) => {

    const response = await fetchData(payload);
    console.log("plan Mode response Data", response.data);
    let donutData;
    if (radioValue == "AUM") {
        donutData = response.data.map((ele) => {
            return { label: ele.planmode, value: parseFloat(ele.aggregate_aum).toFixed(2) }
        })
    }
    else if (radioValue == "PAN Count") {
        donutData = response.data.map((ele) => {
            return { label: ele.planmode, value: ele.aggregate_count }
        })
    }

    return donutData;


}

export const fetchTB30Data = async (payload, { radioValue }) => {

    const response = await fetchData(payload);
    console.log("plan Mode response Data", response.data);
    let donutData;
    if (radioValue == "AUM") {
        donutData = response.data.map((ele) => {
            return { label: ele.terflagfolio, value: parseFloat(ele.aggregate_aum).toFixed(2), valuePosition: "inside" }
        })
    }
    else if (radioValue == "PAN Count") {
        donutData = response.data.map((ele) => {
            return { label: ele.terflagfolio, value: ele.aggregate_count }
        })
    }

    return donutData;


}

export const fetchInvestorDemoData = async (payload, { radioValue, capsuleBtnValue }) => {

    let response = await fetchData(payload)
    console.log("investor response Data", response.data);
    let chartData;
    chartData = response.data.map((ele) => {
        return {
            label: ele[radioValue.toLowerCase()],
            value: capsuleBtnValue == "AUM" ? parseFloat(ele.aggregate_aum / 10000000).toFixed(2) : ele.aggregate_count
        }
    })
    return chartData;

}

export const fetchAssetCategoryData = async (payload, { radioValue }) => {

    let response = await fetchData(payload)
    console.log("asset category response Data", response.data);
    let chartData;

    if (radioValue == "AUM") {
        chartData = response.data.map((ele) => {
            return { label: ele.assetcategorynewmcr, value: parseFloat(ele.aggregate_aum / 10000000).toFixed(2) }
        })
    }
    else if (radioValue == "PAN Count") {
        chartData = response.data.map((ele) => {
            return { label: ele.assetcategorynewmcr, value: ele.aggregate_count }
        })
    }
    return chartData;

}
export const fetchMapData = async (payload) => {
    let response = await fetchData(payload)
    let mapData;
    mapData = response.data.map((ele) => {
        return {
            "id": stateID[ele.final_state],
            "value": parseFloat(ele.aggregate_aum).toFixed(2),
            "color": colorCode[stateZone[ele.final_state]],
            "fontColor": darkFontID.includes(stateID[ele.final_state]) ? "#96967F" : "#e3e2e1"
        }
    })
    return mapData;
}
export const fetchMapTableData = async (payload, { radioValue }) => {
    let response = await fetchData(payload)
    let tableData;
    const tableColumn = {
        "State": "final_state",
        "Region": "zone",
        "City": "final_city"
    }
    tableData = response.data.map((ele) => {
        return {
            [radioValue]: ele[tableColumn[radioValue]],
            "AUM": parseFloat(ele.aggregate_aum / 10000000).toFixed(2),
            "PAN Count": ele.aggregate_count,
        }
    })
    return tableData;
}
export const fetchDefaultFilterData = async () => {
    const payload = {
        page: "aum",
        fund: "RMF"
    }
    const response = await axios.post("/api/getfilters", payload);
    console.log("plan Mode response Data", response.data);
    const resData = response.data[0];
    let deafultFilterData = {
        "assetClass": resData.assetclassnewmcr,
        "assetCategory": resData.assetcategorynewmcr,
    }
    console.log(deafultFilterData)
    return deafultFilterData;
}
const stateID = {
    "KARNATAKA": "017",
    "DAMAN AND DIU": "009",
    "OTHERS": "000",
    "DELHI": "010",
    "LADAKH": "",
    "RAJASTHAN": "029",
    "MANIPUR": "022",
    "ANDHRA PRADESH": "002",
    "WEST BENGAL": "035",
    "MADHYA PRADESH": "020",
    "KERALA": "018",
    "GUJARAT": "012",
    "TELANGANA": "036",
    "ANDAMAN AND NICOBAR": "001",
    "BIHAR": "005",
    "GOA": "011",
    "CHANDIGARH": "006",
    "TRIPURA": "032",
    "DADRA AND NAGAR HAVELI": "008",
    "NAGALAND": "025",
    "JHARKHAND": "016",
    "ASSAM": "004",
    "PUNJAB": "028",
    "JAMMU AND KASHMIR": "015",
    "PUDUCHERRY": "027",
    "ODISHA": "026",
    "MEGHALAYA": "023",
    "MIZORAM": "024",
    "MAHARASHTRA": "021",
    "ARUNACHAL PRADESH": "003",
    "CHHATTISGARH": "007",
    "TAMIL NADU": "031",
    "SIKKIM": "030",
    "LAKSHADWEEP": "019",
    "HARYANA": "013",
    "UTTAR PRADESH": "033",
    "UTTARAKHAND": "034",
    "HIMACHAL PRADESH": "014"
}
const stateZone = {
    "KARNATAKA": "South",
    "ANDHRA PRADESH": "South",
    "PUDUCHERRY": "South",
    "KERALA": "South",
    "TELANGANA": "South",
    "TAMIL NADU": "South",
    "LAKSHADWEEP": "South",

    "MAHARASHTRA": "West",
    "DAMAN AND DIU": "West",
    "GUJARAT": "West",
    "RAJASTHAN": "West",
    "GOA": "West",
    "MADHYA PRADESH": "West",
    "DADRA AND NAGAR HAVELI": "West",

    "DELHI": "North",
    "JAMMU AND KASHMIR": "North",
    "PUNJAB": "North",
    "HARYANA": "North",
    "UTTARAKHAND": "North",
    "HIMACHAL PRADESH": "North",
    "UTTAR PRADESH": "North",
    "CHANDIGARH": "North",
    "LADAKH": "North",

    "WEST BENGAL": "East",
    "ANDAMAN AND NICOBAR": "East",
    "BIHAR": "East",
    "CHHATTISGARH": "East",
    "MANIPUR": "East",
    "TRIPURA": "East",
    "NAGALAND": "East",
    "JHARKHAND": "East",
    "ASSAM": "East",
    "ODISHA": "East",
    "MEGHALAYA": "East",
    "MIZORAM": "East",
    "ARUNACHAL PRADESH": "East",
    "SIKKIM": "East",

    "OTHERS": "None",
}
const colorCode = {
    "North": "#61c99b",
    "South": "#ba87ed",
    "East": "#5abec7",
    "West": "#4990f0"
}
//Labels that should have black font
const darkFontID = ["001", "011", "019", "027"]