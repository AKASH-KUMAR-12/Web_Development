
import React, { useEffect, useState } from 'react'
import FusionCharts from "fusioncharts";
import charts from "fusioncharts/fusioncharts.charts";
import ReactFusioncharts from "react-fusioncharts";
import { Box, Grid } from '@mui/material';
import HeaderParent from "../../../utilityComponents/components/HeaderParent";
import { useDispatch, useSelector } from 'react-redux';
import { clearAumFilterData, clearFilterData, setAssetCategoryData, setAssetClassData, setAumData, setFilterSelected, setInvestorData } from '../../../reduxStore/filterReducer';
import { ArrowBack } from '@mui/icons-material';
import { useLocation } from 'react-router-dom';
import { clearFlowFilterData, setFlowAssetClassData, setFlowFilterSelected, setFlowPageFilters, setFlowSchemeNameData, setFlowTransactionSourceData, setFlowTransactionTypeData } from '../../../reduxStore/flowReducer';
charts(FusionCharts);

let finalArray = [];
const Donut = ({ data, count, listData, cardSelected, fetchAPI, fetchPayload, headerProps, xs, md }) => {
  const location = useLocation();
  let page = location.pathname;


  let texts;
  let pantext = `<b>$label</b> <br/><b>$value </b>`
  let aumtext = `<b>$label</b> <br/><b>₹$value Cr</b>`
  let datas
  if (count == 'AUM') {
    datas = data.map((item) => ({
      label: item.label,
      value: (parseFloat(item.value) / 10000000).toFixed(2)
    }))
    texts = aumtext
  }

  else {
    datas = data;
    texts = pantext
  }

  let response;
  const [apiData, setApiData] = useState({});
  const [showBackBtn, setShowBackBtn] = useState(false);
  const dispatch = useDispatch();
  const investorData = useSelector((state) => state.filterData?.investor)
  const zoneData = useSelector((state) => state.filterData?.zone)
  const stateData = useSelector((state) => state.filterData?.state)
  const assetclassData = useSelector((state) => state.filterData?.assetClass)
  const assetcategoryData = useSelector((state) => state.filterData?.assetCategory)
  const filterSelected = useSelector((state) => state.filterData?.filterSelected)
  // console.log("*******************************************************************************", apiData);

  useEffect(() => {
    setApiData(datas)
    // if (headerProps.heading == "Investor Category") { fetchInvCatData() }
    // if (headerProps.heading == "Asset Class") { fetchAssetClassData() }
    // if (headerProps.heading == "Plan Mode") { fetchPlanModeData() }
    // if (headerProps.heading == "T30/B30") { fetchTB30Data() }
    fetchingAPI();

  },
    [investorData, zoneData, assetcategoryData, assetclassData, headerProps.radioValue, cardSelected])
  useEffect(() => {
    !filterSelected && setShowBackBtn(false);
  }, [filterSelected])

  const fetchingAPI = async () => {
    if (fetchAPI) {
      setApiData(await fetchAPI(fetchPayload, { radioValue: headerProps.radioValue, cardSelected }))
    }
  }
  console.log(headerProps.heading, ">>>>", apiData)


  // const fetchInvCatData = async () => {
  //   const payload =
  //   {
  //     "fund": "RMF",
  //     "zone": zoneData,
  //     "investor": investorData,
  //     "query_name": "aum-InvestorCategory",
  //     "state": stateData,
  //     "assetclass": assetclassData,
  //     "assetcategory": assetcategoryData,
  //     "comment": filterSelected ? "" : "-- "
  //   }
  //   const response = await fetchData(payload);
  //   let donutData;
  //   if (headerProps.radioValue == "AUM") {

  //     donutData = response.data.map((ele) => {
  //       return { label: ele.investor_category, value: parseFloat(ele.aggregate_aum).toFixed(2) }
  //     })
  //   }
  //   else if (headerProps.radioValue == "PAN Count") {
  //     donutData = response.data.map((ele) => {
  //       return { label: ele.investor_category, value: ele.aggregate_count }
  //     })
  //   }
  //   setApiData(donutData);
  //   return donutData;

  // }

  // const fetchAssetClassData = async () => {
  //   const payload =
  //   {
  //     "fund": "RMF",
  //     "zone": zoneData,
  //     "investor": investorData,
  //     "query_name": "aum-AssetClass",
  //     "state": stateData,
  //     "assetclass": assetclassData,
  //     "assetcategory": assetcategoryData,
  //     "comment": filterSelected ? "" : "-- "
  //   }
  //   const response = await fetchData(payload);
  //   let donutData;
  //   // console.log(">>>>>>>>>>>>>>>>>>>>>>>", response.data)
  //   donutData = response.data.map((ele) => {
  //     return { label: ele.assetclassnewmcr, value: parseFloat(ele.aggregate_aum).toFixed(2) }
  //   })

  //   setApiData(donutData);
  //   return donutData;

  // }

  // const fetchPlanModeData = async () => {
  //   // console.log("??????????????????????????????????????????????????????")
  //   const payload =
  //   {
  //     "fund": "RMF",
  //     "zone": zoneData,
  //     "investor": investorData,
  //     "query_name": "aum-PlanMode",
  //     "state": stateData,
  //     "assetclass": assetclassData,
  //     "assetcategory": assetcategoryData,
  //     "comment": filterSelected ? "" : "-- "
  //   }
  //   const response = await fetchData(payload);
  //   console.log("plan Mode response Data", response.data);
  //   let donutData;
  //   if (headerProps.radioValue == "AUM") {
  //     donutData = response.data.map((ele) => {
  //       return { label: ele.planmode, value: parseFloat(ele.aggregate_aum).toFixed(2) }
  //     })
  //   }
  //   else if (headerProps.radioValue == "PAN Count") {
  //     donutData = response.data.map((ele) => {
  //       return { label: ele.planmode, value: ele.aggregate_count }
  //     })
  //   }
  //   setApiData(donutData);
  //   return donutData;


  // }

  // const fetchTB30Data = async () => {
  //   // console.log("??????????????????????????????????????????????????????")
  //   const payload =
  //   {
  //     "fund": "RMF",
  //     "zone": zoneData,
  //     "investor": investorData,
  //     "query_name": "aum-TerFlag",
  //     "state": stateData,
  //     "assetclass": assetclassData,
  //     "assetcategory": assetcategoryData,
  //     "comment": filterSelected ? "" : "-- "
  //   }
  //   const response = await fetchData(payload);
  //   console.log("plan Mode response Data", response.data);
  //   let donutData;
  //   if (headerProps.radioValue == "AUM") {
  //     donutData = response.data.map((ele) => {
  //       return { label: ele.terflagfolio, value: parseFloat(ele.aggregate_aum).toFixed(2) }
  //     })
  //   }
  //   else if (headerProps.radioValue == "PAN Count") {
  //     donutData = response.data.map((ele) => {
  //       return { label: ele.terflagfolio, value: ele.aggregate_count }
  //     })
  //   }
  //   setApiData(donutData);
  //   return donutData;


  // }



  // if(count=='AUM'){
  //   texts=aumtext
  // }
  // else{
  //   texts=pantext
  // }
  const dataSource = {
    chart: {
      theme: "candy",
      chartTopMargin: 80,
      chartLeftMargin: -70,
      chartBottomMargin: 10,
      plottooltext: texts,
      // chartRightMargin: 0,
      use3DLighting: false,
      showShadow: false,
      doughnutRadius: 70,
      pieRadius: 90,
      showToolTip: "1",
      interactiveLegend: "1",
      legendBorderColor: "#ffffff",
      xAxisNameFontColor: "#909090",
      yAxisNameFontColor: "#909090",
      "legendItemFont": "Roboto",
      drawCustomLegendIcon: "1",
      valuePosition: "inside",
      legendIconSides: "4",
      legendPosition: window.innerWidth <= 640 ? "bottom" : "right-bottom",
      legendIconStartAngle: "45",
      bgcolor: "#ffffff",
      showLegend: "1",
      showborder: "0",
      palettecolors: "#2057A6,#69B8F4,#8ED8B7,#82C7ED,#8FABD3,#BA87ED",
      legendPosition: "bottom-right",
      "legendBgColor": "#fff",
      "legendBorderAlpha": "0",
      legendWidth: "200",
      // legendShadow: 0,
      showValues: 0,
      legendNumRows: 6,
    },
    data: apiData,

  };
  return (

    <Grid item xs={xs || 12} md={md || 12} sx={{
      bgcolor: "#fff",
      marginTop: "20px",
      borderRadius: '8px',
      alignItems: "center",
      borderRadius: "8px",
      paddingTop: ".1rem",
      boxShadow: 6
    }}>
      <HeaderParent
        headerProps={headerProps}
      />
      <Grid container sx={{ bgcolor: "white", height: "auto", borderRadius: "8px" }} >
        <Grid item xs={12} md={listData ? 6 : 12} sx={{ position: "relative", padding: ".5rem", margin: ".5rem", marginRight: 0, paddingRight: 0, height: "16rem" }}>
          <button onClick={() => {

            switch (headerProps.heading) {
              case 'Investor Category': {
                dispatch(clearAumFilterData("investor"))
                // dispatch(setFlowPageFilters({ ...flowPageFilters, transactionType: false }))
                break
              }
              case "Asset Class": {
                dispatch(clearAumFilterData("assetClass"))
                // dispatch(setFlowPageFilters({ ...flowPageFilters, assetClass: false }))
                break
              }
            }
            // dispatch(setFilterSelected({ filterSelected: false }))

            setShowBackBtn(false);
          }}
            style={{ position: "absolute", zIndex: 5, left: -3, height: "fit-content", display: showBackBtn ? "block" : "none", cursor: "pointer", borderColor: "#fff", paddingInline: ".4rem" }}><ArrowBack fontSize='small' /></button>
          <ReactFusioncharts
            sx={{ position: "absolute", top: "50%", left: "50%" }}
            type="doughnut2d"
            width="98%"
            height="90%"
            dataFormat="JSON"
            dataSource={dataSource}
            events={{
              'slicingStart': function (eventObj, args) {
                // if (localStorage.getItem("Finstax:AumDefaultFilter")) {
                //   const localData = JSON.parse(localStorage.getItem("Finstax:AumDefaultFilter"));
                //   dispatch(setAssetClassData({ assetclass: localData["AssetClass"] }))
                //   dispatch(setAssetCategoryData({ assetcategory: localData["AssetCategory"] }))
                // }
                dispatch(setFilterSelected({ filterSelected: true }))

                switch (headerProps.heading) {
                  case 'Investor Category': {
                    dispatch(setAumData({ title: "investor", value: [args.data.id] }))
                    break
                  }
                  case "Asset Class": {
                    dispatch(setAumData({ title: "assetClass", value: [args.data.id] }))
                    break
                  }
                }
                setShowBackBtn(true);
              }
            }}
          />
        </Grid>
        {listData &&
          <Grid item md={5.6} xs={12} sx={{ margin: ".5rem auto", height: "16rem" }}>
            <Box sx={{ height: "70%", width: "90%", padding: "1rem", margin: "1rem auto", display: "flex", alignItems: "center", justifyContent: "center", borderLeft: { xs: "0px", md: "2px solid #b9b9b9" } }}>
              <Box sx={{
                height: 'auto',
                borderRadius: '8px',
                display: 'flex',
                width: '85%',
                background: "linear-gradient(170.95deg, rgba(105, 184, 244, 0.1) 1.31%, rgba(255, 255, 255, 0.1) 67.68%)",
                padding: '2rem 1.2rem 2rem 1.2rem',
                // marginLeft: "1rem",
                boxShadow: 4,
              }}>
                <ul>
                  {
                    listData.map((listEle, key) => (

                      <li key={key} style={{
                        fontFamily: 'Roboto',
                        fontSize: "0.85rem",
                        fontWeight: '400',
                        lineHeight: '28px',
                        letterSpacing: '0em',
                        textAlign: 'left',
                        color: '#333333CC',
                      }}>{listEle}</li>
                    ))
                  }
                </ul>
              </Box>
            </Box>

          </Grid>}
      </Grid>
    </Grid>
  )
}

export default Donut;