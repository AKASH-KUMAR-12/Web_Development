import { Box, Grid } from "@mui/material";
import FusionCharts from "fusioncharts";
import charts from "fusioncharts/fusioncharts.charts";
import ReactFusioncharts from "react-fusioncharts";
import HeaderParent from "../../../utilityComponents/components/HeaderParent";
import { useDispatch, useSelector } from "react-redux";
import { useEffect, useState } from "react";
import { setAssetCategoryData, setAssetClassData, clearFilterData, setAumData } from "../../../reduxStore/filterReducer";
import axios from "axios";

// Resolves charts dependancy
charts(FusionCharts);
export default function MultiLineChart({ data, xAxisName, yAxisName, headerProps }) {
    let response;
    const [apiData, setApiData] = useState({});
    const [firstRenderFlag, setFirstRenderFlag] = useState(true);
    const dispatch = useDispatch();
    const investorData = useSelector((state) => state.filterData?.investor)
    const zoneData = useSelector((state) => state.filterData?.zone)
    const stateData = useSelector((state) => state.filterData?.state)
    const assetclassData = useSelector((state) => state.filterData?.assetClass)
    const assetcategoryData = useSelector((state) => state.filterData?.assetCategory)
    const distributorData = useSelector((state) => state.filterData?.distributor)
    const filterSelected = useSelector((state) => state.filterData?.filterSelected)


    useEffect(() => {
        fetchData();
    },
        [headerProps.radioValue])


    const fetchData = async () => {
        const payload =
        {
            "fund": "RMF",
            "zone": zoneData,
            "investor": investorData,
            "query_name": "aum-timeseries",
            "state": stateData,
            "assetclass": assetclassData,
            "assetcategory": assetcategoryData,
            "comment": filterSelected ? "" : "-- "
        }
        const month = ["JAN 23", "FEB 23", "MAR 23", "APR 23", "MAY 23", "JUN 23", "JUL 23", "AUG 23", "SEPT 23", "OCT 23", "NOV 23", "DEC 23"];
        response = await axios.post("/api/getaumData", payload)
        console.log("multi series response Data", response.data);
        if (headerProps.radioValue == "AUM") {
            let aumForecastData = response.data.data.filter((ele) => (
                new Date(ele.batchclosedt).getFullYear() === new Date().getFullYear())
            ).map((ele) => {
                // if (new Date(ele.batchclosedt).getMonth() >= new Date().getMonth()) {
                return {
                    label: month[new Date(ele.batchclosedt).getMonth()],
                    value: parseFloat(ele.aum).toFixed(2),
                    month: new Date(ele.batchclosedt).getMonth(),
                    dashed: new Date(ele.batchclosedt).getMonth() >= new Date().getMonth() ? "1" : "0",
                    color: new Date(ele.batchclosedt).getMonth() >= new Date().getMonth() ? "#15CC7A" : "#0f65b1",
                    displayValue: new Date(ele.batchclosedt).getMonth() > new Date().getMonth() ? `\nForcecast \n${parseFloat(ele.aum / 1000).toFixed(2)}K` : "",

                }
                // }
            })
            let aumCurrentData = response.data.data.filter((ele) => (
                new Date(ele.batchclosedt).getFullYear() === new Date().getFullYear() &&
                new Date(ele.batchclosedt).getMonth() <= new Date().getMonth()
            )
            ).map((ele) => {
                return { label: month[new Date(ele.batchclosedt).getMonth()], value: parseFloat(ele.aum).toFixed(2), month: new Date(ele.batchclosedt) }
            })
            let customSort = (a, b) => a.month - b.month;
            aumForecastData = aumForecastData.sort(customSort);
            aumCurrentData = aumCurrentData.sort(customSort);
            console.log(aumCurrentData)
            setApiData({ currentData: aumForecastData, forecastData: aumForecastData })
        }
        else if (headerProps.radioValue == "PAN Count") {
            let countData = response.data.data.filter((ele) => (
                new Date(ele.batchclosedt).getFullYear() === new Date().getFullYear() &&
                (new Date(ele.batchclosedt).getMonth() < new Date().getMonth())
            )
            ).map((ele) => {
                // if (new Date(ele.batchclosedt).getMonth() >= new Date().getMonth()) {
                return { label: month[new Date(ele.batchclosedt).getMonth()], value: ele.pan_count, month: new Date(ele.batchclosedt) }
                // }
            })
            let customSort = (a, b) => a.month - b.month;
            countData = countData.sort(customSort);

            setApiData({ currentData: countData })
        }
        console.log(response.data);

        // setAumDefaultFilter(response.data);
        if (firstRenderFlag || filterSelected == false) {
            dispatch(setAumData({ title: "assetCategory", value: response.data.assetcategorynewmcr }))
            dispatch(setAumData({ title: "assetClass", value: response.data.assetclassmewmcr }))
            localStorage.setItem("Finstax:AumDefaultFilter", JSON.stringify(
                { "assetClass": response.data.assetcategorynewmcr, "assetCategory": response.data.assetclassmewmcr }))
        }
        setFirstRenderFlag(false);
        return response;
    }

    const dataSource = {
        chart: {
            // theme: "fusion",
            // xaxisname: xAxisName,
            // yaxisname: `${headerProps.radioValue == "AUM" ? "AUM (in crores)" : "PAN Count"}`,
            // xAxisNameFont: "Roboto",
            // yAxisNameFont: "Roboto",
            // xAxisNameFontSize: "12",
            // yAxisNameFontSize: "12",
            // xAxisNameFontColor: "#909090",
            // yAxisNameFontColor: "#909090",
            // labelFontSize: "10",
            // // numbersuffix: "k",
            // yAxisValueFontSize: "10",
            // bgColor: "#FFFFFF",
            // plotFillColor: "#2057A6",
            // "bgAlpha": "50",
            // "showcanvasborder": "0",
            // "showxaxisline": "1",
            // "showyaxisline": "1",
            // "lineColor": "#2057a6",
            // numDivLines: 11,
            // divLineColor: "#d3d4d4",
            // setadaptiveymin: "1",
            // theme: "fusion",
            // "anchorBgColor": "#2057a6",
            // "showAlternateHGridColor": "0",
            // "showPlotBorder": "1",
            // "drawFullAreaBorder": "0",
            // "plotBorderThickness": "2",
            // chartLeftMargin: 0,
            // chartBottomMargin: 10,
            // "showValues": "1",
            // plottooltext: "$label: $value Cr",
            // showLegend: 0,
            // showLabels: 1,
            xaxisname: xAxisName,
            yaxisname: yAxisName,
            xAxisNameFont: "Roboto",
            yAxisNameFont: "Roboto",
            xAxisNameFontSize: "12",
            yAxisNameFontSize: "12",
            xAxisNameFontColor: "#909090",
            yAxisNameFontColor: "#909090",
            labelFontSize: "10",
            yAxisValueFontSize: "10",
            bgColor: "#FFFFFF",
            plotFillColor: "#2057A6",
            "bgAlpha": "50",
            "showcanvasborder": "0",
            "showxaxisline": "1",
            "showyaxisline": "1",
            "lineColor": "#2057a6",
            numDivLines: 11,
            divLineColor: "#d3d4d4",
            setadaptiveymin: "1",
            theme: "fusion",
            "anchorBgColor": "#2057a6",
            "showAlternateHGridColor": "0",
            "showPlotBorder": "1",
            "drawFullAreaBorder": "0",
            "plotBorderThickness": "2",
            chartLeftMargin: 0,
            chartBottomMargin: 10,
            "showValues": "1",
            plottooltext: "$label: $value Cr",
            valueFontSize: 10,
        },
        data: apiData.currentData
        // categories: [
        //     {
        //         category: [
        //             {
        //                 label: "JAN 23",
        //             },
        //             {
        //                 label: "FEB 23",
        //             },
        //             {
        //                 label: "MAR 23",
        //             },
        //             {
        //                 label: "APR 23",
        //             },
        //             {
        //                 label: "MAY 23",
        //             },
        //             {
        //                 label: "JUN 23",
        //             },
        //             {
        //                 label: "JULY 23"
        //             },
        //             {
        //                 label: "AUG 23",
        //             },
        //             {
        //                 label: "SEP 23",
        //             },
        //             {
        //                 label: "OCT 23"
        //             },
        //             {
        //                 label: "NOV 23"
        //             },
        //             {
        //                 label: "DEC 23"
        //             },

        //         ]
        //     }
        // ],
        // dataset: [
        //     {
        //         seriesname: "Current",

        //         anchorBgColor: "#0FB156",
        //         showValues: 0,
        //         data: apiData.currentData
        //     },
        //     {
        //         seriesname: "Forecast",
        //         dashed: "1",
        //         showValues: 0,
        //         color: "#15CC7A",

        //         data: apiData.forecastData
        //     },


        // ]
    };



    return (
        <>
            <Grid item xs={12} sx={{
                bgcolor: "#fff",
                marginTop: "20px",
                borderRadius: '8px',
                alignItems: "center",
                borderRadius: "8px",
                paddingTop: ".1rem",
                boxShadow: 6
            }}>
                <HeaderParent
                    headerProps={headerProps}
                />
                <Box sx={{ position: "relative", padding: ".5rem", bgcolor: "white", height: "16rem", borderRadius: "8px" }} >
                    <ReactFusioncharts style={{ position: "absolute", top: "50%", left: "50%" }}
                        type="line"
                        width="98%"
                        height="95%"
                        dataFormat="JSON"
                        dataSource={dataSource}
                    />
                </Box>
            </Grid>

        </>
    );

}
