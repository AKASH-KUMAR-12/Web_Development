import FusionCharts from "fusioncharts";
import charts from "fusioncharts/fusioncharts.charts";
import ReactFusioncharts from "react-fusioncharts";
import React, { useState } from "react";
import { Box, Grid } from "@mui/material";
import HeaderParent from "../../../utilityComponents/components/HeaderParent";
import { useEffect } from "react";
import { useSelector } from "react-redux";

// Resolves charts dependancy


const BarChart = ({ data, xAxisName, yAxisName, cardSelected, count, fetchAPI, fetchPayload, height, md, xs, headerProps, sx }) => {
  const [apiData, setApiData] = useState({});
  const investorData = useSelector((state) => state.filterData?.investor)
  const zoneData = useSelector((state) => state.filterData?.zone)
  const stateData = useSelector((state) => state.filterData?.state)
  const assetclassData = useSelector((state) => state.filterData?.assetClass)
  const assetcategoryData = useSelector((state) => state.filterData?.assetCategory)
  const filterSelected = useSelector((state) => state.filterData?.filterSelected)
  useEffect(() => {
    setApiData(datas)
    fetchingAPI();
  }, [headerProps.radioValue, investorData, assetclassData, zoneData, assetcategoryData, stateData, cardSelected])

  const fetchingAPI = async () => {
    if (fetchAPI) {
      setApiData(await fetchAPI(fetchPayload, { cardSelected }));
    }
  }
  console.log(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>", apiData)
  let texts;
  let pantext = `$label: $value`
  let aumtext = `$label: ₹$value Cr`
  let datas
  // if (count == 'AUM') {
  datas = data.map((item) => {
    if (item.value < 0) {
      return ({
        color: "#F88787",
        label: item.label,
        value: (parseFloat(item.value)).toFixed(2)

      })
    }
    else {
      return ({
        label: item.label,
        value: (parseFloat(item.value)).toFixed(2)

      })
    }
  })
  //   texts = aumtext
  // }

  // else {
  //   datas = data;
  //   texts = pantext
  // }

  console.log(datas)
  charts(FusionCharts);
  const dataSource = {

    chart: {
      "theme": "fusion",
      xAxisName: xAxisName,
      yAxisName: yAxisName,
      xAxisNameFont: "Roboto",
      yAxisNameFont: "Roboto",
      xAxisNameFontSize: "12",
      yAxisNameFontSize: "12",
      xAxisLineColor: "#969696",
      yAxisLineColor: "#969696",
      labelFontSize: "10",
      yAxisValueFontSize: "10",
      plotSpacePercent: 50,
      plottooltext: texts,
      bgcolor: "#FFFFFF",
      "showxaxisline": "0",
      "showyaxisline": "1",
      color: "#FFFFFF",
      patterBgColor: "#FFFFFF",
      theme: 'fusion',
      barCategoryGap: 1,
      "chartBottomMargin": "10",
      pallete: 5,
      divLineColor: "#00080a",
      animation: 0,
      drawCrossLine: 1,
      crossLineAnimation: 0,
      // plottooltext: "$label: $value Cr",
      divLineColor: "#00080a",
      showBorder: false,
      palettecolors: "#2057A6,#69B8F4,#8ED8B7,#82C7ED,#8FABD3,#BA87ED",
      toolTipFontSize: 6
    },
    "data": apiData
  }

  return (
    <Grid item xs={xs || 12} md={md || 12} sx={{
      bgcolor: "#fff",
      marginTop: "20px",
      borderRadius: '8px',
      alignItems: "center",
      borderRadius: "8px",
      paddingTop: ".1rem",
      boxShadow: 6,
      ...sx
    }}>
      <HeaderParent
        headerProps={headerProps}
      />
      <Box sx={{ position: "relative", padding: ".5rem", bgcolor: "white", height: height || "16rem", borderRadius: "8px" }} >
        <ReactFusioncharts style={{ position: "absolute", top: "50%", left: "50%" }}
          type="bar2d"
          width="98%"
          height="95%"
          dataFormat="JSON"
          dataSource={dataSource}
        />
      </Box>
    </Grid>

  );
}

export default BarChart