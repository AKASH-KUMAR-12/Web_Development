import * as React from 'react';
import { styled } from '@mui/material/styles';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell, { tableCellClasses } from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import { TableFooter, TablePagination } from '@mui/material';
import { useEffect } from 'react';

const StyledTableCell = styled(TableCell)(({ theme }) => ({
    [`&.${tableCellClasses.head}`]: {
        backgroundColor: "#2057A6",
        color: theme.palette.common.white,
    },
    [`&.${tableCellClasses.body}`]: {
        fontSize: '.8rem',
    },
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
    '&:nth-of-type(odd)': {
        backgroundColor: "#f4f9ff",
    },
    '&:last-child td, &:last-child th': {
        border: 0,
    },
}));

function createData(region, inflow, panCount) {
    return { region, inflow, panCount };
}

const rows = [
    createData('North', "₹ 12.66 Cr", "12,271"),
    createData('South', "₹ 19.99 Cr", "10,660"),
    createData('East', "₹ 8.13 Cr", "10,580"),
    createData('West', "₹ 46.66 Cr", "26,911"),
    createData('Others', "₹ 5.33 Cr", "1,492"),

];

export default function MapTable({ rows, columns }) {
    const [page, setPage] = React.useState(0);
    const [rowsPerPage, setRowsPerPage] = React.useState(5);

    const handleChangePage = (event, newPage) => {
        setPage(newPage);
    };

    const handleChangeRowsPerPage = (event) => {
        setRowsPerPage(+event.target.value);
        setPage(0);
    };
    useEffect(() => {
        setPage(0);
    }, [columns])

    console.log(rows, columns)
    return (
        <Paper elevation={8} sx={{ width: "95%", margin: "0px auto", overflow: 'scroll', maxHeight: 300, borderBottom: 'none', boxShadow: 4, borderRadius: "5px", }}>
            <TableContainer
                // sx={{ maxWidth: "95%", marginInline: 2, boxShadow: "0px 1px 1px 1px rgba(0,0,0,0.52)" }}
                sx={{
                    maxHeight: 200, borderBottom: 'none', maxWidth: "100%", marginInline: 0, borderRadius: "5px", boxShadow: 0,
                    "&::-webkit-scrollbar": {
                        width: 10
                    },
                    "&::-webkit-scrollbar-track": {
                        backgroundColor: "#dee6f2"
                    },
                    "&::-webkit-scrollbar-thumb": {
                        backgroundColor: "#2057a6",
                        borderRadius: 2
                    }
                }}
            >
                <Table stickyHeader aria-label="sticky table" size="small">
                    <TableHead>
                        <TableRow>
                            <StyledTableCell style={{ fontSize: ".8rem", width: "12px" }}>{columns[0]}</StyledTableCell>
                            <StyledTableCell style={{ fontSize: ".8rem" }} align="center">{columns[1]}</StyledTableCell>
                            <StyledTableCell style={{ fontSize: ".8rem" }} align="center">{columns[2]}</StyledTableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody >
                        {(rowsPerPage > 0
                            ? rows.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                            : rows
                        ).map((row, i) => (
                            <StyledTableRow key={i} >
                                <StyledTableCell component="th" scope="row">
                                    {row[columns[0]]}
                                </StyledTableCell>
                                <StyledTableCell align="center">{row[columns[1]]}</StyledTableCell>
                                <StyledTableCell align="center">{row[columns[2]]}</StyledTableCell>

                            </StyledTableRow>
                        ))}
                    </TableBody>
                </Table>
            </TableContainer>
            <TablePagination
                sx={{ "& .MuiTablePagination-toolbar": { padding: 0, paddingRight: "3rem" } }}
                labelRowsPerPage="Rows Per Page"
                component="div"
                rowsPerPageOptions={[]}
                count={rows.length}
                rowsPerPage={rowsPerPage}
                page={page}
                onPageChange={handleChangePage}
                onRowsPerPageChange={handleChangeRowsPerPage}
            />
        </Paper>
    );
}