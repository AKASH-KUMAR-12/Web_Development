import { Box, Tab,Typography } from '@mui/material'
import React, { useEffect, useRef, useState } from 'react'
import { models } from "powerbi-client"
import { TabContext, TabList, TabPanel } from '@mui/lab';
import { PowerBIEmbed } from 'powerbi-client-react';
import axios from 'axios';
import './style.css'
function CustomTabPanel(props) {
    const { children, value, index, ...other } = props;

    return (
        <div
            role="tabpanel"
            hidden={value !== index}
            id={`simple-tabpanel-${index}`}
            aria-labelledby={`simple-tab-${index}`}
            {...other}
        >
            {value === index && (
                <Box sx={{ p: 3 }}>
                    <Typography>{children}</Typography>
                </Box>
            )}
        </div>
    );
}



function a11yProps(index) {
    return {
        id: `simple-tab-${index}`,
        'aria-controls': `simple-tabpanel-${index}`,
    };
}

let reportNames = [
    {
        label: 'AMC vs Industry',
        value: 'marketshare',
        reportid: '6d337e73-02cc-4cda-85e5-47980291f214',
        embedUrl: 'https://app.powerbi.com/reportEmbed?reportId=6d337e73-02cc-4cda-85e5-47980291f214&groupId=me',
    },
    {
        label: 'AUM',
        value: 'aum',
        reportid: '12f96d72-2756-4864-b2ad-689a338f2320',
        embedUrl: 'https://app.powerbi.com/reportEmbed?reportId=12f96d72-2756-4864-b2ad-689a338f2320&groupId=me'
    },
    {
        label: 'Net Sales',
        value: 'netsales',
        reportid: '2faa544c-2bec-445f-a5b6-abdc02076f28',
        embedUrl: 'https://app.powerbi.com/reportEmbed?reportId=2faa544c-2bec-445f-a5b6-abdc02076f28&groupId=me'
    },
    {
        label: 'SIP',
        value: 'sip',
        reportid: '45e33428-b81d-42c1-a2b0-060747877ae4',
        embedUrl: 'https://app.powerbi.com/reportEmbed?reportId=45e33428-b81d-42c1-a2b0-060747877ae4&groupId=me'
    },
    {
        label: 'ETF',
        value: 'etf',
        reportid: '255a9b18-8e17-4a39-a55d-80bf3165b688',
        embedUrl: 'https://app.powerbi.com/reportEmbed?reportId=255a9b18-8e17-4a39-a55d-80bf3165b688&groupId=me'
    }
]


const AMCAnalytics = () => {
    const [value, setValue] = React.useState('etf');
    const embeddingContainer = useRef(null)
    const [accessToken, setAccessToken] = useState("");
    const handleChange = (event, newValue) => {
        setValue(newValue);
        console.log(newValue);
    }
    useEffect(() => {

        const fetchTokenEveryHour = () => {
            fetchData();
            const oneHour = 60 * 60 * 1000;
            setTimeout(fetchTokenEveryHour, oneHour);
        };
        fetchTokenEveryHour();
    }, []);

    const fetchData = () => {

        axios.get('/api/fetchToken')

            .then((response) => {
                console.log("The required resposne", response);
                setAccessToken(response.data.res.token);

            })

            .catch((error) => {

                console.error('Error fetching token:', error);

            });

    };

    return (

        <Box>
                <Box sx={{ width: '97%', boxShadow: 6, margin: "1rem auto", borderRadius: ".5rem", }}>
                    <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>


                        <TabContext value={value}>
                            <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
                                <TabList onChange={handleChange} aria-label="lab API tabs example">
                                    {
                                        reportNames.map((item, index) => {
                                            return (
                                                <Tab label={item.label} value={item.value} />
                                            )
                                        })
                                    }
                                </TabList>
                            </Box>
                            {
                                reportNames.map((item, index) => {
                                    return (
                                        <TabPanel value={item.value} >

                                            <div
                                                style={{
                                                    justifyItems: "center",
                                                    height: "95vh",
                                                }}
                                            >
                                                <PowerBIEmbed
                                                    embedConfig={{
                                                        type: 'report',
                                                        id: `${item.reportid}`,
                                                        embedUrl: `${item.embedUrl}`,
                                                        accessToken: `${accessToken}`,
                                                        tokenType: models.TokenType.Aad,
                                                        settings: {
                                                            panes: {
                                                                filters: {
                                                                    expanded: false,
                                                                    visible: false
                                                                }
                                                            },
                                                            background: models.BackgroundType.Transparent,
                                                        }
                                                    }}

                                                    eventHandlers={
                                                        new Map([
                                                            ['loaded', function () { console.log('Report loaded'); }],
                                                            ['rendered', function () { console.log('Report rendered'); }],
                                                            ['error', function (event) { console.log(event.detail); }],
                                                            ['visualClicked', () => console.log('visual clicked')],
                                                            ['pageChanged', (event) => console.log(event)],
                                                        ])
                                                    }

                                                    cssClassName={"Embed-container"}

                                                    getEmbeddedComponent={(embeddedReport) => {
                                                        console.log(embeddedReport);
                                                        window.report = embeddedReport;
                                                    }}
                                                />
                                            </div>
                                        </TabPanel>
                                    )
                                })
                            }
                        </TabContext>
                    </Box>
                </Box>
        </Box>

    )
}

export default AMCAnalytics