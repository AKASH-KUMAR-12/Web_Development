import React from "react";
import Card from "./components/Card";
import { Box, Grid } from "@mui/material";
import RegionalDistributorCount from "./components/RegionalDistributorCount";
import InvestorCategory from "./components/InvestorCategory";
import DistributorCategory from "./components/DistributorCategory";
import { assetClassData, SIPAgeingData, data, planModelistArray, revenueData } from "../../utilityComponents/Database"
import InvestorDemographyMap from "../AUM/components/InvestorDemographyMap";
import DistributorWiseCollection from "./components/DistributorWiseCollection";
import ModeOfAcquisition from "./components/ModeOfAcquisition";
import NFOInflow from "./components/NFOInflow";
import DistActiveByRegion from "./components/DistActiveByRegion";
import BranchWiseDistAct from "./components/BranchWiseDistAct";
import DistCategoryWiseAcquisition from "./components/DistCategoryWiseAcqisition";
import BarChart from "../../utilityComponents/charts/BarChart";
import Donut from "../../utilityComponents/charts/Donut";
import VerticalBarChart from "../../utilityComponents/charts/verticalBarChart";
import MapChart from "../../utilityComponents/charts/MapChart";

const NFODashboard = () => {
    const regionalData = [
        {
            "label": "South",
            "value": "45"
        },
        {
            "label": "West",
            "value": "75"
        },
        {
            "label": "East",
            "value": "55"
        },
        {
            "label": "North",
            "value": "45"
        },
        {
            "label": "Others",
            "value": "25"
        }

    ]
    const acquisitionData = [
        {
            "label": "Physical",
            "value": "65"
        },
        {
            "label": "Exchange",
            "value": "75"
        },
        {
            "label": "AMC Digital",
            "value": "55"
        },
        {
            "label": "Channel Partner",
            "value": "45"
        },
        {
            "label": "MFC Online",
            "value": "25"
        }

    ]
    const City = [
        {
            "label": "T30",
            "value": "45"
        },
        {
            "label": "B30",
            "value": "75"
        },
    ]
    const InvestorCategory= [
        {
            label: "Non-Retail",
            value: "1000",
        },
        {
            label: "Retail",
            value: "500",

        }
    ]
    const distributorCategory = [
        {
            label: "MFD(IFA)",
            value: "41"
        },
        {
            label: "ND",
            value: "50"
        },
        {
            label: "RIA",
            value: "35"
        },
        {
            label: "BANK",
            value: "32"
        }
    ]
    const planModelistArray = [
        "Direct SIP book has grown by 172 Cr SIP book",
        "Regular SIP book has grown by 278 Cr SIP book",
        "Contribution of direct SIP Book has grown up by 7%"
    ]
    return(

            <>
            <Box sx={{ padding: "0", paddingInline: "0rem", width: "95%", margin: "0px auto" }}>
            <Box
                    sx={{
                        position: "relative",
                        top: "0rem",
                        height: "1.5rem",
                        zIndex: "10",
                        borderRadius: "9px",
                        margin: "0rem 0rem 0rem 1rem",
                    }}
                >
                    <h3 className="box_shadow" style={{ position: "absolute", top: "1.5rem", marginInline: "auto", width: "96.5%", background: "#fff", padding: "0.7rem", borderRadius: "9px", }}>Data as on 30th of September</h3>
                </Box>

                <Grid container  justifyContent={"space-between"} alignItems={"center"}
                    sx={{ height: { lg: "75vh", md: "75vh", xs: "82vh" }, width: "100%", paddingInline: "1rem",marginTop:"4.5rem", overflow: "scroll", paddingBottom: "3rem" }}>   
         <Card/>
                      <Donut
                        md={5.8}
                        data={regionalData }
                        headerProps={{
                            heading: "Regional Distributor Count",
                            xs1:12
                        }}
                      />
                        <Donut
                        md={5.8}
                        data={City}
                        headerProps={{
                            heading: "City Categories",
                            
                        }}
                      />
                       <Donut
                        data={InvestorCategory}
                        listData={planModelistArray}
                        headerProps={{
                            heading: "Investor Category",
                            
                        }}
                    />
                      <BarChart 
                         data={distributorCategory}
                         headerProps={{
                             heading: "Distributor Category",
                             xs1:12
                         }}
                         />
                     
                    <MapChart
                        headerProps={{
                            heading: "Investor Demography - Location"
                        }}
                    />
                    <DistributorWiseCollection/>
                    <BarChart 
                         xAxisName={"Transaction Category"}
                         yAxisName={"Value(in Crs)"}
                         data={acquisitionData }
                         headerProps={{
                             heading: "Mode of Acquisition",
                             xs1:12
                         }}
                         />
                         <BarChart 
                         xAxisName={"Transaction Category"}
                         yAxisName={"No. of Customers- Acquired"}
                         data={acquisitionData }
                         headerProps={{
                             heading: "NFO Inflow",
                             xs1:12
                         }}
                         />
                            <Donut
                        data={regionalData}
                        listData={planModelistArray}
                        headerProps={{
                            heading: "Distributor Activated by Region"
                        }}
                    />
                    <BranchWiseDistAct/> 
                          <BarChart 
                            xAxisName={"Distributor Category"}
                            yAxisName={"No. of Customers"}
                         data={distributorCategory }
                         headerProps={{
                             heading: "Distributor Category wise Acquisition",
                             xs1:12
                         }}
                         />


        </Grid>
             </Box>
            </>
   
    )
}

export default NFODashboard