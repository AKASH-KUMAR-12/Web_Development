import { Grid } from '@mui/material'
import React, { useEffect, useState } from 'react'
import HeaderParent from '../../../utilityComponents/components/HeaderParent'
import ScrollingTable from '../../../utilityComponents/Table'


const BranchWiseDistAct = ({ data }) => {
    
    const rows = [
        createData('Mumbai', '1,634', '234', ),
        createData('Vijayawada', '1,145', '160', ),
        createData('Sidhi', '967', '134', ),
        createData('Pune', '830', '126', ),
        createData('Bangalore', '650', '113', ),
        createData('Kolkata', '520', '106', ),
        createData('Ahmedabad', '324', '96', ),
        createData('Delhi', '213', '87', ),
        createData('Chennai', '142', '73', ),
        createData('Fort Mumbai', '103', '62', ),
    ];
    const columns = [
        {
            id: 'Distributor',
            label: 'Branch Name',
            align: 'center',
            format: (value) => value.toLocaleString('en-US'),
        },
        {
            id: 'SIP_Count',
            label: 'Distributor Activated',
            align: 'center',
            format: (value) => value.toLocaleString('en-US'),
        },

        {
            id: 'SIPCount2',
            label: 'Distributor Empaneled',
            align: 'center',
            format: (value) => value.toLocaleString('en-US'),
        },
     
    ];
    function createData(Distributor, SIP_Count, SIPCount2, ) {
        return { Distributor, SIP_Count, SIPCount2,  };
    }
    return (
        <ScrollingTable
        rows={rows}
        columns={columns}
        headerProps={{
            heading: "Branch wise Distributor Activation",
            dropdownOptions: [{ title: "Top 10" }, { title: "Top 20" }, { title: "Top 50" }]
        }}/>
    )
}

export default BranchWiseDistAct