import { Grid } from '@mui/material'
import React, { useEffect, useState } from 'react'
import HeaderParent from '../../../utilityComponents/components/HeaderParent'
import ScrollingTable from '../../../utilityComponents/Table'


const DistributorWiseCollection = ({ data }) => {
    
    const rows = [
        createData('Sumit Nath Jha', 'ARN-0019', '₹ 245 Cr', '3,294', '10,223'),
        createData('Lalit Alai', 'ARN-0011', '₹ 127 Cr', '2,176', '7,345'),
        createData('Sonakshi Goel', 'ARN-3811', '₹ 83 Cr', '1,496', '3,928'),
        createData('Vignesh Kumaran','ARN-3290', '₹ 56 Cr', '1,385', '2,456'),
        createData('Mallika Sharma', 'ARN-3829', '₹ 45 Cr', '1,075', '1,435'),
      
    ];
    const columns = [
        {
            id: 'Distributor',
            label: 'Distributor Name',
            align: 'center',
            format: (value) => value.toLocaleString('en-US'),
        },
        {
            id: 'SIP_Count',
            label: 'Distributor ARN',
            align: 'center',
            format: (value) => value.toLocaleString('en-US'),
        },

        {
            id: 'SIPCount2',
            label: 'Total Collection',
            align: 'center',
            format: (value) => value.toLocaleString('en-US'),
        },
        {
            id: 'SIP_Bounced',
            label: 'Total Application',
            align: 'center',
            format: (value) => value.toLocaleString('en-US'),
        },
        {
            id: 'SIPBounced2',
            label: 'Total Investor',
            align: 'center',
            format: (value) => value.toLocaleString('en-US'),
        },
    ];
    function createData(Distributor, SIP_Count, SIPCount2, SIP_Bounced, SIPBounced2) {
        return { Distributor, SIP_Count, SIPCount2, SIP_Bounced, SIPBounced2 };
    }
    return (
        <ScrollingTable
        rows={rows}
        columns={columns}
        headerProps={{
            heading: "Distributor wise Collection",
        }}/>
    )
}

export default DistributorWiseCollection