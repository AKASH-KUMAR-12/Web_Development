import { Box } from '@mui/material'
import React from 'react'
import {Grid} from '@mui/material';
const CardBody = (props) => {
    return (
        <div style={{
            padding:'15px 0 0 18px',
            backgroundColor: "white",
                      height: 'auto',
                      borderRadius: '7px',
                      borderTop: '3.7px solid #2057A6',
                      background: 'linear-gradient(to bottom,rgba(105, 184, 244, 0.1),rgba(255, 255, 255, 0.1))',
                      boxShadow: '0px 2px 8px 0px #00000033',
                      textAlign: 'left'
        }}>
          <div style={{
              fontSize:'14px',
              fontWeight:'400',
          }}>{props.title}</div>
          <Box sx={{
              fontWeight:'700',
              fontSize:{md:"1.5rem",xs:"1rem"},
              color: '#333333',
              padding:'1rem 0 0.5rem 0 '
          }}>{props.value}</Box>
          </div>
    );
}
const Card = () => {
  return (
    <Grid container spacing={2} mb={2}>

    <Grid item xs={2.4} md={2.4}>
      <CardBody title="Total Collection" value="₹ 1,669.57 Cr "/>
    </Grid>
  
    <Grid item xs={2.4} md={2.4}>
    <CardBody title="Total Application" value="91,936" />
    </Grid>
  
    <Grid item xs={2.4} md={2.4}>
    <CardBody title="Investor Count" value="88,637" />
    </Grid>
  
    <Grid item xs={2.4} md={2.4}>
    <CardBody title="Distributors Activated" value="5,465" />
    </Grid>
  
    <Grid item xs={2.4} md={2.4}>
    <CardBody title="Total Customers Acquired" value="47,116" />
    </Grid>
  
  </Grid>
    
  )
}

export default Card