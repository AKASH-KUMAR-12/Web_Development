import React, { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { useSelector } from "react-redux";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { AdapterMoment } from "@mui/x-date-pickers/AdapterMoment";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import "./style/sipStyle.css"
import moment from "moment";
import { encrypt } from "../../utils/chipher";
import axios from "axios";
import SecureLS from "secure-ls";
import { setSIPResponse } from "../../reduxStore/ApiResponceReducer";
import { setcurrentDate } from "../../reduxStore/reducer";
import { setactivePage } from "../../reduxStore/reducer";
import { setFreshSipData } from "../../reduxStore/reducer";
import SIPBookDashBoard from "./SIPBook/main";
import FreshSipDashBoard from "./FreshSIP/main";
import { Container, Grid } from "@mui/material";
const Dashboard = () => {
  let ls = new SecureLS();
  const usertoken = ls.get("user-token");
  const dispatch = useDispatch();
  const currentDate = moment();
  let lastDateOfMonth = null;
  const [selectedYear, setSelectedYear] = useState(currentDate.format("YYYY"));
  const [selectedMonth, setSelectedMonth] = useState(currentDate.format("MM"));
  const activePage = useSelector((state) => state.currentCycle.activePage);
  console.log("activePage:", activePage);

  lastDateOfMonth = moment({ year: selectedYear, month: selectedMonth - 1 })
    .endOf("month")
    .format("YYYY-MM-DD");
  console.log("lastDateofMonth:", lastDateOfMonth);
  dispatch(setcurrentDate({ currentDate: lastDateOfMonth }));

  const setfreshsipactivePage = () => {
    dispatch(setactivePage({ activePage: "Fresh SIP" }));
  };

  const setsipactivePage = () => {
    dispatch(setactivePage({ activePage: "SIP" }));
  };
  useEffect(() => {
    if (activePage === "SIP") {
      const getGraphsResult = async () => {
        let payload = {
          fund: "RMF",
          batchclosedt: "2023-06-30",
          token: usertoken,
        };

        const encryptedPayload = encrypt(payload);

        var response = await axios.post(`/api/getsipbook`, {
          payload: encryptedPayload,
        });
        console.log("data from api of cards", response.data);
        dispatch(setSIPResponse({ ApiResponse: response.data }));
      };
      getGraphsResult();
    } else {
      const getGraphsResult = async () => {
        let payload = {
          fund: "RMF",
          batchclosedt: "2023-06-30",
          token: usertoken,
        };

        const encryptedPayload = encrypt(payload);

        var response = await axios.post(`/api/getfreshSip`, {
          payload: encryptedPayload,
        });
        console.log("data from api of cards from freshSip", response.data);
        dispatch(setFreshSipData({ freshData: response.data }));
      };
      getGraphsResult();
    }
  }, [lastDateOfMonth, activePage]);

  return (
    <>
      <Container sx={{ padding: "0", paddingInline: "0rem", width: "100%", margin: "0px auto" }}>
        <Grid container className="box_shadow"
          sx={{
            alignItems: "center",
            borderRadius: "8px",
            width: "96.5%",
            height: "2.8rem",
            margin: "1.5rem 1rem 0rem 1.2rem",
            backgroundColor: "#fff"
          }}
        >
          <Grid item xs={5} >
            <h3 style={{ cursor: "default", padding: "0.7rem", }}> Data as on 30th of September </h3>
          </Grid>

          <Grid item xs={4} style={{}} >
            <button
              onClick={setsipactivePage}
              style={{
                cursor: "pointer",
                padding: "7px 40px",
                marginLeft: "10px",
                borderRadius: "20px 0px 0px 20px",
                border: "1px solid #2057A6",
                fontSize: '.8rem',
                backgroundColor: activePage == "SIP" ? "#2057A6" : "#fff",
                color: activePage == "SIP" ? "#fff" : "",
              }}
            >
              SIP Book
            </button>
            <button
              onClick={setfreshsipactivePage}
              style={{
                cursor: "pointer",
                padding: "7px 40px",
                borderRadius: "0px 20px 20px 0px",
                border: "1px solid #2057A6",
                backgroundColor: activePage !== "SIP" ? "#2057A6" : "#fff",
                color: activePage !== "SIP" ? "#fff" : "",
                fontSize: '.8rem',
              }}
            >
              Fresh SIP
            </button>
          </Grid>

          {activePage === "SIP" && (
            <Grid item xs={3} style={{ display: "flex", alignItems: "center", justifyContent: "flex-end", }}>


              <div style={{ width: "93px" }}>
                <LocalizationProvider dateAdapter={AdapterMoment}>
                  <DatePicker

                    views={["month"]}
                    monthsPerRow={2}

                    onChange={(date) => {
                      setSelectedMonth(moment(date).format("MM"));
                    }}
                    slotProps={{ textField: { size: "small" } }}
                    sx={{
                      boxShadow: "rgba(99, 99, 99, 0.2) 0px 2px 8px 0px",
                      "& .css-o9k5xi-MuiInputBase-root-MuiOutlinedInput-root": { color: "#000" }
                    }}
                  />
                </LocalizationProvider>
              </div>
              <div style={{ width: "84px", marginLeft: "1rem", marginRight: "1rem" }}>
                <LocalizationProvider dateAdapter={AdapterMoment}>
                  <DatePicker
                    disableFuture
                    views={["year"]}
                    minDate={moment('01/01/2000')}
                    maxDate={moment()}
                    onChange={(date) => {
                      setSelectedYear(moment(date).format("YYYY"));
                    }}
                    slotProps={{
                      textField: { size: "small", width: "100%" },
                    }}
                  />
                </LocalizationProvider>
              </div>

            </Grid>
          )}

        </Grid>

        <div style={{ height: "80vh", overflowY: "scroll", paddingInline: ".3rem" }}>

          {activePage === "SIP" ? (
            <div style={{ marginTop: "20px" }}>
              <SIPBookDashBoard />
            </div>
          ) : (
            <div style={{ marginTop: "20px" }}>
              <FreshSipDashBoard />
            </div>
          )}
        </div>
      </Container>
    </>
  );
};

export default Dashboard;
