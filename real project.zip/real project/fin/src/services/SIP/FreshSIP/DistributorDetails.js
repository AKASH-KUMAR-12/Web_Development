import { Grid } from '@mui/material'
import React, { useEffect, useState } from 'react'
import HeaderParent from '../../../utilityComponents/components/HeaderParent'
import Donut from '../../../utilityComponents/charts/Donut'
import VerticalBarChart from '../../../utilityComponents/charts/verticalBarChart'
import axios from 'axios'
import { useSelector } from 'react-redux'
import ScrollingTable from '../../../utilityComponents/Table'


const DistributorDetails = ({ data }) => {
    // const [data, setData] = useState([])
    // const investorData = useSelector((state) => state.filterData?.investor)
    // const zoneData = useSelector((state) => state.filterData?.zone)
    // const stateData = useSelector((state) => state.filterData?.state)
    // const assetclassData = useSelector((state) => state.filterData?.assetclass)
    // const assetcategoryData = useSelector((state) => state.filterData?.assetcategory)
    // const distributorData = useSelector((state) => state.filterData?.distributor)

    // useEffect(() => {
    //     fetchData();
    // }, [investorData, zoneData, stateData, assetclassData, assetcategoryData, distributorData])



    // const fetchData = async () => {
    //     const payload =
    //     {
    //         "fund": "101",
    //         "zone": zoneData,
    //         "investor": investorData,
    //         "query_name": "AssetCategory",
    //         "state": stateData,
    //         "assetclass": assetclassData,
    //         "assetcategory": assetcategoryData,
    //         "distributor": distributorData,
    //         "order": "DESC"
    //     }
    //     const response = await axios.post("/api/getaumData", payload)

    //     console.log(response.data);
    //     setData(response.data);
    //     return response;
    // }
    const columns = [
        {
          id: 'Distributor',
          label: 'Distributor Name',
          minWidth: 120,
          align: 'center',
          format: (value) => value.toLocaleString('en-US'),
        },
        {
          id: 'SIP_Count',
          label: 'Fresh SIP Count',
          minWidth: 120,
          align: 'center',
          format: (value) => value.toLocaleString('en-US'),
        },
      
        {
          id: 'Fresh_Kfin',
          label: 'Fresh SIP Count(Kfin)',
          minWidth: 120,
          align: 'center',
          format: (value) => value.toLocaleString('en-US'),
        },
        {
          id: 'SIP_Bounced',
          label: 'SIP Bounced',
          minWidth: 120,
          align: 'center',
          format: (value) => value.toLocaleString('en-US'),
        },
        {
          id: 'SIP_Kfin',
          label: 'SIP Bounced(Kfin)',
          minWidth: 120,
          align: 'center',
          format: (value) => value.toLocaleString('en-US'),
        },
      ];
      
      function createData(Distributor, SIP_Count,Fresh_Kfin,SIP_Bounced,SIP_Kfin) {
        return { Distributor, SIP_Count,Fresh_Kfin,SIP_Bounced,SIP_Kfin };
      }
      
      const rows = [
        createData('NJ India Invest Pvt Ltd', '7,79,244', '31,16,976', '₹ 3,105.49 Cr', '₹ 12,421.96 Cr'),
        createData('ICICI Securities Limited', '3,24,460', '12,97,840', '₹ 775.06 Cr', '₹ 3,100.24 Cr'),
        createData('Prudent Corporate Advisory Services Ltd', '2,91,248', '11,64,992', '₹ 658.74 Cr', '₹ 2,634.96 Cr'),
        createData('State Bank of India', '95,615', '3,82,460', '₹ 439.99 Cr', '₹ 1,759.96 Cr'),
        createData('Axis Bank Limited', '2,64,637', '10,58,548', '₹ 384.04 Cr', '₹ 1,536.16 Cr'),
        createData('HDFC BANK LIMITED', '88,711', '3,54,844', '₹ 288.43 Cr', '₹ 1,513.72 Cr'),
        createData('HDFC SECURITIES LTD', '2,55,519', '10,22,076', '₹ 204.16 Cr', '₹ 816.64 Cr'),
        createData('HMG CAPITAL SERVICES ...', '1,084', '4,336', '₹ 178.35 Cr', '₹ 713.4 Cr'),
        createData('SLA FINSERV PRIVATE LIMITED', '2,780', '11,120', '₹ 146.93 Cr', '₹ 587.72 Cr'),
        createData('PHONEPE WEALTH BROKING...', '4,20,213', '16,80,852', '₹ 135.80 Cr', '₹ 543.2 Cr'),
      ];
    return (
      <ScrollingTable
      rows={rows}
      columns={columns}
      headerProps={{
          heading: "Distributor Details",
          dropdownOptions: [{ title: "Top 10" }, { title: "Top 20" }, { title: "Top 50" }]
      }}/>
    )
}

export default DistributorDetails