import React from 'react'
import HeaderParent from '../../../utilityComponents/components/HeaderParent'
import TopDistributorTable from './TopDistributorTable'
import TopCitiesTable from './TopCitiesTable'
import { Grid } from '@mui/material'

const TopDistributorCity = () => {
  return (
    <Grid container sx={{ backgroundColor: "#fff", display: 'flex', justifyContent: "space-between", marginTop: "10px", marginBottom: "20px", borderRadius: ".5rem" }}>
        <Grid item xs={12} sm={12} md={5.9} sx={{ boxShadow: 6, borderRadius: "8px", marginBottom: "1rem" }}>
          <HeaderParent
          headerProps={{
            heading:" Top Distributors",
            dropdownOptions: [{ title: "Top 10" }, { title: "Top 20" }, { title: "Top 50" }]
          }}
            />
          <TopDistributorTable />
        </Grid>
        <Grid item xs={12} sm={12} md={5.9} sx={{ boxShadow: 6, borderRadius: "8px", marginBottom: "1rem" }}>
          <HeaderParent   headerProps={{
            heading:" Top Cities",
            dropdownOptions: [{ title: "Top 10" }, { title: "Top 20" }, { title: "Top 50" }]
          }}/>
          <TopCitiesTable />
        </Grid>
      </Grid>
  )
}

export default TopDistributorCity