import React from 'react';
import Paper from '@mui/material/Paper';
import Table from '@mui/material/Table';
import { styled } from '@mui/material/styles';
import TableBody from '@mui/material/TableBody';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import TableCell, { tableCellClasses } from '@mui/material/TableCell';

const columns = [
  {
    id: 'City',
    label: 'City',
    minWidth: 120,
    align: 'center',
    format: (value) => value.toLocaleString('en-US'),
  },
  {
    id: 'SIP_Count',
    label: 'Fresh SIP Count',
    minWidth: 120,
    align: 'center',
    format: (value) => value.toLocaleString('en-US'),
  },

  {
    id: 'SIP_Amount',
    label: 'Fresh SIP Amount',
    minWidth: 120,
    align: 'center',
    format: (value) => value.toLocaleString('en-US'),
  },
];

function createData(City, SIP_Count, SIP_Amount) {
  return { City, SIP_Count, SIP_Amount };
}

const rows = [
  createData('KOLKATA', '841', '₹ 1.31 Cr'),
  createData('NORTH 24 PARGANAS', '3,779', '₹ 0.69 Cr'),
  createData('SHIMOGA', '8,585', '₹ 12.57 Cr'),
  createData('MAHAD', '606', '₹ 0.20 Cr'),
  createData('PORANKI RURAL', '19', '₹ 0.00 Cr'),
  createData('JAGRAON', '239', '₹ 0.08 Cr'),
  createData('CUTTACK SADAR', '61', '₹ 0.01 Cr'),
  createData('GOMEWADI', '21', '₹ 0.00 Cr'),
  createData('VASAI', '4,037', '₹ 6.19 Cr'),
  createData('PUNE', '1,781', '₹ 4.79 Cr'),
];

export default function TopCitiesTable() {
  const [page, setPage] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(10);

  const StyledTableCell = styled(TableCell)(({ theme }) => ({
    [`&.${tableCellClasses.head}`]: {
      backgroundColor: theme.palette.common.black,
      color: theme.palette.common.white,
    },
    [`&.${tableCellClasses.body}`]: {
      fontSize: 13,
      padding: '1.3em 0 1.3em 0 '
    },
  }));
  const StyledTableRow = styled(TableRow)(({ theme }) => ({
    '&:nth-of-type(odd)': {
      backgroundColor: '#F4F9FF',
    },
    '&:last-child td, &:last-child th': {
      border: 0,
    },
  }));
  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(+event.target.value);
    setPage(0);
  };

  return (
    <Paper sx={{ width: window.innerWidth <= 390 ? '87%' : '95%', overflow: "hidden", margin: '1rem', }}>
      <TableContainer sx={{
        maxHeight: 265, borderBottom: 'none',
        "&::-webkit-scrollbar": {
          width: 10
        },
        "&::-webkit-scrollbar-track": {
          backgroundColor: "#dee6f2"
        },
        "&::-webkit-scrollbar-thumb": {
          backgroundColor: "#2057a6",
          borderRadius: 2
        }
      }}>
        <Table stickyHeader aria-label="customized table">
          <TableHead>
            <StyledTableRow>
              {columns.map((column) => (
                <StyledTableCell
                  key={column.id}
                  align={column.align}
                  style={{ minWidth: column.minWidth, color: column.color, backgroundColor: "#2057A6" }}
                >
                  {column.label}
                </StyledTableCell>
              ))}
            </StyledTableRow>
          </TableHead>
          <TableBody>
            {rows
              .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
              .map((row, rowkey) => {

                return (
                  <StyledTableRow hover role="checkbox" tabIndex={-1} key={rowkey}>
                    {columns.map((column) => {
                      const value = row[column.id];
                      return (
                        <StyledTableCell key={column.id} align={column.align}>
                          {column.format && typeof value === 'number'
                            ? column.format(value)
                            : value}
                        </StyledTableCell>
                      );
                    })}
                  </StyledTableRow>
                );
              })}
          </TableBody>
        </Table>
      </TableContainer>
    </Paper>
  );
}