import React from 'react'
import { styled } from '@mui/material/styles';
import Paper from '@mui/material/Paper';
import { useState } from "react";
import { useSelector } from "react-redux/es/hooks/useSelector";
import { useDispatch } from "react-redux";
import { Box, Grid } from '@mui/material';



const FreshSIPCard = () => {
    const dispatch = useDispatch();
const activePage = useSelector((state) => state.currentCycle.activePage);
const api_results = useSelector((state) => state.CurrentApiData.ApiResponse);
const api_FreshResult = useSelector((state) => state.currentCycle.freshData);
const selectedDate = useSelector((state) => state.currentCycle.currentDate);
const [sipBookResult, setSIPbookResult] = useState([]);
const [amountCardHeader, setAmountCardHeader] = useState("");
const [cardAmount, setCardAmount] = useState();
const [countCardHeader, setCountCardHeader] = useState("");
const [cardCount, setCardCount] = useState("");
const [AverageValue, setAverageValue] = useState("");
const [amountDiffence, setAmountDifference] = useState();
const [countDiffence, setCountDifference] = useState();
const [amtUpAndDown, setAmtUpAndDown] = useState("");
const [countUpAndDown, setCountUpAndDown] = useState("");


const Item = styled(Paper)(({ theme }) => ({
  backgroundColor: '#E3EAF3',
  padding: theme.spacing(1),
  border: 0,
}));
const row1_blueCard = { width: "80%", height: "5.3rem", margin: ".3rem auto", "border-radius": "0.5rem", color: "#fff", backgroundColor: "transparent", boxShadow: 0, borderTop: "3x solid blue" };
let transactionCatagoryData = [{
  chartData: [
    {
      "label": "New Lumpsum",
      "value": "15"
    },
    {
      "label": "Additional Lumpsum",
      "value": "45"
    },
    {
      "label": "New SIP",
      "value": "-30"
    },
    {
      "label": "Additional SIP",
      "value": "22"
    },
    {
      "label": "Switch In",
      "value": "-43"
    }],
  chartAxis:
  {
    xName: "Transaction Cateogory", yName: "Value in Thousands"
  }
}]
let trData = [
  {
    "name": "Fresh SIP Amount",
    "value": "₹ 2,094.28 Cr"
  },
  {
    "name": "Fresh SIP Count",
    "value": "3,78,956"
  },
  {
    "name": "Average SIP Value",
    "value": "₹ 5,527.89 Cr"
  }
]


let currentMonthResult = api_results.filter((data) => {
  return data.batchclosedt === "2023-04-30";
});
  return (
    <Box
        sx={{
          background: "#fff",
          padding: "1rem .5rem",
          boxShadow: 6,
          borderRadius: ".5rem"
        }}
      >
    <Grid container spacing={1} sx={{ margin: "0 1% 0 0", "& .css-1ik6aa3-MuiPaper-root": { backgroundColor: "#fff", height: "21rem", borderRadius: ".5rem" } }}>
      {
        trData.map((item, i) => {
          return (<Grid xs={12} md={4} sx={{ "& .css-1ik6aa3-MuiPaper-root": { boxShadow: 6 }, borderLeft: { md: i !== 0 && "1px solid #999999", xs: "none" } }}>
            <Item className="display" sx={{ ...row1_blueCard }}  >
              <p style={{ margin: "1rem", fontWeight: "200" }}>{item.name}</p>
              <h3 style={{ margin: "0rem 1rem 1rem 1rem" }}>{item.value}</h3>
            </Item>
          </Grid>)
        })
      }
    </Grid>
      </Box>
  )
}

export default FreshSIPCard