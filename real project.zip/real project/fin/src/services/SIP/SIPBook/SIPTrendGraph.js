import { Grid } from '@mui/material'
import React, { useEffect, useState } from 'react'
import HeaderParent from '../../../utilityComponents/components/HeaderParent'
import axios from 'axios'
import { useSelector } from 'react-redux'
import MultiLineChart from '../../../utilityComponents/charts/MultiLineChart'


const SIPTrendGraph = ({ heading,data ,radiolist}) => {
    // const [data, setData] = useState([])
    // const investorData = useSelector((state) => state.filterData?.investor)
    // const zoneData = useSelector((state) => state.filterData?.zone)
    // const stateData = useSelector((state) => state.filterData?.state)
    // const assetclassData = useSelector((state) => state.filterData?.assetclass)
    // const assetcategoryData = useSelector((state) => state.filterData?.assetcategory)
    // const distributorData = useSelector((state) => state.filterData?.distributor)

    // useEffect(() => {
    //     fetchData();
    // }, [investorData, zoneData, stateData, assetclassData, assetcategoryData, distributorData])



    // const fetchData = async () => {
    //     const payload =
    //     {
    //         "fund": "101",
    //         "zone": zoneData,
    //         "investor": investorData,
    //         "query_name": "AssetCategory",
    //         "state": stateData,
    //         "assetclass": assetclassData,
    //         "assetcategory": assetcategoryData,
    //         "distributor": distributorData,
    //         "order": "DESC"
    //     }
    //     const response = await axios.post("/api/getaumData", payload)

    //     console.log(response.data);
    //     setData(response.data);
    //     return response;
    // }
    return (
        <Grid container xs={12} justifyContent={"space-between"} sx={{
            borderTop: "3px solid #010C43",
            marginBlock: "20px",
            borderRadius: '8px',
            alignItems: "center",
            height: "auto",
        }}>
            <Grid item xs={12} sx={{ bgcolor: "#fff", borderRadius: "8px", boxShadow: 6 }}>
                <HeaderParent xs={12} xs3={4}
                    heading={heading}
                    radioList={radiolist}
                />
                <MultiLineChart
                    xAxisName={"Month"}
                    yAxisName={"AUM (in crores)"}
                    data={data}

                />
            </Grid>
        </Grid>
    )
}

export default SIPTrendGraph