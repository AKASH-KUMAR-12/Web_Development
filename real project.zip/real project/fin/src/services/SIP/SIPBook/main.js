import React from "react";

// import SipAgeing from "../subcomponents/sipbook/sipageing";
// import SipAmount from "../subcomponents/sipbook/sipAmount";
import SipSummary from "../SIPBook/SIPSummary";
import SecureLS from "secure-ls";
import { useDispatch } from "react-redux";
import { useSelector } from "react-redux/es/hooks/useSelector";
import { Box, FormControl, Grid, MenuItem, Select } from "@mui/material";
import Comp from "../SIPBook/CardComp";
import PlanMode from "./PlanMode";
import AssetClass from "./AssetClass";
import SchemeDetails from "./SchemeDetails";
import DistributorCategory from "./DistributorCategory";
import SIPAgeingAmount from "./SIPAgeingAmount";
import InvestorDemography from "./InvestorDemography";
import InvestorDemographyMap from "./InvestorDemographyMap";
import SIPTrendGraph from "./SIPTrendGraph";
import DistributorDetails from "./DistributorDetails"
import SIPBookCard from "./SIPBookCard";
import VerticalBarChart from "../../../utilityComponents/charts/verticalBarChart";
import Donut from "../../../utilityComponents/charts/Donut";
import BarChart from "../../../utilityComponents/charts/BarChart";
import MapChart from "../../../utilityComponents/charts/MapChart";
import MultiLineChart from "../../../utilityComponents/charts/MultiLineChart";

const SIPBookDashBoard = () => {

    const selectedDate = useSelector((state) => state.currentCycle.currentDate);
    let ls = new SecureLS();
    const dispatch = useDispatch();
    const usertoken = ls.get("user-token");
    const [rowNum, setRowNum] = React.useState(5);
    const [trendRadioValue, setTrendRadioValue] = React.useState("SIP Book");

    const handleChange = (event) => {
        setRowNum(event.target.value);
    };
    const planModeData = [
        {
            "label": "Direct",
            "value": "45"
        },
        {
            "label": "Regular",
            "value": "65"
        }

    ]
    const SIPAmountData = [
        {
            label: "<500",
            "value": "700000"
        },
        {
            label: "500-1000",
            "value": "250000"
        },
        {
            label: "1000-2500",
            "value": "550000"
        },
        {
            label: "2500-5000",
            "value": "470000"
        },
        {
            label: "5000-10000",
            "value": "660000"
        },
        {
            label: "10000-20000",
            "value": "370000"
        },
        {
            label: ">20000",
            "value": "370000"
        },]

    const SIPAgeingData = [
        {
            label: "0-1",
            "value": "700000"
        },
        {
            label: "1-2",
            "value": "250000"
        },
        {
            label: "2-3",
            "value": "550000"
        },
        {
            label: "3-4",
            "value": "470000"
        },
        {
            label: "4-5",
            "value": "660000"
        },
        {
            label: ">5",
            "value": "370000"
        },
    ]

    const InvestorDemography = [
        {
            label: "<18",
            "value": "70"
        },
        {
            label: "18-25",
            "value": "90"
        },
        {
            label: "25-35",
            "value": "30"
        },
        {
            label: "35-45",
            "value": "40"
        },
        {
            label: "45-55",
            "value": "20"
        },
        {
            label: "55-65",
            "value": "80"
        },
        {
            label: ">65",
            "value": "70"
        },
    ]
    const data = [
        {
            "label": "Hybrid",
            "value": "43"
        },
        {
            "label": "Debt",
            "value": "57"
        },
        {
            "label": "Equity",
            "value": "33"
        }
    ]
    const cityCategoryData = [
        {
            "label": "T30",
            "value": "45"
        },
        {
            "label": "B30",
            "value": "65"
        }

    ]
    const assetClassData = [
        {
            "label": "Hybrid",
            "value": "33"
        },
        {
            "label": "Debt",
            "value": "33"
        },
        {
            "label": "Equity",
            "value": "33"
        },

    ]
    const distributorCategory = [
        {
            label: "MFD(IFA)",
            value: "41"
        },
        {
            label: "ND",
            value: "50"
        },
        {
            label: "DIRECT",
            value: "30"
        },
        {
            label: "RIA",
            value: "35"
        },
        {
            label: "BANK",
            value: "32"
        }
    ]
    const trendChartData = {
        currentData: [
            { label: 'JAN 23', value: '289514.83' },
            { label: 'FEB 23', value: '288802.27' },
            { label: 'MAR 23', value: '285520.11' },
            { label: 'APR 23', value: '304516.54' },
            { label: 'MAY 23', value: '317425.64' },
            { label: 'JUN 23', value: '325925.02' },
            { label: 'JUL 23', value: '347865.95' },
            { label: 'AUG 23', value: '354133.28' },
            { label: 'SEPT 23', value: '357087.96' },
            { label: 'OCT 23', value: '361797.66' },
            { label: 'NOV 23', value: '367630.55' }
        ]
    }

    const planModelistArray = [
        "Direct SIP book has grown by 172 Cr SIP book",
        "Regular SIP book has grown by 278 Cr SIP book",
        "Contribution of direct SIP Book has grown up by 7%"
    ]
    const assetClasslistArray = [
        "Equity SIP Book has grown from 220 Cr to 240 Cr",
        "Debt SIP book has grown from 9 Cr to 14 Cr",
        "Hybrid SIP book has grown from 105 Cr to 126 Cr."
    ]
    const cityCategorylistArray = [
        "T30 SIP book has grown by 118 Cr SIP book",
        "B30 SIP book has grown by 143 Cr SIP book",
        "Contribution of B30 SIP Book has grown up by 2%"
    ]


    return (
        <>
            <Grid container xs={12} justifyContent={"space-between"} alignItems={"center"}
                sx={{ height: { lg: "75vh", md: "75vh", xs: "82vh" }, width: "100%", paddingInline: "1rem", overflow: "scroll", paddingBottom: "3rem" }}>
                <SIPBookCard />
                <SipSummary />
                <Donut
                    data={planModeData}
                    listData={planModelistArray}
                    headerProps={{
                        heading: "Plan Mode"
                    }}
                />
                <Donut
                    data={data}
                    listData={assetClasslistArray}
                    headerProps={{
                        heading: "Asset Class"
                    }}
                />
                <SchemeDetails />

                <BarChart
                    xAxisName={"SIP Book"}
                    yAxisName={"Distributor Category"}
                    data={distributorCategory}
                    headerProps={{
                        heading: "Distributor Category",
                    }}
                />
                <VerticalBarChart
                    xAxisName={"SIP Age in Years"}
                    yAxisName={"SIP Count"}
                    data={SIPAgeingData}
                    md={5.8}
                    headerProps={{
                        heading: "SIP Ageing",

                    }}
                />
                <VerticalBarChart
                    xAxisName={"SIP Amount"}
                    yAxisName={"SIP Count"}
                    data={SIPAmountData}
                    md={5.8}
                    headerProps={{
                        heading: "SIP Amount",

                    }}
                />
                <Donut
                    data={cityCategoryData}
                    listData={cityCategorylistArray}
                    headerProps={{
                        heading: "City Categories"
                    }}
                />
                <VerticalBarChart
                    xAxisName={"Age"}
                    yAxisName={"SIP Count"}
                    data={InvestorDemography}
                    headerProps={{
                        heading: "Investor Demography",
                        radioList: ["Age", "Gender", "Occupation"]
                    }}
                />
                <MapChart
                    headerProps={{
                        heading: "Investor Demography - Location"
                    }}
                />
                <MultiLineChart
                    xAxisName={"Month"}
                    yAxisName={"AUM (in crores)"}
                    data={trendChartData}
                    headerProps={{
                        heading: "Trend Graph",
                        radioList: ["SIP Book", "SIP Count"],
                        radioValue: trendRadioValue,
                        setRadioValue: setTrendRadioValue
                    }}
                />
                <DistributorDetails />

            </Grid>
        </>
    );
};

export default SIPBookDashBoard;
