import React from 'react';
import Paper from '@mui/material/Paper';
import Table from '@mui/material/Table';
import { styled } from '@mui/material/styles';
import TableBody from '@mui/material/TableBody';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import TableCell, { tableCellClasses } from '@mui/material/TableCell';

const columns = [
  {
    id: 'Scheme',
    label: 'Scheme Name',
    minWidth: 120,
    align: 'center',
    format: (value) => value.toLocaleString('en-US'),
  },
  {
    id: 'SIP_Count',
    label: 'SIP Count',
    minWidth: 120,
    align: 'center',
    format: (value) => value.toLocaleString('en-US'),
  },

  {
    id: 'SIP_Registered',
    label: 'SIP Registered',
    minWidth: 120,
    align: 'center',
    format: (value) => value.toLocaleString('en-US'),
  },
];

function createData(Scheme, SIP_Count, SIP_Registered) {
  return { Scheme, SIP_Count, SIP_Registered };
}

const rows = [
  createData('Small Cap Fund', '20,027', '₹ 8 Cr'),
  createData('Mid Cap Fund', '13,314', '₹ 7.5 Cr'),
  createData('Large Cap Fund', '24,419', '₹ 6 Cr'),
  createData('Flexible Cap Fund', '33,109', '₹ 6.2 Cr'),
  createData('Multi Cap Fund', '30,623', '₹ 5.1 Cr'),
  createData('Large & Mid Cap Fund', '33,106', '₹ 10 Cr'),
  createData('Focused Fund', '27,108', '₹ 8.5 Cr'),
  createData('Nifty 50 Index Fund', '22,809', '₹ 7 Cr'),
  createData('Balanced Advantage Fund', '37,902', '₹ 6.7 Cr'),
  createData('Gold Fund', '41,103', '₹ 5 Cr'),
];

export default function Scheme() {
  const [page, setPage] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(10);

  const StyledTableCell = styled(TableCell)(({ theme }) => ({
    [`&.${tableCellClasses.head}`]: {
      backgroundColor: theme.palette.common.black,
      color: theme.palette.common.white,
    },
    [`&.${tableCellClasses.body}`]: {
      fontSize: 13,
      padding: '1.3em 0 1.3em 0 '
    },
  }));
  const StyledTableRow = styled(TableRow)(({ theme }) => ({
    '&:nth-of-type(odd)': {
      backgroundColor: '#F4F9FF',
    },
    '&:last-child td, &:last-child th': {
      border: 0,
    },
  }));
  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(+event.target.value);
    setPage(0);
  };

  return (
    <Paper sx={{ width: window.innerWidth <= 390 ? '87%' : '97%', overflow: "hidden", margin: '1rem', }}>
      <TableContainer sx={{
        maxHeight: 265, borderBottom: 'none',
        "&::-webkit-scrollbar": {
          width: 10
        },
        "&::-webkit-scrollbar-track": {
          backgroundColor: "#dee6f2"
        },
        "&::-webkit-scrollbar-thumb": {
          backgroundColor: "#2057a6",
          borderRadius: 2
        }
      }}>
        <Table stickyHeader aria-label="customized table">
          <TableHead>
            <StyledTableRow>
              {columns.map((column) => (
                <StyledTableCell
                  key={column.id}
                  align={column.align}
                  style={{ minWidth: column.minWidth, color: column.color, backgroundColor: "#2057A6" }}
                >
                  {column.label}
                </StyledTableCell>
              ))}
            </StyledTableRow>
          </TableHead>
          <TableBody>
            {rows
              .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
              .map((row, rowkey) => {

                return (
                  <StyledTableRow hover role="checkbox" tabIndex={-1} key={rowkey}>
                    {columns.map((column) => {
                      const value = row[column.id];
                      return (
                        <StyledTableCell key={column.id} align={column.align}>
                          {column.format && typeof value === 'number'
                            ? column.format(value)
                            : value}
                        </StyledTableCell>
                      );
                    })}
                  </StyledTableRow>
                );
              })}
          </TableBody>
        </Table>
      </TableContainer>
    </Paper>
  );
}