import { Box, Grid } from '@mui/material'
import React from 'react'
import HeaderParent from '../../../utilityComponents/components/HeaderParent'
import VerticalBarChart from '../../../utilityComponents/charts/verticalBarChart'
import { useSelector } from 'react-redux'


const SIPAgeingAmount = ({ data }) => {
    const api_results = useSelector((state) => state.CurrentApiData.ApiResponse);
    const bookVAL = useSelector((state) => state.currentCycle.SIPvalue);
    const selectedDate = useSelector((state) => state.currentCycle.currentDate);
    let freshApiResult = useSelector((state) => state.currentCycle.freshData);
    let ageingData = freshApiResult[5]?.["SIP AGEING"];
    let aamountData = freshApiResult[6]?.["SIP AMOUNT"];
    const activePage = useSelector((state) => state.currentCycle.activePage);
    let currentMonthResult = api_results.filter((data) => {
      return data.batchclosedt === "2023-05-31";
    });
    let ageingArray = currentMonthResult[0]?.sip_ageing;
    let finalVal = activePage === "SIP" ? ageingArray : data[0];
    let finalVal1 = activePage === "SIP" ? ageingArray : data[1];


    return (
        <Grid container xs={12} gap={2} justifyContent={"space-between"} sx={{
            marginTop: "20px",
            borderRadius: '8px',
            alignItems: "center",
            height: "auto",
        }}>
            <Grid item md={5.8} xs={12} sx={{ bgcolor: "#fff", borderRadius: "8px", boxShadow: 6, borderTop: "3px solid #010C43", }}>
                <HeaderParent xs={12} xs3={6}
                    heading="SIP Ageing"
                />
                <VerticalBarChart
                    data={data}
                />
            </Grid>
            <Grid item md={5.8} xs={12} sx={{ bgcolor: "#fff", borderRadius: "8px", boxShadow: 6, borderTop: "3px solid #010C43", }}>
                <HeaderParent xs={12} xs3={6}
                    heading="SIP Amount"
                />
                <VerticalBarChart
                    data={data}
                />
            </Grid>
        </Grid>
    )
}

export default SIPAgeingAmount