import { Grid,} from '@mui/material'
import React from 'react'
import Comp from "./CardComp";
import { styled } from '@mui/material/styles';
import Paper from '@mui/material/Paper';

const Item = styled(Paper)(({ theme }) => ({
    backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : 'transparent',
    ...theme.typography.body2,
    padding: theme.spacing(1),
    textAlign: 'center',
    color: '#000000',
    border: 'none',
    boxShadow: 'none',
    paddingInline: ".2rem"
  }));

  const SIPCard = styled(Grid)(({ theme }) => ({
    height: '8em',
    marginTop: '0em',
    borderRadius: '7px',
    background: 'linear-gradient(to bottom,rgba(105, 184, 244, 0.1),rgba(255, 255, 255, 0.1))',
    borderTop: '3.7px solid #2057A6',
    boxShadow: '0px 2px 8px 0px #00000033',
    "&:hover": {
      backgroundColor: "#2057A6",
      color:"white"
    }
  }));

const SIPBookCard = () => {
  return (
    <Grid container >
    <Grid item xs={12}>
      <Item> <Grid container gap={{ xs: 1.5, md: 0 }} sx={{
        width: '100%',
        justifyContent: "space-between"
      }}>
        <SIPCard item xs={12} sm={5.8} md={2.8} sx={{ borderColor: "#2057A6" }}>
          <Comp header="Ceased SIP" title1="SIP Count" value1="4,150" title2="SIP Value" value2="192 Cr" />
        </SIPCard>
        <SIPCard item xs={12} sm={5.8} md={2.8} sx={{ borderColor: "#8FABD3" }} >
          <Comp header="Matured SIP" title1="SIP Count" value1="22,054" title2="SIP Value" value2="15.23 Cr" />
        </SIPCard>
        <SIPCard item xs={12} sm={5.8} md={2.8} sx={{ borderColor: "#8ED8B7" }} >
          <Comp header="Paused SIP" title1="SIP Count" value1="5,302" title2="SIP Value" value2="1.21 Cr" />
        </SIPCard >
        <SIPCard item xs={12} sm={5.8} md={2.8} sx={{ borderColor: "#BA87ED" }}>
          <Comp header="SIP Top Up" title1="SIP Count" value1="8,302" title2="SIP Value" value2="180.21 Cr" />
        </SIPCard>
      </Grid>
      </Item>
    </Grid>
  </Grid>
  )
}

export default SIPBookCard