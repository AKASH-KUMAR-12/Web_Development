import React from "react"

const CardComp = (props) => {
    return (
        <div>
            <div style={{
                fontSize: '1.2em',
                fontWeight: 'bold',
                marginLeft: "1.5em",
                padding: '0.9em 0 0 0 ',
                textAlign: 'left'
            }
            }>{props.header}</div>
            <div style={{ display: "flex" }}>

                <div style={{
                    position: 'sticky'
                }}>
                    <div style={{
                        fontSize: '100%',
                        fontWeight: '420',
                        textAlign: 'left',
                        padding: '1.5em 0 0 1.7em',
                        position: 'sticky'
                    }}>{props.title1}</div>
                    <div style={{
                        fontSize: '100%',
                        fontWeight: '420',
                        textAlign: 'left',
                        padding: '0 0 0 1.7em',
                        position: 'sticky'
                    }}>{props.value1}</div>
                </div>
                <div style={{
                    position: 'sticky'
                }}>
                    <div style={{
                        fontSize: '100%',
                        fontWeight: '420',
                        textAlign: 'left',
                        padding: '1.5em 0 0 1.7em',
                        position: 'sticky'
                    }}>{props.title2}</div>
                    <div style={{
                        fontSize: '100%',
                        fontWeight: '420',
                        textAlign: 'left',
                        padding: '0 0 0 1.7em',
                        position: 'sticky'
                    }}>{props.value2}</div>
                </div>
            </div>
        </div>


    )
}

export default CardComp;