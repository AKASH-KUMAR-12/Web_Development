import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux/es/hooks/useSelector";
import { useDispatch } from "react-redux";
// import "../../../../services/SIPBookComp/components/style/sipBook.css";
import "../style/sip.css";
import { Grid } from "@mui/material";

const SipSummary = () => {
  const dispatch = useDispatch();
  const activePage = useSelector((state) => state.currentCycle.activePage);
  const api_results = useSelector((state) => state.CurrentApiData.ApiResponse);
  const api_FreshResult = useSelector((state) => state.currentCycle.freshData);
  const selectedDate = useSelector((state) => state.currentCycle.currentDate);


  let currentMonthResult = api_results.filter((data) => {
    return data.batchclosedt === "2023-04-30";
  });

  return (
    <>
      <Grid
        container
        spacing={0}
        sx={{
          background: "#fff",
          borderRadius: "8px",
          padding: "1rem",
          boxShadow: "rgba(99, 99, 99, 0.2) 0px 2px 8px 0px",
        }}
      >
        <Grid item xs={12} sm={12} md={3}>
          <div className="sip_card display" >
            <div style={{ marginLeft: '1rem' }}>
              <p>SIP Book</p>
              <h3>₹ 5,100.85 Cr</h3>
            </div>
          </div>
        </Grid>
        <Grid item xs={12} sm={12} md={8} sx={{ borderLeft: "2px solid #b9b9b9" }}>
          <div>
            <ul className="description_card_list_container">
              <li>SIP Book as of Sept 23 is ₹ 5.5K Cr.</li>
              <li>SIP Book has Increased by ₹ 382 Cr (6.9%) from last month.</li>
              <li>SIP Book has Increased by ₹ 2.4K Cr (122%) in current Financial year.</li>
            </ul>
          </div>
        </Grid>
      </Grid >

      <Grid
              container
        spacing={0}
        sx={{
          background: "#fff",
          borderRadius: "8px",
          padding: "1rem",
          marginBlock: "1rem",
          boxShadow: "rgba(99, 99, 99, 0.2) 0px 2px 8px 0px",
        }}
      >
        <Grid item xs={12} sm={12} md={3}>
          <div className="sip_card display">
            <div style={{ marginLeft: '1rem' }}>
              <p>SIP Count</p>
              <h3>11,85,850</h3>
            </div>
          </div>
        </Grid>

        <Grid item xs={12} sm={12} md={8} sx={{ borderLeft: "2px solid #b9b9b9" }}>
          <div>
            <ul className="description_card_list_container" style={{
              ".list_item": {
                fontFamily: 'Roboto',
                fontSize: '13px',
                fontWeight: '500',
                lineHeight: '28px',
                letterSpacing: '0em',
                textAlign: 'left',
                color: '#333333CC',
              }
            }}>
              <li className="list_item">SIP Count as of Sept 23 is 11,85,850</li>
              <li className="list_item">SIP Count has Increased by 2,528 (0.21%) from last month.</li>
              <li className="list_item">SIP Count has Increased by 3,24,723 (37%) in current Financial year.</li>
            </ul>
          </div>
        </Grid>
      </Grid>
      <Grid className="average_sip_card" xs={12}>
        <p>Average SIP Value for a AMC is  ₹ 43,014.29 .</p>
      </Grid>

    </>

  );

};



export default SipSummary;