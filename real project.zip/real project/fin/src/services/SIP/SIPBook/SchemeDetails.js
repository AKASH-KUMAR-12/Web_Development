import { Grid } from '@mui/material'
import React, { useEffect, useState } from 'react'
import HeaderParent from '../../../utilityComponents/components/HeaderParent'
import Donut from '../../../utilityComponents/charts/Donut'
import VerticalBarChart from '../../../utilityComponents/charts/verticalBarChart'
import axios from 'axios'
import { useSelector } from 'react-redux'
import ScrollingTable from '../../../utilityComponents/Table'


const SchemeDetails = ({ data }) => {
    // const [data, setData] = useState([])
    // const investorData = useSelector((state) => state.filterData?.investor)
    // const zoneData = useSelector((state) => state.filterData?.zone)
    // const stateData = useSelector((state) => state.filterData?.state)
    // const assetclassData = useSelector((state) => state.filterData?.assetclass)
    // const assetcategoryData = useSelector((state) => state.filterData?.assetcategory)
    // const distributorData = useSelector((state) => state.filterData?.distributor)

    // useEffect(() => {
    //     fetchData();
    // }, [investorData, zoneData, stateData, assetclassData, assetcategoryData, distributorData])



    // const fetchData = async () => {
    //     const payload =
    //     {
    //         "fund": "101",
    //         "zone": zoneData,
    //         "investor": investorData,
    //         "query_name": "AssetCategory",
    //         "state": stateData,
    //         "assetclass": assetclassData,
    //         "assetcategory": assetcategoryData,
    //         "distributor": distributorData,
    //         "order": "DESC"
    //     }
    //     const response = await axios.post("/api/getaumData", payload)

    //     console.log(response.data);
    //     setData(response.data);
    //     return response;
    // }
    const rows = [
        createData('Small Cap Fund', '20,137', '₹ 10 Cr', '₹ 8 Cr', '₹ 2 Cr'),
        createData('Mid Cap Fund', '15,315', '₹ 8.5 Cr', '₹ 6.5 Cr', '₹ 2 Cr'),
        createData('large Cap Fund', '26,419', '₹ 7 Cr', '₹ 5 Cr', '₹ 2 Cr'),
        createData('Flexi Cap Fund', '35,109', '₹ 6.7 Cr', '₹ 6.7 Cr', '₹ 2 Cr'),
        createData('Multi Cap Fund', '30,651', '₹ 5 Cr', '₹ 4 Cr', '₹ 1 Cr'),
    ];
    const columns = [
        {
            id: 'Distributor',
            label: 'Distributor Name',
            //minWidth: 120,
            align: 'center',
            format: (value) => value.toLocaleString('en-US'),
        },
        {
            id: 'SIP_Count',
            label: 'Fresh SIP Count',
            //minWidth: 120,
            align: 'center',
            format: (value) => value.toLocaleString('en-US'),
        },

        {
            id: 'SIPCount2',
            label: 'Fresh SIP Count (Kfin)',
            //minWidth: 120,
            align: 'center',
            format: (value) => value.toLocaleString('en-US'),
        },
        {
            id: 'SIP_Bounced',
            label: 'SIP Bounced',
            //minWidth: 120,
            align: 'center',
            format: (value) => value.toLocaleString('en-US'),
        },
        {
            id: 'SIPBounced2',
            label: 'SIP Bounced (Kfin)',
            //minWidth: 120,
            align: 'center',
            format: (value) => value.toLocaleString('en-US'),
        },
    ];
    function createData(Distributor, SIP_Count, SIPCount2, SIP_Bounced, SIPBounced2) {
        return { Distributor, SIP_Count, SIPCount2, SIP_Bounced, SIPBounced2 };
    }
    return (
    
        <ScrollingTable
        rows={rows}
        columns={columns}
        headerProps={{
            heading: "Scheme Details",
            dropdownOptions: [{ title: "Top 10" }, { title: "Top 20" }, { title: "Top 50" }]
        }}
    />
    )
}

export default SchemeDetails