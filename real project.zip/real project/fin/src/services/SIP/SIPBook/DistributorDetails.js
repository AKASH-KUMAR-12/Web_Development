import { Grid } from '@mui/material'
import React, { useEffect, useState } from 'react'
import HeaderParent from '../../../utilityComponents/components/HeaderParent'
import Donut from '../../../utilityComponents/charts/Donut'
import VerticalBarChart from '../../../utilityComponents/charts/verticalBarChart'
import axios from 'axios'
import { useSelector } from 'react-redux'
import ScrollingTable from '../../../utilityComponents/Table'


const DistributorDetails = ({ data }) => {
    // const [data, setData] = useState([])
    // const investorData = useSelector((state) => state.filterData?.investor)
    // const zoneData = useSelector((state) => state.filterData?.zone)
    // const stateData = useSelector((state) => state.filterData?.state)
    // const assetclassData = useSelector((state) => state.filterData?.assetclass)
    // const assetcategoryData = useSelector((state) => state.filterData?.assetcategory)
    // const distributorData = useSelector((state) => state.filterData?.distributor)

    // useEffect(() => {
    //     fetchData();
    // }, [investorData, zoneData, stateData, assetclassData, assetcategoryData, distributorData])



    // const fetchData = async () => {
    //     const payload =
    //     {
    //         "fund": "101",
    //         "zone": zoneData,
    //         "investor": investorData,
    //         "query_name": "AssetCategory",
    //         "state": stateData,
    //         "assetclass": assetclassData,
    //         "assetcategory": assetcategoryData,
    //         "distributor": distributorData,
    //         "order": "DESC"
    //     }
    //     const response = await axios.post("/api/getaumData", payload)

    //     console.log(response.data);
    //     setData(response.data);
    //     return response;
    // }
    const columns = [
        {
          id: 'Distributor',
          label: 'Distributor Name',
          minWidth: 120,
          align: 'center',
          format: (value) => value.toLocaleString('en-US'),
        },
        {
          id: 'SIP_Count',
          label: 'SIP Count',
          minWidth: 120,
          align: 'center',
          format: (value) => value.toLocaleString('en-US'),
        },
      
        {
          id: 'SIP_Registered',
          label: 'SIP Registered',
          minWidth: 120,
          align: 'center',
          format: (value) => value.toLocaleString('en-US'),
        },
      ];
      
      function createData(Distributor, SIP_Count, SIP_Registered) {
        return { Distributor, SIP_Count, SIP_Registered };
      }
      
      const rows = [
        createData('Lalit Alai', '20,290', '₹ 9 Cr'),
        createData('Ashwain Kumar', '29,315', '₹ 8.5 Cr'),
        createData('Yuvraj Abhishek', '26,275', '₹ 7.5 Cr'),
        createData('Sumit Nath Jha', '35,368', '₹ 6.2 Cr'),
        createData('Sonakshi Goel', '30,258', '₹ 4.2 Cr'),
        createData('Manas Rastogi', '33,985', '₹ 9.3 Cr'),
        createData('Pranati Tiwari', '27,268', '₹ 4.5 Cr'),
        createData('Hardik Agrawal', '22,368', '₹ 4 Cr'),
        createData('Trina Koley', '37,258', '₹ 5.3 Cr'),
        createData('Aradhana Nayak', '41,235', '₹ 4.2 Cr'),
      ];
    return (
      <ScrollingTable
      rows={rows}
      columns={columns}
      headerProps={{
          heading: "Distributor Details",
          dropdownOptions: [{ title: "Top 10" }, { title: "Top 20" }, { title: "Top 50" }]
      }}/>
    )
}

export default DistributorDetails