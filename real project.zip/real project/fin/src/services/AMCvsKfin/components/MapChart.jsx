import React from 'react';
import ReactFC from 'react-fusioncharts';
import FusionCharts from 'fusioncharts';
import FusionMaps from 'fusioncharts/fusioncharts.maps';
import India from 'fusionmaps/maps/fusioncharts.india';
import Odisha from 'fusionmaps/maps/fusioncharts.odisha';
import Maharashtra from 'fusionmaps/maps/fusioncharts.maharashtra';
import AndraPradesh from 'fusionmaps/maps/fusioncharts.andhrapradesh';
import arunachalpradesh from 'fusionmaps/maps/fusioncharts.arunachalpradesh';
import Rajasthan from 'fusionmaps/maps/fusioncharts.rajasthan';
import Bihar from 'fusionmaps/maps/fusioncharts.bihar';
import Assam from 'fusionmaps/maps/fusioncharts.assam';
import Nagaland from 'fusionmaps/maps/fusioncharts.nagaland';
import Punjab from 'fusionmaps/maps/fusioncharts.punjab';
import gujarat from 'fusionmaps/maps/fusioncharts.gujarat';
import delhi from 'fusionmaps/maps/fusioncharts.delhi';
import chandigarh from 'fusionmaps/maps/fusioncharts.chandigarh';
import chhattisgarh from 'fusionmaps/maps/fusioncharts.chhattisgarh';
import goa from 'fusionmaps/maps/fusioncharts.goa';
import haryana from 'fusionmaps/maps/fusioncharts.haryana';
import himachalpradesh from 'fusionmaps/maps/fusioncharts.himachalpradesh';
import jammuandkashmir from 'fusionmaps/maps/fusioncharts.jammuandkashmir';
import jharkhand from 'fusionmaps/maps/fusioncharts.jharkhand';
import karnataka from 'fusionmaps/maps/fusioncharts.karnataka';
import kerala from 'fusionmaps/maps/fusioncharts.kerala';
import madhyapradesh from 'fusionmaps/maps/fusioncharts.madhyapradesh';
import manipur from 'fusionmaps/maps/fusioncharts.manipur';
import meghalaya from 'fusionmaps/maps/fusioncharts.meghalaya';
import mizoram from 'fusionmaps/maps/fusioncharts.mizoram';
import puducherry from 'fusionmaps/maps/fusioncharts.puducherry';
import sikkim from 'fusionmaps/maps/fusioncharts.sikkim';
import tamilnadu from 'fusionmaps/maps/fusioncharts.tamilnadu';
import uttarakhand from 'fusionmaps/maps/fusioncharts.uttarakhand';
import uttarpradesh from 'fusionmaps/maps/fusioncharts.uttarpradesh';
import westbengal from 'fusionmaps/maps/fusioncharts.westbengal';
import telangana from 'fusionmaps/maps/fusioncharts.telangana';
import dadraandnagarhaveli from 'fusionmaps/maps/fusioncharts.dadraandnagarhaveli';
import damananddiu from 'fusionmaps/maps/fusioncharts.damananddiu';
import tripura from 'fusionmaps/maps/fusioncharts.tripura';
import FusionTheme from 'fusioncharts/themes/fusioncharts.theme.fusion';
import MapTable from './MapTable';
import { Box, FormControlLabel, Grid, Radio, RadioGroup } from '@mui/material';
ReactFC.fcRoot(FusionCharts, FusionMaps, India,
    Odisha,
    Maharashtra,
    jharkhand,
    AndraPradesh,
    Rajasthan,
    Bihar,
    Assam,
    Nagaland,
    Punjab,
    arunachalpradesh,
    gujarat,
    dadraandnagarhaveli,
    damananddiu,
    delhi,
    chandigarh,
    chhattisgarh,
    goa,
    haryana,
    himachalpradesh,
    jammuandkashmir,
    jharkhand,
    karnataka,
    kerala,
    madhyapradesh,
    manipur,
    meghalaya,
    mizoram,
    puducherry,
    sikkim,
    tamilnadu,
    uttarakhand,
    uttarpradesh,
    westbengal,
    telangana,
    tripura,
    FusionTheme);

const mapData = [
    { "id": "001", "value": 2834, "link": "newchart-json-AP", fontColor: "#96967F" },
    { "id": "002", "value": 3182, "link": "newchart-json-AP" },
    { "id": "003", "value": 2280, "link": "newchart-json-AP" },
    { "id": "004", "value": 2911, "link": "newchart-json-AP" },
    { "id": "005", "value": 2292, "link": "newchart-json-AP" },
    { "id": "006", "value": 530, "link": "newchart-json-AP" },
    { "id": "007", "value": 1515, "link": "newchart-json-AP" },
    { "id": "008", "value": 2515, "link": "newchart-json-AP" },
    { "id": "009", "value": 728, "link": "newchart-json-AP" },
    { "id": "010", "value": 974, "link": "newchart-json-AP" },
    { "id": "011", "value": 1848, "link": "newchart-json-AP", fontColor: "#96967F" },
    { "id": "012", "value": 1278, "link": "newchart-json-AP" },
    { "id": "013", "value": 463, "link": "newchart-json-AP" },
    { "id": "014", "value": 198, "link": "newchart-json-AP" },
    { "id": "015", "value": 378, "link": "newchart-json-AP" },
    { "id": "016", "value": 2610, "link": "newchart-json-AP" },
    { "id": "017", "value": 3200, "link": "newchart-json-AP" },
    { "id": "018", "value": 3820, "link": "newchart-json-AP" },
    { "id": "019", "value": 940, fontColor: "#96967F" },
    { "id": "020", "value": 1416, "link": "newchart-json-AP" },
    { "id": "021", "value": 1004, "link": "newchart-json-AP" },
    { "id": "022", "value": 2604, "link": "newchart-json-AP" },
    { "id": "023", "value": 4011, "link": "newchart-json-AP" },
    { "id": "024", "value": 2203, "link": "newchart-json-AP" },
    { "id": "025", "value": 2775, "link": "newchart-json-AP" },
    { "id": "026", "value": 2721, "link": "newchart-json-AP" },
    { "id": "027", "value": 3417, "link": "newchart-json-AP", fontColor: "#96967F" },
    { "id": "028", "value": 347, "link": "newchart-json-AP" },
    { "id": "029", "value": 1530, "link": "newchart-json-AP" },
    { "id": "030", "value": 2530, "link": "newchart-json-AP" },
    { "id": "031", "value": 3530, "link": "newchart-json-AP" },
    { "id": "032", "value": 2530, "link": "newchart-json-AP" },
    { "id": "033", "value": 530, "link": "newchart-json-AP" },
    { "id": "034", "value": 120, "link": "newchart-json-AP" },
    { "id": "035", "value": 2520, "link": "newchart-json-AP" },
    { "id": "036", "value": 3530, "link": "newchart-json-AP" },
    { "id": "037", "value": 520, "link": "newchart-json-AP" },
]
const ChartConfig = {
    "chart": {
        "animation": "1",
        "showLabels": "1",
        "entityFillColor": "#A8A8A8",
        "entityFillHoverColor": "#E5E5E9",
        "theme": "fusion",
        "showBorder": "1",
        "bordercolor": "#FFFFFF",
        "entityborderThickness": "1",
        "fillColor": "#19a6f8",
        "fillAlpha": 100,
        "nullEntityColor": "#19a6f8",
        "showlegend": "0",
    }
}
const LinkData = [{
    "id": "AP",
    "linkedchart": ChartConfig
}
]
const colorrange = {
    "minvalue": "0",
    "startlabel": "Low",
    "endlabel": "High",
    "code": "#2c46f2",
    "gradient": "0",
    "color": [
        { "maxvalue": "2000", "code": "#4990F0" },
        { "maxvalue": "3000", "code": "#8ED8B7" },
        { "maxvalue": "1000", "code": "#7CD4DE" },
        { "maxvalue": "4000", "code": "#BA87ED" },
    ]
};

const chartConfigs = {
    type: 'maps/india',
    width: '48%',
    height: '500',
    dataFormat: 'json',
    dataSource: {
        "chart": {
            chartLeftMargin: "40",
            chartRightMargin: "0",
            chartTopMargin: "0",
            chartBottomMargin: "0",
            showLabels: "1",
            includeNameInLabels: "1",
            useSNameInLabels: "0",
            baseFontColor: "#ffffff",
            baseFontSize: 10,
            borderColor: "#FFFFFF",
            borderAlpha: "100",
            "animation": "0",
            "showbevel": "0",
            "usehovercolor": "1",
            "showlegend": "0",
            toolTipBgColor: "#000000",
            "showBorder": "1",
            "bordercolor": "#FFFFFF",
            "entityborderThickness": "1.5",
            "entityFillHoverColor": "#5AC1FD",
            "connectorcolor": "#000000",
            "hovercolor": "#E5E5E9",
            "theme": "fusion"
        },
        connectors: {
            thickness: 10,
            color: "#ffffff"
        },
        "colorrange": colorrange,
        "data": mapData,
        "linkeddata": LinkData
    },
    "events": {
        "renderComplete": function (e) {
            e.sender.configureLink({
                "type": "maps/india"
            }, 0);

            e.sender.addEventListener("entityClick", function (eventObj, dataObj) {
                const clickedRegion = dataObj.id;


                const regionToChartType = {
                    "001": "maps/andamanandnicobar",
                    "002": "maps/andhrapradesh",
                    "003": "maps/arunachalpradesh",
                    "004": "maps/assam",
                    "005": "maps/bihar",
                    "006": "maps/chandigarh",
                    "007": "maps/chhattisgarh",
                    "008": "maps/dadraandnagarhaveli",
                    "009": "maps/damananddiu",
                    "010": "maps/delhi",
                    "011": "maps/goa",
                    "012": "maps/gujarat",
                    "013": "maps/haryana",
                    "014": "maps/himachalpradesh",
                    "015": "maps/jammuandkashmir",
                    "016": "maps/jharkhand",
                    "017": "maps/karnataka",
                    "018": "maps/kerala",
                    "019": "maps/lakshadweep",
                    "020": "maps/madhyapradesh",
                    "021": "maps/maharashtra",
                    "022": "maps/manipur",
                    "023": "maps/meghalaya",
                    "024": "maps/mizoram",
                    "025": "maps/nagaland",
                    "026": "maps/odisha",
                    "027": "maps/puducherry",
                    "028": "maps/punjab",
                    "029": "maps/rajasthan",
                    "030": "maps/sikkim",
                    "031": "maps/tamilnadu",
                    "032": "maps/tripura",
                    "033": "maps/uttarpradesh",
                    "034": "maps/uttarakhand",
                    "035": "maps/westbengal",
                    "036": "maps/telangana",
                    "037": "maps/jammuandkashmir",
                };
                const linkedChartType = regionToChartType[clickedRegion];
                if (linkedChartType) {
                    e.sender.configureLink({
                        "type": linkedChartType
                    }, 0);
                }
            });

        }
    }
};



const MapChart = () => {
    return (
        <Grid item xs={12} md={12} >
            <div
                style={{
                    display: "flex",
                    justifyContent: "space-between",
                    borderBottom: "2px solid #b9b9b9",
                    marginBottom: "1px"
                }}
            >
                <div
                    style={{ display: "flex", alignItems: "center", margin: "10px" }}
                >
                    <p style={{ fontWeight: "bold" }}>Investor Demography - Location</p>
                </div>
            </div>

            <Box sx={{ display: 'flex', justifyContent: "center", alignItems: "center", flexWrap: "wrap", width: "95%", paddingBlock: "2%" }}>
                <ReactFC {...chartConfigs} />
                <Box sx={{
                    width: {
                        md: "30%",
                    }, position: "relative",
                }} >
                    <div>
                        <p style={{ borderLeft: "1rem solid #7CD4DE", height: "0.9rem", margin: "0 1rem 0 1rem", fontSize: "0.8rem", padding: "0.1rem 0 0 0.5rem" }}>North</p>
                        <p style={{ borderLeft: "1rem solid #BA87ED", height: "0.9rem", margin: "0.5rem 1rem 0 1rem", fontSize: "0.8rem", padding: "0.1rem 0 0 0.5rem" }}>South</p>
                        <p style={{ borderLeft: "1rem solid #4990F0", height: "0.9rem", margin: "0.5rem 1rem 0 1rem", fontSize: "0.8rem", padding: "0.1rem 0 0 0.5rem" }}>West</p>
                        <p style={{ borderLeft: "1rem solid #8ED8B7", height: "0.9rem", margin: "0.5rem 1rem 0 1rem", fontSize: "0.8rem", padding: "0.1rem 0 0 0.5rem" }}>East</p>
                    </div>
                    <RadioGroup
                        sx={{
                            '& .MuiSvgIcon-root': {
                                fontSize: "0.7rem",
                            },
                            '& .MuiTypography-root': {
                                fontSize: ".8rem"
                            },
                            padding: 2

                        }}
                        row
                        aria-labelledby="demo-radio-buttons-group-label"
                        defaultValue="region"
                        name="radio-buttons-group"
                    >
                        <FormControlLabel value="region" sx={{}} control={<Radio />} label="Region" />
                        <FormControlLabel value="state" sx={{}} control={<Radio />} label="State" />
                        <FormControlLabel value="city" sx={{}} control={<Radio />} label="City" />
                    </RadioGroup>
                    <MapTable />
                </Box>
            </Box>
        </Grid>
    );
}


export default MapChart
