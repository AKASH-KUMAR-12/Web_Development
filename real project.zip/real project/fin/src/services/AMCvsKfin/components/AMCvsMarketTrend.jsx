import React from "react";
import { Grid, Paper, styled } from "@mui/material";
// import "../../SIPBookComp/components/style/style.css";
import LineChart from "../../../newCharts/charts/LineChart";

const AMCvsMarketTrend = () => {
  const [value, setValue] = React.useState("AUM");
  const handleChange = (event) => {
    setValue(event.target.value);
  };
  const Item = styled(Paper)(({ theme }) => ({
    backgroundColor: '#fff',
    padding: theme.spacing(1),
    border: 0,
  }));
  const data1 = [
    {
      label: "JAN",
      value: "15"
    },
    {
      label: "FEB",
      value: "22"
    },
    {
      label: "MAR",
      value: "40"
    },
    {
      label: "APR",
      value: "30"
    },
    {
      label: "MAY",
      value: "44"
    },
    {
      label: "JUN",
      value: "40"
    },
    {
      label: "JULY",
      value: "55"
    },
    {
      label: "AUG",
      value: "60",

    },
    {
      label: "SEP",
      value: "70",

    },
    {
      label: "OCT",
      value: "75",

    },
    {
      label: "NOV",
      value: "78",

    },
    {
      label: "DEC",
      value: "80",
    }
  ]

  const data2 = [{
    label: "AUG",
    value: "60",

  },
  {
    label: "SEP",
    value: "70",

  },
  {
    label: "OCT",
    value: "75",

  },
  {
    label: "NOV",
    value: "78",

  },
  {
    label: "DEC",
    value: "80",
  }]

  return (
    <Grid container sx={{ margin: "2% 0 0 0", "& .css-1ik6aa3-MuiPaper-root": { backgroundColor: "#fff", height: "auto" } }}>
      <Grid item xs={11.8} sx={{ "& .css-1ik6aa3-MuiPaper-root": { boxShadow: 6, padding: "0" } }}>
        <Item elevation={8} sx={{ borderRadius: "8px" }}>
          <h3 style={{ padding: "0.5rem" }}>AMC vs Market Share Trend Graph</h3>
          <hr style={{ backgroundColor: "#b9b9b9" }} />
          <div style={{ margin: "0.7rem" }}>
            <LineChart data={data1} xAxisName={"AMC's Name"} yAxisName={"Market Share in Percentage"} />
          </div>
        </Item>

      </Grid>
    </Grid>
  );
};

export default AMCvsMarketTrend;
