import React from 'react'
import { styled } from '@mui/material/styles';
import Grid from '@mui/material/Unstable_Grid2';
import Paper from '@mui/material/Paper';
import { useSelector } from 'react-redux';
import OverlappedBarChart from '../../../newCharts/charts/OverlappedBarChart';
const Item = styled(Paper)(({ theme }) => ({
    backgroundColor: '#E3EAF3',
    padding: theme.spacing(1),
    border: 0,
}));

const SchemeSubCatagory = () => {
    const amcAtGlanceData = useSelector((state) => state.CurrentApiData?.AmcAtGlanceApiResponse)
    console.log("amcAtGlanceData", amcAtGlanceData);
    const donutData = [
        {
            "label": "Debt",
            "value": "45"
        },
        {
            "label": "Equity",
            "value": "45"
        },
        {
            "label": "Hybrid",
            "value": "10"
        },
    ]
    let transactionCatagoryData = [{
        chartData: [
            {
                "label": "Small Cap Fund",
                "value": "15"
            },
            {
                "label": "Ultra Short Term Fund",
                "value": "45"
            },
            {
                "label": "Mid Cap Fund",
                "value": "30"
            },
            {
                "label": "Overnight Fund",
                "value": "22"
            }
            ,
            {
                "label": "Multicap Fund",
                "value": "32"
            }
            ,
            {
                "label": "Equity Hybrid Fund",
                "value": "42"
            },
        ],
        chartAxis:
        {
            xName: "Scheme Sub Catagory", yName: "Value in Thousands"
        }
    }]
    return (
        <>
            <Grid container spacing={1} sx={{ margin: "2% 1% 0 0", "& .css-1ik6aa3-MuiPaper-root": { backgroundColor: "#fff", height: "auto" } }}>
                <Grid xs={12} sx={{ "& .css-1ik6aa3-MuiPaper-root": { boxShadow: 6, padding: "0" } }}>
                    <Item>
                        <Grid container>
                            <Grid item xs={4}>
                                <h4 style={{ padding: "0.5rem" }}>Scheme Sub Category</h4>
                            </Grid>
                            <Grid item xs={4} display={"flex"} alignItems={"center"} justifyContent={"center"} >
                                <p style={{ height: "1rem", borderLeft: "1rem solid #2057A6", fontSize: ".8rem", margin: "0rem 0.2rem", padding: "0rem .5rem" }}>PGIM Share</p>
                                <p style={{ height: "1rem", borderLeft: "1rem solid #69b8f4", fontSize: ".8rem", margin: "0rem 0.2rem", padding: "0rem .5rem" }}>Kfin Share</p>
                            </Grid>
                        </Grid>
                        <hr style={{ backgroundColor: "#b9b9b9" }} />
                        <div style={{ margin: "0.7rem" }}>
                            <OverlappedBarChart yAxisName={"Value in Thousands"} xAxisName={"PMIG Scheme Name"} data={transactionCatagoryData[0]} />
                        </div>
                    </Item>

                </Grid>
            </Grid>
        </>
    )
}

export default SchemeSubCatagory