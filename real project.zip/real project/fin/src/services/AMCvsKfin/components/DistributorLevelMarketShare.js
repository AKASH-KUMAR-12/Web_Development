import React from 'react'
import DualAxisColumnChart from '../subcomponents/DualAxisColumnChart'
import { Grid, Paper, styled } from '@mui/material'

const DistributorLevelMarketShare = () => {
    const Item = styled(Paper)(({ theme }) => ({
        backgroundColor: '#E3EAF3',
        padding: theme.spacing(1),
        border: 0,
    }));
    return (
        <>
            <Grid container sx={{ margin: "2% 0 0 0", "& .css-1ik6aa3-MuiPaper-root": { height: "auto" } }}>
                <Grid item xs={11.8} sx={{ "& .css-1ik6aa3-MuiPaper-root": { boxShadow: 6, padding: "0" } }}>
                    <Item elevation={8} sx={{ borderRadius: "8px", backgroundColor: "#fff" }}>
                        <Grid container>
                            <Grid item xs={4}>
                                <h4 style={{ padding: "0.5rem" }}>Distributor Level Market Share</h4>
                            </Grid>
                            <Grid item xs={4} display={"flex"} alignItems={"center"} justifyContent={"center"} >
                                <p style={{ height: "1rem", borderLeft: "1rem solid #2057A6", fontSize: ".8rem", margin: "0rem 0.2rem", padding: "0rem .5rem" }}>PGIM Share</p>
                                <p style={{ height: "1rem", borderLeft: "1rem solid #69b8f4", fontSize: ".8rem", margin: "0rem 0.2rem", padding: "0rem .5rem" }}>Kfin Share</p>
                                <p style={{ height: "1rem", borderLeft: "1rem solid #8ed8b7", fontSize: ".8rem", margin: "0rem 0.2rem", padding: "0rem .5rem" }}>Market Share</p>
                            </Grid>
                        </Grid>


                        <hr style={{ backgroundColor: "#b9b9b9" }} />
                        <div style={{ margin: "0.7rem" }}>

                            <DualAxisColumnChart />
                        </div>
                    </Item>

                </Grid>
            </Grid>
        </>
    )
}

export default DistributorLevelMarketShare