import FusionCharts from "fusioncharts";
import charts from "fusioncharts/fusioncharts.charts";
import ReactFusioncharts from "react-fusioncharts";
import React, { useEffect, useRef } from 'react'

const TransCategoryBarChart = ({ data }) => {
    charts(FusionCharts);
    const { chartData, chartAxis } = data;
    const chartRef = useRef(null);
    useEffect(() => {
        if (chartRef.current && chartRef.current.parentElement) {
            const containerWidth = chartRef.current.parentElement.offsetWidth;
            FusionCharts.items[chartRef.current.id].resizeTo(containerWidth);
        }
    }, []);
    const dataSource = {

        "chart": {
            theme: "fusion",
            labelFontSize: "10",
            yAxisValueFontSize: "10",
            xAxisNameFontSize: "10",
            yAxisNameFontSize: "10",
            xAxisNameFont: "Roboto",
            yAxisNameFont: "Roboto",
            xAxisNameFontColor: "#909090",
            yAxisNameFontColor: "#909090",
            plotSpacePercent: 50,
            chartTopMargin: "30",
            chartBottomMargin: "10",
            yAxisName: chartAxis.yName,
            xAxisName: chartAxis.xName,
            alignCaptionWithCanvas: "0",
            showBorder: "0",
            showcanvasborder: "0",
            bgColor: "#FFFFFF",
            showYAxisLine: "1",
            yAxisLineColor: "#807878",
            showAlternateVGridColor: "0",
            divLineColor: "#cdd4cf",
            plotBorderColor: "#FFFFFF",
            plotFillRatio: "100",
            paletteColors: "#80d8b7, #2057a6, #06adcf, #5193c9, #51c985, #c951a7,#BA87ED",
            labelDisplay: "wrap"
        },
        data: chartData
    };

    return (
        <ReactFusioncharts
            type="bar2d"
            width="100%"
            height="90%"
            dataFormat="JSON"
            dataSource={dataSource}
            ref={chartRef}
        />
    );
}






export default TransCategoryBarChart