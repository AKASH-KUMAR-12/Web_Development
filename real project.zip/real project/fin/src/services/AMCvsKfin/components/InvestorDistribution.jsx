import React from 'react'
import { Grid, Paper, styled } from "@mui/material";
import VerticalBarChart from '../../../newCharts/charts/verticalBarChart';
import Radio from "@mui/material/Radio";
import RadioGroup from "@mui/material/RadioGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import FormControl from "@mui/material/FormControl";

const InvestorDistribution = () => {
  const Item = styled(Paper)(({ theme }) => ({
    backgroundColor: '#fff',
    padding: theme.spacing(1),
  }));
  const data = [
    {
      label: "<18",
      value: "9"
    },
    {
      label: "18-25",
      value: "30"
    },
    {
      label: "25-35",
      value: "57"
    },
    {
      label: "35-45",
      value: "95"
    },
    {
      label: "45-55",
      value: "22"
    },
    {
      label: "55-65",
      value: "35"
    },
    {
      label: ">65",
      value: "88"
    }
  ]

  const [value, setValue] = React.useState("Age");

  const font_size = window.innerWidth <= 400 ? "5" : "10";
  const handleChange = (event) => {
    setValue(event.target.value);
  };
  return (
    <Grid container spacing={2} sx={{ borderRadius: "8px", marginBottom: "20px", marginTop: "10px" }}>
      <Grid item xs={12} md={11.8} sx={{ "& .css-1ik6aa3-MuiPaper-root": { boxShadow: 6, padding: "0" } }}>
        <Item elevation={8}>
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              borderBottom: "2px solid #b9b9b9",
              marginBottom: "1px"
            }}
          >
            <div
              style={{ display: "flex", alignItems: "center", marginLeft: "10px", }}
            >
              <p style={{ fontWeight: "bold" }}>Investor Distribution</p>
            </div>


            <div>

              <FormControl>
                <RadioGroup
                  sx={{
                    '& .MuiTypography-root': {
                      fontSize: '.8rem',
                    }
                  }}
                  row
                  aria-labelledby="demo-controlled-radio-buttons-group"
                  name="controlled-radio-buttons-group"
                  value={value}
                  onChange={handleChange}
                >
                  <FormControlLabel
                    value="Age"
                    control={<Radio />}
                    label="Age"
                  />
                  <FormControlLabel
                    value="Gender"
                    control={<Radio />}
                    label="Gender"
                  />
                  <FormControlLabel
                    value="Occupation"
                    control={<Radio />}
                    label="Occupation"
                  />
                </RadioGroup>
              </FormControl>
            </div>
          </div>
          <div >
            <VerticalBarChart data={data} xAxisName={"Investor"} yAxisName={"Average AUM"} />
          </div>
        </Item>
      </Grid>
    </Grid>
  )
}

export default InvestorDistribution