import React from 'react'
import { styled } from '@mui/material/styles';
import Grid from '@mui/material/Unstable_Grid2';
import Paper from '@mui/material/Paper';
import Donut from '../../../newCharts/charts/Donut';
import { useSelector } from 'react-redux';
import OverlappedBarChart from '../subcomponents/OverlappedBarChart';
import HoverableDropdown from '../subcomponents/Dropdown';
import topBarFilterImg from "../../../images/topBarFilterIcon.png";
const Item = styled(Paper)(({ theme }) => ({
    backgroundColor: '#E3EAF3',
    padding: theme.spacing(1),
    border: 0,
}));

const AssetClassSchemeCategory = () => {
    const amcAtGlanceData = useSelector((state) => state.CurrentApiData?.AmcAtGlanceApiResponse)
    console.log("amcAtGlanceData", amcAtGlanceData);
    const donutData = [
        {
            "label": "Cash",
            "value": "45"
        },
        {
            "label": "Debt",
            "value": "75"
        },
        {
            "label": "Equity",
            "value": "30"
        },
    ]

    return (
        <>
            <Grid container spacing={1} sx={{ margin: "1% 1% 0 0", "& .css-1ik6aa3-MuiPaper-root": { backgroundColor: "#fff", height: "auto" } }}>
                <Grid xs={12} md={5} sx={{ "& .css-1ik6aa3-MuiPaper-root": { boxShadow: 6, padding: "0" } }}>
                    <Item>
                        <h4 style={{ padding: "0.5rem" }}>Asset Class wise Market Share</h4>
                        <hr style={{ backgroundColor: "#b9b9b9" }} />
                        <div style={{ margin: "0.4rem", }}>
                            <Donut data={donutData} />
                        </div>
                    </Item>

                </Grid>
                <Grid xs={12} md={7} sx={{ "& .css-1ik6aa3-MuiPaper-root": { boxShadow: 6, padding: "0" } }}>
                    <Item>
                        <Grid container>
                            <Grid item xs={3.5}>
                                <h4 style={{ padding: "0.5rem" }}>Scheme Category</h4>
                            </Grid>
                            <Grid item xs={4.5} display={"flex"} alignItems={"center"} >
                                <p style={{ height: "1rem", borderLeft: "1rem solid #2057A6", fontSize: ".8rem", margin: "0rem 0.2rem", padding: "0rem .5rem" }}>PGIM Share</p>
                                <p style={{ height: "1rem", borderLeft: "1rem solid #69b8f4", fontSize: ".8rem", margin: "0rem 0.2rem", padding: "0rem .5rem" }}>Kfin Share</p>
                            </Grid>
                            <Grid item xs={4} style={{ display: "flex", alignItems: "center" }}>

                                <img
                                    src={topBarFilterImg}
                                    alt="FilterBtn"
                                    style={{ height: "36px", cursor: "pointer" }}
                                />

                                <HoverableDropdown />

                            </Grid>
                        </Grid>
                        <hr style={{ backgroundColor: "#b9b9b9" }} />
                        <div style={{ margin: "0.7rem" }}>
                            <OverlappedBarChart yAxisName={"Value in Crores"} xAxisName={"PGIM Scheme Names"} />
                        </div>
                    </Item>

                </Grid>
            </Grid>
        </>
    )
}

export default AssetClassSchemeCategory