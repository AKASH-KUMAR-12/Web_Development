import * as React from 'react';
import { styled } from '@mui/material/styles';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell, { tableCellClasses } from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';

const StyledTableCell = styled(TableCell)(({ theme }) => ({
    [`&.${tableCellClasses.head}`]: {
        backgroundColor: "#4990F0",
        color: theme.palette.common.white,
    },
    [`&.${tableCellClasses.body}`]: {
        fontSize: '.8rem',
    },
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
    '&:nth-of-type(odd)': {
        backgroundColor: theme.palette.action.hover,
    },
    '&:last-child td, &:last-child th': {
        border: 0,
    },
}));

function createData(region, marketShare, aum) {
    return { region, marketShare, aum };
}

const rows = [
    createData('North', "5,98,043", 110.52),
    createData('South', "6,42,654", 100.23),
    createData('East', "7,98,450", 167.12),
    createData('West', "3,67,098", 142.28)

];

export default function MapTable() {
    return (

        <TableContainer component={Paper} sx={{ maxWidth: "95%", marginInline: 2, boxShadow: 4 }} >
            <Table aria-label="customized table" size="small">
                <TableHead >
                    <TableRow>
                        <StyledTableCell align="center" sx={{ fontSize: "0.7rem", }}>Region</StyledTableCell>
                        <StyledTableCell align="center" sx={{ fontSize: "0.7rem" }}>Market Share</StyledTableCell>
                        <StyledTableCell align="center" sx={{ fontSize: "0.7rem" }}>AUM (Cr.)</StyledTableCell>
                    </TableRow>
                </TableHead>
                <TableBody>
                    {rows.map((row) => (
                        <StyledTableRow key={row.region} >
                            <StyledTableCell component="th" scope="row" align="center" >
                                {row.region}
                            </StyledTableCell>
                            <StyledTableCell align="center" >{row.marketShare}</StyledTableCell>
                            <StyledTableCell align="center" >{row.aum}</StyledTableCell>

                        </StyledTableRow>
                    ))}
                </TableBody>
            </Table>
        </TableContainer>
    );
}