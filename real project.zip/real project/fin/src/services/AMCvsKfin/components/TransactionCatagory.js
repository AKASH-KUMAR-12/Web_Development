import React from 'react';
import { styled } from '@mui/material/styles';
import Grid from '@mui/material/Unstable_Grid2';
import Paper from '@mui/material/Paper';
import TransCategoryVerticalBarChart from '../subcomponents/TransCategoryVerticalBarChart';
import { DatePicker, LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterMoment } from '@mui/x-date-pickers/AdapterMoment';
import { Box } from '@mui/material';
import moment from 'moment';

const Item = styled(Paper)(({ theme }) => ({
  backgroundColor: '#fff',
  padding: theme.spacing(1),
  border: 0,
}));
const row1_blueCard = { height: "5.5rem", marginBottom: "0.8rem", marginRight: "0.5rem", "border-radius": "0.5rem", color: "#fff", boxShadow: 0 };
const data = [
  {
    label: "Axis",
    value: "97"
  },
  {
    label: "Nippon",
    value: "93"
  },
  {
    label: "Bajaj",
    value: "87"
  },
  {
    label: "Edelweiss",
    value: "85"
  },
  {
    label: "Sundaram",
    value: "79"
  },
  {
    label: "Canara",
    value: "75",
    color: "#2057A6"
  },
  {
    label: "BOI",
    value: "68"
  },
  {
    label: "Motilal",
    value: "63"
  },
  {
    label: "Mirae",
    value: "58"
  },
  {
    label: "Invesco",
    value: "51"
  }
]
let trData = [
  {
    "name": "AMC AUM",
    "value": " 76259.28 Cr"
  },
  {
    "name": "Industry AUM",
    "value": " 40,56,209 Cr"
  },
  {
    "name": "Market Share",
    "value": " 1.88% Cr"
  }
]
const TransactionCatagory = () => {
  return (
    <>
      <Grid container spacing={1} sx={{ margin: "0 1% 0 0", "& .css-1ik6aa3-MuiPaper-root": { backgroundColor: "#fff", height: "auto" } }}>
        <Grid xs={12} md={3} sx={{ "& .css-1ik6aa3-MuiPaper-root": { boxShadow: 6 } }}>
          {
            trData.map((item, i) => {
              return (<Item className='background' key={i} sx={{ ...row1_blueCard }} >
                <h4 style={{ margin: "1rem" }}>{item.name}</h4>
                <h3 style={{ margin: "1rem" }}>&#8377;{item.value}</h3>
              </Item>)
            })
          }


        </Grid>

        <Grid xs={12} md={9} sx={{ "& .css-1ik6aa3-MuiPaper-root": { boxShadow: 6, padding: "0" } }}>
          <Item elevation={8} sx={{ height: { xs: "400px", md: "90%" }, borderRadius: "8px", padding: "0 .5rem 1rem .5rem" }}>
            <Grid container padding={".2rem 0"}>
              <Grid item xs={4}>
                <h3 style={{ padding: "0.5rem" }}>Transaction Category</h3>
              </Grid>
              <Grid display={"flex"} alignItems={"center"} justifyContent={"center"} item xs={4}>
                <p style={{ height: "1rem", borderLeft: "1rem solid #2057A6", fontSize: ".8rem", margin: "0rem 0.5rem", padding: "0rem .5rem" }}>PGIM</p>
                <p style={{ height: "1rem", borderLeft: "1rem solid #69b8f4", fontSize: ".8rem", margin: "0rem 0.5rem", padding: "0rem .5rem" }}>Other AMC</p>
              </Grid>
              <Grid item xs={4} style={{ display: "flex", alignItems: "center", justifyContent: "flex-end" }}>


                <p style={{ marginInline: "6px", fontWeight: "500", fontSize: ".8rem" }}>Select FY</p>
                <Box sx={{ width: "120px", "& .css-o9k5xi-MuiInputBase-root-MuiOutlinedInput-root": { height: "2rem" } }}>
                  <LocalizationProvider dateAdapter={AdapterMoment}>
                    <DatePicker
                      disableFuture
                      views={["year"]}
                      minDate={moment('01 /01 / 2000')}
                      slotProps={{ textField: { size: "small" } }}
                      sx={{
                        boxShadow: "rgba(99, 99, 99, 0.2) 0px 2px 8px 0px",
                      }}
                    />
                  </LocalizationProvider>
                </Box>
              </Grid>
            </Grid>


            <hr style={{ backgroundColor: "#b9b9b9" }} />
            <div style={{ height: "90%", width: "98%", position: "relative" }}>
              <TransCategoryVerticalBarChart data={data} xAxisName={"AMC's"} yAxisName={"AUM"} />
            </div>
          </Item>

        </Grid>
      </Grid>

    </>
  )
}

export default TransactionCatagory