import React from 'react'
import FusionCharts from "fusioncharts";
import charts from "fusioncharts/fusioncharts.charts";
import ReactFusioncharts from "react-fusioncharts";

charts(FusionCharts);

const SchemeCategoryBarChart = ({ data, xAxisName, yAxisName }) => {
    const dataSource = {
        "chart": {
            "xAxisName": xAxisName,
            "yAxisName": yAxisName,
            "theme": "fusion",
            xAxisName: xAxisName,
            yAxisName: yAxisName,
            xAxisNameFont: "Roboto",
            yAxisNameFont: "Roboto",
            xAxisNameFontSize: "12",
            yAxisNameFontSize: "12",
            labelFontSize: "10",
            yAxisValueFontSize: "10",
            bgcolor: "#FFFFFF",
            "showxaxisline": "1",
            "showyaxisline": "1",
            color: "#FFFFFF",
            patterBgColor: "#FFFFFF",
            theme: 'fusion',
            barCategoryGap: 1,
            "chartBottomMargin": "10",
            pallete: 5,
            divLineColor: "#00080a",
            animation: 0,
            drawCrossLine: 1,
            crossLineAnimation: 0,
            plottooltext: "seriesname: value Cr",
            toolTipWidth: "400px",
            divLineColor: "#00080a",
            showBorder: false,
            palettecolors: "#2057A6,#69B8F4,#8ED8B7,#82C7ED,#8FABD3,#BA87ED",
            toolTipFontSize: 6,
            plotSpacePercent: 50,
            showLegend: 0
        },
        "categories": [{
            "category": [{
                "label": "Small Cap Fund"
            }, {
                "label": "Overnight Fund"
            }, {
                "label": "Short Duration Fund"
            }, {
                "label": "Small Cap Fund"
            }, {
                "label": "Dynamic Bond Fund"
            }, {
                "label": "MidCap Opportunity"
            }]
        }],
        "dataset": [{
            "seriesname": "Kfin Share",
            "data": [{
                "value": "40"
            }, {
                "value": "36"
            }, {
                "value": "25"
            }, {
                "value": "28"
            }, {
                "value": "32"
            }, {
                "value": "29"
            }]
        }, {
            "seriesname": "PMIG Share",
            "data": [{
                "value": "-40"
            }, {
                "value": "-36"
            }, {
                "value": "-25"
            }, {
                "value": "-28"
            }, {
                "value": "-32"
            }, {
                "value": "-19"
            }]
        }]
    }

    return (
        <ReactFusioncharts
            type="stackedbar2d"
            width="100%"
            height="37%"
            dataFormat="JSON"
            dataSource={dataSource}
        />
    )
}

export default SchemeCategoryBarChart