import React, { useState } from 'react';
import { styled } from "@mui/material/styles";
import { MenuItem } from '@mui/material';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import KeyboardArrowUpIcon from '@mui/icons-material/KeyboardArrowUp';
function HoverableDropdown() {
    const [isDropdownVisible, setDropdownVisible] = useState(false);
    const [dropdownValue, setDropdownValue] = useState({ value: "0", title: "Choose Asset Class", sTitle: "" })
    const data = [
        { value: "1", title: "Small Cap Fund" },
        { value: "2", title: "Overnight Fund" },
        { value: "3", title: "Short Duration Fund" },
        { value: "4", title: "Dynamic Bond Fund" },
        { value: "5", title: "Midcap Opportunity" }
    ]
    const handleMouseEnter = () => {
        setDropdownVisible(true);
    };

    const handleMouseLeave = () => {
        setDropdownVisible(false);
    };
    const Option = styled(MenuItem)(() => ({
        fontSize: '.8rem',
        borderRadius: 8,
        padding: "10px",
        cursor: "pointer",
        width: 150,
        height: "1.5rem",
        borderRadius: "15px",
        "&:hover": {
            backgroundColor: "#007bff",
            color: "#fff",
        }
    }));

    const DropdownContainer = styled('div')({
        position: 'relative',
        display: 'inline-block',
        width: 'fit-content',
        borderRadius: "4px",
        cursor: "pointer",
        border: "none",
        outline: "none",
        '&:hover .dropdown-content': {
            display: 'block'
        }
    });
    const DropdownTrigger = styled('button')({
        textAlign: 'left',
        width: 150,
        height: "1.5rem",
        borderRadius: '4px',
        backgroundColor: '#ffffff',
        fontSize: ".7rem",
        border: 'none',
        padding: "10px 10px",
        cursor: 'pointer',
        boxShadow: "rgba(0, 0, 0, 0.12) 0px 1px 3px, rgba(0, 0, 0, 0.24) 0px 1px 2px",
    });
    const DropdownContent = styled('div')({
        display: 'block',
        position: 'absolute',
        backgroundColor: 'white',
        boxShadow: '0px 8px 16px 0px rgba(0, 0, 0, 0.2)',
        zIndex: 1,
        borderRadius: '8px',
        padding: '5px 5px',
        marginTop: '1px',
    });
    return (
        <DropdownContainer
            onMouseEnter={handleMouseEnter}
            onMouseLeave={handleMouseLeave}
        >
            <DropdownTrigger className="dropdown-trigger" style={{ display: "flex", flexDirection: 'row', justifyContent: 'space-between', alignItems: "center" }}>
                {dropdownValue.sTitle}{dropdownValue.title}
                {isDropdownVisible ? <KeyboardArrowDownIcon fontSize='small' sx={{ m: 0, p: 0 }} /> : <KeyboardArrowUpIcon fontSize='small' sx={{ m: 0, p: 0 }} />}
            </DropdownTrigger>
            {isDropdownVisible && (
                <DropdownContent className='dropdown-content'>
                    {data.map((ele, key) => (
                        <Option value={ele.value} key={ele.value} onClick={() => setDropdownValue(ele)} >
                            {ele.title}
                        </Option>
                    ))}

                </DropdownContent>
            )}
        </DropdownContainer>
    );
}

export default HoverableDropdown;
