import FusionCharts from "fusioncharts";
import charts from "fusioncharts/fusioncharts.charts";
import ReactFusioncharts from "react-fusioncharts";
charts(FusionCharts);

const dataSource = {
    chart: {

        pyaxisname: "AUM in Crs",
        syaxisname: "MS in percentage",
        xAxisName: "Distributor Category",
        snumbersuffix: "%",
        numbersuffix: " Cr",
        syaxismaxvalue: "25",
        theme: "fusion",
        showvalues: "0",
        drawcrossline: "1",
        xAxisNameFont: "Roboto",
        yAxisNameFont: "Roboto",
        syAxisNameFont: "Roboto",
        xAxisNameFontSize: "10",
        yAxisNameFontSize: "10",
        syAxisNameFontSize: "10",
        yAxisNameFontBold: 0,
        xAxisNameFontBold: 0,
        labelFontSize: "10",
        yAxisValueFontSize: "10",
        showXAxisLine: "1",
        xAxisNameFontColor: "#909090",
        yAxisNameFontColor: "#909090",
        palettecolors: "#2057A6,#69B8F4,#8ED8B7,#82C7ED,#8FABD3,#BA87ED",
        showYAxisLine: "1",
        showsYAxisLine: "1",
        divlinealpha: "20",
        showLegend: 0,
        chartBottomMargin: 10,
        plotSpacePercent: 70,

    },
    categories: [
        {
            category: [
                {
                    label: "Direct"
                },
                {
                    label: "Regular"
                },
            ]
        }
    ],
    dataset: [
        {

            seriesname: "PGIM Share",
            data: [
                {
                    value: "28"
                },
                {
                    value: "25"
                },

            ]

        },
        {

            seriesname: "Kfin Share",
            data: [
                {
                    value: "63"
                },
                {
                    value: "65"
                },



            ]
        },
        {

            seriesname: "Market Share",
            data: [
                {
                    value: "80"
                },
                {
                    value: "87"
                },


            ]
        },
        {

            seriesname: "PGIM Share",
            "parentYAxis": "S",
            "drawAnchors": "0",
            alpha: 0,
            data: [
                {
                    value: "5"
                },
                {
                    value: "5"
                },

            ]

        },
        {

            seriesname: "Kfin Share",
            parentyaxis: "S",
            "drawAnchors": "0",
            alpha: 0,
            data: [
                {
                    value: "15"
                },
                {
                    value: "15"
                },



            ]
        },
        {

            seriesname: "Market Share",
            parentyaxis: "S",
            "drawAnchors": "0",
            alpha: 0,
            data: [
                {
                    value: "17"
                },
                {
                    value: "17"
                },


            ]
        },

    ],



};

export default function DualAxisColumnChart() {

    return (
        <ReactFusioncharts
            type="mscombidy2d"
            width="98%"
            height="47%"
            dataFormat="JSON"
            dataSource={dataSource}
        />
    );
}

