import { Box, Container, Grid } from '@mui/material';
import React, { useState } from 'react'
import AssetClassSchemeCategory from './components/AssetClassSchemeCategory.js';
import TransactionCatagory from './components/TransactionCatagory';
import SchemeSubCatagory from './components/SchemeSubCatagory';
import MapChart from './components/MapChart';

import InvestorDistribution from './components/InvestorDistribution';
import AMCvsMarketTrend from './components/AMCvsMarketTrend.jsx';
import DistributorLevelMarketShare from './components/DistributorLevelMarketShare.js';
import { DatePicker, LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterMoment } from '@mui/x-date-pickers/AdapterMoment';

const AMCvsKfinDashboard = () => {
    const [activePage, setActivePage] = useState("AUM")

    const font_size = window.innerWidth <= 400 ? "5" : "18";
    return (
        <>
            <Container sx={{ paddingBottom: "2rem" }}>
                <div className='box_shadow'
                    style={{
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        flexWrap: "wrap",
                        background: "#fff",
                        padding: "0.7rem",
                        borderRadius: "9px",
                        margin: "1.5rem 0.9rem 1.5rem 0"
                    }}
                >
                    <h2 style={{}}>Data as on 30th of September</h2>

                    <div style={{ width: "fit-content", display: "flex", }}>
                        <button

                            onClick={() => setActivePage("AUM")}
                            style={{
                                padding: "0.4rem 1.1rem",
                                marginLeft: "10px",
                                borderRadius: "20px 0px 0px 20px",
                                border: "1px solid #2057A6",
                                fontSize: font_size,
                                backgroundColor: activePage == "AUM" ? "#2057A6" : "#fff",
                                color: activePage == "AUM" ? "#fff" : "",
                            }}
                        >
                            AUM
                        </button>
                        <button

                            onClick={() => setActivePage("Sales")}
                            style={{
                                padding: ".4rem 1.1rem",
                                border: "1px solid #2057A6",
                                fontSize: font_size,
                                backgroundColor: activePage == "Sales" ? "#2057A6" : "#fff",
                                color: activePage == "Sales" ? "#fff" : "",
                            }}
                        >
                            Sales
                        </button>
                        <button

                            onClick={() => setActivePage("SIP")}
                            style={{
                                padding: ".4rem 1.1rem",
                                borderRadius: "0px 20px 20px 0px",
                                border: "1px solid #2057A6",
                                fontSize: font_size,
                                backgroundColor: activePage == "SIP" ? "#2057A6" : "#fff",
                                color: activePage == "SIP" ? "#fff" : "",
                            }}
                        >
                            SIP
                        </button>
                    </div>
                    <Grid item xs={4} style={{ display: "flex", alignItems: "center", justifyContent: "flex-end" }}>


                        <p style={{ marginInline: "4px", fontWeight: "500" }}>From</p>
                        <div style={{ width: "120px" }}>
                            <LocalizationProvider dateAdapter={AdapterMoment}>
                                <DatePicker
                                    disableFuture
                                    slotProps={{ textField: { size: "small" } }}
                                    sx={{
                                        boxShadow: "rgba(99, 99, 99, 0.2) 0px 2px 8px 0px",
                                    }}
                                />
                            </LocalizationProvider>
                        </div>
                        <p style={{ marginInline: "20px 4px", fontWeight: "500" }}>To</p>
                        <div style={{ width: "120px" }}>
                            <LocalizationProvider dateAdapter={AdapterMoment}>
                                <DatePicker
                                    disableFuture
                                    slotProps={{
                                        textField: { size: "small", width: "100%" },
                                    }}
                                />
                            </LocalizationProvider>
                        </div>

                    </Grid>

                </div>

                <Box sx={{ height: '70vh', paddingBottom: "2rem", paddingInline: ".5rem", overflow: "auto", "& .css-1ik6aa3-MuiPaper-root": { borderRadius: "0.625rem", boxShadow: 4, } }}>
                    <TransactionCatagory />
                    <AssetClassSchemeCategory />
                    <AMCvsMarketTrend />
                    <SchemeSubCatagory />

                    <Grid container spacing={0} sx={{ marginTop: "20px" }}>
                        <Grid item xs={11.9} sx={{
                            background: "#fff",
                            boxShadow: 6,
                            borderRadius: "8px"
                        }}>
                            <MapChart heading="Investor Demography -Location" />
                        </Grid>
                    </Grid>
                    <InvestorDistribution />
                    <DistributorLevelMarketShare />
                </Box>


            </Container>
        </>



    )
}

export default AMCvsKfinDashboard