import React from 'react';
import { styled } from '@mui/material/styles';
import Grid from '@mui/material/Unstable_Grid2';
import Paper from '@mui/material/Paper';
import { Box } from '@mui/material';
import { ArrowDownward, ArrowUpward } from '@mui/icons-material';
const Item = styled(Paper)(({ theme }) => ({
    backgroundColor: '#E3EAF3',
    padding: theme.spacing(1),
    border: 0,}));


const FinanceCards = () => {
    let data = [
        {
            "key": "Revenue Data",
            "value": "30.3",
            cremental: "increases",
            amount: "₹ 1,20,30,22,014",
            percent: "50.5%"
        },
        {
            "key": "Operating Cost",
            "value": "10.48",
            cremental: "increases",
            amount: "₹ 70,13,86,820",
            percent: "16.48%"
        },
    ]

    return (
        <>
            <Grid container spacing={{ xs: 2, md: 2 }} columns={{ xs: 4, sm: 8, md: 12 }} sx={{ margin: "0 1% 2% 1%", display: "flex", "& .css-1ik6aa3-MuiPaper-root": { background: "#fff", height: "7rem", borderTop: 4, borderColor: '#2057A6', borderRadius: '0.625rem', boxShadow: 4 } }}>
                <Grid xs={12} sm={12} md={3.6} display={"flex"} flexDirection={"column"} >
                    {data.map((res, index) => (
                        <Item elevation={8} sx={{ display: "flex", height: "7rem", backgroundColor: "#fff", marginTop: ".5rem", borderTop: 4, borderColor: '#2057A6', borderRadius: '0.625rem' }} >
                            <div style={{ width: "100%" }}>
                                <div style={{ display: "flex", justifyContent: 'space-between', }}>
                                    <p style={{ marginTop: "1%", marginLeft: "2%", fontWeight: "bold" }}>{res.key}</p>
                                    {
                                        (res.cremental == "increases") ? (<h3 style={{ color: "#77B900", marginTop: "1%", marginRight: "2%" }}>+{res.value} Cr</h3>) : (<h3 style={{ color: "red", marginTop: "1%", marginRight: "2%" }}>-{res.value} Cr</h3>)
                                    }
                                </div>

                                <div>
                                    <p style={{ color: "grey", marginTop: "2rem", marginLeft: "2%" }}>
                                        Current Value
                                    </p>
                                </div>
                                <div style={{ display: "flex", justifyContent: 'space-between' }}>
                                    <h3 style={{ marginTop: "0.5rem", marginLeft: "2%" }}>{res.amount}</h3>
                                    {
                                        (res.cremental == "increases") ? (<h3 style={{ color: "#77B900", marginTop: "0.5rem", marginRight: "2%" }}><ArrowUpward fontSize='small' />{res.percent}</h3>) : (<h3 style={{ color: "red", marginTop: "0.5rem", marginRight: "2%" }}><ArrowDownward fontSize='small' />{res.percent}</h3>)
                                    }
                                </div>
                            </div>
                        </Item>
                    ))}
                </Grid>
                <Grid xs={12} sm={12} md={8.4} sx={{ height: "100%" }}>
                    <Item elevation={8} sx={{ display: "flex", justifyContent: "center", alignItems: "center", flexDirection: "row", height: "16rem", marginTop: ".7rem", backgroundColor: "#fff", borderTop: 4, borderColor: '#2057A6', borderRadius: '0.625rem', pt: 0 }}>
                        
                        <Box sx={{ boxShadow: 8, width: "50%", padding: "3.5rem 1rem", marginTop: ".7rem", borderRadius: "8px", bgcolor: "white" }}>


                            <div style={{ display: "flex", justifyContent: 'space-between' }}>
                                <h3 style={{ marginTop: "1%", marginLeft: "2%", color: "#000", fontWeight: "bold" }}>Cost</h3>
                                {
                                    ("decreases" == "increases") ? (<h3 style={{ color: "red", marginTop: "1%", marginRight: "2%" }}>+10.26 Cr</h3>) : (<h3 style={{ color: "#77B900", marginTop: "1%", marginRight: "2%" }}>-10.26 Cr</h3>)
                                }
                            </div>

                            <div>

                                <p style={{ color: "grey", marginTop: "2rem", marginLeft: "2%" }}>
                                    Current Value
                                </p>
                                <div style={{ display: "flex", justifyContent: 'space-between' }}>
                                    <h3 style={{ marginTop: "0.5rem", marginLeft: "2%" }}>₹ 50,16,35,194</h3>
                                    {
                                        ("decreases" == "increases") ? (<h3 style={{ color: "red", marginTop: "0.5rem", marginRight: "2%" }}><ArrowUpward fontSize='small' />20%</h3>) : (<h3 style={{ color: "#77B900", marginTop: "0.5rem", marginRight: "2%" }}><ArrowDownward fontSize='small' />20%</h3>)
                                    }
                                </div>
                            </div>
                        </Box>
                        <Box sx={{ marginBlock: "0rem 1rem", paddingInline: ".5rem", height: "100%", display: "flex", width: "50%", flexWrap: "wrap", justifyContent: "center" }}>
                            <div style={{ flexGrow: .4, marginBlock: "1.8rem .3rem" }}>
                                <Box sx={{ boxShadow: 6, backgroundColor: "white", width: "85%", padding: "1.8rem .5rem", borderRadius: "8px", color: "#000" }}>
                                    <p style={{ color: "#000", marginLeft: "2%" }}>
                                        Commission Cost*
                                    </p>
                                    <div style={{ display: "flex", justifyContent: 'space-between' }}>
                                        <h4 style={{ marginTop: "0.5rem", marginLeft: "2%" }}>₹ 15,06,94,902</h4>
                                        
                                    </div>
                                </Box></div>
                            <div style={{ flexGrow: 1, marginBlock: "1.8rem .3rem" }}>
                                <Box sx={{ boxShadow: 6, backgroundColor: "white", width: "85%", padding: "1.8rem .5rem", borderRadius: "8px", color: "#000" }}>
                                    <p style={{ color: "#000", marginLeft: "2%" }}>
                                        SG&A Cost*
                                    </p>
                                    <div style={{ display: "flex", justifyContent: 'space-between' }}>
                                        <h4 style={{ marginTop: "0.5rem", marginLeft: "2%" }}>₹ 10,92,57,412</h4>
                                       
                                    </div>
                                </Box></div>
                            <div style={{ flexGrow: 1, marginTop: ".3rem" }}>
                                <Box sx={{ boxShadow: 6, backgroundColor: "white", width: "85%", padding: "1.8rem .5rem", borderRadius: "8px", color: "#000" }}>
                                    <p style={{ color: "#000", marginLeft: "2%" }}>
                                        RTA Cost*
                                    </p>
                                    <div style={{ display: "flex", justifyContent: 'space-between' }}>
                                        <h4 style={{ marginTop: "0.5rem", marginLeft: "2%" }}>₹ 11,57,66,742</h4>
                                       
                                    </div>
                                </Box></div>
                            <div style={{ flexGrow: 1, marginTop: ".3rem" }}>
                                <Box sx={{ boxShadow: 6, backgroundColor: "white", width: "85%", padding: "1.8rem .5rem", borderRadius: "8px", color: "#000" }}>
                                    <p style={{ color: "#000", marginLeft: "2%" }}>
                                        Other Cost*
                                    </p>
                                    <div style={{ display: "flex", justifyContent: 'space-between', }}>
                                        <h4 style={{ marginTop: "0.5rem", marginLeft: "2%" }}>₹ 12,59,16,138</h4>
                                        
                                    </div></Box>
                            </div>
                        </Box>
                    </Item>
                </Grid>
            </Grid >
        </>
    )
}

export default FinanceCards