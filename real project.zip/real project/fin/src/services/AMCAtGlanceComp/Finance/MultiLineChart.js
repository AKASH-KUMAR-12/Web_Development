import FusionCharts from "fusioncharts";
import charts from "fusioncharts/fusioncharts.charts";
import ReactFusioncharts from "react-fusioncharts";

charts(FusionCharts);
export default function MultiLineChart({ data, xAxisName, yAxisName }) {
    const dataSource = {
        chart: {
            theme: "fusion",
            xaxisname: xAxisName,
            yaxisname: yAxisName,
            xAxisNameFont: "Roboto",
            yAxisNameFont: "Roboto",
            xAxisNameFontSize: "12",
            yAxisNameFontSize: "12",
            xAxisNameFontColor: "#909090",
            yAxisNameFontColor: "#909090",
            labelFontSize: "10",
            yAxisValueFontSize: "10",
            bgColor: "#FFFFFF",
            plotFillColor: "#2057A6",
            "bgAlpha": "50",
            "showcanvasborder": "0",
            "showxaxisline": "1",
            "showyaxisline": "1",
            "lineColor": "#2057a6",
            numDivLines: 11,
            divLineColor: "#d3d4d4",
            setadaptiveymin: "1",
            theme: "fusion",
            "anchorBgColor": "#2057a6",
            "showAlternateHGridColor": "0",
            "showPlotBorder": "1",
            "drawFullAreaBorder": "0",
            "plotBorderThickness": "2",
            chartLeftMargin: 0,
            chartBottomMargin: 10,
            // plottooltext: "$seriesname: $value Cr",
            showLegend: 0
        },
        categories: [
            {
                category: [
                    {
                        label: "JAN 23",
                    },
                    {
                        label: "FEB 23",
                    },
                    {
                        label: "MAR 23",
                    },
                    {
                        label: "APR 23",
                    },
                    {
                        label: "MAY 23",
                    },
                    {
                        label: "JUN 23",
                    },
                    {
                        label: "JULY 23"
                    },
                    {
                        label: "AUG 23",
                    },
                    {
                        label: "SEP 23",
                    },
                    {
                        label: "OCT 23"
                    },
                    {
                        label: "NOV 23"
                    },
                    {
                        label: "DEC 23"
                    },

                ]
            }
        ],
        dataset: [
            {
                seriesname: "Current",
                color: "#15CC7A",
                anchorBgColor: "#0FB156",
                showValues: 0,
                data: data.data1,
                plottooltext: "$seriesname: $value Cr"
            },
            // {
            //     seriesname: "Forecast",
            //     dashed: "1",
            //     showValues: 0,
            //     data: data.data2
            // },


        ]
    };



    return (
        <ReactFusioncharts
            type="msline"
            width="100%"
            height="45%"
            dataFormat="JSON"
            dataSource={dataSource}
        />
    );

}
