import { Grid } from '@mui/material'
import React from 'react'
import MultiLineChart from './MultiLineChart'

const AllCharts = () => {

  const heading = ["Revenue", "Cost", "Operating Cost"]

  const revenueData = {
    data2: [
      {
        value: "62"
      },
      {
        value: "64"
      },
      {
        value: "64"
      },
      {
        value: "66"
      },
      {
        value: "78"
      },
      {
        value: "82"
      },
      {
        value: "87"
      },
      {
        value: "97"
      },
      {
        value: "121"
      },
      {
        value: "125"
      },
      {
        value: "126"
      },
      {
        value: "132"
      },
    ],

    data1: [
      {
        value: "60"
      },
      {
        value: "63"
      },
      {
        value: "65"
      },
      {
        value: "68"
      },
      {
        value: "75"
      },
      {
        value: "80"
      },

      {
        value: "89",
      },
      {
        value: "98",
      },
      {
        value: "120",
      },

    ]
  }
  const costData = {
    data1: [
      {

        value: "21"
      },
      {

        value: "49"
      },
      {

        value: "40"
      },
      {

        value: "30"
      },
      {

        value: "44"
      },
      {

        value: "40"
      },
      {

        value: "55"
      },
      {

        value: "60",
      },
      {

        value: "50",

      },
      {

        value: "49",
        dashed: "1",

      },
      {

        value: "47",
        dashed: "1",

      },
      {

        value: "50",
        dashed: "1",


      },
    ],
    data2: [
      {

        value: "20"
      },
      {

        value: "48"
      },
      {

        value: "41"
      },
      {

        value: "31"
      },
      {

        value: "43"
      },
      {

        value: "42"
      },
      {

        value: "53"
      },
      {

        value: "59",

      },
      {

        value: "52",

      },
      {

        value: "49",

      },
      {

        value: "47",

      },
      {

        value: "50",


      },
    ]
  }
  const operatingData = {
    data1: [
      {

        value: "15",
        title: "Forecast"
      },
      {

        value: "22",
        title: "Forecast"
      },
      {

        value: "40",
        title: "Forecast"
      },
      {

        value: "30",
        title: "Forecast"
      },
      {

        value: "44",
        title: "Forecast"
      },
      {

        value: "40",
        title: "Forecast"
      },
      {

        value: "55",
        title: "Forecast"
      },
      {

        value: "60",
        title: "Forecast"

      },
      {

        value: "70",
        title: "Forecast"

      },
      {

        value: "80",
        dashed: "1",
        title: "Forecast"

      }, {

        value: "82",
        dashed: "1",
        title: "Forecast"

      },
      {

        value: "83",
        dashed: "1",
        title: "Forecast"

      },],
    data2: [
      {

        value: "17"
      },
      {

        value: "20"
      },
      {

        value: "42"
      },
      {

        value: "33"
      },
      {

        value: "42"
      },
      {

        value: "41"
      },
      {

        value: "58"
      },
      {

        value: "61",

      },
      {

        value: "72",

      },
      {

        value: "80",

      }, {

        value: "82",

      },
      {

        value: "83",

      },
    ]
  }



  return (
    <Grid container columns={{ md: 13 }} sx={{ width: "98%", marginBottom: "1rem", }} rowSpacing={2} columnSpacing={{ xs: 1, sm: 2 }} >
      {heading.map((heading, key) => (
        <Grid key={key} item md={heading == 'Operating Cost' ? 12.5 : 6} sx={{ bgcolor: "white", boxShadow: 6, margin: "1rem 1rem 0.5rem 1.3rem", borderRadius: "0.5rem", }}>
          <p style={{ fontWeight: "bold" }}>{heading}</p>
          {heading === "Revenue" && <div style={{ margin: "0.5rem 1rem 1rem 0", }}>
            <MultiLineChart data={revenueData} />
          </div>}
          {heading === "Cost" && <div style={{ margin: "0.5rem 1rem 1rem 0", }}>
            <MultiLineChart data={costData} />
          </div>}
          {heading === "Operating Cost" && <div style={{ margin: "0.5rem 1rem 1rem 0" }}>
            <MultiLineChart data={operatingData} />
          </div>}
        </Grid>
      ))}
    </Grid>
  )
}

export default AllCharts