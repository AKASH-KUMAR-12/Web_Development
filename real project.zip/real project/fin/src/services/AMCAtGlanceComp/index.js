import Box from '@mui/material/Box';
import { styled } from '@mui/material/styles';
import Grid from '@mui/material/Unstable_Grid2';
import Paper from '@mui/material/Paper';
import BusinessBreakDown from './Business/BusinessBreakDown';
// import "../SIPBookComp/components/style/style.css";
import SecureLS from "secure-ls";
import { encrypt } from "../../utils/chipher";
import { useEffect } from 'react';
import { setAmcAtGlanceResponse } from "../../reduxStore/ApiResponceReducer";
import { useDispatch, useSelector } from 'react-redux';
import { Container } from '@mui/material';
import FinanceCards from './Finance/FinanceCards';
import AllCharts from './Finance/AllCharts';
import { setactivePage } from '../../reduxStore/amcAtGlanceReducer';
import MultiLineChart from './Finance/MultiLineChart';
import BarChart from '../../newCharts/charts/BarChart';
import calender from "../../images/calender.png";
import SatisfactionIndexChart from './Business/SatisfactionIndexChart';
import SpeedoMeter from './Business/SpeedoMeter';
const Item = styled(Paper)(({ theme }) => ({
    backgroundColor: '#E3EAF3',
    padding: theme.spacing(1),
    border: 0,
}));

const AmcGlanceDashBoard = () => {
    let ls = new SecureLS();
    const usertoken = ls.get("user-token");
    const dispatch = useDispatch();
    const activePage = useSelector((state) => state.amcatglanceState.activePage);
    const setActivePage = (active) => {
        dispatch(setactivePage({ activePage: active }));
        console.log(activePage, ">>>>>>");
    };
    let payload = {
        fund: "RMF",
        batchclosedt: "2023-06-30",
        token: usertoken,
    };
    const Item = styled(Paper)(({ theme }) => ({
        backgroundColor: '#E3EAF3',
        padding: theme.spacing(1),
        border: 0,
    }));
    const data = ["Revenue", "Cost", "Operating Margin", "Cost Breakup"]
    const cardData = [
        { key: "NPS- Net promoter Score", amount: "  52" }, { key: "DSAT -  Distributor Satisfaction Score", amount: "4.27" }, { key: "CSAT- Customer Satisfaction Score", amount: "4.11" }]
    const encryptedPayload = encrypt(payload);
    useEffect((() => {
        let chartData = [
            {
                "label": "Equity",
                "value": "30"
            },
            {
                "label": "Debt",
                "value": "50"
            },
            {
                "label": "Hybrid",
                "value": "20"
            }
        ]
        console.log("data from amc at glance", data)
        dispatch(setAmcAtGlanceResponse({ AmcAtGlanceApiResponse: chartData }))
    }), [])
    let aumData = [
        {
            "label": "EMERGING EQUITIES FUND",
            "value": "18k"
        },
        {
            "label": "BLUE CHIP EQUITY FUND",
            "value": "10k"
        },
        {
            "label": "FLEXI CAP FUND",
            "value": "10k"
        },
        {
            "label": "EQUITY HYBRID FUND",
            "value": "9k"
        },
        {
            "label": "SMALL CAP FUND",
            "value": "7.8k"
        }
    ]
    let folioCountData = [
        {
            "label": "EMERGING EQUITIES FUND",
            "value": "849798"
        },
        {
            "label": "EQUITY TAX SAVER FUND",
            "value": "774001"
        },
        {
            "label": "SMALL CAP FUND",
            "value": "745421"
        },
        {
            "label": "BLUE CHIP EQUITY FUND",
            "value": "734656"
        },
        {
            "label": "FLEXI CAP FUND",
            "value": "581134"
        }
    ]
    let CSATData = [
        {
            "label": "WhatsApp",
            "value": "4.8"
        },
        {
            "label": "ContactCenter",
            "value": "4.55"
        },
        {
            "label": "WebForms",
            "value": "4.3"
        },
        {
            "label": "Chat",
            "value": "4.2"
        },
        {
            "label": "OutBounds",
            "value": "4.1"
        },
        {
            "label": "Others",
            "value": "3.8"
        }
    ]
    const aumChartData = {
        data1: [
            {

                value: "15"
            },
            {

                value: "22"
            },
            {

                value: "40"
            },
            {

                value: "30"
            },
            {

                value: "44"
            },
            {

                value: "53"
            },
            {

                value: "55"
            },
            {

                value: "67",

            },
            {

                value: "76",

            },
            {

                value: "78",
                dashed: "1",

            },
            {

                value: "81",
                dashed: "1",

            },
            {

                value: "86",
                dashed: "1",

            }],
        data2: [
            {

                value: "17"
            },
            {

                value: "20"
            },
            {

                value: "42"
            },
            {

                value: "33"
            },
            {

                value: "42"
            },
            {

                value: "51"
            },
            {

                value: "58"
            },
            {

                value: "62",

            },
            {

                value: "75",

            },
            {

                value: "80",

            }, {

                value: "82",

            },
            {

                value: "83",

            },
        ]
    }
    const font_size = window.innerWidth <= 400 ? "5" : "18";

    return (
        <>
            <Container>
                <Box className="box_shadow"
                    sx={{
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        flexWrap: "wrap",
                        background: "#fff",
                        borderRadius: "9px",
                        margin: "1.5rem 0.9rem 1.5rem 1rem",

                    }}
                >
                    <h3 style={{ padding: "0.7rem", }}>Data as on 30th of September</h3>

                    <div style={{ width: "fit-content", display: "flex", marginRight: "1rem" }}>
                        <button

                            onClick={() => setActivePage("Finance")}
                            style={{
                                cursor: "pointer",
                                padding: "0.4rem 2rem",
                                marginLeft: "10px",
                                borderRadius: "20px 0px 0px 20px",
                                border: "1px solid #2057A6",
                                fontSize: font_size,
                                backgroundColor: activePage == "Finance" ? "#2057A6" : "#fff",
                                color: activePage == "Finance" ? "#fff" : "",
                            }}
                        >
                            Finance
                        </button>
                        <button

                            onClick={() => setActivePage("Business")}
                            style={{
                                cursor: "pointer",
                                padding: ".4rem 1.1rem",
                                borderRadius: "0px 20px 20px 0px",
                                border: "1px solid #2057A6",
                                fontSize: font_size,
                                backgroundColor: activePage !== "Finance" ? "#2057A6" : "#fff",
                                color: activePage !== "Finance" ? "#fff" : "",
                            }}
                        >
                            Business
                        </button>
                    </div>

                </Box>

                <Box sx={{ height: '70vh', paddingBottom: "3rem", overflow: "auto" }}>
                    {activePage !== "Finance" ?
                        <>
                            <BusinessBreakDown />
                            <Grid container sx={{ bgcolor: "white", width: "98%", margin: "1rem 0.2rem 1rem 0.5rem", paddingBottom: "1rem", borderRadius: "10px", boxShadow: 6 }} >
                                <p style={{ fontWeight: "bold", padding: "0.5rem 0 0 1rem" }}>NFO Tracker</p>
                                <Box sx={{
                                    display: 'grid',
                                    gridAutoFlow: 'row',
                                    gridTemplateColumns: 'repeat(5, 500px)',
                                    gap: 1,
                                }} rowSpacing={2} columnSpacing={{ xs: 1, sm: 2 }}>
                                    <Item elevation={8} xs={12} sx={{ gridColumn: '1', gridRow: '1 / 3', height: "15rem", marginLeft: "0.5rem", backgroundColor: "#fff", width: "98%", marginLeft: "1.2rem", marginTop: "0.5rem", borderTop: 4, borderColor: 'primary.main', borderRadius: '0.625rem', pt: 0 }}>
                                        <div style={{ display: "flex" }}>
                                            <p style={{ paddingTop: "0.5rem", fontWeight: "bold", width: "65%" }}>Completed NFOs:<span style={{ color: "gray", fontWeight: "lighter", marginLeft: "0.5rem" }}>Flexi Cap Fund</span></p>
                                            <div style={{ fontWeight: "lighter", fontSize: "0.8rem", marginTop: "0.5rem" }}><span style={{ fontWeight: "bold" }}> Open Date : </span>15-Sep-2023<br /><span style={{ fontWeight: "bold" }}> Close Date : </span>30-Sep-2023</div>
                                        </div>
                                        <ul style={{ marginTop: "0.5rem" }}>
                                            <li>
                                                <span style={{ fontWeight: "500" }}>15670</span> investors subscribed
                                            </li>
                                            <li><span style={{ fontWeight: "500" }}>3452</span> new investors added</li>
                                            <li>total subscription stands at <span style={{ fontWeight: "500" }}>2568 Cr</span></li>
                                            <li><span style={{ fontWeight: "500" }}>7685</span> folios have opted for SIP with Average Ticket Size is <span style={{ fontWeight: "500" }}>₹ 2500</span></li>
                                        </ul>


                                    </Item>
                                    <Item elevation={8} xs={12} sx={{ gridColumn: '2', gridRow: '1 / 3', height: "8.5rem", backgroundColor: "#fff", width: "98%", marginLeft: "2rem", marginTop: "0.5rem", marginBottom: "1rem", borderTop: 4, borderColor: 'primary.main', borderRadius: '0.625rem', pt: 0 }}>

                                        <div style={{ display: "flex" }}>
                                            <p style={{ paddingTop: "0.5rem", fontWeight: "bold", width: "65%" }}>Ongoing NFOs:<span style={{ color: "gray", fontWeight: "lighter", marginLeft: "0.5rem" }}>Consumption Fund</span></p>
                                            <div style={{ fontWeight: "lighter", fontSize: "0.8rem", marginTop: "0.5rem" }}><span style={{ fontWeight: "bold" }}> Open Date : </span>28-Sep-2023<br /><span style={{ fontWeight: "bold" }}> Close Date : </span>13-Oct-2023</div>
                                        </div>

                                        <ul style={{ marginTop: "0.5rem" }}>
                                            <li><span style={{ fontWeight: "500" }}>7859 </span>investors subscriber so far</li>
                                            <li><span style={{ fontWeight: "500" }}>1893 </span>new investors added</li>
                                            <li>Total subscription stands at <span style={{ fontWeight: "500" }}>59 Cr</span> </li>
                                        </ul>


                                    </Item>
                                    <Item elevation={8} xs={12} sx={{ gridColumn: '2', gridRow: '2 / 3', backgroundColor: "#fff", width: "98%", marginLeft: "2rem", marginTop: "0.5rem", borderTop: 4, borderColor: 'primary.main', borderRadius: '0.625rem', pt: 0 }}>
                                        <p style={{ paddingTop: "0.5rem" }}><span style={{ fontWeight: "bold", }}>Upcoming NFOs:</span>
                                            <ul style={{ marginTop: "0.5rem" }}>
                                                <li> Small Cap fund</li>
                                                <li> Overnight fund</li>
                                            </ul>

                                        </p>
                                    </Item>
                                </Box>
                            </Grid>
                            <Grid container sx={{ width: "100%", marginBlock: "1rem" }} rowSpacing={2} columnSpacing={{ xs: 1, sm: 2 }} >

                                <Grid item md={5.7} sx={{ bgcolor: "white", boxShadow: 6, margin: "1rem .5rem 0.5rem 1rem", borderRadius: "0.5rem", }}>
                                    <p style={{ fontWeight: "bold" }}>Top 5 Schemes by AUM</p>

                                    <div style={{ margin: "1rem 1rem 1rem 0" }}>
                                        <BarChart data={aumData} xAxisName={"Scheme Name"} yAxisName={"AUM in Crores"} />
                                    </div>
                                </Grid>
                                <Grid item md={5.7} sx={{ bgcolor: "white", boxShadow: 6, margin: "1rem .5rem 0.5rem 1rem", borderRadius: "0.5rem", }}>
                                    <p style={{ fontWeight: "bold" }}>Top 5 Schemes by Folio Count</p>

                                    <div style={{ margin: "1rem 1rem 1rem 0" }}>
                                        <BarChart data={folioCountData} xAxisName={"Scheme Name"} yAxisName={"Folio Count"} />
                                    </div>
                                </Grid></Grid>

                            <Grid container sx={{ bgcolor: "white", boxShadow: 6, borderRadius: "8px", width: "98%", marginLeft: ".5rem", marginBlock: "1rem" }} rowSpacing={2} columnSpacing={{ xs: 1, sm: 2 }} >
                                <Grid item md={4} sx={{ margin: "1rem .5rem 0.5rem 1rem", borderRadius: "0.5rem", }}>
                                    <p style={{ fontWeight: "bold", marginBottom: "1rem" }}>Customer/Distributor Satisfaction Index</p>

                                    {cardData.map((res, index) => (
                                        <Item className="display" elevation={8} sx={{ color: "white", marginTop: ".5rem", width: "90%", display: "flex", flexDirection: "column", height: "6rem", backgroundColor: "#fff", borderRadius: '0.625rem', pt: 0 }} >
                                            <div style={{ paddingBlock: ".2rem" }}>
                                                <div style={{ display: "flex", justifyContent: 'space-between', }}>
                                                    <p style={{ marginTop: "1%", marginLeft: "2%", fontWeight: "bold" }}>{res.key}</p>

                                                </div>

                                                <div style={{ margin: "1rem auto", width: "30%" }}>
                                                    <h2 style={{ marginTop: "0.5rem", marginLeft: "2%" }}>{res.amount}</h2>
                                                </div>
                                            </div>
                                        </Item>
                                    ))}
                                </Grid>
                                <Grid item md={7} sx={{ margin: "1rem .5rem 0.5rem 1rem", borderRadius: "0.5rem" }}>

                                    <div style={{ margin: "1rem 1rem 0rem 0", position: "relative", height: "360px" }}>
                                        <SatisfactionIndexChart style={{ position: "absolute" }} data={CSATData} xAxisName={"Medium"} yAxisName={"Value"} />
                                    </div>
                                </Grid>

                            </Grid>
                            <Grid container sx={{ width: "100%", marginBottom: "1rem" }} rowSpacing={2} columnSpacing={{ xs: 1, sm: 2 }} >

                                <Grid item md={12} sx={{ bgcolor: "white", boxShadow: 6, margin: "1rem .5rem 0.5rem 1rem", borderRadius: "0.5rem", }}>
                                    <p style={{ fontWeight: "bold" }}>AUM</p>

                                    <div style={{ margin: "0.5rem 1rem 1rem 0" }}>
                                        <MultiLineChart data={aumChartData} xAxisName={"Months"} yAxisName={"AUM in Crores"} />
                                    </div>
                                </Grid></Grid>
                            <Grid container sx={{ width: "100%", marginBlock: "1rem" }} rowSpacing={2} columnSpacing={{ xs: 1, sm: 2 }} >

                                <Grid item md={12} sx={{ bgcolor: "white", boxShadow: 6, margin: "1rem .5rem 0.5rem 1rem", borderRadius: "0.5rem", }}>


                                    <div style={{ margin: "1rem 1rem 1rem 0", display: "flex" }}>
                                        <Box sx={{ width: "25%", marginInline: "1rem", bgcolor: "white", boxShadow: 6, position: "relative", padding: "1rem" }}>

                                            < SpeedoMeter style={{ position: "absolute" }} />
                                        </Box>

                                        <Box sx={{ display: "flex", flexWrap: "wrap", boxShadow: 6, borderRadius: "5px", width: "70%", padding: "1rem 1rem" }}>
                                            <p style={{ fontWeight: "bold", width: "100%", marginBottom: ".5rem" }}>Compliance Calendar</p>
                                            <img height={"85%"} width={"200px"} src={calender} />
                                            <ul style={{ width: "60%", marginLeft: "1rem", marginTop: "1rem" }}>
                                                <h3>Circular:</h3>
                                                <p style={{ fontSize: ".8rem" }}> Mandatory for mutual fund holders to submit the nomination details or declaration to opt out of the nomination on or after 1 August, 2022</p>
                                                <p style={{ marginBlock: ".5rem" }}>Current Status : <span style={{ color: "green" }}>100% Achieved</span></p>
                                                <h3 style={{ marginTop: "1rem" }}>Upcoming Circulars: </h3><p>None</p>
                                            </ul>
                                        </Box>
                                    </div>
                                </Grid></Grid>

                        </>
                        :
                        <>
                            <FinanceCards />
                            <AllCharts />
                        </>
                    }

                </Box>

            </Container>



        </>
    )
}
export default AmcGlanceDashBoard;