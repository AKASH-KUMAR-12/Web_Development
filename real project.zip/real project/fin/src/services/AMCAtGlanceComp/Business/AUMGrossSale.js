import React from 'react'
import { styled } from '@mui/material/styles';
import Grid from '@mui/material/Unstable_Grid2';
import Paper from '@mui/material/Paper';
import { useSelector } from 'react-redux';
import Donut from './Donut';
const Item = styled(Paper)(({ theme }) => ({
    backgroundColor: '#E3EAF3',
    padding: theme.spacing(1),
    border: 0,
}));

const AUMGrossSale = () => {
    const amcAtGlanceData = useSelector((state) => state.CurrentApiData?.AmcAtGlanceApiResponse)
    console.log("amcAtGlanceData", amcAtGlanceData);
    let transactionCatagoryData = [{
        chartData: [
            {
                "label": "New Lumpsum",
                "value": "15"
            },
            {
                "label": "Additional Lumpsum",
                "value": "45"
            },
            {
                "label": "New SIP",
                "value": "-30"
            },
            {
                "label": "Additional SIP",
                "value": "22"
            },
            {
                "label": "Switch In",
                "value": "-43"
            }],
        chartAxis:
        {
            xName: "Transaction Cateogory", yName: "Value in Thousands"
        }
    }]

    let grossSaleschartData = [
        {
            "label": "Equity",
            "value": "80"
        },
        {
            "label": "Hybrid",
            "value": "30"
        },
        {
            "label": "Debt",
            "value": "10"
        },
    ]

    return (
        <>
            <Grid container spacing={1} sx={{ margin: "2% 1% 0 0", "& .css-1ik6aa3-MuiPaper-root": { backgroundColor: "#fff", height: "auto" } }}>
                <Grid xs={12} md={6} sx={{ "& .css-1ik6aa3-MuiPaper-root": { boxShadow: 6, padding: "0", borderRadius: "0.5rem", } }}>
                    <Item>
                        <h3 style={{ padding: "0.5rem" }}>Gross Sales</h3>
                        <hr style={{ height: "2px", backgroundColor: "#b9b9b9" }} />
                        <div style={{ paddingBottom: "0.4rem" }}>
                            <Donut centerLabel={"Gross Sale    ₹647.21 Cr"} data={grossSaleschartData} />
                        </div>
                    </Item>
                </Grid>
                <Grid xs={12} md={6} sx={{ "& .css-1ik6aa3-MuiPaper-root": { boxShadow: 6, padding: "0", borderRadius: "0.5rem" } }}>
                    <Item>
                        <h3 style={{ padding: "0.5rem" }}>AUM</h3>
                        <hr style={{ height: "2px", backgroundColor: "#b9b9b9" }} />
                        <div style={{ paddingBottom: "0.4rem" }}>
                            <Donut centerLabel={"AUM   ₹76259.28 Cr"} data={amcAtGlanceData} />
                        </div>
                    </Item>
                </Grid>
            </Grid>
        </>
    )
}

export default AUMGrossSale