import React from "react";
import ReactFC from "react-fusioncharts";
import FusionCharts from "fusioncharts";
import FusionTheme from "fusioncharts/themes/fusioncharts.theme.fusion";
import Widgets from 'fusioncharts/fusioncharts.widgets';

ReactFC.fcRoot(FusionCharts, Widgets, FusionTheme);


const SpeedoMeter = ({ xAxisName, yAxisName }) => {
    const chartConfigs = {
        "type": "angulargauge",
        "renderAt": "chart-container",
        "width": "90%",
        "height": "100%",
        "dataFormat": "json",
        dataSource: {
            chart: {
                caption: "Compliance Metrics",
                subcaption: "*data received from KOMRisk",
                lowerlimit: "0",
                upperlimit: "100",
                showvalue: "1",
                numbersuffix: "%",
                theme: "fusion",
                showtooltip: "0",

            },
            colorrange: {
                color: [
                    {
                        minvalue: "0",
                        maxvalue: "50",
                        code: "#F2726F"
                    },
                    {
                        minvalue: "50",
                        maxvalue: "75",
                        code: "#FFC533"
                    },
                    {
                        minvalue: "75",
                        maxvalue: "100",
                        code: "#62B58F"
                    }
                ]
            },
            dials: {
                dial: [
                    {
                        value: "98"
                    }
                ]
            }
        }
    };



    return (
        <ReactFC {...chartConfigs} />
    );

}
export default SpeedoMeter;