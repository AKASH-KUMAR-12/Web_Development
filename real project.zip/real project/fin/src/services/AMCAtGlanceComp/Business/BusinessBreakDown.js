import React from 'react';
import { styled } from '@mui/material/styles';
import Grid from '@mui/material/Unstable_Grid2';
import Paper from '@mui/material/Paper';
import { ArrowDownward, ArrowUpward } from '@mui/icons-material';
import { Chip } from '@mui/material';
const Item = styled(Paper)(({ theme }) => ({
    backgroundColor: '#E3EAF3',
    padding: theme.spacing(1),
    border: 0,
}));


const BusinessBreakDown = () => {
    let data = [
        {
            "key": "Total AUM",
            "value": " ₹ 1,986 Cr",
            cremental: "increases",
            amount: "₹ 76,259.28 Cr",
            percent: "2.60%"
        },
        {
            "key": "Total Investors",
            "value": "32,143",
            cremental: "increases",
            amount: "31,82,167",
            percent: "1.02%"
        },
        {
            "key": "No. of Distributors Activated ",
            "value": " 134",
            cremental: "increases",
            amount: "32,989",
            percent: "0.40%"
        },
        {
            "key": "Gross Sale",
            "value": " ₹ 60.98 Cr",
            cremental: "increases",
            amount: "₹ 647.21 Cr",
            percent: "10.21%"
        },
        {
            "key": "Gross Redemption",
            "value": " ₹ 37.23 Cr",
            cremental: "decreases",
            amount: "₹ 397.22 Cr",
            percent: "7.21%"
        },
        {
            "key": "Net Sale",
            "value": " ₹ 23.75 Cr",
            cremental: "increases",
            amount: "₹ 249.99 Cr",
            percent: "38.94%"
        },

    ]
    const sipData = [
        {
            "key": "SIP Book Amount",
            "value": " ₹ 250.64 Cr",
            cremental: "increases",
            amount: "₹ 5,100.85 Cr",
            percent: "5.16%"
        },

        {
            "key": "Total SIP Book Count",
            "value": "13,000",
            cremental: "increases",
            amount: "5,80,838",
            percent: "2.28%"
        },
        {
            "key": "Fresh SIP Amount(MTD)",
            "value": "₹ 34.12 Cr",
            cremental: "increases",
            amount: "₹ 647 Cr",
            percent: "5.56%"
        },
        {
            "key": "Fresh SIP Count(MTD)",
            "value": "2,232",
            cremental: "increases",
            amount: "79,722",
            percent: "2.88%"
        },

    ]

    return (
        <>
            <Grid container spacing={{ xs: 2, md: 2 }} columns={{ xs: 4, sm: 8, md: 12 }} sx={{ bgcolor: "white", borderRadius: "8px", boxShadow: 8, padding: ".5rem 1rem", margin: "1% 1% 0 1%", "& .css-1ik6aa3-MuiPaper-root": { background: "#fff", height: "7rem", borderTop: 4, borderColor: 'primary.main', borderRadius: '0.625rem', boxShadow: 4 } }}>
                <Grid item xs={12} mb={1}>
                    <h3 style={{ marginBottom: ".5rem" }}>AMC Analytics</h3>
                    <hr />
                </Grid>
                {data.map((res, index) => (
                    <Grid xs={5} sm={4} md={4} key={index} >
                        <Item >
                            <div style={{ display: "flex", justifyContent: 'space-between' }}>
                                <p style={{ marginTop: "1%", marginLeft: "2%", fontWeight: "bold" }}>{res.key}</p>
                                {
                                    (res.cremental == "increases") ? (<h3 style={{ color: "#77B900", marginTop: "1%", marginRight: "2%" }}>+{res.value}</h3>) : (<h3 style={{ color: "red", marginTop: "1%", marginRight: "2%" }}>-{res.value}</h3>)
                                }
                            </div>
                            <div>
                                {res.key != "Total Investors" ? <p style={{ color: "grey", marginTop: "2rem", marginLeft: "2%" }}>
                                    Current Value
                                </p>
                                    :
                                    <p style={{ color: "grey", marginTop: "2rem", marginLeft: "2%" }}>
                                        No. of Investors
                                    </p>}
                            </div>
                            <div style={{ display: "flex", justifyContent: 'space-between' }}>
                                <h3 style={{ marginTop: "0.5rem", marginLeft: "2%" }}>{res.amount}</h3>
                                {
                                    (res.cremental == "increases") ? (<h3 style={{ color: "#77B900", marginTop: "0.5rem", marginRight: "2%" }}><ArrowUpward />{res.percent}</h3>) : (<h3 style={{ color: "red", marginTop: "0.5rem", marginRight: "2%" }}>{res.key == "Gross Redemption" ? <ArrowUpward /> : <ArrowDownward />}{res.percent}</h3>)
                                }
                            </div>
                        </Item>
                    </Grid>
                ))}
            </Grid>
            <Grid container spacing={{ xs: 2, md: 1 }} columns={{ xs: 4, sm: 8, md: 12 }} sx={{ bgcolor: "white", borderRadius: "8px", boxShadow: 8, padding: "1rem", boxShadow: 8, margin: "3% 1% 0 1%", "& .css-1ik6aa3-MuiPaper-root": { background: "#fff", height: "7rem", borderTop: 4, borderColor: 'primary.main', borderRadius: '0.625rem', boxShadow: 4 } }}>
                <Grid item xs={12} mb={1}>
                    <h3 style={{ marginBottom: ".5rem" }}>SIP</h3>
                    <hr />
                </Grid>
                {sipData.map((res, index) => (
                    <Grid xs={5} sm={4} md={4} key={index} >
                        <Item >
                            <div style={{ display: "flex", justifyContent: 'space-between' }}>
                                <p style={{ marginTop: "1%", marginLeft: "2%", fontWeight: "bold" }}>{res.key}</p>
                                {
                                    (res.cremental == "increases") ? (<h3 style={{ color: "#77B900", marginTop: "1%", marginRight: "2%" }}>+{res.value}</h3>) : (<h3 style={{ color: "red", marginTop: "1%", marginRight: "2%" }}>-{res.value}</h3>)
                                }
                            </div>
                            <div>
                                {res.key != "Total Investors" ? <p style={{ color: "grey", marginTop: "2rem", marginLeft: "2%" }}>
                                    Current Value
                                </p>
                                    :
                                    <p style={{ color: "grey", marginTop: "2rem", marginLeft: "2%" }}>
                                        No. of Investors
                                    </p>}
                            </div>
                            <div style={{ display: "flex", justifyContent: 'space-between' }}>
                                <h3 style={{ marginTop: "0.5rem", marginLeft: "2%" }}>{res.amount}</h3>
                                {
                                    (res.cremental == "increases") ? (<h3 style={{ color: "#77B900", marginTop: "0.5rem", marginRight: "2%" }}><ArrowUpward />{res.percent}</h3>) : (<h3 style={{ color: "red", marginTop: "0.5rem", marginRight: "2%" }}><ArrowDownward />{res.percent}</h3>)
                                }
                            </div>
                        </Item>
                    </Grid>
                ))}
                <Grid xs={5} sm={4} md={8} >
                    <Item >
                        <div style={{ display: "flex", justifyContent: 'space-between' }}>
                            <p style={{ marginTop: "0%", marginLeft: "2%", fontWeight: "bold" }}>AI driven Insights: SIP  <Chip sx={{ bgcolor: "green", color: "white" }} size='small' label="new" /></p>
                        </div>
                        <div>

                            <ul style={{ marginTop: ".2rem", marginLeft: "0%", fontSize: ".8rem" }}>
                                <li>32651 Folios having SIP book 21.67Cr has 2 consecutive rejection cycles in Sep 23.Please <a style={{ fontWeight: "500", cursor: "pointer" }}>click here</a> to generate the mail alert for Distributors/Investors.</li>
                                <li>Highest churn observed in Small cap fund this month (2091 Folios terminated). </li>
                                <li>72003 Folios having SIP value of 750 Cr is maturing in the month of Sep 23.Please <a style={{ fontWeight: "500", cursor: "pointer" }}>click here</a> to download the complete list of Investors along with the cross sell opportunities as per their investment pattern derived from CDP.</li>
                            </ul>
                        </div>

                    </Item>
                </Grid>
            </Grid>
        </>
    )
}

export default BusinessBreakDown