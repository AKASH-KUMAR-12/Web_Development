import React from 'react'
import Donut from '../../../newCharts/charts/Donut';
import { Grid } from '@mui/material';

const data = [
  {
    label: "Male",
    value: "1000",
  },
  {
    label: "Female",
    value: "500",

  },
  {
    label: "Other",
    value: "500",

  }
]

const InvestorDemography = () => {
  const [value, setValue] = React.useState("AUM");
  const handleChange = (event) => {
    setValue(event.target.value);
  };
  return (
    <>
      <Grid item xs={12} md={12}>
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            borderBottom: "2px solid #b9b9b9",
            marginBottom: "1px"
          }}
        >
          <div
            style={{ display: "flex", alignItems: "center", marginLeft: "10px", paddingBlock: ".5rem" }}
          >
            <p style={{ fontWeight: "bold" }}>Investor Category</p>
          </div>

        </div>
      </Grid>
      <Grid container spacing={0}>
        <Grid item xs={12} sm={12} md={5}>
          <Donut data={data} />
        </Grid>

        <Grid item xs={12} sm={12} md={7}>
          <div className="description_main_card_container" >
            <div className="vl"></div>
            <div className="description_card_container" style={{ width: "70%" }}>
              <ul className="description_card_list_container">
                <li>Equity AUM has grown up by 1231 Cr in current FY.</li>
                <li>
                  Debt AUM has grown up by 200 Cr in current FY.
                </li>
                <li>Hybrid AUM has grown up by 517 Cr in current FY.</li>
              </ul>
            </div>
          </div>
        </Grid>
      </Grid>
    </>
  )
}

export default InvestorDemography

