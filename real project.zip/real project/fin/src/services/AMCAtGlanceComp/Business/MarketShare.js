import React from "react";
import { Grid } from "@mui/material";
import "../../SIPBookComp/components/style/style.css";
import Radio from "@mui/material/Radio";
import RadioGroup from "@mui/material/RadioGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import FormControl from "@mui/material/FormControl";
import DoubleChart from "../../../newCharts/charts/DoubleChart"


const MarketShare = () => {
  const [value, setValue] = React.useState("KFinTech AMC");
  const handleChange = (event) => {
    setValue(event.target.value);
  };
  const data = [
    {
      label: "MFD",
      value: "41"
    },
    {
      label: "ND",
      value: "50"
    },
    {
      label: "DIRECT",
      value: "30"
    },
    {
      label: "RIA",
      value: "35"
    },
    {
      label: "BANK",
      value: "32"
    }
  ]

  return (
    <Grid item xs={12} md={12}>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          borderBottom: "2px solid #b9b9b9",
        }}
      >
        <div
          style={{ display: "flex", alignItems: "center", marginLeft: "10px" }}
        >
          <p style={{ fontWeight: "bold" }}>Market Share</p>
        </div>
        <div>
          <FormControl>
            <RadioGroup
              sx={{
                '& .MuiTypography-root': {
                  fontSize: '.8rem',
                }
              }}
              row
              aria-labelledby="demo-controlled-radio-buttons-group"
              name="controlled-radio-buttons-group"
              value={value}
              onChange={handleChange}
            >
              <FormControlLabel
                value="KFinTech AMC"
                control={<Radio />}
                label="KFinTech AMC"
              />
              <FormControlLabel
                value="All AMC"
                control={<Radio />}
                label="All AMC"
              />
            </RadioGroup>
          </FormControl>
        </div>
        <div style={{ display: "flex", alignItems: "center" }}>
          <p style={{ borderLeft: "1.3rem solid #2057A6", height: "1.1rem", fontSize: "0.8rem", padding: "0.1rem 0 0 0.5rem", }}>Flow</p>
          <p style={{ borderLeft: "1.3rem solid #69B8F4", height: "1.1rem", margin: "0 1rem 0 1rem", fontSize: "0.8rem", padding: "0.1rem 0 0 0.5rem" }}>AUM</p>
        </div>

      </div>
      <div style={{ marginTop: "0.9rem", marginLeft: "0.5rem" }}>
        <DoubleChart />
      </div>
    </Grid>
  );
};

export default MarketShare;
