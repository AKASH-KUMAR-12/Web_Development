import * as QuickSightEmbedding from "amazon-quicksight-embedding-sdk";
import React, { useEffect, createRef, useState, useRef } from "react";
import axios from "axios";
import SecureLS from "secure-ls";
import { Box, Card, CardContent, CardHeader, Grid, IconButton, MenuItem, Select, TextField } from "@mui/material";
var ls = new SecureLS({
    encodingType: "aes",
    isCompression: false,
    encryptionSecret: "my-secret-key",
});

let reportNameMap = {
    "MCR": "757328ef-b2a4-4fb1-8858-763b6b17ef5e",
    "Segmentwise": "e3ad8850-d4fd-4709-bd38-7414ff87df4a",
    "Bank Contribution": "79520542-d6bc-4fa1-ba85-43de277424a0",
    "20-25 Percent": "d6862afc-b2c0-4d75-8de0-923c01c52645",
    "Monthly SIP": "b98754bb-4000-40f8-8e38-5f0f9e882ed9",
    "AgeWise SIP": "ddf49a38-a1c7-488a-8e43-8cc28fabc922",
    "5 Percent Corpus": "35d3e36c-e57f-453f-9e3b-11df09442161",
    "State Wise AAUM": "51ee00ec-5e3e-414a-8961-8ac8b1edec24",
    "State Wise SIP AUM": "0a629426-2e68-4ffe-add1-4a5ceeac65ef",
    "State Wise SIP Report": "779b40a2-0120-4644-b4eb-8bd57c065bec",
    "MSR": "6c24e68c-a732-46af-962e-ea4a1841d290",
    "SchemeCategoryWise": "8505d435-0853-4695-adc1-6b5daec64faa",
    "Active and Unique Investor": "437f5ea0-d9cf-45e6-a55b-ed475b0baeff",
    "sales": "3177f365-0fb3-452c-96ad-7a812140cc23",
}

let darkTheme = {
    "MSR": "2c6a27b9-33bf-4dc4-896a-dedf1485f15e",
}
const Sales = () => {
    const [reportName, setType] = useState("MSR")

    const [dashboard, setDashboard] = useState(null)
    var user = ls.get("user");

    const embeddingContainer = useRef(null)


    function onDashboardLoad(payload) {
        console.log("h1")
        var iframe = document.getElementsByClassName('quicksight-embedding-iframe');
        var innerDoc = iframe;
        console.log(innerDoc)
        console.log(document.getElementsByClassName('quicksight-embedding-iframe'))
    }

    useEffect(() => {
    }, [])


    useEffect(() => {
        (async () => {
            embeddingContainer.current.innerHTML = "";
            console.log(embeddingContainer.current)

            await axios
                .get(`https://finstaxdemo.kfintech.com/api/embed?Id=${reportNameMap.sales}`)
                .then((data) => {
                    console.log("url is working");
                    console.log(data)
                    var embedUrl = data.data.EmbedUrl;

                    var options = {
                        url: embedUrl,
                        container: embeddingContainer.current,
                        themeId: "arn:aws:quicksight::aws:theme/MIDNIGHT"
                    };
                    let dashboard;
                    try {
                        dashboard = QuickSightEmbedding.embedDashboard(options)
                        dashboard.on("load", onDashboardLoad)
                    }
                    catch (e) { }

                    setDashboard(dashboard)

                });
        })();


    }, []);

    return (
        <div style={{ overflow: "hidden", whiteSpace: "nowrap" }}>

            <Card
                sx={{ boxShadow: 6, overflow: "hidden", whiteSpace: "nowrap", margin: "20px", height: "88vh", padding: "0px", borderRadius: "8px", display: "flex", flexDirection: "column" }}
            >
                <CardContent sx={{
                    display: "flex",
                    flex: "10",

                }}>
                    <Box sx={{
                        boxShadow: "var(--softUIEffect-1)",
                        flex: "1",
                        boxShadow: 6,
                        borderRadius: "8px"
                    }}>
                        <>
                            <div id="embedding"
                                style={{
                                    paddingTop: "1rem",
                                    justifyItems: "center",
                                    height: "95%",
                                }}
                                ref={embeddingContainer}
                            >
                                { }

                            </div>
                        </>
                    </Box>

                </CardContent>
            </Card>
        </div>

    )
}

export default Sales