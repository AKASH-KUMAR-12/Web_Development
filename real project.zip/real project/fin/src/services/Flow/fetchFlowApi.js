
import axios from "axios";
export const fetchData = async (payload) => {
    try {
        let response = await axios.post("/api/getflow", payload);
        return response;
    }
    catch (e) {
        return e;
    }
}

export const fetchCardsData = async (payload,{activePage }) => {
    const response = await fetchData(payload);
    let cardData
    let cardsValue=response.data[0]
        if (activePage === "amount") {
            cardData=[{
              name: "Inflow",
              value: parseFloat(cardsValue.inflow / 10000000).toFixed(2)
            },
            {
              name: "Outflow",
              value: parseFloat(cardsValue.outflow / 10000000).toFixed(2)
            },
            {
              name: "Netflow",
              value: parseFloat(cardsValue.netflow / 10000000).toFixed(2)
            }]
          }
          else if (activePage === "count") {
            cardData=[{
              name: "Purchase",
              value: cardsValue.purchase
            },
            {
              name: "Redemption",
              value: cardsValue.redemption
            },
            ]
          }
    return cardData;

}

export const fetchTransCatData = async (payload, { cardSelected }) => {

    const response = await fetchData(payload);
    console.log("########################", response, cardSelected)
    let chartData;
    chartData = response.data.map((ele) => {
        if(cardSelected == "purchase" || cardSelected == "redemption")
        {
            return { label: ele.transaction_category, value: ele[cardSelected] }
        }
        else
         {
         return { label: ele.transaction_category, value: parseFloat(ele[cardSelected]/10000000).toFixed(2) }
         }
    })
    return chartData;

}

export const fetchTransTypeData = async (payload, { cardSelected }) => {
    const response = await fetchData(payload);
    let donutData;

    donutData = response.data.filter((ele) => ele[cardSelected] > 0).map((ele) => {
        if(cardSelected == "purchase" || cardSelected == "redemption")
        {
            return { label: ele.transaction_type, value: ele[cardSelected] }
        }
        else
         {
         return { label: ele.transaction_type, value: parseFloat(ele[cardSelected]/10000000).toFixed(2) }
         }
    })
    console.log(donutData)
    // setApiData(donutData);
    return donutData;


}

export const fetchTransSourceData = async (payload, { cardSelected }) => {
    const response = await fetchData(payload);
    console.log("plan Mode response Data", response.data);
    let chartData;
    // if (radioValue == "AUM") {
    chartData = response.data.map((ele) => {
        if(cardSelected == "purchase" || cardSelected == "redemption")
        {
            return { label: ele.transaction_source, value: ele[cardSelected] }
        }
        else
         {
         return { label: ele.transaction_source, value: parseFloat(ele[cardSelected]/10000000).toFixed(2) }
         }
    })
    // }
    // else if (radioValue == "PAN Count") {
    //     donutData = response.data.map((ele) => {
    //         return { label: ele.terflagfolio, value: ele.aggregate_count }
    //     })
    // }
    // setApiData(donutData);
    return chartData;


}
export const fetchAssetClassData = async (payload, { cardSelected }) => {
    const response = await fetchData(payload);
    console.log("plan Mode response Data", response.data);
    let donutData;
    donutData = response.data.map((ele) => {
        if(cardSelected == "purchase" || cardSelected == "redemption")
        {
            return { label: ele.assetclassnewmcr, value: ele[cardSelected] }
        }
        else
         {
         return { label: ele.assetclassnewmcr, value: parseFloat(ele[cardSelected]/10000000).toFixed(2) }
         }
    })
    return donutData;
}
export const fetchSubSchemeCatData = async (payload, { cardSelected }) => {

    const response = await fetchData(payload);
    console.log("plan Mode response Data", response.data);
    let chartData;
    chartData = response.data.map((ele) => {
        if(cardSelected == "purchase" || cardSelected == "redemption")
        {
            return { label: ele.assetcategorynewmcr, value: ele[cardSelected] }
        }
        else
         {
         return { label: ele.assetcategorynewmcr, value: parseFloat(ele[cardSelected]/10000000).toFixed(2) }
         }
    })
    return chartData;


}
export const fetchSchemeNameData = async (payload, { cardSelected }) => {
    const response = await fetchData(payload);
    console.log("plan Mode response Data", response.data);
    let chartData;
    chartData = response.data.map((ele) => {
        if(cardSelected == "purchase" || cardSelected == "redemption")
        {
            return { label: ele.schemename, value: ele[cardSelected] }
        }
        else
         {
         return { label: ele.schemename, value: parseFloat(ele[cardSelected]/10000000).toFixed(2) }
         }
    })
    return chartData;


}
export const fetchBottomCardData = async (payload, { cardSelected }) => {

    const response = await fetchData(payload);
    console.log("plan Mode response Data", response.data);
    let chartData;
    chartData = response.data.data.map((ele) => {
        if (ele[cardSelected] > 0) {
            return { label: ele.final_city, value: parseFloat(ele[cardSelected]).toFixed(2) }
        }
        else {
            return { label: ele.final_city, value: parseFloat(ele[cardSelected]).toFixed(2), color: "#F88787" }

        }
    })
    console.log(chartData)
    return chartData;
}
export const fetchDefaultFilterData = async () => {
    const payload = {
        page: "flow",
        fund: "RMF"
    }
    const response = await axios.post("/api/getfilters", payload);
    console.log("plan Mode response Data", response.data);
    const resData = response.data[0];
    let deafultFilterData = {
        "assetClass": resData.assetclassnewmcr,
        "assetCategory": resData.assetcategorynewmcr,
        "schemeName": resData.schemename,
        "transactionSource": resData.transaction_source,
        "transactionType": resData.transaction_type
    }
    console.log(deafultFilterData)
    return deafultFilterData;
}



export const fetchMapData = async (payload, { cardSelected }) => {

    let response = await fetchData(payload)
    let mapData;
    mapData = response.data.map((ele) => {
        return {
            "id": stateID[ele.final_state],
            "value": parseFloat(ele[cardSelected?.toLowerCase()] / 10000).toFixed(2),
            "color": colorCode[stateZone[ele.final_state]],
            "fontColor": darkFontID.includes(stateID[ele.final_state]) ? "#96967F" : "#e3e2e1"
        }
    })
    return mapData;

}
export const fetchMapTableData = async (payload, { radioValue, cardSelected }) => {

    let response = await fetchData(payload)
    let tableData;
    const tableColumn = {
        "State": "final_state",
        "Region": "zone",
        "City": "final_city"
    }
    tableData = response.data.map((ele) => {
            
            if (cardSelected == "Purchase" || cardSelected == "Redemption" )
            {
                return{
                [radioValue]: ele[tableColumn[radioValue]],
                [cardSelected]:ele[cardSelected?.toLowerCase()],
            "PAN Count": ele.pan_count,}
            }
            else{
                return{
                [radioValue]: ele[tableColumn[radioValue]],
                [cardSelected]: parseFloat(ele[cardSelected?.toLowerCase()] / 10000).toFixed(2),
            "PAN Count": ele.pan_count,}
            }
        }
    )
    console.log("#####################", tableData);
    return tableData;
}

const stateID = {
    "KARNATAKA": "017",
    "DAMAN AND DIU": "009",
    "OTHERS": "000",
    "DELHI": "010",
    "LADAKH": "",
    "RAJASTHAN": "029",
    "MANIPUR": "022",
    "ANDHRA PRADESH": "002",
    "WEST BENGAL": "035",
    "MADHYA PRADESH": "020",
    "KERALA": "018",
    "GUJARAT": "012",
    "TELANGANA": "036",
    "ANDAMAN AND NICOBAR": "001",
    "BIHAR": "005",
    "GOA": "011",
    "CHANDIGARH": "006",
    "TRIPURA": "032",
    "DADRA AND NAGAR HAVELI": "008",
    "NAGALAND": "025",
    "JHARKHAND": "016",
    "ASSAM": "004",
    "PUNJAB": "028",
    "JAMMU AND KASHMIR": "015",
    "PUDUCHERRY": "027",
    "ODISHA": "026",
    "MEGHALAYA": "023",
    "MIZORAM": "024",
    "MAHARASHTRA": "021",
    "ARUNACHAL PRADESH": "003",
    "CHHATTISGARH": "007",
    "TAMIL NADU": "031",
    "SIKKIM": "030",
    "LAKSHADWEEP": "019",
    "HARYANA": "013",
    "UTTAR PRADESH": "033",
    "UTTARAKHAND": "034",
    "HIMACHAL PRADESH": "014"
}
const stateZone = {
    "KARNATAKA": "South",
    "ANDHRA PRADESH": "South",
    "PUDUCHERRY": "South",
    "KERALA": "South",
    "TELANGANA": "South",
    "TAMIL NADU": "South",
    "LAKSHADWEEP": "South",

    "MAHARASHTRA": "West",
    "DAMAN AND DIU": "West",
    "GUJARAT": "West",
    "RAJASTHAN": "West",
    "GOA": "West",
    "MADHYA PRADESH": "West",
    "DADRA AND NAGAR HAVELI": "West",

    "DELHI": "North",
    "JAMMU AND KASHMIR": "North",
    "PUNJAB": "North",
    "HARYANA": "North",
    "UTTARAKHAND": "North",
    "HIMACHAL PRADESH": "North",
    "UTTAR PRADESH": "North",
    "CHANDIGARH": "North",
    "LADAKH": "North",

    "WEST BENGAL": "East",
    "ANDAMAN AND NICOBAR": "East",
    "CHHATTISGARH": "East",
    "BIHAR": "East",
    "MANIPUR": "East",
    "TRIPURA": "East",
    "NAGALAND": "East",
    "JHARKHAND": "East",
    "ASSAM": "East",
    "ODISHA": "East",
    "MEGHALAYA": "East",
    "MIZORAM": "East",
    "ARUNACHAL PRADESH": "East",
    "SIKKIM": "East",

    "OTHERS": "None",
}
const colorCode = {
    "North": "#61c99b",
    "South": "#ba87ed",
    "East": "#5abec7",
    "West": "#4990f0"
}
//Labels that should have black font
const darkFontID = ["001", "011", "019", "027"]