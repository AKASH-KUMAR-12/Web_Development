import React, { useState } from 'react'
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import { styled } from '@mui/material/styles';
import TransactionCatagory from './Amount/TransactionCatagory';
import TransactionTypeAndSource from './Amount/TransactionTypeAndSource';
import AssetSchemeSubCatagory from './Amount/AssetSchemeSubCatagory';
import SchemeGraph from './Amount/SchemeGraph';
import GrossRedemptionNetSales from './Amount/GrossRedemptionNetSales';
import InvestorDemographyMap from './Amount/InvestorDemographyMap';
import { assetClassData, SIPAgeingData, data, planModelistArray, revenueData } from "../../utilityComponents/Database"
import { Grid } from '@mui/material';
import BarChart from '../../utilityComponents/charts/BarChart';
import VerticalBarChart from '../../utilityComponents/charts/verticalBarChart';
import MapChart from '../../utilityComponents/charts/MapChart';
import Donut from '../../utilityComponents/charts/Donut';
import { fetchCardsData, fetchAssetClassData, fetchMapData, fetchMapTableData, fetchTransCatData, fetchInflowData, fetchNetflowData, fetchOutflowData, fetchBottomCardData, fetchSchemeNameData, fetchSubSchemeCatData, fetchTransSourceData, fetchTransTypeData, fetchData, fetchDefaultFilterData } from './fetchFlowApi';
import { useDispatch, useSelector } from 'react-redux';
import { useEffect } from 'react';
import { clearFlowFilterData, setFlowData } from '../../reduxStore/flowReducer';
import FilterChip from '../../utilityComponents/FilterChip';

const transactionCategory = [
  {
    label: "New Lumpsum",
    value: "41"
  },
  {
    label: "Additional Lumpsum",
    value: "50"
  },
  {
    label: "Additional SIP",
    value: "35"
  },
  {
    label: "Others",
    value: "32"
  }
]
const donutData = [
  {
    "label": "SIP",
    "value": "45"
  },
  {
    "label": "Lumpsum",
    "value": "75"
  },
  {
    "label": "Other",
    "value": "30"
  },
]
let chartData = [
  {
    "label": "Exchange",
    "value": "15"
  },
  {
    "label": "Channel Par...",
    "value": "17"
  },
  {
    "label": "AMC Digital",
    "value": "5"
  },
  {
    "label": "MFU Online",
    "value": "7"
  },
  {
    "label": "MFCentral",
    "value": "3"
  },
  {
    "label": "Kfintech Di...",
    "value": "4"
  },
  {
    "label": "Physical Br...",
    "value": "47"
  }]
const assetData = [
  {
    "label": "Debt",
    "value": "45"
  },
  {
    "label": "Equity",
    "value": "45"
  },
  {
    "label": "Hybrid",
    "value": "10"
  },
]
let schemeData = [
  {
    "label": "Small Cap Fund",
    "value": "15"
  },
  {
    "label": "Ultra Short Term Fund",
    "value": "45"
  },
  {
    "label": "Mid Cap Fund",
    "value": "30"
  },
  {
    "label": "Overnight Fund",
    "value": "22"
  }
  ,
  {
    "label": "Multicap Fund",
    "value": "32"
  }
  ,
  {
    "label": "Equity Hybrid Fund",
    "value": "42"
  }]
const SchemeGraphData =
  [{
    label: "SMALL CAP FUND",
    "value": "15"
  },
  {
    label: "ULTRA SHORT TERM FUND",
    "value": "45"
  },
  {
    label: "MID CAP FUND",
    "value": "30"
  },
  {
    label: "OVERNIGHT FUND",
    "value": "22"
  }
    ,
  {
    label: "MULTICAP FUND",
    "value": "32"
  }
    ,
  {
    label: "EQUITY HYBRID FUND",
    "value": "42"
  },
  ]
let transactionCatagoryData = [{
  chartData: [
    {
      "label": "Bangalore",
      "value": "15"
    },
    {
      "label": "mumbai",
      "value": "45"
    },
    {
      "label": "Delhi",
      "value": "30"
    },
    {
      "label": "Bilaspur",
      "value": "22"
    }],
  chartAxis:
  {
    xName: "Transaction Cateogory", yName: "Value in Thousands"
  }
},
{
  chartData: [
    {
      "label": "Bangalore",
      "value": "-15"
    },
    {
      "label": "mumbai",
      "value": "-45"
    },
    {
      "label": "Delhi",
      "value": "-30"
    },
    {
      "label": "Bilaspur",
      "value": "-22"
    },],
  chartAxis:
  {
    xName: "Flow", yName: "City"
  }
},
{
  chartData: [
    {
      "label": "Bangalore",
      "value": "15",
    },
    {
      "label": "mumbai",
      "value": "45"
    },
    {
      "label": "Delhi",
      "value": "30"
    },
    {
      "label": "Bilaspur",
      "value": "-22"
    },],
  chartAxis:
  {
    xName: "Flow", yName: "City"
  }
}]


const FlowDashBoard = () => {
  const [activePage, setActivePage] = useState("amount");
  const [cardSelected, setCardSelected] = useState("Inflow");
  const [mapRadio, setMapRadio] = useState("Region");
  // const [reRender, setReRender] = useState(false);
  const dispatch = useDispatch();
  const reducerState = useSelector((state) => state.flowFilterData);
  const investorData = useSelector((state) => state.flowFilterData?.investor)
  const zoneData = useSelector((state) => state.flowFilterData?.zone)
  const stateData = useSelector((state) => state.flowFilterData?.state)
  const assetClassData = useSelector((state) => state.flowFilterData?.assetClass)
  const assetCategoryData = useSelector((state) => state.flowFilterData?.assetCategory)
  const transTypeData = useSelector((state) => state.flowFilterData?.transactionType)
  const transSourceData = useSelector((state) => state.flowFilterData?.transactionSource)
  const schemeNameData = useSelector((state) => state.flowFilterData?.schemeName)
  const filterSelected = useSelector((state) => state.flowFilterData?.filterSelected)

  console.log(schemeNameData, transSourceData, transTypeData, filterSelected)
  useEffect(() => {
    const fetchingDefaultFilterData = async () => {

      const response = await fetchDefaultFilterData();
      console.log("called", response)
      localStorage.setItem("Finstax:FlowDefaultFilter", JSON.stringify(response));
      dispatch(setFlowData({ title: "transactionType", value: response["transactionType"] }))
      dispatch(setFlowData({ title: "transactionSource", value: response["transactionSource"] }))
      dispatch(setFlowData({ title: "assetClass", value: response["assetClass"] }))
      dispatch(setFlowData({ title: "assetCategory", value: response["assetCategory"] }))
      dispatch(setFlowData({ title: "schemeName", value: response["schemeName"] }))

    }
    if (!reducerState.filterSelected) { fetchingDefaultFilterData() };
  }, [reducerState.filterSelected])
  useEffect(() => {

    console.log("*******************************************************************************", investorData, zoneData, assetClassData, assetCategoryData, transTypeData, transSourceData, filterSelected);
  }, [investorData, assetClassData, assetCategoryData, zoneData, stateData, transTypeData, transSourceData])


  const cardsPayload =
  {
    "fund": "RMF",
    "zone": zoneData,
    "investor": investorData,
    "query_name": `flow-cards-${activePage}`,
    "state": stateData,
    "assetclass": assetClassData,
    "assetcategory": assetCategoryData,
    "transaction_type": transTypeData,
    "transaction_source": transSourceData,
    "schemename": schemeNameData,
    "comment": filterSelected ? "" : "-- ",
  }
  const transCatPayload =
  {
    "fund": "RMF",
    "zone": zoneData,
    "investor": investorData,
    "demographyColumn": cardSelected.toLowerCase(),
    "query_name": `flow-transactioncat-${activePage}`,
    "state": stateData,
    "assetclass": assetClassData,
    "assetcategory": assetCategoryData,
    "transaction_type": transTypeData,
    "transaction_source": transSourceData,
    "schemename": schemeNameData,
    "comment": filterSelected ? "" : "-- ",
  }
  const transTypePayload =
  {
    "fund": "RMF",
    "zone": zoneData,
    "investor": investorData,
    "query_name": `flow-middlecards-${activePage}`,
    "order": cardSelected.toLowerCase(),
    "demographyColumn": "transaction_type",
    "state": stateData,
    "assetclass": assetClassData,
    "assetcategory": assetCategoryData,
    "transaction_type": transTypeData,
    "transaction_source": transSourceData,
    "schemename": schemeNameData,
    "comment": filterSelected ? "" : "-- ",
  }
  const transSourcePayload =
  {
    "fund": "RMF",
    "zone": zoneData,
    "investor": investorData,
    "query_name": `flow-middlecards-${activePage}`,
    "order": cardSelected.toLowerCase(),
    "demographyColumn": "transaction_source",
    "state": stateData,
    "assetclass": assetClassData,
    "assetcategory": assetCategoryData,
    "transaction_type": transTypeData,
    "transaction_source": transSourceData,
    "schemename": schemeNameData,
    "comment": filterSelected ? "" : "-- ",
  }
  const assetClassPayload =
  {
    "fund": "RMF",
    "zone": zoneData,
    "investor": investorData,
    "query_name": `flow-middlecards-${activePage}`,
    "order": cardSelected.toLowerCase(),
    "demographyColumn": "assetclassnewmcr",
    "state": stateData,
    "assetclass": assetClassData,
    "assetcategory": assetCategoryData,
    "transaction_type": transTypeData,
    "transaction_source": transSourceData,
    "schemename": schemeNameData,
    "comment": filterSelected ? "" : "-- ",
  }
  const subschemeCatPayload =
  {
    "fund": "RMF",
    "zone": zoneData,
    "investor": investorData,
    "query_name": `flow-middlecards-${activePage}`,
    "order": cardSelected.toLowerCase(),
    "demographyColumn": "assetcategorynewmcr",
    "state": stateData,
    "assetclass": assetClassData,
    "assetcategory": assetCategoryData,
    "transaction_type": transTypeData,
    "transaction_source": transSourceData,
    "schemename": schemeNameData,
    "comment": filterSelected ? "" : "-- ",
  }
  const schemeNamePayload =
  {
    "fund": "RMF",
    "zone": zoneData,
    "investor": investorData,
    "query_name": `flow-middlecards-${activePage}`,
    "order": cardSelected.toLowerCase(),
    "demographyColumn": "schemename",
    "state": stateData,
    "assetclass": assetClassData,
    "assetcategory": assetCategoryData,
    "transaction_type": transTypeData,
    "transaction_source": transSourceData,
    "schemename": schemeNameData,
    "comment": filterSelected ? "" : "-- ",
  }
  const mapPayload = {
    "fund": "RMF",
    "zone": zoneData,
    "investor": investorData,
    "query_name": `flow-demography-${activePage}`,
    "comment": filterSelected ? "" : "-- ",
    "order": cardSelected.toLowerCase(),
    "demographyColumn": "final_state" || "zone" || "final_city",
    "state": stateData,
    "assetclass": assetClassData,
    "assetcategory": assetCategoryData,
    "transaction_type": transTypeData,
    "transaction_source": transSourceData,
    "schemename": schemeNameData,
  }

  const flowBottomCardPayload =
  {
    "fund": "RMF",
    "query_name": `flow-bottomcards-${activePage}`,
    "demographyColumn": cardSelected.toLowerCase()
  }

  const font_size = window.innerWidth <= 400 ? "5" : "18";
  return (
    <>
      <Box sx={{ padding: "0", width: "95%", margin: "0px auto" }}>
        <Box className='box_shadow'
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            flexWrap: "wrap",
            background: "#fff",

            borderRadius: "9px",
            margin: "1.5rem 1rem 1rem 1rem"
          }}
        >
          <h3 style={{ padding: "0.7rem", }}>Data as on 30th of September</h3>

          <div style={{ width: "fit-content", display: "flex", marginRight: "1rem" }}>
            <button

              onClick={() => {
                setActivePage("amount");
                setCardSelected("Inflow")
              }}

              style={{
                cursor: "pointer",
                padding: "0.4rem 2rem",
                marginLeft: "10px",
                borderRadius: "20px 0px 0px 20px",
                border: "1px solid #2057A6",
                fontSize: font_size,
                backgroundColor: activePage == "amount" ? "#2057A6" : "#fff",
                color: activePage == "amount" ? "#fff" : "",
              }}
            >
              Amount
            </button>
            <button

              onClick={() => {
                setActivePage("count")
                setCardSelected("Purchase")
              }}
              style={{
                cursor: "pointer",
                padding: ".4rem 1.1rem",
                borderRadius: "0px 20px 20px 0px",
                border: "1px solid #2057A6",
                fontSize: font_size,
                backgroundColor: activePage !== "amount" ? "#2057A6" : "#fff",
                color: activePage !== "amount" ? "#fff" : "",
              }}
            >
              Transaction Count
            </button>
          </div>

        </Box>

        <Grid container xs={12} justifyContent={"space-between"} alignItems={"center"}
          sx={{ height: { lg: "75vh", md: "75vh", xs: "82vh" }, width: "100%", paddingInline: "1rem", overflow: "scroll", paddingBottom: "3rem" }}>
          <FilterChip />
          <Grid item xs={12} md={3} sx={{ "& .css-1ik6aa3-MuiPaper-root": { boxShadow: 6 } }}>
            <TransactionCatagory
              fetchAPI={fetchCardsData}
              fetchPayload={cardsPayload}
              cardSelected={cardSelected}
              setCardSelected={setCardSelected}
              activePage={activePage}
            />
          </Grid >

          <BarChart
            xAxisName={"Value in Crores"}
            yAxisName={"Transaction Category"}
            data={transactionCategory}
            cardSelected={cardSelected.toLowerCase()}
            md={9}
            height={"17rem"}
            sx={{ marginTop: "0rem" }}
            fetchAPI={fetchTransCatData}
            fetchPayload={transCatPayload}
            headerProps={{
              heading: "Transaction Category",
            }}
          />
          <Donut
            md={5.8}
            data={donutData}
            fetchAPI={fetchTransTypeData}
            fetchPayload={transTypePayload}
            cardSelected={cardSelected.toLowerCase()}
            cardTitle="transactionType"
            reducerProps={{
              reducerName: "flowFilterData",
              setReducerData: setFlowData,
              clearFilterData: clearFlowFilterData
            }}
            headerProps={{
              heading: "Transaction Type",

            }}
          />
          <VerticalBarChart
            yAxisName={"Value in Crores"}
            xAxisName={"Transaction Source"}
            md={5.8}
            data={chartData}
            hoverText={activePage == "amount" ? "Value: ₹ $value Cr" : ""}
            fetchAPI={fetchTransSourceData}
            fetchPayload={transSourcePayload}
            cardSelected={cardSelected.toLowerCase()}
            cardTitle={"transactionSource"}
            headerProps={{
              heading: "Transaction Source",
              xs1: 12
            }}
          />
          <Donut
            md={5.8}
            data={assetData}
            fetchAPI={fetchAssetClassData}
            fetchPayload={assetClassPayload}
            cardSelected={cardSelected.toLowerCase()}
            cardTitle="assetClass"
            reducerProps={{
              reducerName: "flowFilterData",
              setReducerData: setFlowData,
              clearFilterData: clearFlowFilterData
            }}
            headerProps={{
              heading: "Asset Class",

            }}
          />
          <VerticalBarChart
            yAxisName={"Value in Crores"}
            xAxisName={"Scheme Sub Category"}
            md={5.8}
            data={schemeData}
            hoverText={activePage == "amount" ? "Value: ₹ $value Cr" : ""}
            fetchAPI={fetchSubSchemeCatData}
            fetchPayload={subschemeCatPayload}
            cardSelected={cardSelected.toLowerCase()}
            cardTitle={"assetCategory"}
            headerProps={{
              heading: "Scheme Sub Category",
              xs1: 12
            }}
          />
          <VerticalBarChart
            xAxisName={"Scheme"}
            yAxisName={"Value"}
            data={SchemeGraphData}
            hoverText={activePage == "amount" ? "Value: ₹ $value Cr" : ""}
            fetchAPI={fetchSchemeNameData}
            fetchPayload={schemeNamePayload}
            cardSelected={cardSelected.toLowerCase()}
            cardTitle={"schemeName"}
            headerProps={{
              heading: "Scheme Name",

            }}
          />
          <MapChart
            fetchAPI={fetchMapTableData}
            fetchMapAPI={fetchMapData}
            fetchPayload={mapPayload}
            cardSelected={cardSelected}
            tableColumn={[mapRadio, cardSelected, "PAN Count"]}
            headerProps={{
              heading: "Investor Demography - Location",
              radioValue: mapRadio,
              setRadioValue: setMapRadio
            }}
          />

          {(activePage == "amount") ? <>
            <BarChart
              xAxisName={"City"}
              yAxisName={"Flow"}
              md={3.9}
              data={transactionCatagoryData[0].chartData}
              fetchAPI={fetchBottomCardData}
              fetchPayload={{ ...flowBottomCardPayload, demographyColumn: "inflow" }}
              cardSelected={"inflow"}
              headerProps={{
                heading: "Inflow",
                xs1: 12
              }}
            />
            <BarChart
              xAxisName={"City"}
              yAxisName={"Flow"}
              md={3.9}
              data={transactionCatagoryData[1].chartData}
              fetchAPI={fetchBottomCardData}
              fetchPayload={{ ...flowBottomCardPayload, demographyColumn: "outflow" }}
              cardSelected={"outflow"}
              headerProps={{
                heading: "Outflow",
                xs1: 12
              }}
            />
            <BarChart
              xAxisName={"City"}
              yAxisName={"Flow"}
              md={3.9}
              data={transactionCatagoryData[2].chartData}
              fetchAPI={fetchBottomCardData}
              fetchPayload={{ ...flowBottomCardPayload, demographyColumn: "netflow" }}
              cardSelected={"netflow"}
              headerProps={{
                heading: "Netflow",
                xs1: 12
              }}
            /></> : <>
            <BarChart
              xAxisName={"City"}
              yAxisName={"Flow"}
              md={5.8}
              data={transactionCatagoryData[0].chartData}
              fetchAPI={fetchBottomCardData}
              fetchPayload={{ ...flowBottomCardPayload, demographyColumn: "purchase" }}
              cardSelected={"purchase"}
              headerProps={{
                heading: "Purchase",
                xs1: 12
              }}
            />
            <BarChart
              xAxisName={"City"}
              yAxisName={"Flow"}
              md={5.8}
              // data={transactionCatagoryData[1].chartData}
              fetchAPI={fetchBottomCardData}
              fetchPayload={{ ...flowBottomCardPayload, demographyColumn: "redemption" }}
              cardSelected={"redemption"}
              headerProps={{
                heading: "Redemption",
                xs1: 12
              }}
            /></>
          }


        </Grid>


      </Box>
    </>


  )
}

export default FlowDashBoard