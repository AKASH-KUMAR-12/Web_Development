import React from 'react'
import { styled } from '@mui/material/styles';
import Grid from '@mui/material/Unstable_Grid2';
import Paper from '@mui/material/Paper';
import { useSelector } from 'react-redux';
import BiDirectionalHorizontalBarChart from '../../../newCharts/charts/BiDirectionalHorizontalBarChart';
import HeaderParent from '../../../utilityComponents/components/HeaderParent';
import BarChart from '../../../utilityComponents/charts/BarChart';
const Item = styled(Paper)(({ theme }) => ({
    backgroundColor: '#E3EAF3',
    padding: theme.spacing(1),
    border: 0,
}));

const GrossRedemptionNetSales = () => {
    const amcAtGlanceData = useSelector((state) => state.CurrentApiData?.AmcAtGlanceApiResponse)
    console.log("amcAtGlanceData", amcAtGlanceData);
    let transactionCatagoryData = [{
        chartData: [
            {
                "label": "Bangalore",
                "value": "15"
            },
            {
                "label": "mumbai",
                "value": "45"
            },
            {
                "label": "Delhi",
                "value": "-30"
            },
            {
                "label": "Bilaspur",
                "value": "22"
            }],
        chartAxis:
        {
            xName: "Transaction Cateogory", yName: "Value in Thousands"
        }
    },
    {
        chartData: [
            {
                "label": "Bangalore",
                "value": "15"
            },
            {
                "label": "mumbai",
                "value": "45"
            },
            {
                "label": "Delhi",
                "value": "-30"
            },
            {
                "label": "Bilaspur",
                "value": "22"
            },],
        chartAxis:
        {
            xName: "Flow", yName: "City"
        }
    },
    {
        chartData: [
            {
                "label": "Bangalore",
                "value": "-15",
            },
            {
                "label": "mumbai",
                "value": "-45"
            },
            {
                "label": "Delhi",
                "value": "-30"
            },
            {
                "label": "Bilaspur",
                "value": "-22"
            },],
        chartAxis:
        {
            xName: "Flow", yName: "City"
        }
    }]
    return (
        <>
            <Grid container xs={12} justifyContent={"space-between"} sx={{
                // borderTop: "3px solid #010C43",
                marginBlock: "20px",
                borderRadius: '8px',
                alignItems: "center",
                height: "auto",
            }}>
                <Grid item xs={3.9} sx={{ bgcolor: "#fff", borderRadius: "8px", boxShadow: 6 }}>
                    <HeaderParent xs={12} xs1={12}
                        heading="Inflow"
                    />
                    <BarChart
                        xAxisName={"City"}
                        yAxisName={"Flow"}
                        data={transactionCatagoryData[0].chartData}
                    />
                </Grid>
                <Grid item xs={3.9} sx={{ bgcolor: "#fff", borderRadius: "8px", boxShadow: 6 }}>
                    <HeaderParent xs={12} xs1={12}
                        heading="Outflow"
                    />
                    <BarChart
                        xAxisName={"City"}
                        yAxisName={"Flow"}
                        data={transactionCatagoryData[1].chartData}
                    />
                </Grid>
                <Grid item xs={3.9} sx={{ bgcolor: "#fff", borderRadius: "8px", boxShadow: 6 }}>
                    <HeaderParent xs={12} xs1={12}
                        heading="Netflow"
                    />
                    <BarChart
                        xAxisName={"City"}
                        yAxisName={"Flow"}
                        data={transactionCatagoryData[2].chartData}
                    />
                </Grid>
            </Grid>
        </>
    )
}

export default GrossRedemptionNetSales