import React from 'react'
import { styled } from '@mui/material/styles';
import Grid from '@mui/material/Unstable_Grid2';
import Paper from '@mui/material/Paper';
import { useSelector } from 'react-redux';
import Donut from '../../../utilityComponents/charts/Donut';
import BarChart from '../../../utilityComponents/charts/BarChart';
import HeaderParent from '../../../utilityComponents/components/HeaderParent';
const Item = styled(Paper)(({ theme }) => ({
    backgroundColor: '#E3EAF3',
    padding: theme.spacing(1),
    border: 0,
}));

const TransactionTypeAndSource = ({ data }) => {
    const amcAtGlanceData = useSelector((state) => state.CurrentApiData?.AmcAtGlanceApiResponse)
    console.log("amcAtGlanceData", amcAtGlanceData);
    const donutData = [
        {
            "label": "SIP",
            "value": "45"
        },
        {
            "label": "Lumpsum",
            "value": "75"
        },
        {
            "label": "Other",
            "value": "30"
        },
    ]
    let chartData = [
        {
            "label": "Exchange",
            "value": "15"
        },
        {
            "label": "Channel Par...",
            "value": "17"
        },
        {
            "label": "AMC Digital",
            "value": "5"
        },
        {
            "label": "MFU Online",
            "value": "7"
        },
        {
            "label": "MFCentral",
            "value": "3"
        },
        {
            "label": "Kfintech Di...",
            "value": "4"
        },
        {
            "label": "Physical Br...",
            "value": "47"
        }]

    return (
        <>
            <Grid container xs={12} justifyContent={"space-between"} sx={{
                // borderTop: "3px solid #010C43",
                marginTop: "20px",
                borderRadius: '8px',
                alignItems: "center",
                height: "auto",
            }}>
                <Grid item xs={5.9} sx={{ bgcolor: "#fff", borderRadius: "8px", boxShadow: 6 }}>
                    <HeaderParent xs={12}
                        heading="Transaction Type"
                    />
                    <Donut
                        data={donutData}
                    />
                </Grid>
                <Grid item xs={5.9} sx={{ bgcolor: "#fff", borderRadius: "8px", boxShadow: 6 }}>
                    <HeaderParent xs={12} xs1={12}
                        heading="Transaction Source"
                    />
                    <BarChart
                        data={chartData}
                    />
                </Grid>
            </Grid>
        </>
    )
}

export default TransactionTypeAndSource