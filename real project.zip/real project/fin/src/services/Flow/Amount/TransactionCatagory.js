import React, { useState } from 'react';
import { styled } from '@mui/material/styles';
import Grid from '@mui/material/Unstable_Grid2';
import Paper from '@mui/material/Paper';
import BiDirectionalHorizontalBarChart from '../../../newCharts/charts/BiDirectionalHorizontalBarChart';
import Background from '../images/cardBackground.svg'
import TransCategoryBarChart from './TransCategoryBarChart';
import BarChart from '../../../utilityComponents/charts/BarChart';
import HeaderParent from '../../../utilityComponents/components/HeaderParent';
import { useEffect } from 'react';
import { clearFlowFilterData, setFlowData, setFlowFilterSelected } from '../../../reduxStore/flowReducer';
import { useSelector } from 'react-redux';
import { Box, CircularProgress } from '@mui/material';

const Item = styled(Paper)(({ theme }) => ({
  backgroundColor: '#fff',
  padding: theme.spacing(1),
  border: 0,
}));


const row1_blueCard = { height: "auto", marginBlock: "0.5rem", marginRight: "0.5rem", borderRadius: "0.5rem", boxShadow: 0, borderTop: "3px solid #2057A6", cursor: "pointer" };
let transactionCatagoryData = [{
  chartData: [
    {
      "label": "New Lumpsum",
      "value": "15"
    },
    {
      "label": "Additional Lumpsum",
      "value": "45"
    },
    {
      "label": "New SIP",
      "value": "30"
    },
    {
      "label": "Additional SIP",
      "value": "22"
    },
    {
      "label": "Switch In",
      "value": "43"
    }],
  chartAxis:
  {
    xName: "Transaction Cateogory", yName: "Value in Crores"
  }
}]
// let trData = [
//   {
//     "name": "Inflow",
//     "value": " 2393.33 Cr"
//   },
//   {
//     "name": "Outflow",
//     "value": " 1746.12 Cr"
//   },
//   {
//     "name": "NetFlow",
//     "value": " 647.21 Cr"
//   }
// ]
const TransactionCatagory = ({ data, fetchAPI, fetchPayload, cardSelected, setCardSelected, activePage }) => {
  const [loading, setLoading] = useState(true);
  const investorData = useSelector((state) => state.flowFilterData?.investor)
  const zoneData = useSelector((state) => state.flowFilterData?.zone)
  const stateData = useSelector((state) => state.flowFilterData?.state)
  const assetClassData = useSelector((state) => state.flowFilterData?.assetClass)
  const assetCategoryData = useSelector((state) => state.flowFilterData?.assetCategory)
  const transTypeData = useSelector((state) => state.flowFilterData?.transactionType)
  const transSourceData = useSelector((state) => state.flowFilterData?.transactionSource)
  const schemeNameData = useSelector((state) => state.flowFilterData?.schemeName)
  const flowFilterSelected = useSelector((state) => state.flowFilterData?.filterSelected)
  const flowPageFilters = useSelector((state) => state.flowFilterData?.flowPageFilters)


  const [trData, setTrData] = useState([
    {
      "name": "Inflow",
      "value": " N/A"
    },
    {
      "name": "Outflow",
      "value": " N/A"
    },
    {
      "name": "Netflow",
      "value": " N/A"
    },

  ]
  )


  useEffect(() => {
    
    fetchingAPI();
  
  }, [transTypeData, transSourceData, investorData, zoneData, schemeNameData, assetCategoryData, stateData, assetClassData, flowFilterSelected, activePage])
  const fetchingAPI = async () => {
    setLoading(true);
    const cardsValue = await fetchAPI(fetchPayload,{activePage});
    setTrData(cardsValue)
 console.log(cardsValue)
//     if (activePage === "amount") {
//       setTrData([{
//         name: "Inflow",
//         value: parseFloat(cardsValue.inflow / 10000000).toFixed(2)
//       },
//       {
//         name: "Outflow",
//         value: parseFloat(cardsValue.outflow / 10000000).toFixed(2)
//       },
//       {
//         name: "Netflow",
//         value: parseFloat(cardsValue.netflow / 10000000).toFixed(2)
//       }])
//     }
//     else if (activePage === "count") {
//       setLoading(true);
//       setTrData([{
//         name: "Purchase",
//         value: cardsValue.purchase
//       },
//       {
//         name: "Redemption",
//         value: cardsValue.redemption
//       },
//       ])
//     }
    setLoading(false);
  

  }
  return (

    <Grid>
      {
   loading ?

    <Box sx={{ height: "100%", display: "flex", justifyContent: "center", alignItems: "center" }}>
      <CircularProgress />
    </Box>
    :
    (activePage == "amount") ?
        trData.map((item, i) => {
            return (<Item sx={{ ...row1_blueCard, color: item.name == cardSelected && "white", boxShadow: 8 }} onClick={() => setCardSelected(item.name)} className={item.name == cardSelected ? "background" : ""}>
              <h4 style={{ margin: "0.5rem 1rem 1rem 1rem" }}>{item.name}</h4>
              <h2 style={{ margin: "1rem", fontWeight: "600" }}>&#8377;{item.value} {"Cr"}</h2>
            </Item>)
          })
          :
            trData.map((item, i) => {
            return (<Item sx={{ ...row1_blueCard, color: item.name == cardSelected && "white", boxShadow: 8, height: "6rem", padding: "0.5rem", justifyContent: "space-between", margin: "0.8rem" }} onClick={() => setCardSelected(item.name)} className={item.name == cardSelected ? "background" : ""}>
              <h4 style={{ margin: "1rem 1rem 1rem 1rem" }}>{item.name}</h4>
              <h2 style={{ margin: "1rem", fontWeight: "600" }}>{item.value}</h2>
            </Item>)
          })
        }
        
      
    </Grid >
  )
}

export default TransactionCatagory