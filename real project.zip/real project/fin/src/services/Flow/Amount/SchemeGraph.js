import React from 'react';
import { styled } from '@mui/material/styles';
import Grid from '@mui/material/Unstable_Grid2';
import Paper from '@mui/material/Paper';
import VerticalBarChart from '../../../utilityComponents/charts/verticalBarChart';
import HeaderParent from '../../../utilityComponents/components/HeaderParent';


const Item = styled(Paper)(({ theme }) => ({
    backgroundColor: '#E3EAF3',
    padding: theme.spacing(1),
    border: 0,
}));


const SchemeGraph = () => {
    let data = [{
        "label": "SMALL CAP FUND",
        "value": "15"
    },
    {
        "label": "ULTRA SHORT TERM FUND",
        "value": "45"
    },
    {
        "label": "MID CAP FUND",
        "value": "30"
    },
    {
        "label": "OVERNIGHT FUND",
        "value": "22"
    }
        ,
    {
        "label": "MULTICAP FUND",
        "value": "32"
    }
        ,
    {
        "label": "EQUITY HYBRID FUND",
        "value": "42"
    },
    ]
    return (
        <>
            <Grid container xs={12} justifyContent={"space-between"} sx={{
                // borderTop: "3px solid #010C43",
                marginTop: "20px",
                borderRadius: '8px',
                alignItems: "center",
                height: "auto",
            }}>
                <Grid item xs={12} sx={{ bgcolor: "#fff", borderRadius: "8px", boxShadow: 6 }}>
                    <HeaderParent xs={12}
                        heading="Scheme Name"
                    />
                    <VerticalBarChart
                        data={data}
                        xAxisName={"Scheme"}
                        yAxisName={"Values"}
                    />
                </Grid>
            </Grid>
        </>
    )
}

export default SchemeGraph