import { Grid } from '@mui/material'
import React from 'react'
import HeaderParent from '../../../utilityComponents/components/HeaderParent'
import MapChart from '../../../utilityComponents/charts/MapChart'



const InvestorDemographyMap = () => {


    return (
        <Grid container xs={12} justifyContent={"space-between"} sx={{
            // borderTop: "3px solid #010C43",
            marginTop: "20px",
            borderRadius: '8px',
            alignItems: "center",
            height: "auto",
        }}>
            <Grid item xs={12} sx={{ bgcolor: "#fff", borderRadius: "8px", boxShadow: 6 }}>
                <HeaderParent xs={12} xs1={12}
                    heading="Investor Demography - Location"
                />
                <MapChart />
            </Grid>
        </Grid>
    )
}

export default InvestorDemographyMap