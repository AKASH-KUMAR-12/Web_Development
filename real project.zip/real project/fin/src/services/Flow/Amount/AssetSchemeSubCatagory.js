import React from 'react'
import { styled } from '@mui/material/styles';
import Grid from '@mui/material/Unstable_Grid2';
import Paper from '@mui/material/Paper';
import { useSelector } from 'react-redux';
import HeaderParent from '../../../utilityComponents/components/HeaderParent';
import Donut from '../../../utilityComponents/charts/Donut';
import BarChart from '../../../utilityComponents/charts/BarChart';
const Item = styled(Paper)(({ theme }) => ({
    backgroundColor: '#E3EAF3',
    padding: theme.spacing(1),
    border: 0,
}));

const AssetSchemeSubCatagory = () => {
    const amcAtGlanceData = useSelector((state) => state.CurrentApiData?.AmcAtGlanceApiResponse)
    console.log("amcAtGlanceData", amcAtGlanceData);
    const donutData = [
        {
            "label": "Debt",
            "value": "45"
        },
        {
            "label": "Equity",
            "value": "45"
        },
        {
            "label": "Hybrid",
            "value": "10"
        },
    ]

    let chartData = [
        {
            "label": "Small Cap Fund",
            "value": "15"
        },
        {
            "label": "Ultra Short Term Fund",
            "value": "45"
        },
        {
            "label": "Mid Cap Fund",
            "value": "30"
        },
        {
            "label": "Overnight Fund",
            "value": "22"
        }
        ,
        {
            "label": "Multicap Fund",
            "value": "32"
        }
        ,
        {
            "label": "Equity Hybrid Fund",
            "value": "42"
        }]
    return (
        <>
            <Grid container xs={12} justifyContent={"space-between"} sx={{
                // borderTop: "3px solid #010C43",
                marginTop: "20px",
                borderRadius: '8px',
                alignItems: "center",
                height: "auto",
            }}>
                <Grid item xs={5.9} sx={{ bgcolor: "#fff", borderRadius: "8px", boxShadow: 6 }}>
                    <HeaderParent xs={12}
                        heading="Asset Class"
                    />
                    <Donut
                        data={donutData}
                    />
                </Grid>
                <Grid item xs={5.9} sx={{ bgcolor: "#fff", borderRadius: "8px", boxShadow: 6 }}>
                    <HeaderParent xs={12} xs1={12}
                        heading="Scheme Sub CAtegory"
                    />
                    <BarChart
                        data={chartData}
                    />
                </Grid>
            </Grid>
        </>
    )
}

export default AssetSchemeSubCatagory