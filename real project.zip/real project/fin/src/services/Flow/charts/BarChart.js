import FusionCharts from "fusioncharts";
import charts from "fusioncharts/fusioncharts.charts";
import Bar2D from "fusioncharts/fusioncharts.charts";
import ReactFC from "react-fusioncharts";
import React, { useState } from "react";
import FusionTheme from "fusioncharts/themes/fusioncharts.theme.fusion";
import { Box, Grid } from "@mui/material";
import HeaderParent from "../../../utilityComponents/components/HeaderParent";
import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { clearFlowFilterData, setFlowData, setFlowFilterSelected } from '../../../reduxStore/flowReducer';
import { ArrowBack } from "@mui/icons-material";

// Resolves charts dependancy
ReactFC.fcRoot(FusionCharts, Bar2D, FusionTheme);


const BarChart = ({ data, xAxisName, yAxisName, cardSelected, count, fetchAPI, fetchPayload, height, md, xs, headerProps, sx }) => {
  const [apiData, setApiData] = useState([]);
  const [showBackBtn, setShowBackBtn] = useState(false);
  const dispatch = useDispatch();
  const investorData = useSelector((state) => state.flowFilterData?.investor)
  const zoneData = useSelector((state) => state.flowFilterData?.zone)
  const stateData = useSelector((state) => state.flowFilterData?.state)
  const assetClassData = useSelector((state) => state.flowFilterData?.assetClass)
  const assetCategoryData = useSelector((state) => state.flowFilterData?.assetCategory)
  const transTypeData = useSelector((state) => state.flowFilterData?.transactionType)
  const transSourceData = useSelector((state) => state.flowFilterData?.transactionSource)
  const schemeNameData = useSelector((state) => state.flowFilterData?.schemeName)
  const flowFilterSelected = useSelector((state) => state.flowFilterData?.filterSelected)
  const flowPageFilters = useSelector((state) => state.flowFilterData?.flowPageFilters)
  useEffect(() => {
    setApiData(data)
    fetchingAPI();
  }, [transTypeData, transSourceData, investorData, zoneData, schemeNameData, assetCategoryData, stateData, assetClassData, flowFilterSelected, headerProps.radioValue, cardSelected])

  const fetchingAPI = async () => {
    if (fetchAPI) {
      const response = await fetchAPI(fetchPayload, { cardSelected })
      setApiData(response.map((item) => {
        if (item.value < 0) {
          return ({
            color: "#F88787",
            label: item.label,
            value: (parseFloat(item.value)).toFixed(2)

          })
        }
        else {
          return ({
            label: item.label,
            value: (parseFloat(item.value)).toFixed(2)

          })
        }
      })
      );
    }
  }
  console.log(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>", apiData)
  let texts;
  let pantext = `$label: $value`
  let aumtext = `$label: ₹$value Cr`
  let datas
  // if (count == 'AUM') {
  // datas=apiData
  // setApiData(datas)
  //   texts = aumtext
  // }

  // else {
  //   datas = data;
  //   texts = pantext
  // }

  console.log(datas)
  const chartConfigs = {
    type: "bar2d",
    width: "99%",
    height: "95%",
    dataFormat: "json",
    dataSource: {

      chart: {
        "theme": "fusion",
        xAxisName: xAxisName,
        yAxisName: yAxisName,
        xAxisNameFont: "Roboto",
        yAxisNameFont: "Roboto",
        xAxisNameFontSize: "12",
        yAxisNameFontSize: "12",
        xAxisLineColor: "#969696",
        yAxisLineColor: "#969696",
        labelFontSize: "10",
        yAxisValueFontSize: "10",
        plotSpacePercent: 50,
        plottooltext: texts,
        bgcolor: "#FFFFFF",
        "showxaxisline": "0",
        "showyaxisline": "1",
        color: "#FFFFFF",
        patterBgColor: "#FFFFFF",
        theme: 'fusion',
        barCategoryGap: 1,
        "chartBottomMargin": "10",
        pallete: 5,
        divLineColor: "#00080a",
        animation: 0,
        drawCrossLine: 1,
        crossLineAnimation: 0,
        // plottooltext: "$label: $value Cr",
        divLineColor: "#00080a",
        showBorder: false,
        palettecolors: "#2057A6,#69B8F4,#8ED8B7,#82C7ED,#8FABD3,#BA87ED",
        toolTipFontSize: 6
      },
      "data": apiData,
      "events": {
        "dataLoaded": function (eventObj, dataObj) {
          console.log(dataObj.id);
          alert("hey")
          // dispatch(setFlowFilterSelected({ filterSelected: true }))

          // switch (headerProps.heading) {
          //   case 'Transaction Source': {
          //     dispatch(setFlowData({ title: "transactionSource", value: [dataObj.id] }))
          //     break
          //   }
          //   case 'Sub Scheme Category': {
          //     dispatch(setFlowData({ title: "assetCategory", value: [dataObj.id] }))
          //     break
          //   }
          // }
          // setShowBackBtn(true);
        }
      }
    }
  }

  return (
    <Grid item xs={xs || 12} md={md || 12} sx={{
      bgcolor: "#fff",
      marginTop: "20px",
      borderRadius: '8px',
      alignItems: "center",
      borderRadius: "8px",
      paddingTop: ".1rem",
      boxShadow: 6,
      ...sx
    }}>
      <HeaderParent
        headerProps={headerProps}
      />
      <button onClick={() => {

        switch (headerProps.heading) {
          case "Transaction Source": {
            dispatch(clearFlowFilterData("transactionSource"))
            // dispatch(setFlowPageFilters({ ...flowPageFilters, transactionType: false }))
            break
          }
          case "Scheme Sub Category": {
            dispatch(clearFlowFilterData("assetCategory"))
            // dispatch(setFlowPageFilters({ ...flowPageFilters, assetClass: false }))
            break
          }
        }
        // dispatch(setFlowFilterSelected({ filterSelected: false }))

        setShowBackBtn(false);
      }}
        style={{ position: "absolute", zIndex: 5, left: -3, height: "fit-content", display: showBackBtn ? "block" : "none", cursor: "pointer", borderColor: "#fff", paddingInline: ".4rem" }}>
        <ArrowBack fontSize='small' /></button>

      <Box sx={{ position: "relative", padding: ".5rem", bgcolor: "white", height: height || "16rem", borderRadius: "8px" }} >
        <ReactFC style={{ position: "absolute", top: "50%", left: "50%" }} {...chartConfigs} />
      </Box>
    </Grid>

  );
}

export default BarChart