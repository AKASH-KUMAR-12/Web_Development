import ReactFC from "react-fusioncharts";
import Column2D from "fusioncharts/fusioncharts.charts";
import FusionTheme from "fusioncharts/themes/fusioncharts.theme.fusion";
import FusionCharts from "fusioncharts";
import { Box, Grid } from "@mui/material";
import HeaderParent from "../../../utilityComponents/components/HeaderParent";
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import axios from "axios";
import { ArrowBack } from "@mui/icons-material";
import { clearFlowFilterData, setFlowData, setFlowFilterSelected } from '../../../reduxStore/flowReducer';



ReactFC.fcRoot(FusionCharts, Column2D, FusionTheme);

const VerticalBarChart = ({ data, xAxisName, yAxisName, cardSelected, fetchAPI, fetchPayload, headerProps, xs, md }) => {
  console.log("The requires data >>", data);

  const datas = data.map((item) => ({
    label: item.assetcategorynewmcr,
    value: (parseFloat(item.aggregate_aum) / 10000000).toFixed(2)
  }))

  let response;
  const [apiData, setApiData] = useState([]);
  const [showBackBtn, setShowBackBtn] = useState(false);
  const dispatch = useDispatch();
  const investorData = useSelector((state) => state.flowFilterData?.investor)
  const zoneData = useSelector((state) => state.flowFilterData?.zone)
  const stateData = useSelector((state) => state.flowFilterData?.state)
  const assetClassData = useSelector((state) => state.flowFilterData?.assetClass)
  const assetCategoryData = useSelector((state) => state.flowFilterData?.assetCategory)
  const transTypeData = useSelector((state) => state.flowFilterData?.transactionType)
  const transSourceData = useSelector((state) => state.flowFilterData?.transactionSource)
  const schemeNameData = useSelector((state) => state.flowFilterData?.schemeName)
  const flowFilterSelected = useSelector((state) => state.flowFilterData?.filterSelected)
  const flowPageFilters = useSelector((state) => state.flowFilterData?.flowPageFilters)
  // console.log("*******************************************************************************", apiData);

  useEffect(() => {
    setApiData(data)
    fetchingAPI();
  }, [transTypeData, transSourceData, investorData, zoneData, schemeNameData, assetCategoryData, stateData, assetClassData, flowFilterSelected, headerProps.radioValue, cardSelected])

  const fetchingAPI = async () => {
    if (fetchAPI) {
      setApiData(await fetchAPI(fetchPayload, { radioValue: headerProps.radioValue, cardSelected }));
    }
  }


  const chartConfigs = {
    type: "column2d",
    width: "99%",
    height: "95%",
    dataFormat: "json",
    dataSource: {
      chart: {
        xAxisName: headerProps.radioValue,
        yAxisName: yAxisName,
        xAxisNameFont: "Roboto",
        yAxisNameFont: "Roboto",
        xAxisNameFontSize: "12",
        yAxisNameFontSize: "12",
        yAxisNameFontBold: 0,
        xAxisNameFontBold: 0,
        labelFontSize: "10",
        yAxisValueFontSize: "10",
        showXAxisLine: "1",
        xAxisNameFontColor: "#909090",
        yAxisNameFontColor: "#909090",
        palettecolors: "#2057A6,#69B8F4,#8ED8B7,#82C7ED,#8FABD3,#BA87ED",
        showYAxisLine: "1",
        theme: "fusion",
        showValues: "0",
        bgColor: "#FFFFFF",
        showBorder: "0",
        chartBottomMargin: "20",
        showCanvasBorder: "0",
        showPlotBorder: "0",
        plotFillRatio: "100",
        showAlternateHGridColor: "0",
        divLineColor: "#cdd4cf",
        plottooltext: "Value: ₹ $value Cr",
        chartLeftMargin: 10,
        chartBottomMargin: 10,
        // "showValues": "1",
        // labelDisplay:'AUTO', 'WRAP', 'STAGGER', 'ROTATE', 'NONE'

      },
      data: apiData,
    },
    "events": {
      "dataplotClick": function (eventObj, dataObj) {
        console.log(dataObj.id);
        dispatch(setFlowFilterSelected({ filterSelected: true }))

        switch (headerProps.heading) {
          case 'Scheme Name': {
            dispatch(setFlowData({ title: "schemeName", value: [dataObj.id] }))
            break
          }
        }
        setShowBackBtn(true);
      }
    }
  }


  return (
    <>
      <Grid item xs={xs || 12} md={md || 12} sx={{
        bgcolor: "#fff",
        marginTop: "20px",
        borderRadius: '8px',
        alignItems: "center",
        borderRadius: "8px",
        paddingTop: ".1rem",
        boxShadow: 6
      }}>
        <HeaderParent
          headerProps={headerProps}
        />
        <button onClick={() => {
          dispatch(clearFlowFilterData("schemeName"))
          // dispatch(setFlowFilterSelected({ filterSelected: false }))
          showBackBtn(false);
        }}
          style={{ height: "fit-content", display: showBackBtn ? "block" : "none", cursor: "pointer", borderColor: "#fff", paddingInline: ".4rem", marginLeft: ".5rem" }}>
          <ArrowBack fontSize='small' />
        </button>

        <Box sx={{ position: "relative", padding: ".5rem", bgcolor: "white", height: "16rem", borderRadius: "8px" }} >
          <ReactFC style={{ position: "absolute", top: "50%", left: "50%" }} {...chartConfigs} />
        </Box>
      </Grid>


    </>
  );
};

export default VerticalBarChart;
