import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import FusionCharts from "fusioncharts";
import { BrowserRouter } from "react-router-dom";


const config = require("../src/config/Key");
FusionCharts.options.license({
  key : config().license,
  creditLabel: false,
});


const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
    <BrowserRouter>
    <App />
    </BrowserRouter>
);
