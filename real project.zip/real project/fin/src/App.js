import React, { useState } from 'react';
import Router from "./Router";
import store from "./reduxStore/store";
import { Provider } from 'react-redux';



const App = () => {

  return (

    <Provider store={store}>
      <Router />
    </Provider>

  );
};

export default App;
