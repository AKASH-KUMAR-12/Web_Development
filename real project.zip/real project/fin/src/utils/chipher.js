import CryptoJS from "crypto-js";

var encryptionKey = "secret key 123";

const encrypt = (myDataObj) => {
  const myData = JSON.stringify(myDataObj);

  try {
    const enData = CryptoJS.AES.encrypt(myData, encryptionKey).toString();
    return enData;
  } catch (err) {
    console.log(err);
  }
};

const decrypt = (myData) => {
  try {
    var decryptedData = CryptoJS.AES.decrypt(myData, encryptionKey);

    var decryptedDataParsed = JSON.parse(
      decryptedData.toString(CryptoJS.enc.Utf8)
    );
    console.log("decrypted:", decryptedDataParsed);
  } catch (err) {
    console.log(err);
  }

  return decryptedDataParsed;
};

export { encrypt, decrypt };