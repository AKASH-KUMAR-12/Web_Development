import { configureStore } from "@reduxjs/toolkit";
import { sipBookSlice } from "./reducer";
import { ApiResponseSlice } from "./ApiResponceReducer";
import { filterSlice } from "./filterReducer";
import { amcAtGlanceSlice } from "./amcAtGlanceReducer";
import { flowFilterSlice } from "./flowReducer";

const store = configureStore({
    reducer: {
        amcatglanceState: amcAtGlanceSlice.reducer,
        currentCycle: sipBookSlice.reducer,
        CurrentApiData: ApiResponseSlice.reducer,
        filterData: filterSlice.reducer,
        flowFilterData: flowFilterSlice.reducer
    }
})

export default store;