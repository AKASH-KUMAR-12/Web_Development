import { createSlice } from "@reduxjs/toolkit";

export const amcAtGlanceSlice = createSlice({
    name: "AMC At Glance",
    initialState: {
        activePage: "Finance"
    },
    reducers: {
        setactivePage: (state, action) => {
            return {
                ...state,
                activePage: action.payload.activePage,
            };
        },
    },
});

export const { setactivePage } = amcAtGlanceSlice.actions;
