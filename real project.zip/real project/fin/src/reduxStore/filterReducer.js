import { createSlice } from "@reduxjs/toolkit";
let initialFilterState = {
  filterSelected: false,
  investor: ["NON-RETAIL", "RETAIL"],
  zone: ["EAST", "WEST", "NORTH", "SOUTH", "OTHERS"],
  state: [
    "KARNATAKA",
    "DAMAN AND DIU",
    "OTHERS",
    "DELHI",
    "LADAKH",
    "RAJASTHAN",
    "MANIPUR",
    "ANDHRA PRADESH",
    "WEST BENGAL",
    "MADHYA PRADESH",
    "KERALA",
    "GUJARAT",
    "TELANGANA",
    "ANDAMAN AND NICOBAR",
    "BIHAR",
    "GOA",
    "CHANDIGARH",
    "TRIPURA",
    "DADRA AND NAGAR HAVELI",
    "NAGALAND",
    "JHARKHAND",
    "ASSAM",
    "PUNJAB",
    "JAMMU AND KASHMIR",
    "PUDUCHERRY",
    "ODISHA",
    "MEGHALAYA",
    "MIZORAM",
    "MAHARASHTRA",
    "ARUNACHAL PRADESH",
    "CHHATTISGARH",
    "TAMIL NADU",
    "SIKKIM",
    "LAKSHADWEEP",
    "HARYANA",
    "UTTAR PRADESH",
    "UTTARAKHAND",
    "HIMACHAL PRADESH"
  ],
  assetClass: [
    // "FUND OF FUNDS SCHEME (DOMESTIC)",
    // "GROWTH/EQUITY ORIENTED SCHEMES",
    // "OTHER SCHEMES",
    // "INCOME/DEBT ORIENTED SCHEMES",
    // "HYBRID SCHEMES",
    // "SOLUTION ORIENTED  SCHEMES"
  ],
  assetCategory: [
    // "MEDIUM TO LONG DURATION FUND",
    // "FIXED TERM PLAN",
    // "LARGE CAP FUND",
    // "DYNAMIC ASSET ALLOCATION / BALANCED ADVANTAGE FUND",
    // "BANKING AND PSU FUND",
    // "BALANCED HYBRID FUND/ AGGRESSIVE HYBRID FUND",
    // "MULTI ASSET ALLOCATION FUND",
    // "LOW DURATION FUND",
    // "GILT FUND",
    // "MEDIUM DURATION FUND",
    // "DYNAMIC BOND FUND",
    // "LARGE & MID CAP FUND",
    // "INCOME/DEBT ORIENTED SCHEMES",
    // "ULTRA SHORT DURATION FUND",
    // "MONEY MARKET FUND",
    // "OVERNIGHT FUND",
    // "VALUE FUND/CONTRA FUND",
    // "MID CAP FUND",
    // "SMALL CAP FUND",
    // "CORPORATE BOND FUND",
    // "MULTI CAP FUND",
    // "CREDIT RISK FUND",
    // "SHORT DURATION FUND",
    // "CONSERVATIVE HYBRID FUND",
    // "FLEXI CAP FUND",
    // "EQUITY SAVINGS FUND",
    // "FUND OF FUNDS SCHEME (DOMESTIC)",
    // "FLOATER FUND",
    // "SECTORAL/THEMATIC FUNDS",
    // "LONG DURATION FUND",
    // "RETIREMENT FUND",
    // "INDEX FUNDS",
    // "ARBITRAGE FUND",
    // "ELSS",
    // "LIQUID FUND",
    // "FOCUSED FUND"
  ],
}
const resetFilterData = { ...initialFilterState }
export const filterSlice = createSlice({
  name: "FILTER DATA",
  initialState: initialFilterState,
  reducers: {
    setInvestorData: (state, action) => {
      return {
        ...state,
        investor: action.payload.investor,
      };
    },
    setZoneData: (state, action) => {
      return {
        ...state,
        zone: action.payload.zone,
      };
    },
    setStateData: (state, action) => {
      return {
        ...state,
        state: action.payload.state,
      };
    },
    setAssetClassData: (state, action) => {
      return {
        ...state,
        assetClass: action.payload.assetclass,
      };
    },
    setAssetCategoryData: (state, action) => {
      return {
        ...state,
        assetCategory: action.payload.assetcategory,
      };
    },
    setDistributorData: (state, action) => {
      return {
        ...state,
        distributor: action.payload.distributor,
      };
    },
    setFilterSelected: (state, action) => {
      return {
        ...state,
        filterSelected: action.payload.filterSelected
      }
    },
    setAumData: (state, action) => {
      console.log(action.payload)
      return {
        ...state,
        [action.payload.title]: action.payload.value
      }
    },
    resetAumFilter: (state, action) => {
      return {
        ...resetFilterData
      };
    },
    setAumLocalData: (state, action) => {
      let defaultFilterData = {
        assetCategory: [],
        assetClass: []
      };
      if (localStorage.getItem("Finstax:AumDefaultFilter")) {
        defaultFilterData = JSON.parse(localStorage.getItem("Finstax:AumDefaultFilter"));
      }
      return {
        ...state,
        assetClass: defaultFilterData["assetClass"],
        assetCategory: defaultFilterData["assetCategory"]
      };
    },
    clearAumFilterData: (state, action) => {
      let defaultFilterData = {
        assetCategory: [],
        assetClass: []
      };
      if (localStorage.getItem("Finstax:AumDefaultFilter")) {
        defaultFilterData = JSON.parse(localStorage.getItem("Finstax:AumDefaultFilter"));
      }
      initialFilterState = { ...initialFilterState, ...defaultFilterData }
      console.log(initialFilterState)
      return {
        ...state,
        [action.payload]: initialFilterState[action.payload]
      };
    },
  }
});

export const { setInvestorData, setZoneData, setStateData, setAssetClassData, setAssetCategoryData,
  setDistributorData, setFilterSelected, clearFilterData, clearAumFilterData, setAumData, resetAumFilter, setAumLocalData } = filterSlice.actions;
