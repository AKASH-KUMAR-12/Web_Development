import { createSlice } from "@reduxjs/toolkit";

export const ApiResponseSlice = createSlice({
    name: "cycle",
    initialState: {
        ApiResponse:[],
        AmcAtGlanceApiResponse:[]
    },
    reducers: {   

        setSIPResponse: (state, action) => {
                return {
                    ...state,
                    ApiResponse:action.payload.ApiResponse
            }
        },
        setAmcAtGlanceResponse:(state, action)=>{
            console.log("action.payload.AmcAtGlanceApiResponse",action.payload.AmcAtGlanceApiResponse)
              return{
                ...state, 
                AmcAtGlanceApiResponse:action.payload.AmcAtGlanceApiResponse

              }
        }
        },
  
    },
  );
  
  export const {setSIPResponse, setAmcAtGlanceResponse} = ApiResponseSlice.actions;
  