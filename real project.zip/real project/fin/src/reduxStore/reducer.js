import { createSlice } from "@reduxjs/toolkit";

export const sipBookSlice = createSlice({
  name: "SIP BOOk",
  initialState: {
    activePage: "SIP",
    currentDate: "",
    freshData:"",
  },
  reducers: {
    setactivePage: (state, action) => {
      return {
        ...state,
        activePage: action.payload.activePage,
      };
    },
    setcurrentDate: (state, action) => {
      return {
        ...state,
        currentDate: action.payload.currentDate,
      };
    },
    setFreshSipData: (state, action) => {
      return {
        ...state,
        freshData: action.payload.freshData,
      };
    },
  },
});

export const { setcurrentDate, setactivePage,setFreshSipData } = sipBookSlice.actions;
