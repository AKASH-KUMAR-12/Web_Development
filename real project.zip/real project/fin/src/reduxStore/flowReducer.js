import { createSlice } from "@reduxjs/toolkit";
let initialFilterState = {
    filterSelected: false,
    investor: ["NON-RETAIL", "RETAIL"],
    zone: ["EAST", "WEST", "NORTH", "SOUTH", "OTHERS"],
    state: [
        "KARNATAKA",
        "DAMAN AND DIU",
        "OTHERS",
        "DELHI",
        "LADAKH",
        "RAJASTHAN",
        "MANIPUR",
        "ANDHRA PRADESH",
        "WEST BENGAL",
        "MADHYA PRADESH",
        "KERALA",
        "GUJARAT",
        "TELANGANA",
        "ANDAMAN AND NICOBAR",
        "BIHAR",
        "GOA",
        "CHANDIGARH",
        "TRIPURA",
        "DADRA AND NAGAR HAVELI",
        "NAGALAND",
        "JHARKHAND",
        "ASSAM",
        "PUNJAB",
        "JAMMU AND KASHMIR",
        "PUDUCHERRY",
        "ODISHA",
        "MEGHALAYA",
        "MIZORAM",
        "MAHARASHTRA",
        "ARUNACHAL PRADESH",
        "CHHATTISGARH",
        "TAMIL NADU",
        "SIKKIM",
        "LAKSHADWEEP",
        "HARYANA",
        "UTTAR PRADESH",
        "UTTARAKHAND",
        "HIMACHAL PRADESH"
    ],
    assetClass: [],
    assetCategory: [],
    schemeName: [],
    transactionSource: [],
    transactionType: [],
    // flowPageFilters: {
    //     assetClass: false,
    //     assetCategory: false,
    //     schemeName: false,
    //     transactionSource: false,
    //     transactionType: false,
    // }
}
const resetFilterData = { ...initialFilterState }
export const flowFilterSlice = createSlice({
    name: "FILTER DATA",
    initialState: initialFilterState,
    reducers: {
        setInvestorData: (state, action) => {
            return {
                ...state,
                investor: action.payload.investor,
            };
        },
        setZoneData: (state, action) => {
            return {
                ...state,
                zone: action.payload.zone,
            };
        },
        setStateData: (state, action) => {
            return {
                ...state,
                state: action.payload.state,
            };
        },
        setFlowAssetClassData: (state, action) => {
            return {
                ...state,
                assetclass: action.payload.assetclass,
            };
        },
        setFlowAssetCategoryData: (state, action) => {
            return {
                ...state,
                assetcategory: action.payload.assetcategory,
            };
        },
        setFlowTransactionSourceData: (state, action) => {
            return {
                ...state,
                transactionsource: action.payload.transactionsource,
            };
        },
        setFlowTransactionTypeData: (state, action) => {
            return {
                ...state,
                transactiontype: action.payload.transactiontype
            }
        },
        setFlowSchemeNameData: (state, action) => {
            console.log(action)
            return {
                ...state,
                schemename: action.payload.schemename
            }
        },
        setFlowFilterSelected: (state, action) => {
            return {
                ...state,
                filterSelected: action.payload.filterSelected
            }
        },
        setFlowPageFilters: (state, action) => {
            return {
                ...state,
                flowPageFilters: { ...action.payload }
            }
        },

        setFlowData: (state, action) => {
            console.log(action.payload)
            return {
                ...state,
                [action.payload.title]: action.payload.value
            }
        },
        resetFlowFilter: () => {
            return {
                ...resetFilterData
            }
        },
        setFlowLocalData: (state, action) => {
            let defaultFilterData = {
                assetClass: [],
                assetCategory: [],
                schemeName: [],
                transactionSource: [],
                transactionType: [],
            };
            if (localStorage.getItem("Finstax:FlowDefaultFilter")) {
                defaultFilterData = JSON.parse(localStorage.getItem("Finstax:FlowDefaultFilter"));
            }
            return {
                ...state,
                "assetClass": defaultFilterData["assetClass"],
                "assetCategory": defaultFilterData["assetCategory"],
                "schemeName": defaultFilterData["schemeName"],
                "transactionType": defaultFilterData["transactionType"],
                "transactionSource": defaultFilterData["transactionSource"],
            };
        },
        clearFlowFilterData: (state, action) => {
            console.log(initialFilterState)
            let defaultFilterData = {
                assetClass: [],
                assetCategory: [],
                schemeName: [],
                transactionSource: [],
                transactionType: [],
            };
            if (localStorage.getItem("Finstax:FlowDefaultFilter")) {
                defaultFilterData = JSON.parse(localStorage.getItem("Finstax:FlowDefaultFilter"));
            }
            initialFilterState = { ...initialFilterState, ...defaultFilterData }
            return {
                ...state,
                [action.payload]: initialFilterState[action.payload]
            };
        },




    },
});

export const { setInvestorData, setZoneData, setStateData, setFlowAssetClassData, setFlowAssetCategoryData,
    setFlowSchemeNameData, setFlowTransactionSourceData, setFlowTransactionTypeData, clearFlowFilterData, setFlowData,
    setFlowFilterSelected, setFlowPageFilters, resetFlowFilter, setFlowLocalData } = flowFilterSlice.actions;
