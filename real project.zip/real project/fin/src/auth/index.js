import React from "react";
import {Container, Grid} from "@mui/material";
import Login from "../auth/Login";
import "./style/Login.css"
const HomePage = ({setIsLoggedIn}) => {
    return (
        <>
            <section className="hero">
                <Container fixed>
                    <Grid container spacing={3} >
                        <Grid item xs={12} sm={12} md={12} lg={6}>
                            <Login/>
                        </Grid>
                    </Grid>
                </Container>
            </section>
        </>
    );
};

export default HomePage;