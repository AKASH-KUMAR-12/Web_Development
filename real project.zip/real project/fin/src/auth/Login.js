import React, { useRef, useState } from "react";
import Finwix_logo from "../images/updatedLog.svg";
import Username from "../images/username.svg";
import Password from "../images/password.svg";
import axios from "axios";
import "./style/Login.css";
import { encrypt } from "../utils/chipher";
import SecureLS from "secure-ls";
import { useNavigate } from "react-router-dom";
import KfinLogo from "../images/Kfinogo.svg";
const Login = () => {

  let ls = new SecureLS();
  const email = useRef(null);
  const password = useRef(null);

  const navigate = useNavigate();

  const [userstate, setuserState] = useState("");

  const handleLogin = async (event) => {
    event.preventDefault();

    const payload = {
      email: email.current.value,
      password: password.current.value,
    };

    const encryptedPayload = encrypt(payload);

    const response = await axios.post(`/api/login`, { payload: encryptedPayload });
    console.log("Response while login:", response);
    navigate("app/AMCAtGlance");
  };

  return (
    <div className="login_main" style={{ width: "84%", height: "auto" }}>
      <div className="Kfin-logo-container">
        <img src={KfinLogo} alt="KfinLogo" />
      </div>
      <div className="loginform_container border-frame">
        <div className="Finstax-logo-cotainer">
          <img
            style={{ height: "80px", marginLeft: "80px" }}
            src={Finwix_logo}
            alt="Finwix_logo"
          />
        </div>
        <form type="submit" onSubmit={handleLogin} autocomplete="off">
          <div>
            <div className="loginform_inputcontainer">
              <input
                type="text"
                placeholder="User ID"
                className="loginform_inputType"
                ref={email}
              />
              <img
                src={Username}
                alt="username"
                className="usernameinput_icon"
              />
            </div>
            <div className="loginform_inputcontainer">
              <input
                type="password"
                placeholder="Password"
                className="loginform_inputType"
                ref={password}
              />
              <img
                src={Password}
                alt="username"
                className="passwordinput_icon"
              />
              <div className="Forgot_links_container">
                <a href="https://idm.kfintech.com/ForgotPassword">
                  Forgot Password?
                </a>
              </div>
            </div>
          </div>
          <div className="login_buttoncontainer ">
            <button className="signin-button ">SIGN IN</button>
          </div>
        </form>
        <div className="signupLink_container ">
          <div>Don't have an account?</div>{" "}
          <a href={"https://idm.kfintech.com/"} target="_blank">
            SIGN UP NOW
          </a>
        </div>
      </div>
    </div>
  );
};
export default Login;
