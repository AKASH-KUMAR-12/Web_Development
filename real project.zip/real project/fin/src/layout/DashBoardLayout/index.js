import React from "react";
import TopBar from "./components/TopLayout/TopBar";
import { Box, Grid } from "@mui/material";
import { SideBar } from "./components/SideBar";
import { Outlet } from "react-router-dom";
import footerLogo from "../../images/footerLogo.svg"

const DashBoardLayout = () => {
  return (
    <>
      <TopBar />
      <Grid container spacing={0} sx={{ bgcolor: "#F7F6FA", overflow: "hidden", height: "fit-content" }}>
        <Grid item sx={{ bgcolor: "#F7F6FA" }} lg={1.9} md={1.9} sm={3}>
          <SideBar />
        </Grid>
        <Grid item lg={10.1} md={10.1} sm={9}
          sx={{ width: '95%', fontFamily: "Roboto", backgroundColor: "#F7F6FA", paddingBottom: "3rem", height: { lg: "90vh", md: "86vh", xs: "92vh" }, paddingInline: 0 }} >
          <Outlet />
        </Grid>
      </Grid >
      <Box sx={{ zIndex: "1000", height: "2rem", width: "100%", backgroundColor: "#2057A6", textAlign: "center", padding: 0, position: "fixed", bottom: 0 }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "center" }}>
          <p style={{ display: "inline", color: "#FAFAFA", marginRight: "0.5%", marginTop: "0.6%" }}>Powered By</p>
          <img src={footerLogo} alt={"KFintech"} style={{ marginTop: "0.5%", width: "9%" }} />
        </div>
      </Box>
    </>
  );
};

export default DashBoardLayout;
