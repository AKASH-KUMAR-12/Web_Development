import React, { useState } from 'react'
import { List, ListItem, ListItemButton, ListItemIcon, ListItemText, Collapse, Alert } from '@mui/material'
import Checkbox from '@mui/material/Checkbox';
import crossimg from "../../../../images/crossimg.svg";
import filterbtn from "../../../../images/filterbtn.svg";
import Button from '@mui/material/Button';
import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { setAumData, clearAumFilterData, resetAumFilter } from "../../../../reduxStore/filterReducer";
import { Container, InputAdornment, TextField } from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import { useLocation } from 'react-router-dom';
import { clearFlowFilterData, resetFlowFilter, setFlowData } from '../../../../reduxStore/flowReducer';

const FilterList = ({ handleOpen, open }) => {
  const [openNestedList, setOpenNestedList] = useState({ "Investor Category": false, "localInvestorData": [], "Zone": false, "localZoneData": [] })
  const dispatch = useDispatch();
  const page = useLocation().pathname;
  let reducerName = "filterData";
  let setReducerData = setAumData;
  let resetFilter = resetAumFilter;
  switch (page) {
    case "/app/aum": {
      reducerName = "filterData"
      setReducerData = setAumData;
      resetFilter = resetAumFilter;
      break;
    }
    case "/app/flow": {
      reducerName = "flowFilterData"
      setReducerData = setFlowData;
      resetFilter = resetFlowFilter;
      break;
    }
  }
  const investorData = useSelector((state) => state[reducerName]?.investor)
  const zoneData = useSelector((state) => state[reducerName]?.zone)
  // console.log(page, reducerName, useSelector((e) => e))
  const dataLists = [
    {
      name: "Investor Category",
      nestedLists: ["RETAIL", "NON-RETAIL"]
    },
    {
      name: "Zone",
      nestedLists: ["EAST", "WEST", "NORTH", "SOUTH", "OTHERS"]
    }
  ]
  useEffect(() => {
    setOpenNestedList({ ...openNestedList, localInvestorData: investorData, localZoneData: zoneData })
  }, [investorData, zoneData]);
  const handleToggle = (key, category) => () => {
    let currentIndex;
    let newChecked = []
    console.log(category);
    if (category == "investor") {
      currentIndex = openNestedList["localInvestorData"].indexOf(key);
      newChecked = [...openNestedList["localInvestorData"]];
      if (currentIndex === -1) {
        newChecked.push(key);
      } else {
        newChecked.splice(currentIndex, 1);
      }
      setOpenNestedList({ ...openNestedList, ["localInvestorData"]: newChecked });

    }
    else {
      currentIndex = openNestedList["localZoneData"].indexOf(key);
      newChecked = [...openNestedList["localZoneData"]];
      if (currentIndex === -1) {
        newChecked.push(key);
      } else {
        newChecked.splice(currentIndex, 1);
      }
      setOpenNestedList({ ...openNestedList, ["localZoneData"]: newChecked });

    }
  };
  const handleApply = () => {
    if (openNestedList["localInvestorData"] == 0 || openNestedList["localIZoneData"] == 0) {
      alert("Please select one option atleast")
    }
    else {
      dispatch(setReducerData({ title: "investor", value: openNestedList["localInvestorData"] }))
      dispatch(setReducerData({ title: "zone", value: openNestedList["localZoneData"] }))
      dispatch(setReducerData({ title: "filterSelected", value: true }))
    }
    handleOpen(false)
  }


  const handelNestedLists = (title) => {
    setOpenNestedList({ ...openNestedList, [title]: !openNestedList[title] })
  }
  const [searchTerm, setSearchTerm] = useState("");

  const handleChange = (event) => {
    setSearchTerm(event.target.value);
  };
  return (
    <>
      {
        open &&
        <>
          <div style={{ display: "flex", justifyContent: "center", alignItems: "center", padding: "0.5rem 1rem 0rem 0" }}>
            <Container maxWidth="md" sx={{ mt: 1 }}>
              <TextField
                id="search"
                type="search"
                label="Search"
                size='small'
                value={searchTerm}
                onChange={handleChange}
                sx={{ width: 300, }}
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      <SearchIcon style={{ fill: "#2057A6" }} />
                    </InputAdornment>
                  ),
                }}
              />
            </Container>
            <img src={crossimg} onClick={() => handleOpen(false)} />
          </div>
          <List sx={{ padding: 0, "& .css-r3dtdp-MuiListItem-root": { paddingTop: "0" } }}>
            <ListItem divider sx={{ "& .css-16ac5r2-MuiButtonBase-root-MuiListItemButton-root": { "height": "2rem", padding: "0rem 0rem 0rem 1rem", borderRadius: "1rem" } }}>
              <ListItemButton onClick={() => handelNestedLists("Investor Category")}>
                <ListItemText primary={"Investor Category"} />
                <ListItemIcon sx={{ paddingLeft: "3rem" }}>
                  <img src={filterbtn} />
                </ListItemIcon>

              </ListItemButton>
            </ListItem>
            <Collapse in={openNestedList["Investor Category"]}>
              <List sx={{ paddingBlock: "0" }}>
                {dataLists[0].nestedLists.map((key, i) => {
                  const labelId = `checkbox-list-label-${key}`;
                  return (<ListItem divider sx={{ paddingBlock: "0" }} >
                    <ListItemButton onClick={handleToggle(key, "investor")} sx={{ "height": "1.8rem", marginLeft: '35px', borderRadius: "1rem", marginBlock: "0.2rem" }}>
                      <ListItemIcon>
                        <Checkbox
                          edge="start"
                          checked={openNestedList["localInvestorData"].indexOf(key) !== -1}
                          tabIndex={-1}
                          disableRipple
                          inputProps={{ 'aria-labelledby': labelId }}
                        />
                      </ListItemIcon>
                      <ListItemText id={labelId} primary={`${key}`} key={key} />
                    </ListItemButton>
                  </ListItem>)

                })}
              </List>
            </Collapse>
          </List>

          <List sx={{ padding: 0, "& .css-r3dtdp-MuiListItem-root": { paddingTop: "0" } }}>
            <ListItem divider sx={{ "& .css-16ac5r2-MuiButtonBase-root-MuiListItemButton-root": { "height": "2rem", padding: "0rem 0rem 0rem 1rem", borderRadius: "1rem" } }}>
              <ListItemButton onClick={() => handelNestedLists("Zone")} >

                <ListItemText primary={"Region"} />
                <ListItemIcon sx={{ paddingLeft: "3rem" }} >
                  <img src={filterbtn} />
                </ListItemIcon>

              </ListItemButton>
            </ListItem>
            <Collapse in={openNestedList["Zone"]}>
              <List sx={{ paddingBlock: "0" }}>
                {dataLists[1].nestedLists.map((key, i) => {
                  const labelId = `checkbox-list-label-${key}`;
                  return (<ListItem divider sx={{ paddingBlock: "0" }} >
                    <ListItemButton onClick={handleToggle(key, "zone")} sx={{ "height": "1.8rem", marginLeft: '35px', borderRadius: "1rem", marginBlock: "0.2rem" }}>
                      <ListItemIcon>
                        <Checkbox
                          edge="start"
                          checked={openNestedList["localZoneData"].indexOf(key) !== -1}
                          tabIndex={-1}
                          disableRipple
                          inputProps={{ 'aria-labelledby': labelId }}
                        />
                      </ListItemIcon>
                      <ListItemText id={labelId} primary={`${key}`} key={key} />
                    </ListItemButton>
                  </ListItem>)

                })}
              </List>
            </Collapse>
          </List>


          {/* { */}
          {/* (openNestedList["Investor Category"] || openNestedList["Zone"]) && */}
          <div style={{ margin: "0.5rem", display: "flex", justifyContent: "space-evenly" }}>
            <Button variant="contained" size='small' onClick={() => { handleApply() }} sx={{ width: "40%" }}>Apply Filter</Button>
            <Button variant="outlined" size='small'
              onClick={() => {
                // dispatch(clearReducerData("investor"))
                // dispatch(clearReducerData("zone"))
                dispatch(resetFilter())
                handleOpen(false)
              }} sx={{ width: "40%" }}>Reset to Default</Button>
          </div>
          {/* } */}
        </>
      }
    </>
  )
}

export default FilterList