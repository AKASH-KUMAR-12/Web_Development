import styled from "@emotion/styled";
import { AppBar, Box, Toolbar, Typography } from "@mui/material";
import React, { useState } from "react";
import logo from "../../../../images/finstaxLogo.svg";
import jiologo from "../../../../images/JIOBLACKROCK.png";
import topBarFilterImg from "../../../../images/topBarFilterIcon.png";
import FilterList from "./FilterList";
import MenuIcon from "@mui/icons-material/Menu";
import { SideBar } from "../SideBar";
import Marquee from "react-fast-marquee";


const StyledToolBar = styled(Toolbar)({
  display: "flex",
  justifyContent: "space-between",
  backgroundColor: "white",
  color: "blue",
  Shadows: "none",
  "@media (max-width: 600px)": {
    justifyContent: "space-evenly",
  },
});

const TopBar = () => {
  const [openselectBox, setOpenselectBox] = useState(false);
  const [openSideBar, setOpenSideBar] = useState(false);

  const onClickSideBar = () => {
    setOpenSideBar(!openSideBar);
  };
  const message = ["* Net SIP inflows is 42% of the gross SIP inflows", "The MF industry adds close to 4 lakh new investors in Sept 2023", "Money market funds outperforming Liquid funds.", "Industry AUM increased 9 per cent during the three-month period ending September 2023. This marked the highest quarterly growth for the industry since September 2021 *"]
  return (
    <>
      <AppBar position="sticky" style={{ boxShadow: "0px 0px 5px 0px #00000033" }} sx={{ xs: { width: "100vw" } }}>
        <StyledToolBar>
          <Typography>
            <img src={logo} alt={"FINSTAX"} style={{ height: "46px" }} />
            <img src={jiologo} alt={"FINSTAX"} style={{ height: "40px" }} />
          </Typography>
          <Box sx={{ height: "fit-content", width: { md: "54vw", xs: "38vw" } }}>
            <Marquee speed={50} pauseOnHover={true} >

              <div style={{ color: "#2057A6", marginLeft: "200px" }}>
                {
                  message.map((mes) => {

                    return <span style={{ marginLeft: "100px" }}>{mes}</span>
                  })
                }

              </div>

            </Marquee>
          </Box>
          <Typography m={"5px"}>

            <img
              src={topBarFilterImg}
              alt="FilterBtn"
              style={{ height: "46px", cursor: "pointer" }}
              onClick={() => {
                setOpenselectBox(!openselectBox);
              }}
            />

          </Typography>
          <Typography sx={{ display: { xs: "block", sm: "none" } }}>
            <MenuIcon onClick={onClickSideBar} />
          </Typography>
        </StyledToolBar>
      </AppBar>

      {openselectBox && (
        <Box
          sx={{
            bgcolor: "background.paper",
            width: { xm: "17%", md: "30%" },
            position: "absolute",
            right: "1rem",
            zIndex: "3",
            boxShadow: "2",
            marginTop: "0.5rem",
            borderRadius: "1rem"
          }}
        >

          <FilterList handleOpen={setOpenselectBox} open={openselectBox} />
        </Box>
      )}
      {openSideBar && (
        <Box>
          <SideBar props={1} />
        </Box>
      )}
    </>
  );
};

export default TopBar;
