import { Box, Collapse } from "@mui/material";
import React, { useState } from "react";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import ListItemButton from "@mui/material/ListItemButton";
import ListItemText from "@mui/material/ListItemText";
import AmcAtGlance from "../../../images/AmcAtGlance.svg";
import AUM from "../../../images/AUM.svg";
import SIPBook from "../../../images/SIPBook.svg";
import Flow from "../../../images/Flow.svg"
import NFO from "../../../images/NFO.svg"
import Distributor from "../../../images/Distributor.svg"
import { NavLink, useLocation, useNavigate } from "react-router-dom";
import { KeyboardArrowDown, KeyboardArrowRightOutlined } from "@mui/icons-material";
import analytics from "../../../images/analytics.png"
import AMCvsKfin from "../../../images/amcvskfin.svg"
const data = [
  {
    path: "AMCAtGlance",
    name: "AMC At Glance",
    img: AmcAtGlance,
  },
  {
    path: "AUM",
    name: "AUM",
    img: AUM,
  },
  {
    path: "sip",
    name: "SIP Book",
    img: SIPBook,
  },
  {
    path: "Distributor",
    name: "Distributor",
    img: Distributor,
  },
  {
    path: "NFO",
    name: "NFO",
    img: NFO,
  },
  {
    path: "flow",
    name: "Flow",
    img: Flow,
  },
  // {
  //   path: "Demo",
  //   name: "DeMo",
  //   img: Flow,
  // },
  // {
  //   path: "sales",
  //   name: "Sales Report",
  //   img: SIPBook,
  // },

];

export const SideBar = ({ children, props }) => {
  const navigate = useNavigate();
  const [openNav, setOpenNav] = useState(false);
  const handelNavBar = () => {
    setOpenNav(true);
  };
  const location = useLocation();
  let url = location.pathname;
  const [selectedItem, setSelectedItem] = useState(url.substring(5));
  const [openDropdown, setOpenDropdown] = useState(false);
  const handleItemClick = (item) => {
    setSelectedItem(item);
  }
  const handleOpen = () => {
    setOpenDropdown(!openDropdown)
  }
  return !props ? (
    <Box
      bgcolor="white"
      flex={1.5}
      padding="0rem 1rem "
      boxShadow="0px 2px 8px 0px #00000033"
      sx={{ display: { sm: "block", xs: "none" }, fontWeight: "bold", fontSize: "1rem", height: "98%", position: "sticky", left: "0", top: "0", width: "fit-content" }}
    >
      <List sx={{ paddingTop: 1, "& .css-r3dtdp-MuiListItem-root": { paddingTop: "0" } }}>
        <ListItem
          disablePadding
          divider
          onClick={handleOpen}
          sx={{
            "& .css-16ac5r2-MuiButtonBase-root-MuiListItemButton-root": {
              backgroundColor: 'transparent',
            },
          }}
        >
          <ListItemButton>
            <img src={analytics} alt="img" height="21px" width="21px" />
            <ListItemText
              secondary={"AMC Analytics"}
              sx={{
                "& .css-83ijpv-MuiTypography-root": {
                  fontWeight: "bold",
                  marginLeft: "1rem",
                  fontSize: "13px",
                  color: openDropdown ? '#2057a6' : 'black'
                },
              }}
            />

            {openDropdown ? <KeyboardArrowDown /> : <KeyboardArrowRightOutlined />}
          </ListItemButton>
        </ListItem>
        <Collapse in={openDropdown}>
          <List
            sx={{ "& .css-1nxmd3h-MuiListItem-root": { marginBottom: "17px" } }}
          >
            {data.map((value, index) => (
              <ListItem
                key={value.name}
                component={NavLink}
                to={value.path}
                disablePadding
                selected={selectedItem === value.path}

                onClick={() => {
                  navigate(value.key);
                  handleItemClick(value.path)
                }}
                sx={{
                  "& .css-16ac5r2-MuiButtonBase-root-MuiListItemButton-root": {
                    backgroundColor: selectedItem === value.path ? '#E3EAF3' : 'transparent',
                  },
                }}
              >
                <ListItemButton
                  onClick={() => {
                    handelNavBar()
                  }}>
                  <img src={value.img} alt="img" />
                  <ListItemText
                    secondary={value.name}
                    sx={{
                      "& .css-83ijpv-MuiTypography-root": {
                        fontWeight: "bold",
                        marginLeft: "1rem",
                        fontSize: "12px",
                        color: selectedItem === value.path ? '#2057a6' : 'black'
                      },
                    }}
                  />
                </ListItemButton>
              </ListItem>
            ))}

          </List>
        </Collapse>
        <ListItem
          key={"Business Metrics"}
          component={NavLink}
          to={"Report"}
          disablePadding
          selected={selectedItem === "Business Metrics"}
          divider
          onClick={() => {
            navigate("Report");
            handleItemClick("Business Metrics")
          }}
          sx={{
            "& .css-16ac5r2-MuiButtonBase-root-MuiListItemButton-root": {
              backgroundColor: selectedItem === "Business Metrics" ? '#E3EAF3' : 'transparent',
            },
          }}
        >
          <ListItemButton
            onClick={() => {
              handelNavBar()
            }}>
            <img src={AmcAtGlance} alt="img" />
            <ListItemText
              secondary={"Business Metrics"}
              sx={{
                "& .css-83ijpv-MuiTypography-root": {
                  fontWeight: "bold",
                  marginLeft: "1rem",
                  fontSize: "13px",
                  color: selectedItem === "Business Metrics" ? '#2057a6' : 'black'
                },
              }}
            />
          </ListItemButton>
        </ListItem>
        <ListItem
          key={"sales"}
          component={NavLink}
          to={"sales"}
          disablePadding
          selected={selectedItem === "sales"}
          divider
          onClick={() => {
            navigate("sales");
            handleItemClick("sales")
          }}
          sx={{
            "& .css-16ac5r2-MuiButtonBase-root-MuiListItemButton-root": {
              backgroundColor: selectedItem === "sales" ? '#E3EAF3' : 'transparent',
            },
          }}
        >
          <ListItemButton
            onClick={() => {
              handelNavBar()
            }}>
            <img src={SIPBook} alt="img" />
            <ListItemText
              secondary={"Sales Report"}
              sx={{
                "& .css-83ijpv-MuiTypography-root": {
                  fontWeight: "bold",
                  marginLeft: "1rem",
                  fontSize: "13px",
                  color: selectedItem === "sales" ? '#2057a6' : 'black'
                },
              }}
            />
          </ListItemButton>
        </ListItem>
        <ListItem
          key={"operations"}
          component={NavLink}
          to={"operations"}
          disablePadding
          selected={selectedItem === "operations"}
          divider
          onClick={() => {
            navigate("operations");
            handleItemClick("operations")
          }}
          sx={{
            "& .css-16ac5r2-MuiButtonBase-root-MuiListItemButton-root": {
              backgroundColor: selectedItem === "operations" ? '#E3EAF3' : 'transparent',
            },
          }}
        >
          <ListItemButton
            onClick={() => {
              handelNavBar()
            }}>
            <img src={Distributor} alt="img" />
            <ListItemText
              secondary={"Operations"}
              sx={{
                "& .css-83ijpv-MuiTypography-root": {
                  fontWeight: "bold",
                  marginLeft: "1rem",
                  fontSize: "13px",
                  color: selectedItem === "operations" ? '#2057a6' : 'black'
                },
              }}
            />
          </ListItemButton>
        </ListItem>
        <ListItem
          key={"AMC vs Kfin"}
          component={NavLink}
          to={"amcvskfin"}
          disablePadding
          selected={selectedItem === "AMC vs Kfin"}
          divider
          onClick={() => {
            navigate("amcvskfin");
            handleItemClick("AMC vs Kfin")
          }}
          sx={{
            "& .css-16ac5r2-MuiButtonBase-root-MuiListItemButton-root": {
              backgroundColor: selectedItem === "AMC vs Kfin" ? '#E3EAF3' : 'transparent',
              // borderRadius:selectedItem===index?'10px':'0'
            },
          }}
        >
          <ListItemButton
            onClick={() => {
              handelNavBar()
            }}>
            <img src={AMCvsKfin} alt="img" />
            <ListItemText
              secondary={"AMC vs Kfin"}
              sx={{
                "& .css-83ijpv-MuiTypography-root": {
                  fontWeight: "bold",
                  marginLeft: "1rem",
                  fontSize: "13px",
                  color: selectedItem === "AMC vs Kfin" ? '#2057a6' : 'black'
                },
              }}
            />
          </ListItemButton>
        </ListItem>

      </List>
      {children}
    </Box>
  ) : (
    <Box
      bgcolor="white"
      flex={0.5}
      p={2}
      boxShadow="0px 2px 8px 0px #00000033"
      height="100vh"
      position="fixed"
      sx={{
        ...(openNav && { display: "none" }),
      }}
    >
      <List sx={{ fontSize: "500px" }}>
        {data.map((value, index) => (
          <ListItem
            key={value.name}
            component={NavLink}
            to={value.path}
            disablePadding
          >
            <ListItemButton onClick={handelNavBar}>
              <img src={value.img} alt="img" />
              <ListItemText
                secondary={value.name}
                sx={{
                  "& .css-83ijpv-MuiTypography-root": {
                    fontWeight: "bold",
                    marginLeft: "16px",
                    fontSize: "12px",
                  },
                }}
              />
            </ListItemButton>
          </ListItem>
        ))}
      </List>
    </Box>
  );
};
