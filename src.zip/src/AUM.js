import React from 'react'
import Photo from './components/Menu'
import Navbar from './components/Navbar'
import Top from './components/Top'
import Mid from './components/Mid'
import './AUM.css'

const AUM = () => {
  return (
    <div className='container'>
      <div className='menu'>
        <Photo/>
      </div>
      <div className='top_container'> 
        <Navbar/>
        <div className='scroll'>
        <Top />
        <Mid/>
        </div>
      </div>
    </div>
    
  )
}

export default AUM