import React from 'react'

const Bottom = () => {
  return (
    <div className='footer'></div>
  )
}

export default Bottom