import React from 'react'
import photo from '../img/menu.png'
import './comp_style.css'

const Menu = () => {
  return (
    <div><img className='menu' src={photo}/></div>
  )
}

export default Menu