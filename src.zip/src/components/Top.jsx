import React from 'react'
import './comp_style.css'

const Top = () => {
  return (
    <div className='top'>
        <div className='dashboard'>
            <h2>&emsp;Dashboard</h2>
        </div>
        <div className='date'>
            <p>Data as on 30th June</p>
        </div>
    </div>
  )
}

export default Top