import React from 'react'
import './comp_style.css'

const Navbar = () => {
  return (
    <div className='nav'></div>
  )
}

export default Navbar