import React from 'react'
import FusionCharts from "fusioncharts";
import charts from "fusioncharts/fusioncharts.charts";
import ReactFusioncharts from "react-fusioncharts";

charts(FusionCharts);

const dataSource = {
  chart: {
    theme: "candy",
    use3DLighting:false,
    showShadow: false,
    doughnutRadius: window.innerWidth <=390 ? 40:70,
    pieRadius:window.innerWidth <=390 ? 60:100,
    showLegend :1,
    bgcolor:"#ffffff",
    "showborder": "0",
    "legendPosition": window.innerWidth <=390 ? "bottom":"right-bottom",
    legendBorderColor :"#ffffff",
    "chartLeftMargin": window.innerWidth <=390 ? "0":"100",
    "chartTopMargin": "0",
    "chartRightMargin": "0",
    "chartBottomMargin": window.innerWidth <=390 ? "0":"20",
    "drawCustomLegendIcon": "1",
    "legendIconSides": "4",
    "legendIconStartAngle": "45"
  },
  data: [
    {
      label: "Hybrid",
      value: "1000",
      showLabel:'0',
      showValue:'0',
      color:"#2057a6"
    },
    {
      label: "Debt",
      value: "500",
      showLabel:'0',
      showValue:'0',
      color:"#8ed8b7"
    },
    {
        label:"Equity",
        value: "400",
        showLabel:'0',
      showValue:'0',
      color:"#69b8f4"
    }  
  ]
};

const assetChart=()=>
   {
    return (
      <>
      <div>
      <ReactFusioncharts
        type="doughnut2d"
        width={window.innerWidth <=390 ? "110%":"100%"}
        height="35%"
        dataFormat="JSON"
        dataSource={dataSource}
      /></div>
      
      </>
    );
  }


export default assetChart