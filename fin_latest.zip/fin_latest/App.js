import React from "react";
import { BrowserRouter } from "react-router-dom";
import Router from "./Router";
import store from "./reduxStore/store";
import { Provider } from 'react-redux';
import { ThemeProvider, createTheme } from "@mui/material";

const App = () => {
 const theme = createTheme({
    breakpoints: {
      values: {
        xs: 0,
        sm: 640,
        md: 1024,
        lg: 1200,
        xl: 1536,
      },
    },
  });

  return (

    <ThemeProvider theme={theme}>
    <Provider store={store}>
      <Router />
    </Provider>
    </ThemeProvider>
  );
};

export default App;
