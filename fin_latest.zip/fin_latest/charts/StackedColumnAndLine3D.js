import FusionCharts from "fusioncharts";
import charts from "fusioncharts/fusioncharts.charts";
import ReactFusioncharts from "react-fusioncharts";
import { Authcontext } from "../DemoAmc";
import { useContext,useEffect,useState } from "react";
import { reactLocalStorage } from "reactjs-localstorage";
import ReactFC from "react-fusioncharts";
import Excelexport from "fusioncharts/fusioncharts.excelexport";
const StackedColumnAndLine3D = ({data, title, subCaption, x_title, y_title, label, value1, value2, value3, filename}) => {

// Resolves charts dependancy
charts(FusionCharts,Excelexport);
// ReactFC.fcRoot(Excelexport);
const bgcolor = { 
  light_color: "#FFFFFF,#FFF5DC", 
  dark_color: "#1D2E56" }
const datacolor ={
  onLight:"#ffffff",
  onDark:"#030303"
}
const [themeMode, setThemeMode] = useState({
  bg:"",
  datalevel:""
})
const [max,setMax]= useState("");
useEffect(() => {
  data.map((obj)=>{
    setMax(data[0].value);
})
  if (reactLocalStorage.get("theme") == "light") { 
      let modeSet = {bg:`${bgcolor.light_color}`,datalevel:`${datacolor.onDark}`}
      setThemeMode(modeSet) } 
    else { 
      let modeSet = {bg:`${bgcolor.dark_color}`,datalevel:`${datacolor.onLight}`}
      setThemeMode(modeSet)
    }
}, [data,reactLocalStorage.get("theme")])
const value = useContext(Authcontext);
const dataSource = {
  chart: {
    bgColor:`${themeMode.bg}`,  
    divLineColor:`${themeMode.datalevel}`, 
    baseFontColor:`${themeMode.datalevel}`,
    toolTipBgColor:`${themeMode.bg}`,
    subcaptionFontColor:`${themeMode.datalevel}`,
    labelFontColor:`${themeMode.datalevel}`,
    valueFontColor:`${themeMode.datalevel}`,
    xAxisNameFontColor: `${themeMode.datalevel}`,
    yAxisNameFontColor: `${themeMode.datalevel}`,
    // numberprefix: "$",
    // numbersuffix: "B",
    xAxisName: `${x_title}`,
    yAxisName: `${y_title}`,
    plottooltext: "$seriesName : <b>₹$dataValue Cr</b>",
    showhovereffect: "1",
    showsum: "1",
    showvalues: "0",
    // palettecolors:`${value.stack3.color}`,
    caption: `${title}`,
    subcaption: `${subCaption}`,
    theme: "fusion",
    // palettecolors: "#1AD598,#EA3A3D,#6495ED",
    plotGradientColor: "#ffffff",
    // toolTipSepChar: "1",
    // seriesNameInToolTip: "1",
    // showToolTipShadow: "1",
    // plotHoverEffect: "1",
    // useEllipsesWhenOverflow: "0",
    labelDisplay: "rotate",
    slantLabel : "1",
    // exportEnabled: "1",
    // exportFormats: 'PDF=Export as PDF | XLSX= Export as XLSX |CSV=Export as CSV',
    exportFileName:`${filename}`
  },
  categories: [
    {
        category: [
            ...data.map((item)=>{
             //  console.log("labels" , {label:item.label})
             return ({label:item[label]})
            })
           ]
    }
  ],
  dataset: [
    {
        seriesname: `${value1}`,
        data: [
          ...data.map((item)=>{
           //  console.log("labels" , {label:item.label})
           return ({value:item[value1]})
          })
         ]
    },
    {
        seriesname: `${value2}`,
        data: [
          ...data.map((item)=>{
           //  console.log("labels" , {label:item.label})
           return ({value:item[value2]})
          })
         ]
    },
    {
      seriesname: `${value3}`,
      plottooltext: "$seriesName : <b>₹$dataValue Cr</b>",
      renderas: "Line",
      data: [
        ...data.map((item)=>{
         //  console.log("labels" , {label:item.label})
         return ({value:item[value3]})
        })
       ]
    }
  ]
};
if(value){
  dataSource.chart.palettecolors=`${value.stack3.color}`
  console.log(dataSource.chart)
}
else{
  dataSource.chart.palettecolors=`#1AD598,#EA3A3D,#6495ED`
}

    return (
      <ReactFusioncharts
        type="stackedcolumn3dline"
        width="100%"
        height="500"
        dataFormat="JSON"
        dataSource={dataSource}
      />
    );
}

export default StackedColumnAndLine3D;