// Include react
import React,{useContext, useState, useEffect} from "react";
import FusionCharts from "fusioncharts";
import charts from "fusioncharts/fusioncharts.charts";
import ReactFusioncharts from "react-fusioncharts";
import { Authcontext } from "../DemoAmc";
import Excelexport from "fusioncharts/fusioncharts.excelexport";


// class MyComponent extends React.Component {
//   render() {
 
const PieChart2d = ({data, title,filename}) => {
  const value = useContext( Authcontext );
    // Resolves charts dependancy
    charts(FusionCharts,Excelexport);
    // ReactFC.fcRoot(Excelexport)
    const dataSource = {
    chart: {
        
        plottooltext: "<b>₹$value Cr</b> $label ",
        showlegend: "0",
        showpercentvalues: "1",
        usedataplotcolorforlabels: "1",
        theme: "fusion",
        animation:"1",
        animationDuration:"5",
        showHoverEffect:"1",
        caption: `${title}`,
        captionFontColor: "#000000",
        plotHoverEffect:"1",
        // plotFillHoverColor:"#77e307",
        // plotFillHoverAlpha:"500",
        // plotBorderHoverColor:"#9032a8",
        // alphaAnimation: "10",
        // showShadow:"1",
        // use3DLighting:"1",
        // baseFont:"1",
        baseFontSize:"19",
        pieRadius:"140",
        // baseFontColor:"#9032a8",
        showToolTip:"1",
        toolTipBgColor:"#f2fc45",
        // exportEnabled: "1",
        // exportFormats: 'PDF=Export as PDF | XLSX= Export as XLSX |CSV=Export as CSV',
        exportFileName:`${filename}`
        // palette: "5",
        // "paletteColors": "#f5121f, #34ebc0, #280af7, #f2fc45, #b43a3c, #9032a8, #000, #77e307, #8442e7, #11d8f2"
        // plotBorderHoverThickness: "30"
    },
    data
    // data: [
    //     {
    //     label: "Apache",
    //     value: "32647479"
    //     },
    //     {
    //     label: "Microsoft",
    //     value: "22100932"
    //     },
    //     {
    //     label: "Zeus",
    //     value: "14376"
    //     },
    //     {
    //     label: "Other",
    //     value: "18674221"
    //     }
    // ]
    };
    if(value){
      dataSource.chart.palettecolors=`${value.doughnut.color}`
      // console.log(dataSource.chart)
    }

    
    return (
      <ReactFusioncharts
        type="pie2d"
        width="100%"
        height="390"
        dataFormat="JSON"
        dataSource={dataSource}
        
      />
    );
    // }
}

export default PieChart2d;
