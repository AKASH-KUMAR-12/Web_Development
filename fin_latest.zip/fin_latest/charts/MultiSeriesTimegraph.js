import React, { Component, useEffect, useState, useContext } from "react";
// Import fusioncharts.js files from fusioncharts module
import FusionCharts from "fusioncharts";
// Import the timeseries file from fusioncharts module
import TimeSeries from "fusioncharts/fusioncharts.timeseries";
// Import ReactFusioncharts from react-fusioncharts module
// import ReactFC from 'react-fusioncharts';
import ReactFC from "react-fusioncharts";
import { Authcontext } from "../DemoAmc";
import Excelexport from 'fusioncharts/fusioncharts.excelexport';


const MultiSeriesTimegraph = ({data, title, y_title,filename}) => {

    // Add core FusionCharts module and TimeSeries module as dependecies in react-fusioncharts
    
    ReactFC.fcRoot(FusionCharts, TimeSeries, Excelexport);
    const value = useContext(Authcontext);
    console.log(value)
    const jsonify = res => res.json();
    // const dataFetch = fetch(
    //   "https://s3.eu-central-1.amazonaws.com/fusion.store/ft/data/plotting-multiple-series-on-time-axis-data.json"
    // ).then(jsonify);
    // const schemaFetch = fetch(
    //   "https://s3.eu-central-1.amazonaws.com/fusion.store/ft/schema/plotting-multiple-series-on-time-axis-schema.json"
    // ).then(jsonify);
     const dataFetch= data;
     const schemaFetch=[{
      "name": "label",
      "type": "date",
      "format": "%Y-%m-%d"
    }, {
      "name": "amc_category",
      "type": "string"
    }, {
      "name": "value",
      "type": "number"
    }];

      const obj = {
        type: 'timeseries',
        renderAt: 'container',
        width: '100%',
        height: '400',
        dataSource: {
          chart:{
            palettecolors:`${value?value.timeSeries2.color:""}`,
            // exportEnabled:"1",
            // exportFormats: 'PDF=Export as PDF | XLSX= Export as XLSX |CSV=Export as CSV',
            exportFileName:`${filename}`
          },
          legend: {
            enabled: '1',
            position: 'top'
        },
          caption: {
            text: `${title}`
          },
          series: "amc_category",
          yAxis:  [
            {
            plot: {
                value: "value",
                type: "line"
            },
            format: {
                prefix: "₹"
            },
            title: `${y_title}`
            }
        ],
          // Initially data is set as null
          data: {}
        }
      // }
    };
    const [timeseriesDs,setTimeseriesDs] = useState(obj);

    // In this method we will create our DataStore and using that we will create a custom DataTable which takes two
    // parameters, one is data another is schema. Check the method definition to get more info.
    // this.createDataTable = this.createDataTable.bind(this);
  
console.log(data)
  const onFetchData = () => {
    Promise.all([dataFetch, schemaFetch]).then(res => {
      const data = res[0];
      const schema = res[1];
      // First we are creating a DataStore
      // const fusionDataStore = new FusionCharts.DataStore();
      // After that we are creating a DataTable by passing our data and schema as arguments
      const fusionTable = new FusionCharts.DataStore().createDataTable(
        data,
        schema
      );
      // Afet that we simply mutated our timeseries datasource by attaching the above
      // DataTable into its data property.
      const timeseriesDs1 = Object.assign({}, timeseriesDs);
      timeseriesDs1.dataSource.data = fusionTable;
      // this.setState({
      //   timeseriesDs1
      // });
      setTimeseriesDs(timeseriesDs1);
    });
    // console.log("inside create tabeldate  datafetch:", dataFetch);
  };

  // We are creating the DataTable immidietly after the component is mounted
  // componentDidMount() {
  //   this.createDataTable();
  // }

  // createDataTable();

  useEffect(()=>{
    onFetchData();
  },[data]);

  return (
    // <div className="App">
    <ReactFC {...timeseriesDs} />
    // </div>
  );
};

export default MultiSeriesTimegraph;