import React,{useContext,useEffect,useState} from "react";
// Include the react-fusioncharts component
import ReactFC from "react-fusioncharts";

// Include the fusioncharts library
import FusionCharts from "fusioncharts";

// Include the chart type
import Column2D from "fusioncharts/fusioncharts.charts";

// Include the theme as fusion
import FusionTheme from "fusioncharts/themes/fusioncharts.theme.fusion";
import { Authcontext } from "../DemoAmc";
import { reactLocalStorage } from "reactjs-localstorage";
import Excelexport from "fusioncharts/fusioncharts.excelexport";
// import { useContext } from "react";
// STEP 4 - Creating the DOM element to pass the react-fusioncharts component
// class BarChart extends React.Component {
// render() {
const VerticalSimpleBarChart = ({
  data,
  title,
  x_title,
  y_title,
  width,
  drillDown,
  subCaption,
  price, 
  filename
}) => {
  // Adding the chart and theme as dependency to the core fusioncharts
  ReactFC.fcRoot(FusionCharts, Column2D, FusionTheme, Excelexport);

  const bgcolor = { 
    light_color: "#DDEAF7", 
    dark_color: "#1D2E56" }
  const datacolor ={
    onLight:"#ffffff",
    onDark:"#030303"
  }
  const [themeMode, setThemeMode] = useState({
    bg:"",
    datalevel:""
  })

  const [max,setMax]= useState("");
  useEffect(() => {
    data.map((obj)=>{
      setMax(data[0].value);
  })
    if (reactLocalStorage.get("theme") == "light") { 
        let modeSet = {bg:`${bgcolor.light_color}`,datalevel:`${datacolor.onDark}`}
        setThemeMode(modeSet) } 
      else { 
        let modeSet = {bg:`${bgcolor.dark_color}`,datalevel:`${datacolor.onLight}`}
        setThemeMode(modeSet)
      }
}, [data,reactLocalStorage.get("theme")])
  const value = useContext( Authcontext );
  // STEP 2 - Chart Data
  const chartData = data;

  // STEP 3 - Creating the JSON object to store the chart configurations
  const chartConfigs = {
    type: "column2d", // The chart type
    width: `${width}`, // Width of the chart
    height: "400", // Height of the chart
    dataFormat: "json", // Data type
    dataSource: {
      // Chart Configuration
      chart: {
        bgColor:`${themeMode.bg}`,  
      divLineColor:`${themeMode.datalevel}`, 
      baseFontColor:`${themeMode.datalevel}`,
      toolTipBgColor:`${themeMode.bg}`,
      subcaptionFontColor:`${themeMode.datalevel}`,
      labelFontColor:`${themeMode.datalevel}`,
      valueFontColor:`${themeMode.datalevel}`,
      xAxisNameFontColor: `${themeMode.datalevel}`,
      yAxisNameFontColor: `${themeMode.datalevel}`,
      // canvasBgAlpha:"50",
      // containerBackgroundOpacity : '50',
      // bgAlpha:"80",
      caption: `${title}`,
        subCaption: `${subCaption}`,
        xAxisName: `${x_title}`,
        yAxisName: `${y_title}`,
        theme: "fusion",
        drawCrossLine: 1,
        // crossLineAnimation: 0,
       
        showValues: "1",
        plottooltext: `<b>$label</b> <br> <b>₹$value ${price}</b>`,
        animation: 0,
        placeValuesInside: 0,
        labelFontSize: 14.5,
        showToolTip: 1,
        showpercentvalues: "1",
        showHoverEffect: "1",

        labelPadding: "10px",
        labelDisplay: "auto",
        useEllipsesWhenOverflow: "1",
        tooltipPosition: "auto",
        // exportEnabled: "1",
        // exportFormats: 'PDF=Export as PDF | XLSX= Export as XLSX |CSV=Export as CSV',
        //exportFileName:`${filename}`
      },
      // Chart Data
      data: chartData,
    },
    events: {
      dataplotClick: function(evt, args) {
        //chartClick name is hardcoded from backend
        //so do not change it.
        //console.log("click", evt);
        window.chartClick = function(str) {
          // console.log("string = ", str);
          drillDown(str);
        };
      },
    },
  };
  if(value){
    chartConfigs.dataSource.chart.palettecolors=`${value.simple.light}`
  }
  return <ReactFC {...chartConfigs} />;
 }


export default VerticalSimpleBarChart;
