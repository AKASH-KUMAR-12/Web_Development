import FusionCharts from "fusioncharts";
import charts from "fusioncharts/fusioncharts.charts";
import ReactFusioncharts from "react-fusioncharts";
import mscolumnline3d from 'fusioncharts/fusioncharts.charts';
import ReactFC from "react-fusioncharts";
import Excelexport from "fusioncharts/fusioncharts.excelexport";

const MultiseriesColumn3D_LineSingleYaxisChart = ({data, title, subCaption, x_title, y_title, label, value1, value2, value3, mscolumnline3d,filename}) => {

// Resolves charts dependancy
charts(FusionCharts,Excelexport);
// ReactFC.fcRoot(Excelexport);

const dataSource = {
  chart: {
    showvalues: "0",
    caption: `${title}`,
    subcaption: `${subCaption}`,
    captionFontColor: "#000000",
    // numberprefix: "$",
    // numbersuffix: "B",
    xAxisName: `${x_title}`,
    yAxisName: `${y_title}`,
    plottooltext: "$seriesName : <b>₹$dataValue Cr</b>",
    showhovereffect: "1",
    showsum: "1",
    theme: "fusion",
    palettecolors: "#1AD598,#EA3A3D,#6495ED",
    xAxisNameFontColor: "#000000",
    yAxisNameFontColor: "#000000",
    plotGradientColor: "#ffffff",
    // exportEnabled: "1",
    // exportFormats: 'PDF=Export as PDF | XLSX= Export as XLSX |CSV=Export as CSV',
    exportFileName:`${filename}`
  },
  categories: [
    {
        category: [
            ...data.map((item)=>{
              
             return ({label:item[label]})
            })
           ]
    }
  ],
  dataset: [
    {
        seriesname: `${value1}`,
        data: [
          ...data.map((item)=>{
            
           return ({value:item[value1]})
          })
         ]
    },
    {
        seriesname: `${value2}`,
        data: [
          ...data.map((item)=>{
            
           return ({value:item[value2]})
          })
         ]
    },
    {
      seriesname: `${value3}`,
      plottooltext: "$seriesName : <b>₹$dataValue Cr</b>",
      renderas: "Line",
      data: [
        ...data.map((item)=>{
          
         return ({value:item[value3]})
        })
       ]
    }
  ]
};

    return (
      <ReactFusioncharts
        type="mscolumnline3d"
        width="100%"
        height="500"
        dataFormat="JSON"
        dataSource={dataSource}
      />
    );
}

export default MultiseriesColumn3D_LineSingleYaxisChart;

// // Include react
// import React from 'react';

// // Include the react-fusioncharts component
// import ReactFC from 'react-fusioncharts';

// // Include the fusioncharts library
// import FusionCharts from 'fusioncharts';

// // Include the chart type
// import mscolumnline3d from 'fusioncharts/fusioncharts.charts';

// // Include the theme as fusion
// import FusionTheme from 'fusioncharts/themes/fusioncharts.theme.fusion';

// // Adding the chart and theme as dependency to the core fusioncharts
// ReactFC.fcRoot(FusionCharts, mscolumnline3d, FusionTheme);

// // STEP 2- Define the categories representing the labels on the X-axis

// const categories =  [
//   {
//       "category": [
//           {
//               "label": "Quarter 1"
//           },
//           {
//               "label": "Quarter 2"
//           },
//           {
//               "label": "Quarter 3"
//           },
//           {
//               "label": "Quarter 4"
//           }
//       ]
//     }
//   ]
 
//   // STEP 3- Construct the dataset comprising multiple series

//   const dataset = [

//     {
//       "seriesname": "Inflow",
//       "data": [
//           {
//               "value": "235000"
//           },
//           {
//               "value": "225100"
//           },
//           {
//               "value": "222000"
//           },
//           {
//               "value": "230500"
//           }
//       ]
//   },
//   {
//       "seriesname": "Outflow",
//       "data": [
//           {
//               "value": "230000"
//           },
//           {
//               "value": "143000"
//           },
//           {
//               "value": "198000"
//           },
//           {
//               "value": "327600"
//           }
//       ]
//   },
//   {
//       "seriesname": "Netflow",
//       "renderas": "Line",
//       "data": [
//           {
//               "value": "455000"
//           },
//           {
//               "value": "334000"
//           },
//           {
//               "value": "426000"
//           },
//           {
//               "value": "403000"
//           }
//       ]
//   }
//   ]



// // STEP 4 - Creating the JSON object to store the chart configurations

// const chartConfigs = {

//     type: 'mscolumnline3d',// The chart type

//     width: '1450', // Width of the chart

//     height: '400', // Height of the chart

//     dataFormat: 'json', // Data type

//      dataSource: {

//     //Chart Configurations

//       "chart": {

//         "caption": "Top Distributors By Flow",

//         // "subCaption": "Harry's SuperMart",

//         "xAxisname": "Quarter",

//         "yAxisName": "Flow",

//         "numberPrefix": "₹",

//         "theme": "fusion",

//         "displaylabel": "",
//         "useEclipsesWhenOverflow": "1",

//     },

//       "categories": categories,

//       "dataset": dataset,

//     }

//   }

// class App extends React.Component {

//   render() {

//      return (

//      <ReactFC

//         {...chartConfigs}/>



//      );

//   }

// }

  
//   export default App;


//   // // MultiseriesColumn3D_LineSingleYaxisChart

// // import React from "react";
// // import ReactDOM from "react-dom";
// // import FusionCharts from "fusioncharts";
// // import ReactFC from 'react-fusioncharts';
// // import charts from "fusioncharts/fusioncharts.charts";
// // import mscolumnline3d from 'fusioncharts/fusioncharts.charts';
// // import ReactFusioncharts from "react-fusioncharts";
// // import FusionTheme from 'fusioncharts/themes/fusioncharts.theme.fusion';
// // ReactFC.fcRoot(FusionCharts, mscolumnline3d, FusionTheme);

// // const MultiseriesColumn3D_LineSingleYaxisChart = ({
// // // data,
// // x_title,
// // y_title,
// // title,
// // width}) => {


// // // Resolves charts dependancy
// // charts(FusionCharts);
// // const categories =  [
// //   {
// //       "category": [
// //           {
// //               "label": "Quarter 1"
// //           },
// //           {
// //               "label": "Quarter 2"
// //           },
// //           {
// //               "label": "Quarter 3"
// //           },
// //           {
// //               "label": "Quarter 4"
// //           }
// //       ]
// //     }
// //   ]
 
// //   // STEP 3- Construct the dataset comprising multiple series

// //   const dataset = [

// //     {
// //       "seriesname": "Fixed Cost",
// //       "data": [
// //           {
// //               "value": "235000"
// //           },
// //           {
// //               "value": "225100"
// //           },
// //           {
// //               "value": "222000"
// //           },
// //           {
// //               "value": "230500"
// //           }
// //       ]
// //   },
// //   {
// //       "seriesname": "Variable Cost",
// //       "data": [
// //           {
// //               "value": "230000"
// //           },
// //           {
// //               "value": "143000"
// //           },
// //           {
// //               "value": "198000"
// //           },
// //           {
// //               "value": "327600"
// //           }
// //       ]
// //   },
// //   {
// //       "seriesname": "Budgeted cost",
// //       "renderas": "Line",
// //       "data": [
// //           {
// //               "value": "455000"
// //           },
// //           {
// //               "value": "334000"
// //           },
// //           {
// //               "value": "426000"
// //           },
// //           {
// //               "value": "403000"
// //           }
// //       ]
// //   }
// //   ]

// // const dataSource = {
// //     chart: {
// //         caption: `${title}`,
// //         captionFontColor: "#000000",
// //         // subcaption: "For the year 2017",
// //         yaxisname: `${y_title}`,
// //         xaxisname: `${x_title}`,
// //         width:`${width}`,
// //         decimals: "1",
// //         theme: "fusion",
// //         plottooltext: "$label <br> ₹ <b>$value</b> Cr",
// //         // exportEnabled: "1",
// //         labelFontSize: "12px",
// //         // labelBorderPadding: "100px",
// //         xAxisNameFontSize: "20px",
// //         yAxisNameFontSize: "20px",
// //         xAxisNameFontBold:"0",
// //         yAxisNameFontBold:"1",
// //         xAxisNameFontColor:"#000000",
// //         yAxisNameFontColor:"#000000",
// //     },
// //     data: dataset,
// //     "categories": categories,
// //     };

// //     return (
// //       <ReactFusioncharts
// //         type="mscolumnline3d"
// //         height="400"
// //         dataFormat="JSON"
// //         dataSource={dataSource}
// //       />
// //     );
// // }

// // export default MultiseriesColumn3D_LineSingleYaxisChart;