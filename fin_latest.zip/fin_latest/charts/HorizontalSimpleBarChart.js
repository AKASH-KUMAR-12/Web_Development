
import ReactDOM from "react-dom";

// Include the react-fusioncharts component
import ReactFC from "react-fusioncharts";

// Include the fusioncharts library
import FusionCharts from "fusioncharts";

// Include the chart type
import Bar2D from "fusioncharts/fusioncharts.charts";

// Include the theme as fusion
import FusionTheme from "fusioncharts/themes/fusioncharts.theme.fusion";
import React, { Component ,useEffect, useState} from 'react';
import { reactLocalStorage } from 'reactjs-localstorage';




// STEP 4 - Creating the DOM element to pass the react-fusioncharts component
// class BarChart extends React.Component {
  // render() {
const HorizontalSimpleBarChart = ({data, title,width,filename}) => {

  // Adding the chart and theme as dependency to the core fusioncharts
    ReactFC.fcRoot(FusionCharts, Bar2D, FusionTheme);
    const bgcolor = { 
      light_color: "#DDEAF7", 
      dark_color: "#1D2E56" }
    const datacolor ={
      onLight:"#ffffff",
      onDark:"#030303"
    }
    const [themeMode, setThemeMode] = useState({
      bg:"",
      datalevel:""
    })

    const [max,setMax]= useState("");
    useEffect(() => {
            data.map((obj)=>{
                setMax(data[0].value);
            })
            if (reactLocalStorage.get("theme") == "light") { 
                let modeSet = {bg:`${bgcolor.light_color}`,datalevel:`${datacolor.onDark}`}
                setThemeMode(modeSet) } 
              else { 
                let modeSet = {bg:`${bgcolor.dark_color}`,datalevel:`${datacolor.onLight}`}
                setThemeMode(modeSet)
              }
    }, [data,reactLocalStorage.get("theme")])
    // STEP 2 - Chart Data
    const chartData = data;
    // [
    //   {
    //     label: "Venezuela",
    //     value: "290"
    //   },
    //   {
    //     label: "Saudi",
    //     value: "260"
    //   },
    //   {
    //     label: "Canada",
    //     value: "180"
    //   },
    //   {
    //     label: "Iran",
    //     value: "140"
    //   },
    //   {
    //     label: "Russia",
    //     value: "115"
    //   },
    //   {
    //     label: "UAE",
    //     value: "100"
    //   },
    //   {
    //     label: "US",
    //     value: "30"
    //   },
    //   {
    //     label: "China",
    //     value: "30"
    //   }
    // ];

    // STEP 3 - Creating the JSON object to store the chart configurations
    const chartConfigs = {
      type: "bar2d", // The chart type
      width: `${width}`, // Width of the chart
      height: "240",// Height of the chart
      dataFormat: "json", // Data type
      dataSource: {
        // Chart Configuration
        chart: {
          //Set the chart caption
          caption: `${title}`,
          captionFontColor: "#000000",
          bgColor:`${themeMode.bg}`,  
          baseFontColor:`${themeMode.datalevel}`,
          toolTipBgColor:`${themeMode.bg}`,
          captionFontColor:`${themeMode.datalevel}`,
          // "Countries With Most Oil Reserves [2017-18]",
          //Set the chart subcaption
          // subCaption: "In MMbbl = One Million barrels",
          //Set the x-axis name
          // xAxisName: `${x_title}`,
          // "Country",
          labelFontSize : 15,
          //Set the y-axis name
          // yAxisName: `${y_title}`,
          // "Reserves (MMbbl)",
          // numberSuffix: "K",
          //Set the theme for your chart
          theme: "fusion",
          //adding the color pallet ,its pre-defined in the fusionchart
          pallete: 5,
          //here we add the colrs we want to fill in the graph
          // paletteColors:"#6078EA",
          plottooltext:
        "<b>$label</b> <b>₹$value Cr</b>",
          //this is to add the colors in the divident lines.
          divLineColor: "#00080a",
          // usePlotGradientColor: "1",
        // plotGradientColor: "#ffffff",
        animation: 0,
          // divLineAlpha: 100,
          drawCrossLine: 1,
          crossLineAnimation: 0,
          labelFontSize: "9.5px",
          // exportEnabled: "1",
          // exportFormats: 'PDF=Export as PDF | XLSX= Export as XLSX |CSV=Export as CSV',
          exportFileName:`${filename}`
        },
        // Chart Data
        data: chartData
      }
    };
    
    return (<ReactFC {...chartConfigs} />);
  // }
}

export default HorizontalSimpleBarChart;