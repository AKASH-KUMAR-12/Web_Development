import FusionCharts from "fusioncharts";
import charts from "fusioncharts/fusioncharts.charts";
import ReactFusioncharts from "react-fusioncharts";
import { Authcontext } from "../DemoAmc";
import { useContext,useEffect,useState } from "react";
import { reactLocalStorage } from "reactjs-localstorage";
import Excelexport from "fusioncharts/fusioncharts.excelexport";

const StackedColumnAndLine = ({data, title, subCaption, x_title, y_title, label, value1, value2, value3, filename,price}) => {

// Resolves charts dependancy
charts(FusionCharts,Excelexport);
const bgcolor = { 
  light_color: "#DDEAF7", 
  dark_color: "#1D2E56" }
const datacolor ={
  onLight:"#ffffff",
  onDark:"#030303"
}
const [themeMode, setThemeMode] = useState({
  bg:"",
  datalevel:""
})
const [max,setMax]= useState("");
useEffect(() => {
  data.map((obj)=>{
    setMax(data[0].value);
})
  if (reactLocalStorage.get("theme") == "light") { 
      let modeSet = {bg:`${bgcolor.light_color}`,datalevel:`${datacolor.onDark}`}
      setThemeMode(modeSet) } 
    else { 
      let modeSet = {bg:`${bgcolor.dark_color}`,datalevel:`${datacolor.onLight}`}
      setThemeMode(modeSet)
    }
}, [data,reactLocalStorage.get("theme")])
const value = useContext(Authcontext);
const dataSource = {
  chart: {
    bgColor:`${themeMode.bg}`,  
    divLineColor:`${themeMode.datalevel}`, 
    baseFontColor:`${themeMode.datalevel}`,
    toolTipBgColor:`${themeMode.bg}`,
    subcaptionFontColor:`${themeMode.datalevel}`,
    labelFontColor:`${themeMode.datalevel}`,
    valueFontColor:`${themeMode.datalevel}`,
    xAxisNameFontColor: `${themeMode.datalevel}`,
    yAxisNameFontColor: `${themeMode.datalevel}`,
    showvalues: "0",
    caption: `${title}`,
    subcaption: `${subCaption}`,
    captionFontColor: `${themeMode.datalevel}`,
 
    xAxisName: `${x_title}`,
    yAxisName: `${y_title}`,
    plottooltext: `$seriesName : <b>₹$dataValue ${price}</b>`,
    showhovereffect: "1",
    showsum: "1",
    theme: "fusion",

    labelFontSize: 10,
    labelDisplay: "rotate",
    slantLabel : "1",
    // exportEnabled: "1",
    // exportFormats: 'PDF=Export as PDF | XLSX= Export as XLSX |CSV=Export as CSV',
    exportFileName:`${filename}`
  },
  categories: [
    {
        category: [
            ...data.map((item)=>{
             return ({label:item[label]})
            })
           ]
    }
  ],
  dataset: [
    {
        seriesname: `${value1}`,
        data: [
          ...data.map((item)=>{
           return ({value:item[value1]})
          })
         ]
    },
    {
        seriesname: `${value2}`,
        data: [
          ...data.map((item)=>{
           
           return ({value:item[value2]})
          })
         ]
    },
    {
      seriesname: `${value3}`,
     
      renderas: "Line",
      data: [
        ...data.map((item)=>{
         
         return ({value:item[value3]})
        })
       ]
    }
  ]
};
if(value){
  dataSource.chart.palettecolors=`${value.stack3.color}`
 
}

    return (
      <ReactFusioncharts
        type="stackedcolumn2dline"
        width="100%"
        height="600"
        dataFormat="JSON"
        dataSource={dataSource}
      />
    );
}

export default StackedColumnAndLine;