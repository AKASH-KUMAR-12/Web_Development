// // STEP 1 - Include Dependencies
// // Include react
// import React from "react";
// import ReactDOM from "react-dom";
// // Include the react-fusioncharts component
// import ReactFC from "react-fusioncharts";
// // Include the fusioncharts library
// import FusionCharts from "fusioncharts";
// // Include the chart type
// import mscolumn2D from "fusioncharts/fusioncharts.charts";
// // Include the theme as fusion
// import FusionTheme from "fusioncharts/themes/fusioncharts.theme.fusion";
// //   // Adding the chart and theme as dependency to the core fusioncharts
// ReactFC.fcRoot(FusionCharts, mscolumn2D, FusionTheme);
// // STEP 2- Define the categories representing the labels on the X-axis
// const MultiSeriesColumnChart = ({
//   title,
//   x_title,
//   y_title,
//   width,
// //   drillDown,
// //   subCaption,
// }) => {
//   // Adding the chart and theme as dependency to the core fusioncharts
//   ReactFC.fcRoot(FusionCharts, mscolumn2D, FusionTheme);

//   // STEP 2 - Chart Data
//   //   const chartData = data;
//   const categories = [
//     {
//       category: [
//         { label: "Q1" },
//         { label: "Q2" },
//         { label: "Q3" },
//         { label: "Q4" },
//       ],
//     },
//   ];
//   // STEP 3- Construct the dataset comprising multiple series
//   const dataset1 = [
//     {
//       seriesname: "Previous Year",
//       data: [
//         { value: "12000" },
//         { value: "10500" },
//         { value: "23500" },
//         { value: "16000" },
//       ],
//     },
//     {
//       seriesname: "Current Year",
//       data: [
//         { value: "24400" },
//         { value: "29800" },
//         { value: "20800" },
//         { value: "26800" },
//       ],
//     },
//   ];

//   // STEP 3 - Creating the JSON object to store the chart configurations
//   const chartConfigs = {
//     type: "mscolumn2D", // The chart type
//     width: `${width}`, // Width of the chart
//     height: "400", // Height of the chart
//     dataFormat: "json", // Data type
//     dataSource: {
//       // Chart Configuration
//       chart: {
//         theme: "fusion",
//         numberSuffix: "K",
//         plotFillAlpha: "80",
//         //   "divLineIsDashed": "1",
//         //    "divLineDashLen": "1",
//         //    "divLineGapLen": "1" },

//         //{
//         //   //Set the chart caption
//         caption: `${title}`,
//         // subCaption: `${subCaption}`,
//         captionFontColor: "#000000",
//         xAxisName: `${x_title}`,
//         labelFontSize: 15,
//         yAxisName: `${y_title}`,
//         drawCrossLine: 1,
//         crossLineAnimation: 0,
//         //   plottooltext: "<b>$label</b> <br> <b>₹$value Cr</b>",
//         xAxisNameFontColor: "#000000",
//         yAxisNameFontColor: "#000000",
//         showValues: "1",
//         usePlotGradientColor: "1",
//         plotGradientColor: "#ffffff",
//         animation: 1,
//         placeValuesInside: 0,
//         labelFontSize: 14.5,
//         showToolTip: 1,
//         showpercentvalues: "1",
//         showHoverEffect: "0",
//         slantLabels: "1",
//         categories: categories,
//         dataset: dataset1,
//         //   rotateLabels: "1",
//         //   labelDisplay: 'WRAP'
//       },
//       // Chart Data
//         data: dataset1,
//     },
//     // events: {
//     //   dataplotClick: function(evt, args) {
//     //     //chartClick name is hardcoded from backend
//     //     //so do not change it.
//     //     //console.log("click", evt);
//     //     window.chartClick = function(str) {
//     //       // console.log("string = ", str);
//     //       drillDown(str);
//     //     };
//     //   },
//     // },
//   };

//   return <ReactFC {...chartConfigs} />;
//   // }
// };

// export default MultiSeriesColumnChart;

import React from "react";
import FusionCharts from "fusioncharts";
import charts from "fusioncharts/fusioncharts.charts";
import ReactFusioncharts from "react-fusioncharts";
import Excelexport from "fusioncharts/fusioncharts.excelexport";

// Resolves charts dependancy
charts(FusionCharts, Excelexport);

const dataSource = {
  chart: {
    caption: "Yearly Inflow of Distributor",
    xAxisNameFontColor: "#000000",
    yAxisNameFontColor: "#000000",
    captionFontColor: "#000000",
    subcaption: "",
    xaxisname: "Name of the RIA",
    yaxisname: "Purchase",
    formatnumberscale: "1",
    numberprefix: "₹",
    plottooltext:
      "<b>$dataValue</b> <b>$seriesName</b> in $label",
    theme: "fusion",
    drawcrossline: "1",
    // exportEnabled:"1",
    // exportFormats: 'PDF=Export as PDF | XLSX= Export as XLSX |CSV=Export as CSV',
  },
  categories: [
    {
      category: [
        {
          label: "TRUSTPLUTUS FAMILY OFFICE"
        },
        {
          label: "AVENDUS WEALTH MANAGEMENT"
        },
        {
          label: "IFAST FINANCIAL INDIA PRIVATE"
        },
        {
          label: "FINZOOM INVESTMENT ADVISORY"
        },
        {
          label: "CENT RUM INVESTMENT ADVISORY"
        }
      ]
    }
  ],
  dataset: [
    {
      seriesname: "Inflow(201718)",
      data: [
        {
          value: "125000"
        },
        {
          value: "300000"
        },
        {
          value: "480000"
        },
        {
          value: "800000"
        },
        {
          value: "1100000"
        }
      ]
    },
    {
      seriesname: "Inflow(201819)",
      data: [
        {
          value: "70000"
        },
        {
          value: "150000"
        },
        {
          value: "350000"
        },
        {
          value: "600000"
        },
        {
          value: "1400000"
        }
      ]
    },
    {
      seriesname: "Inflow(201920)",
      data: [
        {
          value: "10000"
        },
        {
          value: "100000"
        },
        {
          value: "300000"
        },
        {
          value: "600000"
        },
        {
          value: "900000"
        }
      ]
    }
  ]
};

class MyComponent extends React.Component {
  render() {
    return (
      <ReactFusioncharts
        type="mscolumn2d"
        width="100%"
        height="100%"
        dataFormat="JSON"
        dataSource={dataSource}
      />
    );
  }
}

export default MyComponent;
