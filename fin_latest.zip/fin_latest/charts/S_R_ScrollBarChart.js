import React, {useEffect, useState} from 'react';
import FusionCharts from "fusioncharts";
import charts from "fusioncharts/fusioncharts.charts";
import ReactFusioncharts from "react-fusioncharts";
import { Authcontext } from "../DemoAmc";
import { useContext } from "react";
import Excelexport from "fusioncharts/fusioncharts.excelexport";
import { reactLocalStorage } from 'reactjs-localstorage';

const ScrollBarChart = ({
  data,
  title,
  x_title,
  y_title,
  width,
  price,
  drillDown,
  subCaption,
  filename
}) => {
  
  // Resolves charts dependancy
  charts(FusionCharts,Excelexport);
  const bgcolor = { 
    light_color: "#DDEAF7", 
    dark_color: "#1D2E56" }
  const datacolor ={
    onLight:"#ffffff",
    onDark:"#030303"
  }
  const [themeMode, setThemeMode] = useState({
    bg:"",
    datalevel:""
  })

  const [max,setMax]= useState("");

  useEffect(() => {
    data.map((obj)=>{
      setMax(data[0].value);
  })
    if (reactLocalStorage.get("theme") == "light") { 
        let modeSet = {bg:`${bgcolor.light_color}`,datalevel:`${datacolor.onDark}`}
        setThemeMode(modeSet) } 
      else { 
        let modeSet = {bg:`${bgcolor.dark_color}`,datalevel:`${datacolor.onLight}`}
        setThemeMode(modeSet)
      }
}, [data,reactLocalStorage.get("theme")])
  const value = useContext( Authcontext );
  const dataSource = {
    chart: {
      caption: `${title}`,
      // "palettecolors":`${value.simple.light}`,

    
      bgColor:`${themeMode.bg}`,  
      divLineColor:`${themeMode.datalevel}`, 
      baseFontColor:`${themeMode.datalevel}`,
      toolTipBgColor:`${themeMode.bg}`,
      subcaptionFontColor:`${themeMode.datalevel}`,
      labelFontColor:`${themeMode.datalevel}`,
      valueFontColor:`${themeMode.datalevel}`,
      xAxisNameFontColor: `${themeMode.datalevel}`,
      yAxisNameFontColor: `${themeMode.datalevel}`,
      subcaption: `${subCaption}`,
      xAxisName: `${x_title}`,
      yaxisname: `${y_title}`,
      theme: "fusion",
      numvisibleplot: "5",
      showValues: "1",
      drawCrossLine: 1,
      labelFontSize: 14.5,
      placeValuesInside: 0,
      showToolTip: 1,
      showHoverEffect: "1",
      slantLabels: "1",
      plottooltext:
        ` <b>$label</b> <br/><b>$value ${price}</b> `,
      labeldisplay: "auto",   
      // exportEnabled: "1",
      // exportFormats: 'PDF=Export as PDF | XLSX= Export as XLSX |CSV=Export as CSV',
      exportFileName:`${filename}`
    },
    categories: [
      {
        category: [
         ...data.map((item)=>{
          return ({label:item.label})
         })
        ]
      }
    ],
    dataset: [
     {
        data: [
          ...data.map((item)=>{
            return ({value:item.value,
                    link:item.link})
           })
        ]
       }
    ],
    events: {
      dataplotClick: function(evt, args) {
        //chartClick name is hardcoded from backend
        //so do not change it.
        //console.log("click", evt);
        window.chartClick = function(str) {
          // console.log("string = ", str);
          drillDown(str);
        };
      },
    },
  };
  if(value){
    dataSource.chart.palettecolors=`${value.simple.light}`

  }

  return (
      <ReactFusioncharts
        type="scrollcolumn2d"
        width="100%"
        height="400"
        dataFormat="JSON"
        dataSource={dataSource}
      />
    );
};

export default ScrollBarChart;
