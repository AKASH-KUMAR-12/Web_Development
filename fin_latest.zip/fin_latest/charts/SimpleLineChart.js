// Include react
import React from "react";
import ReactDOM from "react-dom";
// Include the react-fusioncharts component
import ReactFC from "react-fusioncharts";
import FusionCharts from "fusioncharts";
import charts from "fusioncharts/fusioncharts.charts";
import ReactFusioncharts from "react-fusioncharts";



// class MyComponent extends React.Component {
//   render() {
const SimpleLineChart = (props) => {
  console.log("data",props.totalData);
    // Resolves charts dependancy
    charts(FusionCharts);
    const dataSource = {
    chart: {
        caption: "Average Fastball Velocity",
        captionFontColor: "#000000",
        yaxisname: "Velocity ",
        xAxisName: "Years",
        subcaption: "[2005-2016]",
        numbersuffix: " mph",
        setadaptiveymin: "1",
        theme: "fusion",
        xAxisNameFontColor:"#38074d",
        yAxisNameFontColor:"#38074d",
        baseFontSize:"1rem",
        baseFontColor:"#0000A5",
        toolTipColor:"#38074d",
        toolTipBorderColor:"#FEFCFF",
        tooltipBorderAlpha:"63",
        tooltipPosition:"top",
        showToolTipShadow:1,
        "captionPadding": "40",
        "yAxisNamePadding": "40",
        "xAxisNamePadding": "40",
        "divLineColor": "#6699cc",
        "anchorRadius": "6",
        "anchorBorderThickness": "2",
        "anchorBorderColor": "#151B54",
        "anchorBgColor": "#F70D1A",
       " rotatelabels": "0",
    },
    data: [
        {
        label: "2005",
        value: "89.45",
        
        },
        {
        label: "2006",
        value: "89.87"
        },
        {
        label: "2007",
        value: "89.64"
        },
        {
        label: "2008",
        value: "90.13"
        },
        {
        label: "2009",
        value: "90.67"
        },
        {
        label: "2010",
        value: "90.54"
        },
        {
        label: "2011",
        value: "90.75"
        },
        {
        label: "2012",
        value: "90.8"
        },
        {
        label: "2013",
        value: "91.16"
        },
        {
        label: "2014",
        value: "91.37"
        },
        {
        label: "2015",
        value: "91.66"
        },
        {
        label: "2016",
        value: "91.8"
        }
    ]
    // data:[props.totalData]
    };
    return (
      <ReactFusioncharts
        type="line"
        width="1200"
        height="400"
        dataFormat="JSON"
        dataSource={dataSource}
      />
    );
//   }
}

export default SimpleLineChart;