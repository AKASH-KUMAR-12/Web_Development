import FusionCharts from "fusioncharts";
import charts from "fusioncharts/fusioncharts.charts";
import ReactFusioncharts from "react-fusioncharts";
import { Authcontext } from "../DemoAmc";
import { useContext ,useEffect,useState} from "react";
import { reactLocalStorage } from "reactjs-localstorage";
import Excelexport from "fusioncharts/fusioncharts.excelexport";

const StackedColumn = ({data, title, subCaption, x_title, y_title, label, value1, filename,price}) => {
// Resolves charts dependancy
charts(FusionCharts,Excelexport);
const bgcolor = { 
  light_color: "#DDEAF7", 
  dark_color: "#1D2E56" }
const datacolor ={
  onLight:"#ffffff",
  onDark:"#030303"
}
const [themeMode, setThemeMode] = useState({
  bg:"",
  datalevel:""
})
const [max,setMax]= useState("");
useEffect(() => {
  data.map((obj)=>{
    setMax(data[0].value);
})
  if (reactLocalStorage.get("theme") == "light") { 
      let modeSet = {bg:`${bgcolor.light_color}`,datalevel:`${datacolor.onDark}`}
      setThemeMode(modeSet) } 
    else { 
      let modeSet = {bg:`${bgcolor.dark_color}`,datalevel:`${datacolor.onLight}`}
      setThemeMode(modeSet)
    }
}, [data,reactLocalStorage.get("theme")])

const value = useContext( Authcontext );
const dataSource = {
  chart: {
    bgColor:`${themeMode.bg}`,  
    divLineColor:`${themeMode.datalevel}`, 
    baseFontColor:`${themeMode.datalevel}`,
    toolTipBgColor:`${themeMode.bg}`,
    subcaptionFontColor:`${themeMode.datalevel}`,
    labelFontColor:`${themeMode.datalevel}`,
    valueFontColor:`${themeMode.datalevel}`,
    xAxisNameFontColor: `${themeMode.datalevel}`,
    yAxisNameFontColor: `${themeMode.datalevel}`,
    caption: `${title}`,
    // "palettecolors":`${value.stack.color}`,
    subcaption: `${subCaption}`,
    // numbersuffix: " TWh",
    xAxisName: `${x_title}`,
    yAxisName: `${y_title}`,
    showsum: "1",
    numvisibleplot: "10",
    plottooltext: `$seriesName <b>₹$dataValue ${price}</b>` ,
    animation: 0,
    placeValuesInside: 0,
    labelFontSize: 10,
    theme: "fusion",
    showpercentvalues: "1",
    labelDisplay: "rotate",
    slantLabels: "1",
    drawcrossline: "1",
    // exportEnabled: "1",
    // exportFormats: 'PDF=Export as PDF | XLSX= Export as XLSX |CSV=Export as CSV',
    exportFileName:`${filename}`
  },
  categories: [
    {
      category: [
        ...data.map((item)=>{
      
         return ({label:item[label]})
        })
       ]
    }
  ],
  dataset: [
    
  ]
};


if(value1 == "SIP" || value1== "LUMPSUM")
{
  let value = value1.toLowerCase();
  const sip =    {
    seriesname: `${value}`,
    data: [
      ...data.map((item)=>{
      
       return ({value:item[value]})
      })
     ]
  }
  if(value1 == "LUMPSUM"){
    dataSource.chart.palettecolors="#29C3BE"
  }
  dataSource.dataset.push(sip);
}
else{
  let sip =    {
    seriesname: `sip`,
    data: [
      ...data.map((item)=>{

       return ({value:item["sip"]})
      })
     ]
  }
  let lumpsum =    {
    seriesname: `lumpsum`,
    data: [
      ...data.map((item)=>{
       
       return ({value:item["lumpsum"]})
      })
     ]
  }
  dataSource.dataset.push(sip);
  dataSource.dataset.push(lumpsum);

}

if(value){
  dataSource.chart.palettecolors=`${value.stack.color}`
}
    return (
      <ReactFusioncharts
        type="scrollstackedcolumn2d"
        width="100%"
        height="400"
        dataFormat="JSON"
        dataSource={dataSource}
      />
    );
}
export default StackedColumn;
