import React from "react";
import FusionCharts from "fusioncharts";
import PowerCharts from "fusioncharts/fusioncharts.powercharts";
import FusionTheme from "fusioncharts/themes/fusioncharts.theme.fusion";
import ReactFC from "react-fusioncharts";
const keyMap = {
  S: "final_state",
  C: "final_city",
  Z: "ZONE",
};

const SunBurst = ({ data, title, drillDown }) => {
  ReactFC.fcRoot(FusionCharts, PowerCharts, FusionTheme);
  //console.log("data = ", data);
  const dataSource = {
    chart: {
      caption: `${title}`,
      // subcaption:
      //   "Click on the segments to Drill-down for region-wise population distribution",
      showplotborder: "1",
      theme: "fusion",
      plottooltext: "<b>$label</b> <br> <b>₹$value</b>",
      // plotBorderColor: "#000000"
    },
    data: data,
    styles: {
      definition: [
        {
          name: "myHTMLFont",
          type: "font",
          ishtml: "1",
        },
      ],
      application: [
        {
          toobject: "TOOLTIP",
          styles: "myHTMLFont",
        },
      ],
    },
  };

  const chartConfigs = {
    type: "sunburst",
    width: "100%",
    height: "100%",
    dataFormat: "json",
    dataSource: dataSource,
    // dataEmptyMessageFontSize: 20
    events: {
      dataplotClick: function(evt, args) {
        //chartClick name is hardcoded from backend
        //so do not change it.
        console.log("click", evt.data.nodeId);
        const selected = evt.data.nodeId;
        if (selected === "INDIA") {
          console.log("I love my India");
        } else {
          const keyName = selected.split("-");
          //This drillDown is causing re-renders -- bug
          // drillDown(`${keyName[0]}$$${keyMap[keyName[1]]}`);
        }
        // window.chartClick = function(str) {
        //   console.log("string = ", str);
        //   // drillDown(str);
        // };
      },
    },
  };

  return <ReactFC {...chartConfigs} />;
};
export default SunBurst;
