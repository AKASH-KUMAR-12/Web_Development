import React, { useEffect, useState ,  useContext } from "react";
import FusionCharts from "fusioncharts";
import TimeSeries from "fusioncharts/fusioncharts.timeseries";
import ReactFC from "react-fusioncharts";
import { Authcontext } from "../DemoAmc";
import Excelexport from "fusioncharts/fusioncharts.excelexport";
import * as CandyTheme from "fusioncharts/themes/fusioncharts.theme.candy";
import * as FusionTheme from "fusioncharts/themes/fusioncharts.theme.fusion";
import { reactLocalStorage } from "reactjs-localstorage";


const SimpleTimeSeries = ({data, title, y_title, filename}) => {
    ReactFC.fcRoot(FusionCharts, TimeSeries, Excelexport, CandyTheme, FusionTheme);
    const value = useContext(Authcontext);
    const jsonify = res => res.json();
    const dataFetch = data;

    
    let schemaFetch = [{
        "name": "label",
        "type": "date",
        "format": "%Y-%m-%d"
      }, {
        "name": `${y_title}`,
        "type": "number"
      }];

      const obj = {
        type: "timeseries",
        renderAt: "container",
        width: "100%",
        height: "550",
        dataSource: {
            chart: {
              palettecolors:`${value?value.timeSeries.color:""}`,

              // exportEnabled: "1",
              // exportFormats: 'PDF=Export as PDF | XLSX= Export as XLSX |CSV=Export as CSV',
              exportFileName:`${filename}`,
            },
            caption: {
            text: `${title}`
            },
            yaxis: [
                {
                plot: {
                    value: "value",
                    type: "line"
                },
                title: `${y_title}`
                }
            ],
            data: {}
            }
      };
        if (reactLocalStorage.get("theme") == "light"){
          obj.dataSource.chart.theme="fusion"
        }else{
          obj.dataSource.chart.theme="candy"
        }
    const [timeseriesDs,setTimeseriesDs] = useState(obj);

  

  const onFetchData = () => {
    Promise.all([dataFetch, schemaFetch]).then(res => {
      const data = res[0];
      const schema = res[1];
      const fusionTable = new FusionCharts.DataStore().createDataTable(
        data,
        schema
      );
      const timeseriesDs1 = Object.assign({}, timeseriesDs);
      timeseriesDs1.dataSource.data = fusionTable;
    //   this.setState({
    //     timeseriesDs
    //   });
      setTimeseriesDs(timeseriesDs1);
    });
  }


  useEffect(()=>{
    onFetchData();
  },[data]);

    return <ReactFC {...timeseriesDs} />;
}

export default SimpleTimeSeries;
