import FusionCharts from "fusioncharts";
import charts from "fusioncharts/fusioncharts.charts";
import ReactFusioncharts from "react-fusioncharts";
import { Authcontext } from "../DemoAmc";
import { useContext ,useEffect,useState} from "react";
import { reactLocalStorage } from "reactjs-localstorage";
import ReactFC from "react-fusioncharts";
import Excelexport from "fusioncharts/fusioncharts.excelexport";

const GroupedStackedColumn = ({data, title, subCaption, x_title, y_title, label, value1, value2, value3, value4,filename}) => {

// Resolves charts dependancy
charts(FusionCharts,Excelexport);
// ReactFC.fcRoot(Excelexport);
 const bgcolor = { 
  light_color: "#DDEAF7", 
  dark_color: "#1D2E56" }
const datacolor ={
  onLight:"#ffffff",
  onDark:"#030303"
}
const [themeMode, setThemeMode] = useState({
  bg:"",
  datalevel:""
})
const [max,setMax]= useState("");
useEffect(() => {
  data.map((obj)=>{
    setMax(data[0].value);
})
  if (reactLocalStorage.get("theme") == "light") { 
      let modeSet = {bg:`${bgcolor.light_color}`,datalevel:`${datacolor.onDark}`}
      setThemeMode(modeSet) } 
    else { 
      let modeSet = {bg:`${bgcolor.dark_color}`,datalevel:`${datacolor.onLight}`}
      setThemeMode(modeSet)
    }
}, [data,reactLocalStorage.get("theme")])
const value = useContext( Authcontext );

const dataSource = {
  chart: {
    bgColor:`${themeMode.bg}`,  
    divLineColor:`${themeMode.datalevel}`, 
    baseFontColor:`${themeMode.datalevel}`,
    toolTipBgColor:`${themeMode.bg}`,
    subcaptionFontColor:`${themeMode.datalevel}`,
    labelFontColor:`${themeMode.datalevel}`,
    valueFontColor:`${themeMode.datalevel}`,
    xAxisNameFontColor: `${themeMode.datalevel}`,
    yAxisNameFontColor: `${themeMode.datalevel}`,
    caption: `${title}`,
    subcaption: `${subCaption}`,
    xAxisName: `${x_title}`,
    yAxisName: `${y_title}`,
    showsum: "1",
    plottooltext:
      "<b>$seriesName</b> : <b>₹$dataValue Cr</b>",
    theme: "fusion",
    plotGradientColor: "#ffffff",
    labelFontSize: 10,
    labelDisplay: "rotate",
    slantLabel : "1",
    // exportEnabled: "1",
    // exportFormats: 'PDF=Export as PDF | XLSX= Export as XLSX |CSV=Export as CSV',
    exportFileName:`${filename}`
  },
  // categories: [
  //   {
  //       category: [
  //           ...data.map((item)=>{
  //            //  console.log("labels" , {label:item.label})
  //            return ({label:item[label]})
  //           })
  //          ]
  //   }
  // ],
  // dataset: [
  //   {
  //     dataset: [
  //       {
  //           seriesname: `${value1}`,
  //           data: [
  //             ...data.map((item)=>{
  //              //  console.log("labels" , {label:item.label})
  //              return ({value:item[value1]})
  //             })
  //            ]
  //       },
  //     ]
  //   },
  //   {
  //     dataset: [
  //       {
  //           seriesname: `${value2}`,
  //           data: [
  //             ...data.map((item)=>{
  //              //  console.log("labels" , {label:item.label})
  //              return ({value:item[value2]})
  //             })
  //            ]
  //       },
  //     ]
  //   },
  //   {
  //       dataset: [
  //         {
  //             seriesname: `${value3}`,
  //             data: [
  //               ...data.map((item)=>{
  //                //  console.log("labels" , {label:item.label})
  //                return ({value:item[value3]})
  //               })
  //              ]
  //         },
  //       ]
  //     },
  //     {
  //       dataset: [
  //         {
  //             seriesname: `${value4}`,
  //             data: [
  //               ...data.map((item)=>{
  //                //  console.log("labels" , {label:item.label})
  //                return ({value:item[value4]})
  //               })
  //              ]
  //         },
  //       ]
  //     }
  // ]

  "categories": [{
    "category": [{
      "label": "Matalia Stock Broking Private Limited"
    }, {
      "label": "IDBI Bank Ltd"
    }, {
      "label": "MAMTA AGRAWAL"
    }, {
      "label": "Pulipati Ramesh"
    }
    // ,{
    //   "label":"LICHFL Financial Services Ltd"
    // },{
    //   "label":"Sukeshani Subhash Sadawarte"
    // },{
    //   "label":"Subhash Santram Sadawarte"
    // },{
    //   "label":"Ramesh Babu Pusuluri"
    // },{
    //   "label":"S.A. Hazarika"
    // },{
    //   "label":"Axis Bank Ltd"
    // },{
    //   "label":"HDFC Securities"
    // }
  ]
  }],
  "dataset": [{
      "seriesname": "Q1",
      "data": [{
        "value": "1200"
      }, {
        "value": "1500"
      }, {
        "value": "1250"
      }, {
        "value": "1000"
      }]
    }, {
      "seriesname": "Q2",
      "data": [{
          "value": "2540"
        }, {
          "value": "2980"
        }, {
          "value": "2180"
        }, {
          "value": "2680"
        }]
        },
        {
          "seriesname": "Q3",
          "data": [{
            "value": "500"
          }, {
            "value": "450"
          }, {
            "value": "800"
          }, {
            "value": "1150"
          }]
        }, {
          "seriesname": "Q4",
          "data": [{
            "value": "1400"
          }, {
            "value": "1040"
          }, {
            "value": "2080"
          }, {
            "value": "2680"
          }]
        }
      ],

};
if(value){
  dataSource.chart.palettecolors=`${value.doughnut.color}`
}

    return (
      <ReactFusioncharts
        // type="scrollmsstackedcolumn2d"
        type="mscolumn2d"
        width="1250"
        height="400"
        dataFormat="JSON"
        dataSource={dataSource}
      />
    );
}
 export default GroupedStackedColumn;