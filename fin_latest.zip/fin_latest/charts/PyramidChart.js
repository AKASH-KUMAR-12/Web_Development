import React from "react";
import FusionCharts from "fusioncharts";
import FusionTheme from "fusioncharts/themes/fusioncharts.theme.fusion";
import Widgets from "fusioncharts/fusioncharts.widgets";
import ReactFC from "react-fusioncharts";

const PyramidChart = ({data, title}) => { 
// Resolves charts dependancy
ReactFC.fcRoot(FusionCharts, FusionTheme, Widgets);

const dataSource = {
  chart: {
    theme: "fusion",
    caption: `${title}`,
    // subcaption: "Credit Suisse 2017",
    showvalues: "1",
    numbersuffix: " Cr",
    numberprefix: "₹",
    // plottooltext:
    //   "<b>$label</b> <br> <b>$dataValue</b>"
  },
  data: data
};

    const chartConfigs = {
        type: "pyramid",
        width: 1200,
        height: 400,
        dataFormat: "json",
        dataSource: dataSource,
        // dataEmptyMessageFontSize: 20
    };

    return (
        <ReactFC {...chartConfigs} />
    );
};
export default PyramidChart;