import FusionCharts from "fusioncharts";
import charts from "fusioncharts/fusioncharts.charts";
import ReactFusioncharts from "react-fusioncharts";
import ReactFC from "react-fusioncharts";
import { reactLocalStorage } from "reactjs-localstorage";
import { Authcontext } from "../DemoAmc";
import React, { useContext ,useState,useEffect} from "react";
import Excelexport from "fusioncharts/fusioncharts.excelexport";

const StackedBarHorizontal = ({data, title, subCaption, x_title, y_title, label, value1, value2, value3, filename}) => {
  ReactFC.fcRoot(FusionCharts,Excelexport);
  const bgcolor = { 
    light_color: "#DDEAF7", 
    dark_color: "#1D2E56" }
  const datacolor ={
    onLight:"#ffffff",
    onDark:"#030303"
  }
  const [themeMode, setThemeMode] = useState({
    bg:"",
    datalevel:""
  })
  useEffect(() => { 
    if (reactLocalStorage.get("theme") == "light") { 
      let modeSet = {bg:`${bgcolor.light_color}`,datalevel:`${datacolor.onDark}`}
      setThemeMode(modeSet) } 
    else { 
      let modeSet = {bg:`${bgcolor.dark_color}`,datalevel:`${datacolor.onLight}`}
      setThemeMode(modeSet); 
    } }, [data,reactLocalStorage.get("theme")])

  const value = useContext(Authcontext);
// Resolves charts dependancy
const dataSource =  {
  "chart": {
    "theme": "fusion",
    bgColor:`${themeMode.bg}`,  
    divLineColor:`${themeMode.datalevel}`, 
    baseFontColor:`${themeMode.datalevel}`,
    toolTipBgColor:`${themeMode.bg}`,
    subcaptionFontColor:`${themeMode.datalevel}`,
    labelFontColor:`${themeMode.datalevel}`,
    valueFontColor:`${themeMode.datalevel}`,
    xAxisNameFontColor: `${themeMode.datalevel}`,
    yAxisNameFontColor: `${themeMode.datalevel}`,
    caption: `${title}`,
    "caption":`${title}`,
    "subCaption":`${subCaption}`,
    "xAxisname": `${x_title}`,
    "yAxisName": `${y_title}`,
    // exportEnabled:"1",
    // exportFormats: 'PDF=Export as PDF | XLSX= Export as XLSX |CSV=Export as CSV',
    exportFileName:`${filename}`
  },
  "categories": [{
    "category": [{
        "label": "Q1"
      },
      {
        "label": "Q2"
      },
      {
        "label": "Q3"
      },
      {
        "label": "Q4"
      }
    ]
  }],
  "dataset": [{
      "seriesname": "Food Products",
      "data": [{
          "value": "1000"
        },
        {
          "value": "5000"
        },
        {
          "value": "3500"
        },
        {
          "value": "5000"
        }
      ]
    },
    {
      "seriesname": "Non-Food Products",
      "data": [{
          "value": "1400"
        },
        {
          "value": "4800"
        },
        {
          "value": "8300"
        },
        {
          "value": "1800"
        }
      ]
    }
  ]
};

    return (
      <ReactFusioncharts
        type="stackedbar2d"
        width="100%"
        height="400"
        dataFormat="JSON"
        dataSource={dataSource}
      />
    );
}

export default StackedBarHorizontal;