// Include react
import React from "react";
import FusionCharts from "fusioncharts";
import charts from "fusioncharts/fusioncharts.charts";
import ReactFusioncharts from "react-fusioncharts";
import ReactFC from "react-fusioncharts";
import Excelexport from "fusioncharts/fusioncharts.excelexport";


// class MyComponent extends React.Component {
//   render() {
const PieChart_3D = ({data,title,filename}) => {

    // Resolves charts dependancy
    charts(FusionCharts,Excelexport);
    // ReactFC.fcRoot(Excelexport);

    const dataSource = {
    chart: {
        
        plottooltext: "$label <br> ₹ <b>$value</b> Cr",
        showlegend: "0",
        caption: `${title}`,
        captionFontColor: "#000000",
        showpercentvalues: "1",
        usedataplotcolorforlabels: "1",
        theme: "fusion",
        animation:"1",
        animationDuration:"5",
        showHoverEffect:"1",
        plotHoverEffect:"1",
        // plotFillHoverColor:"#77e307",
        // plotFillHoverAlpha:"500",
        // plotBorderHoverColor:"#9032a8",
        // alphaAnimation: "10",
        // showShadow:"1",
        // use3DLighting:"1",
        // baseFont:"1",
        baseFontSize:"19",
        pieRadius:"200",
        // baseFontColor:"#9032a8",
        showToolTip:"1",
        // exportEnabled: "1",
        // exportFormats: 'PDF=Export as PDF | XLSX= Export as XLSX |CSV=Export as CSV',
        exportFileName:`${filename}`
        // toolTipBgColor:"#f2fc45",
        // palette: "5",
        // "paletteColors": "#f5121f, #34ebc0, #280af7, #f2fc45, #b43a3c, #9032a8, #000, #77e307, #8442e7, #11d8f2"
        // plotBorderHoverThickness: "30"
    },
    data
    };
    return (
      <ReactFusioncharts
        type="pie3D"
        width="1200"
        height="390"
        dataFormat="JSON"
        dataSource={dataSource}
        
      />
    );
}

export default PieChart_3D;
