import React, { useContext ,useState,useEffect} from "react";
import FusionCharts from "fusioncharts";
import ReactFC from "react-fusioncharts";
import { Authcontext } from "../DemoAmc";
import Excelexport from "fusioncharts/fusioncharts.excelexport";
import { reactLocalStorage } from "reactjs-localstorage";

const Donut3DChart = ({ data, title, drillDown, subCaption, price, width, filename }) => {
  // Resolves charts dependancy
  ReactFC.fcRoot(FusionCharts,Excelexport);
  const bgcolor = { 
    // light_color: "#FFF5DC,#FFFFFF", 
    light_color: "#DDEAF7",
    dark_color: "#1D2E56" }
  const datacolor ={
    onLight:"#ffffff",
    onDark:"#030303"
  }
  const [themeMode, setThemeMode] = useState({
    bg:"",
    datalevel:""
  })
  useEffect(() => { 
    if (reactLocalStorage.get("theme") == "light") { 
      let modeSet = {bg:`${bgcolor.light_color}`,datalevel:`${datacolor.onDark}`}
      setThemeMode(modeSet) } 
    else { 
      let modeSet = {bg:`${bgcolor.dark_color}`,datalevel:`${datacolor.onLight}`}
      setThemeMode(modeSet); 
    } }, [reactLocalStorage.get("theme")])

  const value = useContext(Authcontext);
  const dataSource = {
    chart: {
      caption: `${title}`,
      subCaption: `${subCaption}`,
      bgColor: `${themeMode.bg}`,
      labelFontColor:`${themeMode.datalevel}`,
      captionFontColor:`${themeMode.datalevel}`,
      baseFontColor:`${themeMode.datalevel}`,
      toolTipBgColor:`${themeMode.bg}`,
      showpercentvalues: "1",
      aligncaptionwithcanvas: "0",
      captionpadding: "0",
      decimals: "1",
      plottooltext: ` <b>$label</b> <br/><b>₹$value ${price}</b> `,
      theme: "fusion",
      showToolTip: "1",
      showLegend: "0",
      // exportEnabled: "1",
      showToolTipShadow: "1",
      doughnutRadius: "60%",
      // exportFormats: 'PDF=Export as PDF | XLSX= Export as XLSX |CSV=Export as CSV',
      exportFileName:`${filename}`,
      // canvasBgAlpha:"0.3",
      // // containerBackgroundOpacity : '50',
      // bgAlpha: "70",
    },
    data: data,
  };

  const chartConfig = {
    type: "doughnut3d",
    width: `${width}`,
    height: "400",
    dataFormat: "JSON",
    dataSource: dataSource,
    events: {
      dataplotClick: function (evt, args) {
        //chartClick name is hardcoded from backend
        //so do not change it.
        //console.log("click", evt);
        window.chartClick = function (str) {
          drillDown(str);
        };
      },
    },
  };
  if (value) {
    dataSource.chart.palettecolors = `${value.doughnut.color}`;
  }
  return <ReactFC {...chartConfig} />;
};

export default Donut3DChart;
