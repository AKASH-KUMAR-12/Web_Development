import React from "react";
import ReactDOM from "react-dom";
import FusionCharts from "fusioncharts";
import charts from "fusioncharts/fusioncharts.charts";
import ReactFusioncharts from "react-fusioncharts";
import ReactFC from "react-fusioncharts";
import Excelexport from "fusioncharts/fusioncharts.excelexport";

const Vertical3DBarChart = ({data,x_title,y_title, filename}) => {


// Resolves charts dependancy
charts(FusionCharts);
ReactFC.fcRoot(Excelexport);

const dataSource = {
    chart: {
        caption: "Revenue By Asset Class",
        captionFontColor: "#000000",
        // subcaption: "For the year 2017",
        yaxisname: `${y_title}`,
        xaxisname: `${x_title}`,
        decimals: "1",
        theme: "fusion",
        plottooltext: "$label <br> ₹ <b>$value</b> Cr",
        // exportEnabled: "1",
        labelFontSize: "12px",
        // labelBorderPadding: "100px",
        xAxisNameFontSize: "20px",
        yAxisNameFontSize: "20px",
        xAxisNameFontBold:"0",
        yAxisNameFontBold:"1",
        xAxisNameFontColor:"#000000",
        yAxisNameFontColor:"#000000",
        // exportEnabled: "1",
        // exportFormats: 'PDF=Export as PDF | XLSX= Export as XLSX |CSV=Export as CSV',
        exportFileName:`${filename}`
    },
    data: data
    };

    return (
      <ReactFusioncharts
        type="column3d"
        width="1200"
        height="400"
        dataFormat="JSON"
        dataSource={dataSource}
      />
    );
}

export default Vertical3DBarChart;
