import React, {useEffect, useState} from 'react';
import FusionCharts from 'fusioncharts';
import Maps from 'fusioncharts/fusioncharts.maps';
import World from 'fusioncharts/maps/fusioncharts.world';
import India from 'fusioncharts/maps/fusioncharts.india';
import ReactFC from 'react-fusioncharts';
import FusionTheme from 'fusioncharts/themes/fusioncharts.theme.fusion';
import { reactLocalStorage } from 'reactjs-localstorage';
import Excelexport from 'fusioncharts/fusioncharts.excelexport';


const IndiaMap = ({data, title, drillDown,price,filename}) => {
    ReactFC.fcRoot(FusionCharts, Maps, World, India, FusionTheme,Excelexport);
    const bgcolor = { 
        light_color: "#DDEAF7", 
        dark_color: "#1D2E56" }
      const datacolor ={
        onLight:"#ffffff",
        onDark:"#030303"
      }
      const [themeMode, setThemeMode] = useState({
        bg:"",
        datalevel:""
      })
    const [max,setMax]= useState("");
    useEffect(() => {
            data.map((obj)=>{
                setMax(data[0].value);
            })
            if (reactLocalStorage.get("theme") == "light") { 
                let modeSet = {bg:`${bgcolor.light_color}`,datalevel:`${datacolor.onDark}`}
                setThemeMode(modeSet) } 
              else { 
                let modeSet = {bg:`${bgcolor.dark_color}`,datalevel:`${datacolor.onLight}`}
                setThemeMode(modeSet)
              }
    }, [data,reactLocalStorage.get("theme")])

    for(let i=0;i<data.length; i++){
        if(data[i].id =='ANDAMAN AND NICOBAR ISLANDS'){
            data[i].id = '001';
        }
        if(data[i].id =='ANDHRA PRADESH'){
            data[i].id = '002';
        }
        if(data[i].id =='ARUNACHAL PRADESH'){
            data[i].id = '003';
        }
        if(data[i].id =='ASSAM'){
            data[i].id = '004';
        }
        if(data[i].id =='BIHAR'){
            data[i].id = '005';
        }
        if(data[i].id =='CHANDIGARH'){
            data[i].id = '006';
        }
        if(data[i].id =='CHHATTISGARH'){
            data[i].id = '007';
        } 
        if(data[i].id =='DADRA AND NAGAR HAVELI'){
            data[i].id = '008';
        }
        if(data[i].id =='DAMAN AND DIU'){
            data[i].id = '009';
        }
        if(data[i].id =='NEW DELHI'){
            data[i].id = '010';
        }
        if(data[i].id =='GOA'){
            data[i].id = '011';
        }
        if(data[i].id =='GUJARAT'){
            data[i].id = '012';
        }
        if(data[i].id =='HARYANA'){
            data[i].id = '013';
        }
        if(data[i].id =='HIMACHAL PRADESH'){
            data[i].id = '014';
        }
        if(data[i].id =='LADAKH'){
            data[i].id = '015';
        }
        if(data[i].id =='JHARKHAND'){
            data[i].id = '016';
        }
        if(data[i].id =='KARNATAKA'){
            data[i].id = '017';
        }
        if(data[i].id =='KERALA'){
            data[i].id = '018';
        }
        if(data[i].id =='LAKSHADWEEP'){
            data[i].id = '019';
        }
        if(data[i].id =='MADHYA PRADESH'){
            data[i].id = '020';
        }
        if(data[i].id =='MAHARASHTRA'){
            data[i].id = '021';
        }
        if(data[i].id =='MANIPUR'){
            data[i].id = '022';
        }
        if(data[i].id =='MEGHALAYA'){
            data[i].id = '023';
        }
        if(data[i].id =='MIZORAM'){
            data[i].id = '024';
        }
        if(data[i].id =='NAGALAND'){
            data[i].id = '025';
        }
        if(data[i].id =='ORISSA'){
            data[i].id = '026';
        }
        if(data[i].id =='PONDICHERRY'){
            data[i].id = '027';
        }
        if(data[i].id =='PUNJAB'){
            data[i].id = '028';
        }
        if(data[i].id =='RAJASTHAN'){
            data[i].id = '029';
        }
        if(data[i].id =='SIKKIM'){
            data[i].id = '030';
        }
        if(data[i].id =='TAMIL NADU'){
            data[i].id = '031';
        }
        if(data[i].id =='TRIPURA'){
            data[i].id = '032';
        }
        if(data[i].id =='UTTAR PRADESH'){
            data[i].id = '033';
        }
        if(data[i].id =='UTTARAKHAND'){
            data[i].id = '034';
        }
        if(data[i].id =='WEST BENGAL'){
            data[i].id = '035';
        }
        if(data[i].id =='TELANGANA'){
            data[i].id = '036';
        }
        if(data[i].id =='JAMMU AND KASHMIR'){
            data[i].id = '037';
        }
      }


      
     

    const chartConfigs = {
    type: 'maps/india',
    width: "100%",
    height: "400",
    dataFormat: 'JSON',
    dataSource: {
        "chart": {
            "caption": `${title}`,

            "showLabels": "1",

            bgColor:`${themeMode.bg}`,  
            baseFontColor:`${themeMode.datalevel}`,
            toolTipBgColor:`${themeMode.bg}`,
            captionFontColor:`${themeMode.datalevel}`,
        
            "entityFillHoverColor": "#666666",

            "plottooltext": ` <b>$label</b> <br/><b>$value ${price} </b> `,              
            "theme": "fusion",
            // exportEnabled: "1",
            // exportFormats: 'PDF=Export as PDF | XLSX= Export as XLSX |CSV=Export as CSV',
            exportFileName:`${filename}`
        },
        "colorrange": {
            "minvalue": "0",
            "code": "#FFE0B2",
            "gradient": "1",
            "color": [
                {
                    "minvalue": "0",
                    "maxvalue": `${(max/6)*1}`,
                    "color": "#004380"
                },
                {
                    "minvalue": `${(max/6)*1}`,
                    "maxvalue": `${(max/6)*2}`,
                    "color": "#0086FF"
                },
                {
                    "minvalue": `${(max/6)*2}`,
                    "maxvalue": `${(max/6)*3}`,
                    "color": "#7FC2FF"
                },
                {
                    "minvalue": `${(max/6)*3}`,
                    "maxvalue": `${(max/6)*4}`,
                    "color": "#FFD700"
                },
                {
                    "minvalue": `${(max/6)*4}`,
                    "maxvalue": `${(max/6)*5}`,
                    "color": "#FFBA00"
                },
                {
                    "minvalue": `${(max/6)*5}`,
                    "maxvalue": `${max}`,
                    "color": "#FFD700"
                }
            ]
        },
        // "data": [
        //     {
        //         "id": "001",
        //         // "label": "Rajasthan",
        //         "value": ".82",
        //         "showLabel": "1"
        //     },
        //     {
        //         "id": "002",
        //         // "label": "Uttar Pradesh",
        //         "value": "2.04",
        //         "showLabel": "1"
        //     },
        //     {
        //         "id": "003",
        //         // "label": "Madhya Pradesh",
        //         "value": "1.78",
        //         "showLabel": "1"
        //     },
        //     {
        //         "id": "037",
        //         // "label": "Assam",
        //         "value": ".40",
        //         "showLabel": "1"
        //     },
        //     {
        //         "id": "021",
        //         // "label": "Maharashtra",
        //         "value": "2.58",
        //         "showLabel": "1"
        //     },
        //     {
        //         "id": "030",
        //         // "label": "Gujarat",
        //         "value": "1.30",
        //         "showLabel": "1"
        //     }
        // ]
        "data": data
    },
    events: {
        dataplotClick: function(evt, args) {
          //chartClick name is hardcoded from backend
          //so do not change it.
          //console.log("click", evt);
          window.chartClick = function(str) {
            // console.log("string = ", str);
            drillDown(str);
          };
        },
      },
    };

    return (
        <ReactFC {...chartConfigs} />
    );

}

export default IndiaMap;
