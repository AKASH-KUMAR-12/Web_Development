import FusionCharts from "fusioncharts";
import charts from "fusioncharts/fusioncharts.charts";
import ReactFusioncharts from "react-fusioncharts";
import React from "react";
import ReactDOM from "react-dom";
import FusionTheme from "fusioncharts/themes/fusioncharts.theme.fusion";
// ReactFC.fcRoot(FusionCharts,  FusionTheme);

// Resolves charts dependancy
charts(FusionCharts);

const dataSource = {
  chart: {
   
    bgColor: "#FFFFFF",
    chartRightPadding:"0px",
    pieRadius:100,
    chartTopMargin:100,
    // labelFontColor:"red",
    // captionFontColor:`${themeMode.datalevel}`,
    // baseFontColor:`${themeMode.datalevel}`,
    // toolTipBgColor:`${themeMode.bg}`,
    // subcaption: "For all users in 2017",
    // showpercentvalues: "1",
    // defaultcenterlabel: "Android Distribution",
    // aligncaptionwithcanvas: "0",
    // captionpadding: "0",
    // decimals: "1",
    plottooltext:
      "<b>$percentValue</b> of our Android users are on <b>$label</b>",
    centerlabel: "# Users: $value",
    theme: "fusion",
    doughnutRadius: "70%",
    showBorder:false,
    showLegend: "2",
    legendPosition:" bottom-right",
    legendNumRows:"3",
    legendBorderThickness:0,
    legendShadow:0,
    palette:3,
    paletteColors:"#C65tFg"
    
    },
  data: [
    {
      label: "Jelly",
      value: "5300"
    },
    {
      label: "Kitkat",
      value: "10500"
    },
  ]
};

class Donut extends React.Component {
  render() {
    return (      
        <div style={{width:"60%",height:"180px",}} >
      <ReactFusioncharts
        type="doughnut2d"
        width="165%"
        height="47%"
        dataFormat="JSON"       
        dataSource={dataSource}
      />
      </div>
    );
  }
}
export default Donut;