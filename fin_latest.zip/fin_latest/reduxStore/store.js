import { configureStore } from "@reduxjs/toolkit";
import { sipBookSlice } from "./reducer";
import { ApiResponseSlice } from "./ApiResponceReducer";

const store = configureStore({
    reducer:{
        currentCycle: sipBookSlice.reducer,
        CurrentApiData: ApiResponseSlice.reducer
    }
})

export default store;