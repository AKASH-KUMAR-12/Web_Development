import { createSlice } from "@reduxjs/toolkit";

export const ApiResponseSlice = createSlice({
    name: "cycle",
    initialState: {
        ApiResponse:[]
    },
    reducers: {   

        setSIPResponse: (state, action) => {
                return {
                    ...state,
                    ApiResponse:action.payload.ApiResponse
            }
        }
      
        },
  
    },
  );
  
  export const {setSIPResponse} = ApiResponseSlice.actions;
  