import React from "react";
import { Card, CardContent, Container, Grid, Typography } from "@mui/material";

// import Navbar from "./components/navbar";
// import HeroContent from "./components/herocontent";
import Login from "../auth/Login";
// import TopBrands from "./components/topbrand";
// import QuestFeature from "./components/questfeature";
// import DropDown from "./components/dropdown";
// import Footer from "./components/footer";
// import QuestWebScreenshot from "./components/questwebscreenshot"
// import "./styles/Index.css";
import "./style/Login.css"
const HomePage = ({setIsLoggedIn}) => {
    return (
        <>
            {/* <Navbar /> */}
            <section className="hero">
                <Container fixed>
                    <Grid container spacing={3} >
                        {/* <Grid item xs={12} sm={12} md={6} lg={} >
                            <HeroContent />
                        </Grid> */}
                        <Grid item xs={12} sm={12} md={12} lg={6}>
                            <Login
                            //  setIsLoggedIn={setIsLoggedIn}
                              />
                        </Grid>
                    </Grid>
                </Container>
            </section>
        </>
    );
};

export default HomePage;