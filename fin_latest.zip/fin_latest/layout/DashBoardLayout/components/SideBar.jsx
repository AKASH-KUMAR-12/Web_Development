import { Box } from "@mui/material";
import React, { useState } from "react";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import ListItemButton from "@mui/material/ListItemButton";
import ListItemText from "@mui/material/ListItemText";
import AmcAtGlance from "../../../images/AmcAtGlance.png";
import AUM from "../../../images/AUM.png";
import SIPBook from "../../../images/SIPBook.png";
import { NavLink, useNavigate } from "react-router-dom";

const data = [
  {
    path: "AMCAtGlance",
    name: "AMC At Glance",
    img: AmcAtGlance,
  },
  {
    path: "AUM",
    name: "AUM",
    img: AUM,
  },
  {
    path: "sip",
    name: "SIP Book",
    img: SIPBook,
  },
  {
    path: "Flow",
    name: "Flow",
    img: SIPBook,
  },
];

export const SideBar = ({ children, props }) => {
  const navigate = useNavigate();
  const [openNav, setOpenNav] = useState(false);
  const handelNavBar = () => {
    setOpenNav(true);
  };
  return !props ? (
    <Box
      bgcolor="white"
      flex={1.5}
      p={2}
      boxShadow="0px 2px 8px 0px #00000033"
      // height="85vh"
      sx={{ display: { md: "block", xs: "none" }, fontWeight: "bold", height: { md: "86.5vh", xs: "100vh" } }}
    >
      <List
        sx={{ "& .css-1nxmd3h-MuiListItem-root": { marginBottom: "17px" } }}
      >
        {data.map((value, index) => (
          <ListItem
            key={value.name}
            component={NavLink}
            to={value.path}
            disablePadding
            onClick={() => {
              navigate(value.key);
            }}
          >
            <ListItemButton onClick={handelNavBar}>
              <img src={value.img} alt="img" />
              <ListItemText
                secondary={value.name}
                sx={{
                  "& .css-83ijpv-MuiTypography-root": {
                    fontWeight: "bold",
                    marginLeft: "16px",
                    fontSize: "14px",
                  },
                }}
              />
            </ListItemButton>
          </ListItem>
        ))}
      </List>
      {children}
    </Box>
  ) : (
    <Box
      bgcolor="white"
      flex={0.5}
      p={2}
      boxShadow="0px 2px 8px 0px #00000033"
      height="100vh"
      position="fixed"
      sx={{
        zIndex: 4,
        ...(openNav && { display: "none" }),
      }}
    >
      <List sx={{ fontSize: "500px" }}>
        {data.map((value, index) => (
          <ListItem
            key={value.name}
            component={NavLink}
            to={value.path}
            disablePadding
          >
            <ListItemButton onClick={handelNavBar}>
              {/* <ListItemIcon > */}
              <img src={value.img} alt="img" />
              {/* </ListItemIcon> */}
              <ListItemText
                secondary={value.name}
                sx={{
                  "& .css-83ijpv-MuiTypography-root": {
                    fontWeight: "bold",
                    marginLeft: "16px",
                    fontSize: "14px",
                  },
                }}
              />
            </ListItemButton>
          </ListItem>
        ))}
      </List>
    </Box>
  );
};
