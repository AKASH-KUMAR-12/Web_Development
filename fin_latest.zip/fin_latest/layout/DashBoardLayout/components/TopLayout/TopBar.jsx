import styled from "@emotion/styled";
import { AppBar, Box, Toolbar, Typography } from "@mui/material";
import React, { useState } from "react";
import logo from "../../../../images/finstaxLogo.svg";
import topBarFilterImg from "../../../../images/topBarFilterIcon.png";
import FilterList from "./FilterList";
import MenuIcon from "@mui/icons-material/Menu";
import { SideBar } from "../SideBar";


const StyledToolBar = styled(Toolbar)({
  display: "flex",
  justifyContent: "space-between",
  backgroundColor: "white",
  color: "blue",
  Shadows: "none",
  "@media (max-width: 600px)": {
    justifyContent: "space-evenly",
  },
});

const TopBar = () => {
  const [openselectBox, setOpenselectBox] = useState(false);
  const [openSideBar, setOpenSideBar] = useState(false);

  const onClickSideBar = () => {
    setOpenSideBar(!openSideBar);
  };

  return (
    <>
      <AppBar className="appbar" position="sticky" style={{ boxShadow: "0px 0px 5px 0px #00000033" }} sx={{ xs: { width: "2000px" } }}>
        <StyledToolBar>
          <Typography>
            {/* <NavLink to={'/app'}> */}
            <img src={logo} alt={"FINSTAX"} style={{ height: "46px" }} />
            {/* </NavLink> */}
          </Typography>
          <Typography m={"5px"}>
            {/* <Button variant="text"> */}
            <img
              src={topBarFilterImg}
              alt="FilterBtn"
              style={{ height: "46px" }}
              onClick={() => {
                setOpenselectBox(!openselectBox);
              }}
            />
            {/* </Button> */}
          </Typography>
          <Typography sx={{ display: { xs: "block", md: "none" } }}>
            <MenuIcon onClick={onClickSideBar} />
          </Typography>
        </StyledToolBar>
      </AppBar>
      {/* open filter menu  */}
      {openselectBox && (
        <Box
          sx={{
            zIndex: 4,
            bgcolor: "background.paper",
            width: { xl: "17%" },
            position: "absolute",
            right: "13px",
          }}
        >
          {/* //InvestorCatagory */}
          <FilterList />
        </Box>
      )}
      {/* SideBar logic  */}
      {openSideBar && (
        <Box>
          <SideBar props={1} />
        </Box>
      )}
    </>
  );
};

export default TopBar;
