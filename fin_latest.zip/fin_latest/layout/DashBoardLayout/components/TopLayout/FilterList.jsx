import React, { useState } from 'react'
import {List, ListItem, ListItemButton, ListItemIcon, ListItemText,Collapse} from '@mui/material'
import Checkbox from '@mui/material/Checkbox';

const dataLists = [
    {
      name: "InvestorCatagory",
      nestedLists: ["HNI", "Retail", "FPI", "Bank", "Non-Retail"]
    },
    {
      name: "DistributorCode",
      nestedLists: ['ARN-123', 'ARN-124', 'ARN-125']
    },
    {
      name: "DistributorCode",
      nestedLists: ['ARN-123', 'ARN-124', 'ARN-125']
    }
  ]

const FilterList = () => {
  const [checked, setChecked] = useState([0]);
  const [openInvestorCatagory, setOpenInvestorCatagory] = useState(false)
  // const [region,setRegion] = useState('');
// const [state,setState] = useState('');
// const [cities,setCities] = useState('');
  const handleClick = () => {
    setOpenInvestorCatagory(!openInvestorCatagory);
  };
    const handleToggle = (key) => () => {
        const currentIndex = checked.indexOf(key);
        const newChecked = [...checked];
    
        if (currentIndex === -1) {
          newChecked.push(key);
        } else {
          newChecked.splice(currentIndex, 1);
        }
    
        setChecked(newChecked);
      };
  return (
 <>
  {dataLists.map((i) => {
            return (
              <>
                <List sx={{padding:0}}>
                  <ListItem divider >
                    <ListItemButton onClick={handleClick}>
                      {/* <ListItemIcon>{">"}</ListItemIcon> */}
                      <ListItemText primary={i.name} />
                    </ListItemButton>
                  </ListItem>

                </List>
                <Collapse in={openInvestorCatagory}>
                  <List >
                    {i.nestedLists.map((key, i) => {
                      const labelId = `checkbox-list-label-${key}`;
                      return (<ListItem divider >
                        <ListItemButton onClick={handleToggle(key)} sx={{padding:0, marginLeft:'35px'}}>
                          <ListItemIcon>
                            <Checkbox
                              edge="start"
                              checked={checked.indexOf(key) !== -1}
                              tabIndex={-1}
                              disableRipple
                              inputProps={{ 'aria-labelledby': labelId }}
                            />
                          </ListItemIcon>
                          <ListItemText id={labelId} primary={`${key}`} key={key} />
                        </ListItemButton>
                      </ListItem>)

                    })}
                  </List>
                </Collapse>

              </>
            )
          })}

 </>
  )
}

export default FilterList