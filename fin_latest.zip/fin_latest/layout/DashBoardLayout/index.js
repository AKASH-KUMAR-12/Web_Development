import React from "react";
import TopBar from "./components/TopLayout/TopBar";
import { Grid } from "@mui/material";
import { SideBar } from "./components/SideBar";
import { Outlet } from "react-router-dom";
import footerLogo from "../../images/footerLogo.svg"

const DashBoardLayout = () => {
  return (
    <>
      <TopBar />
      <Grid container sx={{ height: 'fit-content', width: "100%" }} spacing={0}>
        <Grid item lg={2} md={2} sm={0}>
          <SideBar />
        </Grid>
        <Grid item lg={10} md={10} sm={12}>
          <Outlet />
        </Grid>
        {/* <Grid item lg={10} md={10} sm={9}>
          <div sx={{ width: '100%' , }}>
                <div spacing={2} sx={{ "& .css-1ik6aa3-MuiPaper-root": { boxShadow: "none" }, marginLeft: "-1.3%", "& .css-1955l30-MuiPaper-root": { backgroundColor: "blue", boxShadow: 3 } }}>
                    <div sx={{ height: "5rem" }}>
                        <h2>KFinTech</h2>
                    </div>
                </div>
            </div>
          </Grid> */}
      </Grid>
      <div style={{ height: "3.5%", width: "100vw", backgroundColor: " #2057A6", textAlign: "center" }}>
        <p style={{ display: "inline", color: "#FAFAFA", marginRight: "0.5%" }}>Powered By</p>
        <img src={footerLogo} alt={"KFintech"} style={{ marginTop: "0.5%", width: "9%" }} />
      </div>
    </>
  );
};

export default DashBoardLayout;
