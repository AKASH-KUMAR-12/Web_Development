import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import FusionCharts from "fusioncharts";
import { BrowserRouter } from "react-router-dom";
import "./index.css";

const config = require("../src/config/Key");
FusionCharts.options.license({
  key: config().license,
  creditLabel: false,
});


const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <BrowserRouter>
      <App />
    </BrowserRouter>
  </React.StrictMode>
);
