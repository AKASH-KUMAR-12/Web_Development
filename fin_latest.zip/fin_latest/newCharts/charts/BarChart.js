import FusionCharts from "fusioncharts";
import charts from "fusioncharts/fusioncharts.charts";
import ReactFusioncharts from "react-fusioncharts";
import React from "react";

// Resolves charts dependancy


const BarChart =(data)=> {
  charts(FusionCharts);
const dataSource = {
    
        chart: {
            // "caption": "Top 5 Stores by Sales",
            // "subCaption": "Last month",
            // "yAxisName": "Sales (In USD)",
            "numberPrefix": "$",
            "theme": "fusion",
            xAxisName: "Broker Categoery",           //Set the x-axis name
            yAxisName: "Sip Count",
            paletteColors:"#2057A6",
            bgcolor:"#FFFFFF",
            color:"#FFFFFF",
            patterBgColor:"#FFFFFF",
            theme: 'fusion',
            barCategoryGap:1,
            labelFontSize : 15,
            labelFontSize : 15,
            pallete: 5,
            divLineColor: "#00080a",
            animation: 0,
            drawCrossLine: 1,
          crossLineAnimation: 0,
          labelFontSize: "9.5px",
          plottooltext: "<b>$label</b> <b>₹$value Cr</b>",
          divLineColor: "#00080a",
          chartTopMargin:50,
          showBorder:false,
          palettecolors: "5d62b5,29c3be" 

        },  
        "data": data.data
    }

    return (
      <ReactFusioncharts
        type="bar2d"
        width="98%"
        height="250"
        dataFormat="JSON"
        dataSource={dataSource}
      />
    );
  }

export default BarChart