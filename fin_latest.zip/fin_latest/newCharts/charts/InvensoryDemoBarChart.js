import React from "react";
import ReactDOM from "react-dom";
import ReactFC from "react-fusioncharts";
import FusionCharts from "fusioncharts";
import Column2D from "fusioncharts/fusioncharts.charts";
import FusionTheme from "fusioncharts/themes/fusioncharts.theme.fusion";
ReactFC.fcRoot(FusionCharts, Column2D, FusionTheme);
const chartData = [
    {
        label: "Venezuela",
        value: "290",
    },
    {
        label: "Saudi",
        value: "260",
    },
    {
        label: "Canada",
        value: "180",
    },
    {
        label: "Iran",
        value: "140",
    },
    {
        label: "Russia",
        value: "115",
    },
    {
        label: "UAE",
        value: "100",
    },
    {
        label: "India",
        value: "310",
    }

];


const chartConfigs = {
    type: "column2d", // The chart type
    width: "100%", // Width of the chart
    height: "311", // Height of the chart
    dataFormat: "json", // Data type

    dataSource: {
        // Chart Configuration
        chart: {
            //Set the chart caption
            // caption: "Countries With Most Oil Reserves [2017-18]",
            //Set the chart subcaption
            // subCaption: "In MMbbl = One Million barrels",
            //Set the x-axis name
            xAxisName: "SIP Age in Years",
            //Set the y-axis name
            yAxisName: "SIP count",
            numberSuffix: "K",
            //Set the theme for your chart
            theme: "fusion",
        },
        // Chart Data
        data: chartData,
    },
};

// STEP 4 - Creating the DOM element to pass the react-fusioncharts component
class InvensoryDemoBarChart extends React.Component {
    render() {
        return (
            <>
                <div style={{ display: "flex", margin:"1% 1% 0% 1%" }}>
                    <div style={{ width: "100%", height: "390px", boxShadow:"rgba(0, 0, 0, 0.35) 0px 5px 15px",borderRadius:"20px" }}>
                        <div style={{borderBottom: "1px solid black"}} >
                            <h3 style={{ width: "79", height: "19px", marginLeft: "19px", marginBottom: "10px", marginTop: "15px",fontFamily: "poppins",fontSize: 22 }}>Inventory Demography</h3>
                        </div >
                        <div  style={{paddingTop:"50px"}}>
                            <ReactFC {...chartConfigs} />
                        </div>
                    </div>
                </div>
            </>
        );
    }
}

export default InvensoryDemoBarChart;