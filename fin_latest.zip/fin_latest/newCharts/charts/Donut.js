
import React from 'react'
import FusionCharts from "fusioncharts";
import charts from "fusioncharts/fusioncharts.charts";
import ReactFusioncharts from "react-fusioncharts";
charts(FusionCharts);


let finalArray = [];
const Donut=(data)=> {
  console.log("Dount Data,,,,,",data.data)

 const dataSource = {
  chart: {
    theme: "candy",
    chartTopMargin:50,
    use3DLighting:false,
    showShadow: false,
    doughnutRadius:75,
    pieRadius:100,
    bgcolor:"#ffffff",
    "showborder": "0",
    palettecolors: "5d62b5,29c3be",
    // showLegend:1,
    legendNumRows:6,
    legendPosition:" bottom-right",
    },
  data: data.data
};
return (
  <>
  <div>
  <ReactFusioncharts
    type="doughnut2d"
    width="32%"
    height="50%"
    dataFormat="JSON"
    dataSource={dataSource}
  /></div>
  </>
)
  }

export default Donut;