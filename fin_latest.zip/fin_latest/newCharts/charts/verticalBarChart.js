// import React, { useEffect, useState } from "react";
// import ReactDOM from "react-dom";
import ReactFC from "react-fusioncharts";
// import FusionCharts from "fusioncharts";
import Column2D from "fusioncharts/fusioncharts.charts";
import FusionTheme from "fusioncharts/themes/fusioncharts.theme.fusion";
// import { useSelector } from "react-redux";

import FusionCharts from "fusioncharts";
import charts from "fusioncharts/fusioncharts.charts";
import ReactFusioncharts from "react-fusioncharts";

ReactFC.fcRoot(FusionCharts, Column2D, FusionTheme);

const VerticalBarChart = ({ data, xAxisName, yAxisName, theme ,width }) => {
  const chartConfigs = {
    type: "column2d", // The chart type
    width: width, // Width of the chart
    height: "300", // Height of the chart
    dataFormat: "json", // Data type
    dataSource: {
      // Chart Configuration
      chart: {
      showXAxisLine: "1",
      palettecolors: "5d62b5,29c3be",


            showYAxisLine: "1",

            xaxisname:xAxisName,

            yaxisname: yAxisName,

            // "numberPrefix": "₹",

            labelFontSize: "10",

            yAxisValueFontSize: "10",

            theme: theme,

            showValues: "0",

            bgColor: "#FFFFFF",

            showBorder: "0",

            showCanvasBorder: "0",

            showPlotBorder: "0",

            plotFillRatio: "100",

            showAlternateHGridColor: "0",

            divLineColor: "#cdd4cf",

            plottooltext: "<b>Value</b>{br}   <b>₹ $value</b>",
        
      },
      data: data,
    },
  };

  return (
    <>
      <div style={{ paddingTop: "50px" }}>
        <ReactFC {...chartConfigs} />
      </div>
    </>
  );
};

export default VerticalBarChart;
