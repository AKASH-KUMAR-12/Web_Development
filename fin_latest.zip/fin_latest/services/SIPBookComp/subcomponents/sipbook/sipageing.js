import React, { useState } from "react";
import { useSelector } from "react-redux/es/hooks/useSelector";
import VerticalBarChart from "../../../../newCharts/charts/verticalBarChart";

const SipAgeing = () => {
  const api_results = useSelector((state) => state.CurrentApiData.ApiResponse);
  const bookVAL = useSelector((state) => state.currentCycle.SIPvalue);
  const selectedDate = useSelector((state) => state.currentCycle.currentDate);
  let freshApiResult=useSelector((state)=>state.currentCycle.freshData)
  let assetClassData=freshApiResult[5]?.["SIP AGEING"]
  const activePage = useSelector((state) => state.currentCycle.activePage);
  let currentMonthResult = api_results.filter((data) => {
    return data.batchclosedt === "2023-05-31";
  });
  let ageingArray = currentMonthResult[0]?.sip_ageing;
  let finalVal=activePage === "SIP"? ageingArray:assetClassData

  return (
    <>
       <div className='investor_category'>
       <div style={{ height: "30px", fontFamily: "poppins", borderBottom: "1px solid black", fontSize: 22, paddingLeft: "30px", paddingTop: "5px" }}>
        SIP Ageaing
      </div>
      <VerticalBarChart
        data={finalVal}
        xAxisName={"SIP Ageing"}
        yAxisName={"SIP Age in Year"}
        theme={"fusion"}
        width={520}
      />
      </div>
    </>
  );
};

export default SipAgeing;
