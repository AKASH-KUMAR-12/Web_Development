import * as React from 'react';
import { styled } from '@mui/material/styles';
import Grid from '@mui/material/Grid';
import Paper from '@mui/material/Paper';
import Box from '@mui/material/Box';

const Item = styled(Paper)(({ theme }) => ({
    backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
    ...theme.typography.body2,
    padding: theme.spacing(1),
    textAlign: 'center',
    color: theme.palette.text.secondary,
}));

 const SIPBreakDown = () => {
    return (

        <>
            <Box sx={{ flexGrow: 1, marginTop: "6px" }}>
                <Grid container spacing={2}>
                    <Grid item xs={3}>
                        <div style={{ height: "127px", width: "250px", border: "1px solid black", borderRadius: "10px",backgroundColor:"#10DFFD" }}>
                            <h3 style={{ font: "Roboto", fontWeight: "600", color: "#333333", marginLeft: "30px" }}> Ceased SIP </h3>
                            <div style={{ display: "flex", justifyContent: "space-around", marginTop: "20px", color: "#333333", font: "Roboto", fontWeight: "500" }}>
                                <p>SIP Count</p>
                                <p>SIP Value</p>
                            </div>
                            <div style={{ display: "flex", justifyContent: "space-around", marginTop: "10px", marginBottom: "10px", color: "#333333", font: "Roboto", fontWeight: "500" }}>
                                <p>10,203</p>
                                <p>12.21cr</p>
                            </div>


                        </div>
                    </Grid>
                    <Grid item xs={3}>
                        <div style={{ height: "127px", width: "250px", border: "1px solid black", borderRadius: "10px",backgroundColor:"#10DFFD" }}>
                            <h3 style={{ font: "Roboto", fontWeight: "600", color: "#333333", marginLeft: "30px" }}> Ceased SIP </h3>

                            <div style={{ display: "flex", justifyContent: "space-around", marginTop: "20px", color: "#333333", font: "Roboto", fontWeight: "500" }}>
                                <p>SIP Count</p>
                                <p>SIP Value</p>
                            </div>
                            <div style={{ display: "flex", justifyContent: "space-around", marginTop: "10px", marginBottom: "10px", color: "#333333", font: "Roboto", fontWeight: "500"}}>
                                <p>10,203</p>
                                <p>12.21cr</p>
                            </div>
                        </div>
                    </Grid>
                    <Grid item xs={3}>
                        <div style={{ height: "127px", width: "250px", border: "1px solid black", borderRadius: "10px",backgroundColor:"#10DFFD" }}>
                            <h3 style={{ font: "Roboto", fontWeight: "600", color: "#333333", marginLeft: "30px" }}> Ceased SIP </h3>
                            <div style={{ display: "flex", justifyContent: "space-around", marginTop: "20px", color: "#333333", font: "Roboto", fontWeight: "500" }}>
                                <p>SIP Count</p>
                                <p>SIP Value</p>
                            </div>
                            <div style={{ display: "flex", justifyContent: "space-around", marginTop: "10px", marginBottom: "10px", color: "#333333", font: "Roboto", fontWeight: "500" }}>
                                <p>10,203</p>
                                <p>12.21cr</p>
                            </div>

                        </div>
                    </Grid>
                    <Grid item xs={3}>
                        <div style={{ height: "127px", width: "250px", border: "1px solid black", borderRadius: "10px",backgroundColor:"#10DFFD" }}>
                            <h3 style={{ font: "Roboto", fontWeight: "600", color: "#333333", marginLeft: "30px" }}> Ceased SIP </h3>
                            <div style={{ display: "flex", justifyContent: "space-around", marginTop: "20px", color: "#333333", font: "Roboto", fontWeight: "500" }}>
                                <p>SIP Count</p>
                                <p>SIP Value</p>
                            </div>
                            <div style={{ display: "flex", justifyContent: "space-around", marginTop: "10px", marginBottom: "10px", color: "#333333", font: "Roboto", fontWeight: "500" }}>
                                <p>10,203</p>
                                <p>12.21cr</p>
                            </div>

                        </div>
                    </Grid>
                </Grid>
            </Box>
        </>
      
    );
}

export default SIPBreakDown;
