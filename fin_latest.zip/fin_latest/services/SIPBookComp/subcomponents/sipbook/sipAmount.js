import React, { useState } from "react";
import { useSelector } from "react-redux/es/hooks/useSelector";
import VerticalBarChart from "../../../../newCharts/charts/verticalBarChart";

const SipAmount = () => {
  const api_results = useSelector((state) => state.CurrentApiData.ApiResponse);
  const bookVAL = useSelector((state) => state.currentCycle.SIPvalue);
  const selectedDate = useSelector((state) => state.currentCycle.currentDate);
  const activePage = useSelector((state) => state.currentCycle.activePage);
  let freshApiResult=useSelector((state)=>state.currentCycle.freshData)
  let assetClassData=freshApiResult[6]?.["SIP AMOUNT"]

  let currentMonthResult = api_results.filter((data) => {
    return data.batchclosedt === "2023-05-31";
  });

  let amountArray = currentMonthResult[0]?.sip_amount;
  let finalVal=activePage === "SIP"? amountArray:assetClassData

  return (
    <>
    <div className='investor_category'>
    <div style={{ height: "30px", fontFamily: "poppins", borderBottom: "1px solid black", fontSize: 22, paddingLeft: "30px", paddingTop: "5px" }}>
        SIP Amount
      </div>
      <VerticalBarChart
        data={finalVal}
        xAxisName={"SIP Amount"}
        yAxisName={"SIP Amount in MK"}
        theme={"fusion"}
        width={520}

      />
      </div>
    </>
  );
};

export default SipAmount;
