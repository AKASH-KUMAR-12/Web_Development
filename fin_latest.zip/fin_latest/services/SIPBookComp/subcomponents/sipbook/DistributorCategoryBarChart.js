import React from "react";
import { Grid } from "@mui/material";
import BarChart from "../../../../newCharts/charts/BarChart";
import { useSelector } from "react-redux/es/hooks/useSelector";
import "../../components/style/sipBook.css"

const DistributorCategoryBarChart = () => {

  let freshApiResult=useSelector((state)=>state.currentCycle.freshData)
  let assetClassData=freshApiResult[4]?.["DISTRIBUTOR CATEGORY"]

  return (
    <div className="investor_category">
      <div style={{ height: "30px", fontFamily: "poppins", borderBottom: "1px solid black", fontSize: 22, paddingLeft: "30px", paddingTop: "5px" }}>
        Distributor Category
      </div>
      <div>
      <BarChart data={assetClassData} />
      </div>

      

    </div>

  )
}

export default DistributorCategoryBarChart;