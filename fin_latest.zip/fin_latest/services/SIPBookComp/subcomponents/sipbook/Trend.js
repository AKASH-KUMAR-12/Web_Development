import React from "react";
import InvensoryDemoBarChart from "../../../../newCharts/charts/InvensoryDemoBarChart";
import TrendArea from "../../../../newCharts/charts/TrendAreaChart";
const Trend = () => {

  return (

      <div className='investor_category'>
        <div className='demography_top'>
          <p> Distributor Category </p>
        </div>
        <hr />

        <div style={{ display: "flex", justifyContent: "space-around" ,marginTop:"20px"}}>
        <div style={{ width: "44%" }}>
          <TrendArea />
        </div>
        <div style={{ width: "44%" }} >
          <TrendArea />
        </div>
      </div>
        </div>
      )
}
      export default Trend;