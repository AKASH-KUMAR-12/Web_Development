import React from "react";
import AgeingAmountBarChart from "../../../../newCharts/charts/verticalBarChart";
import InvensoryDemoBarChart from "../../../../newCharts/charts/InvensoryDemoBarChart";
import VerticalBarChart from "../../../../newCharts/charts/verticalBarChart";
import { useSelector } from "react-redux/es/hooks/useSelector";

const InvensoryDemography = () => {
  let freshApiResult=useSelector((state)=>state.currentCycle.freshData)
  let assetClassData=freshApiResult[8]?.["INVESTOR DEMOGRAPHY(AGE)"]

  return (
    <>


<div className="investor_category">
      <div style={{ height: "30px", fontFamily: "poppins", borderBottom: "1px solid black", fontSize: 22, paddingLeft: "30px", paddingTop: "5px" }}>
       Investor Demography
      </div>
      <div>
      <VerticalBarChart data={assetClassData} theme={"fusion"} width={"97%"}/>
      </div>

      

    </div>

    </>
  )
}
export default InvensoryDemography;