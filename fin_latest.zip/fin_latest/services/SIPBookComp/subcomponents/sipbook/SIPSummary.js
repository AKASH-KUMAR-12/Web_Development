import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux/es/hooks/useSelector";
import axios from "axios";
import SecureLS from "secure-ls";
import { useDispatch } from "react-redux";
import { setSIPResponse } from "../../../../reduxStore/ApiResponceReducer";
import { converter } from "../../../../utils/croreconverter";
import "../../../../services/SIPBookComp/components/style/sipBook.css"

const SIPSummary = () => {
  const dispatch = useDispatch();
  // axios.defaults.baseURL = "http://localhost:10001";
  const activePage = useSelector((state) => state.currentCycle.activePage);
  const api_results = useSelector((state) => state.CurrentApiData.ApiResponse);
  const api_FreshResult = useSelector((state) => state.currentCycle.freshData);
  const selectedDate = useSelector((state) => state.currentCycle.currentDate);
  const [sipBookResult, setSIPbookResult] = useState([]);
  const [amountCardHeader, setAmountCardHeader] = useState("");
  const [cardAmount, setCardAmount] = useState();
  const [countCardHeader, setCountCardHeader] = useState("");
  const [cardCount, setCardCount] = useState("");
  const [AverageValue, setAverageValue] = useState("");
  const [amountDiffence, setAmountDifference] = useState();
  const [countDiffence, setCountDifference] = useState();
  const [amtUpAndDown, setAmtUpAndDown] = useState("");
  const [countUpAndDown, setCountUpAndDown] = useState("");

  let currentMonthResult = api_results.filter((data) => {
    return data.batchclosedt === "2023-04-30";
  });

  //This UseEffect Wiill call when date will change to get last 6 month data from Selected Date
  const [freshSipAmount, setFreshSipAmount]= useState("");
  useEffect(() => {
    console.log("fresh Sip Data in summery UseEffect",api_FreshResult[0]);
    // setFreshSipAmount(api_FreshResult[0].data[0].value[0].Fresh_SIP_Amount)
    //suppose response is data which is define above
  }, [Date]);

  // // This UseEffect wll use to Check SipBook Or Fresh Sip and data is present or not for last 6 months to filter with current date
  // useEffect(() => {
  //   if (bookVAL && data) {
  //     console.log("///////", Date);
  //     let prevDate = getPreviousMonthDate(Date);
  //     console.log("111111111111111111111111111111111", typeof prevDate);
  //     console.log("111111111111111111111111111111111", prevDate);

  //     let mainData = sipBookResult.filter(
  //       (element) => element.batchclosedt === Date
  //     )[0];
  //     if (mainData) {
  //       setCardAmount(numDifferentiation(mainData.sip_aum));
  //       setAmountCardHeader("SIP Book");
  //       setCountCardHeader("SIP Count");
  //       setCardCount(mainData.sip_count);
  //       setAverageValue(mainData.avg_sip);
  //     }

  //     let resul = sipBookResult.find((e) => e.batchclosedt === prevDate);
  //     if (resul) {
  //       let Amtdiff = parseInt(cardAmount, 10) - resul.sip_aum;
  //       if (Amtdiff < 0) {
  //         setAmtUpAndDown("Decreased");
  //       } else setAmtUpAndDown("Increased");
  //       let formatedAmtDiff = numDifferentiation(Amtdiff);
  //       // console.log("////++++++++++///",formatedAmtDiff);
  //       setAmountDifference(formatedAmtDiff);
  //       let Countdiff = parseInt(cardCount, 10) - resul.sip_count;
  //       if (Countdiff < 0) {
  //         setCountUpAndDown("Decreased");
  //       } else setCountUpAndDown("Increased");
  //       setCountDifference(Countdiff);
  //       // let formatedCount = numDifferentiation(Countdiff);
  //       // console.log("////++++++++++///",formatedCount);
  //     }
  //     console.log("erfgbn", resul);
  //     console.log("?????????????????????????", mainData);
  //   }
  // }, [][Date]);

  function getPreviousMonthDate(Date) {
    console.log("Again called privious month function");
    var currentDate = new window.Date(Date);
    currentDate.setMonth(currentDate.getMonth() - 1); // Go to the previous month
    const previousYear = currentDate.getFullYear();
    const previousMonth = String(currentDate.getMonth() + 1).padStart(2, "0"); // Add 1 to month and format as two digits
    const lastDayOfPreviousMonth = new window.Date(
      previousYear,
      previousMonth,
      0
    ).getDate();
    const previousMonthFormatted = `${previousYear}-${previousMonth}-${lastDayOfPreviousMonth}`;
    return previousMonthFormatted;
  }

  return (
    <>
      <div
        // style={{
        //   boxShadow: "rgba(0, 0, 0, 0.35) 0px 5px 15px",
        //   margin: "10px 10px 10px 10px",
        //   paddingTop: "5px",
        //   paddingBottom: "5px",
        //   borderRadius: "10px",
        //   backgroundColor:"red"
        // }}
        style={{paddingTop:"5px",paddingBottom:"5px"}}
        className="investor_category"
      >
        <div
          style={{
            margin: "10px 10px 10px 10px",
            boxShadow: " rgba(0, 0, 0, 0.35) 0px 5px 15px",
            borderRadius: "20px",
            display: "flex",
          }}
        >
          {/* SIP Book card */}
          <div
            className="SummeryCards"
            style={{
              boxShadow: " rgba(0, 0, 0, 0.35) 0px 5px 15px",
              margin: "10px 10px 10px 10px",
              display: "inline-flex",
              flexDirection: "column",
              justifyContent: "center",
              paddingLeft: "30px",
              textAlign: "left",
              height: "110px",
              width: "220px",
              borderRadius: "20px",
            }}
          >
            <p
              style={{
                display: "inline-block",
                fontSize: "21px",
                fontFamily: "popins",
                color:"white"
              }}
            >
              {activePage} Book
            </p>
            <p
              style={{
                display: "inline-block",
                fontSize: "21px",
                fontFamily: "popins",
                fontWeight: 600,
                color:"white"

              }}
            >
              {" "}
              {(activePage === 'SIP') ? (converter(currentMonthResult[0]?.sip_aum)):converter(api_FreshResult[0]?.["FRESH SIP AMOUNT"])}
            </p>
          </div>
          <div
            style={{
              borderLeft: "1px solid black",
              display: "inline",
              height: "100px",
              marginTop: "15px",
              marginLeft: "30px",
              color:"white"

            }}
          ></div>

          <div style={{ marginTop: "30px", marginLeft: "30px" }}>
            {activePage === "SIP" ? (
              <>
                <li>
                  {" "}
                  SIP Book as June 23 is {currentMonthResult[0]?.sip_aum}.
                </li>
                <li style={{ paddingTop: "10px" }}>
                  {" "}
                  SIP Book has {amtUpAndDown} by {amountDiffence} (3.57%) from
                  last month.
                </li>
                <li style={{ paddingTop: "10px" }}>
                  {" "}
                  SIP Book has Increased by 67 lacs (3.57%) in current Financial
                  year.
                </li>
              </>
            ) : (
              <>
                <li>Fresh SIP for June 23 is $ 5.8 Cr.</li>
                <li style={{ paddingTop: "10px" }}>
                  Fresh SIP has {countUpAndDown} by ${countDiffence} (3.57%)
                  from last month.
                </li>
              </>
            )}
          </div>
        </div>

        <div
          style={{
            margin: "10px 10px 10px 10px",
            boxShadow: " rgba(0, 0, 0, 0.35) 0px 5px 15px",
            borderRadius: "20px",
            display: "flex",
            
          }}
        >
          <div 
          className="SummeryCards"
            style={{
           
              boxShadow: " rgba(0, 0, 0, 0.35) 0px 5px 15px",
              margin: "10px 10px 10px 10px",
              display: "inline-flex",
              flexDirection: "column",
              justifyContent: "center",
              paddingLeft: "30px",
              textAlign: "left",
              height: "110px",
              width: "220px",
              borderRadius: "20px",
            }}
          >
            <p
              style={{
                display: "inline-block",
                fontSize: "21px",
                fontFamily: "popins",
                color:"white"

              }}
            >
              {activePage} Count
            </p>
            <p
              style={{
                display: "inline-block",
                fontSize: "21px",
                fontFamily: "popins",
                fontWeight: 600,
                color:"white"

              }}
            >
              {(activePage === 'SIP') ? currentMonthResult[0]?.sip_count : api_FreshResult[1]?.["FRESH SIP COUNT"]}
            </p>
          </div>
          <div
            style={{
              borderLeft: "1px solid black",
              display: "inline",
              height: "100px",
              marginTop: "15px",
              marginLeft: "30px",
            }}
          ></div>
          <div style={{ marginTop: "30px", marginLeft: "30px" }}>
            {activePage === "SIP" ? (
              <>
                <li>
                  {" "}
                  SIP Count as June 23 is {currentMonthResult[0]?.sip_count}.
                </li>
                <li style={{ paddingTop: "10px" }}>
                  {" "}
                  SIP Count has {countUpAndDown} by {countDiffence} (3.57%) from
                  last month.
                </li>
                <li style={{ paddingTop: "10px" }}>
                  {" "}
                  SIP Count has Increased by 67 lacs (3.57%) in current
                  Financial year.
                </li>
              </>
            ) : (
              <>
                <li>Fresh SIP Count for Month Of June 23 is $ 5.8 Cr.</li>
                <li style={{ paddingTop: "10px" }}>
                  Fresh SIP Count has Increased by 67 lacs (3.57%) from last
                  month.
                </li>
              </>
            )}
          </div>
        </div>
        <div
          className="SummeryCards"
          style={{
            margin: "10px 10px 10px 10px",
            boxShadow: " rgba(0, 0, 0, 0.35) 0px 5px 15px",
            borderRadius: "10px",
            padding: "2px 0px 2px 20px",
          }}
        >
          <p
            style={{
              display: "inline-block",
              fontSize: "21px",
              fontFamily: "popins",
              color:"white"
            }}
          >
            {(activePage === 'SIP') ? `Average SIP Value for a AMC is ${currentMonthResult[0]?.avg_sip}` : `Average Fresh SIP Value for a AMC is 35K`}
          </p>
        </div>
      </div>
    </>
  );
};

export default SIPSummary;
