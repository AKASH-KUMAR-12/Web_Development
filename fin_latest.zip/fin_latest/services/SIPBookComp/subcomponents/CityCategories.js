import React from "react";
import { Grid } from "@mui/material";
import { useSelector } from "react-redux/es/hooks/useSelector";
import Donut from "../../../newCharts/charts/Donut";
import "../../SIPBookComp/components/style/sipBook.css"
const CityCategories=()=>{
    let freshApiResult=useSelector((state)=>state.currentCycle.freshData)
     let distributorCategoryData=freshApiResult[7]?.["CITY CATEGORIES"]

    return(
        <div className='investor_category'>
        <div className='demography_top'>
            <p>  City Categories </p>
        </div>
        <hr />

        <div className='investor_display'>
        <Grid container spacing={0}> 
        
        <Donut data={distributorCategoryData} />
       
        <div className='vl'></div>
             

        <Grid item xs={12} md={7}>
            <div className='investor_content'>
                <ul>
                    <li>Direct SIP book from (March 23 ) to 172 Cr SIP book.</li>
                    <li>Regular SIP book has grown from (March 23) to 99 Cr SIP book.</li>
                    <li>Contribution of direct SIP Book has grown up by 2.7%.</li>
                </ul>
            </div>
            </Grid>
            </Grid>
        </div>
    </div>
       
    )
}

export default CityCategories;




{/* <div style={{marginLeft:"10px",marginRight:"10px",marginTop:"20px",borderRadius:"20px",boxShadow:"rgba(0, 0, 0, 0.35) 0px 5px 15px",height:"300px"}}>
<div style={{height:"35px",fontFamily:"poppins",borderBottom:"1px solid black",fontSize:22,paddingLeft:"30px",paddingTop:"5px"}}>
    City Categories
</div>
<Grid container >
<Grid item lg={4} md={6}>
    <Donut data={distributorCategoryData} />
</Grid>
<Grid item lg={1} >
<div style={{borderLeft:"1px solid black",height:"190px",marginBottom:"20px",marginTop:"30px",marginLeft:"20px"}}></div>
</Grid>
<Grid item lg={7}  md={6} style={{display:"flex",justifyContent:"center",alignItems:"center"}}>
    <div style={{boxShadow:"rgba(0, 0, 0, 0.35) 0px 5px 15px",padding:"20px 60px 0px 50px",width:"90%",height:"60%",marginRight:"30px",borderRadius:"20px"}}>
        <li style={{paddingTop:"20px",alignSelf:"center"}}>Direct SIP book from (March 23 ) to 172 Cr SIP book</li>
        <li style={{paddingTop:"20px",alignSelf:"center"}}>Regular SIP book from (March 23 ) to 278 Cr SIP book</li>
        <li style={{paddingTop:"20px",alignSelf:"center"}}>Regular SIP book from (March 23 ) to 278 Cr SIP book</li>


    </div>
</Grid>

</Grid>
</div> */}