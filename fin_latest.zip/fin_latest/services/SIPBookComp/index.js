import React, { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { useSelector } from "react-redux";
import { setSIPvalue } from "../../reduxStore/reducer";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { AdapterMoment } from "@mui/x-date-pickers/AdapterMoment";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import moment from "moment";
import { encrypt } from "../../utils/chipher";
import axios from "axios";
import SecureLS from "secure-ls";
import { setSIPResponse } from "../../reduxStore/ApiResponceReducer";
import { setcurrentDate } from "../../reduxStore/reducer";
import { setactivePage } from "../../reduxStore/reducer";
import { setFreshSipData } from "../../reduxStore/reducer";
import SIPBookDashBoard from "./components/sipbook.main";
import FreshSipDashBoard from "./components/freshsip.main";
const Dashboard = () => {
  let ls = new SecureLS();
  const usertoken = ls.get("user-token");
  axios.defaults.baseURL = "http://localhost:50001";
  const dispatch = useDispatch();
  const currentDate = moment();
  let lastDateOfMonth = null;
  const [selectedYear, setSelectedYear] = useState(currentDate.format("YYYY"));
  const [selectedMonth, setSelectedMonth] = useState(currentDate.format("MM"));
  const activePage = useSelector((state) => state.currentCycle.activePage);
  console.log("activePage:", activePage);

  lastDateOfMonth = moment({ year: selectedYear, month: selectedMonth - 1 })
    .endOf("month")
    .format("YYYY-MM-DD");
  console.log("lastDateofMonth:", lastDateOfMonth);
  dispatch(setcurrentDate({ currentDate: lastDateOfMonth }));

  const setfreshsipactivePage = () =>{
    dispatch(setactivePage({ activePage: "Fresh SIP" }));
  }


  const setsipactivePage =() =>{
    dispatch(setactivePage({ activePage: "SIP" }));
  }
  useEffect(() => {
  
    if(activePage === 'SIP'){
      const getGraphsResult = async () => {
        let payload = {
          fund: "RMF",
          batchclosedt: "2023-06-30",
          token: usertoken,
        };

        const encryptedPayload = encrypt(payload);

        var response = await axios.post(`/api/getsipbook`, {
          payload: encryptedPayload,
        });
        console.log("data from api of cards", response.data);
        dispatch(setSIPResponse({ ApiResponse: response.data }));
      };
      getGraphsResult();
    } else{

            const getGraphsResult = async () => {
              let payload = {
                fund: "RMF",
                batchclosedt: "2023-06-30",
                token: usertoken,
              };
      
              const encryptedPayload = encrypt(payload);
      
              var response = await axios.post(`/api/getfreshSip`, {
                payload: encryptedPayload,
              });
              console.log("data from api of cards from freshSip", response.data);
              dispatch(setFreshSipData({ freshData: response.data }));
            };
            getGraphsResult();

    }
  }, [lastDateOfMonth, activePage]);

  return (
    <>
      <div>
        {/* Dashboard div */}
        <div
          style={{
            height: "4rem",
            backgroundColor: "lightblue",
            marginTop: "1rem",
            borderRadius: "10px",
          }}
        >
          <h2
            style={{
              opacity: ".8",
              display: "inline-block",
              marginLeft: "4%",
              marginTop: "1.5%",
            }}
          >
            Dashboard
          </h2>
        </div>

        {/* Data controller div */}
        <div style={{ display: "flex" }}>
          <div >
            <h2
              style={{
                opacity: ".8",
                marginLeft: "4%",
                marginTop: "1.5%",
                marginBottom: "15px",
              }}
            >
              Data as on 30th june
            </h2>
            <button
              onClick={setsipactivePage}
              style={{
                padding: "7px 40px",
                marginLeft: "10px",
                borderRadius: "20px 0px 0px 20px",
                border: "1px solid blue",
                fontSize: 18,
                backgroundColor: activePage == "SIP" ? "blue" : "",
              }}
            >
              SIP Book
            </button>
            <button
              onClick={setfreshsipactivePage}
              style={{
                padding: "7px 40px",
                borderRadius: "0px 20px 20px 0px",
                border: "1px solid blue",
                backgroundColor: activePage !== "SIP" ? "blue" : "",
                fontSize: 18,
              }}
            >
              Fresh SIP
            </button>
          </div>
          <div
            style={{
              // border: "1px solid red",
              display: "flex",
              alignItems: "center",
            }}
          >
            {/* <TextField label="Year" type='number' value={selectedYear} onChange={handleYearChange}/>
                        <TextField label="Month" type='number' value={selectedMonth} onChange={handleMonthChange}/> */}
            {/* <div>
              <LocalizationProvider dateAdapter={AdapterMoment}>
                <DatePicker
                  label={'"month"'}
                  views={["month"]}
                  onChange={(date) => {
                    setSelectedMonth(moment(date).format("MM"));
                  }}
                />
              </LocalizationProvider>
              <LocalizationProvider dateAdapter={AdapterMoment}>
                <DatePicker
                  label={'"year"'}
                  views={["year"]}
                  onChange={(date) => {
                    setSelectedYear(moment(date).format("YYYY"));
                  }}
                />
              </LocalizationProvider>
            </div> */}
          </div>
        </div>
      </div>

      {/* SIP Book and freshSIP Page */}
      <div
        id="div1"
        style={{
          height: "500px",
          position: "relative",
          marginTop: "20px",
          borderRadius: "10px",
        }}
      >
        <div
          id="div2"
          style={{ maxHeight: "100%", overflow: "auto", borderRadius: "10px" }}
        >
          <div id="div3" style={{ height: "auto" }}>
            {activePage === "SIP" ? (
              <div style={{ height: "900px" }}>
                <SIPBookDashBoard />
              </div>
            ) : (
              <div style={{ height: "900px" }}>
                <FreshSipDashBoard/>
             
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
};

export default Dashboard;
