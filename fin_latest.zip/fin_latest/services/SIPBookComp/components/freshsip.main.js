import React from "react";
import SIPSummary from "../subcomponents/sipbook/SIPSummary";
import SecureLS from "secure-ls";
import { encrypt } from "../../../utils/chipher";
import { useDispatch } from "react-redux";
import { useSelector } from "react-redux/es/hooks/useSelector";
import DistributorCategory from "../subcomponents/sipbook/DistributorCategory"
import AssetClass from "../subcomponents/sipbook/AssetClass"
import DistributorCategoryBarChart from "../subcomponents/sipbook/DistributorCategoryBarChart"
import InvensoryDemography from "../subcomponents/sipbook/InvensoryDemography"
import Trend from "../subcomponents/sipbook/Trend"
import CityCategories from "../subcomponents/CityCategories";
import SipAgeing from "../subcomponents/sipbook/sipageing";
import SipAmount from "../subcomponents/sipbook/sipAmount";


const FreshSipDashBoard = () => {

    const selectedDate = useSelector((state) => state.currentCycle.currentDate);
    let ls = new SecureLS();
    const dispatch = useDispatch();
    const usertoken = ls.get("user-token");
    // axios.defaults.baseURL = "http://localhost:10001";

    return (
        <>
            <SIPSummary />
            <DistributorCategory />
            <AssetClass />
            <DistributorCategoryBarChart />
            <div style={{ display: "flex" }}>
                <SipAgeing />
                <SipAmount />
            </div>
            <CityCategories />
            <InvensoryDemography />
            <Trend />
        </>
    );
};

export default FreshSipDashBoard;
