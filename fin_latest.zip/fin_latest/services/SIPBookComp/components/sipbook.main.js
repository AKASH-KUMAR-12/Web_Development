import React from "react";
import SIPSummary from "../subcomponents/sipbook/SIPSummary";
import { useEffect } from "react";
import SipAgeing from "../subcomponents/sipbook/sipageing";
import SipAmount from "../subcomponents/sipbook/sipAmount";
import axios from "axios";
import { setSIPResponse } from "../../../reduxStore/ApiResponceReducer";
import SecureLS from "secure-ls";
import { encrypt } from "../../../utils/chipher";
import { useDispatch } from "react-redux";
import { useSelector } from "react-redux/es/hooks/useSelector";

const SIPBookDashBoard = () => {

    const selectedDate = useSelector((state) => state.currentCycle.currentDate);
    let ls = new SecureLS();
    const dispatch = useDispatch();
    const usertoken = ls.get("user-token");
    // axios.defaults.baseURL = "http://localhost:10001";
  
  return (
    <>
      {/* <SIPBreakDown /> */}
      <SIPSummary />
      <div style={{display:"flex"}}>
      <SipAgeing/>
      <SipAmount/>
      </div>
      {/* <DistributorCategory />
                                    <DistributorCategory /> */}
      {/* <DistributorCategoryBarChart /> */}
      {/* <SIPAgeingAmount /> */}
      {/* <InvensoryDemography /> */}
    </>
  );
};

export default SIPBookDashBoard;
