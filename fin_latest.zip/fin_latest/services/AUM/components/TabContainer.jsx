import { Grid, useMediaQuery } from '@mui/material';
import React from 'react';
import InfoCard from './infoCard'

const TabContainer = () => {
    const dataCard=[{
        "heading":"Total AUM",
        "value":"₹23626.206 Cr",
        "description":"Total AUM month June.....",
        "desc1":"Total AUM month June 23 is ₹287 Cr.",
        "desc2":"SIP Book has Increased by ₹14 Cr (2.71%) from last month.",
        "desc3":"Total AUM month June Decreased by ₹39 Cr(10.53%) in current Financial year."
    },{
        "heading":"Total PAN/ Investors",
        "value":"11,18,177",
        "description":"Total AUM month June.....",
        "desc1":"Total AUM month June 23 is ₹287 Cr.",
        "desc2":"SIP Book has Increased by ₹14 Cr (2.71%) from last month.",
        "desc3":"Total AUM month June Decreased by ₹39 Cr(10.53%) in current Financial year."
    },{
        "heading":"Total Folio Count",
        "value":"14,09,302",
        "description":"Total AUM month June.....",
        "desc1":"Total AUM month June 23 is ₹287 Cr.",
        "desc2":"SIP Book has Increased by ₹14 Cr (2.71%) from last month.",
        "desc3":"Total AUM month June Decreased by ₹39 Cr(10.53%) in current Financial year."
    },{
        "heading":"Distributor Count",
        "value":"16,676",
        "description":"Total AUM month June.....",
        "desc1":"Total AUM month June 23 is ₹287 Cr.",
        "desc2":"SIP Book has Increased by ₹14 Cr (2.71%) from last month.",
        "desc3":"Total AUM month June Decreased by ₹39 Cr(10.53%) in current Financial year."
    }]
    const is1024=useMediaQuery("(width: 1024px)");
  return ( 
    <Grid container 
    spacing={1} sx={{backgroundColor: "white",
        margin:{sm:"0 3rem",xs:"0 1rem"},
        width: is1024?"89%":{sm:"89%", md:"92%",xs:"91%"},
        padding: "0.5rem", 
        fontFamily: "Roboto, sans-serif",
        borderRadius: "0.5rem",
        boxShadow:" 0px 0px 5px 0px rgba(0, 0, 0, 0.26)"
        }}>

  <Grid item sm={6} lg={3} xs={12}>
    <InfoCard data={dataCard[0]}/>
  </Grid>
  <Grid item sm={6} lg={3} xs={12}>
    <InfoCard data={dataCard[1]}/>
  </Grid>
  <Grid item sm={6} lg={3} xs={12}>
    <InfoCard data={dataCard[2]}/>
  </Grid>
  <Grid item sm={6} lg={3} xs={12}>
    <InfoCard data={dataCard[3]}/>
  </Grid>
</Grid>
  )
}

export default TabContainer