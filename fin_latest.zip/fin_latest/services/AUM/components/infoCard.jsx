import React, { useState } from 'react'
import "./TopCard.css"

const Card = ({data}) => {
    const [changeCard,setCard]=useState('display');
    const [changeValue,setValue]=useState('View more');
    const [changePara1,setPara1]=useState('before');
    const [changePara2,setPara2]=useState('after');
    const change=()=>{
        if(changeCard=='display'){
            setCard('non_display');
        }
        else{
            setCard('display');
        }
        if(changeValue=='View more')
        {
            setValue('View less');
        }
        else{
            setValue('View more');
        }
        if(changePara1=='before'){
            setPara1('non_display');
        }
        else{
            setPara1('before');
        }
        if(changePara2=='after'){
            setPara2('display_container');
        }
        else{
            setPara2('after');
        }
    }

  return (
    <div className='card'>
            <div className={changeCard} >
                <p>{data.heading}</p>
                <h2>{data.value}</h2>
            </div>
            <div className='content'>
            <ul className={changePara1}>
            <li>
                <p>{data.desc1}</p>
            </li>
            </ul>
            <ul className={changePara2}>
                <li className='line'><hr width="100%" size="8" color="#3bb4e9"  noshade/></li>
                <li>{data.desc1}</li>
                <li>{data.desc2}</li>
                <li>{data.desc3}</li>
            </ul>
                <a className='click' onClick={change}><u>{changeValue}</u></a>
            </div>
        </div>
  )
}

export default Card;