import FusionCharts from "fusioncharts";
import charts from "fusioncharts/fusioncharts.charts";
import ReactFusioncharts from "react-fusioncharts";

// Resolves charts dependancy
charts(FusionCharts);

const dataSource = {
  chart: {
    xaxisname:"Month",
    yaxisname: "AUM(Cr.)",
    // animation:1,
    // borderColor :"white",
    bgColor :"#FFFFFF",
    "bgAlpha": "50",
    // canvasBgColor :"#FFFFFF",
    showBorder:0,
    "showcanvasborder": "0",
    "showxaxisline": "1",
    "showyaxisline": "1",
    // "alternateHGridColor": "#FFFFFF",
    "lineColor": "#2057a6",
    // labelDisplay:'WRAP',
    numDivLines :11,
    divLineColor : "#d3d4d4",
    setadaptiveymin: "1",
    theme: "gammel",
    "anchorBgColor": "#2057a6",
    "showAlternateHGridColor": "0"
  },
  data: [
    {
      label: "JAN",
      value: "15"
    },
    {
      label: "FEB",
      value: "22"
    },
    {
      label: "MAR",
      value: "40"
    },
    {
      label: "APR",
      value: "30"
    },
    {
      label: "MAY",
      value: "44"
    },
    {
      label: "JUN",
      value: "40"
    },
    {
      label: "JULY",
      value: "55"
    },
    {
      label: "AUG",
      value: "60"
    },
    {
      label: "SEP",
      value: "70"
    },
    {
      label: "OCT",
      value: "75"
    },
    {
      label: "NOV",
      value: "78"
    },
    {
      label: "DEC",
      value: "80"
    }
  ]
};

const LineChart = () => {
    return (
      <ReactFusioncharts
        type="line"
        width={window.innerWidth <=640 ? "200%":"280%"}
        height={window.innerWidth <=1024 ? "25%":"45%"}
        dataFormat="JSON"
        dataSource={dataSource}
      />
    );
  }


export default LineChart
