import React from 'react'
import FusionCharts from "fusioncharts";
import charts from "fusioncharts/fusioncharts.charts";
import ReactFusioncharts from "react-fusioncharts";

charts(FusionCharts);

const DoughnutChart=({data})=>
   {
    const dataSource = {
      chart: {
        theme: "candy",
        use3DLighting:false,
        showShadow: false,
        doughnutRadius: window.innerWidth <=640 ? 65:70,
        pieRadius:window.innerWidth <=640 ? 85:100,
        showLegend :"1",
        bgcolor:"#ffffff",
        "interactiveLegend": "1",
        "showborder": "0",
        "legendPosition": window.innerWidth <=640 ? "bottom":"right-bottom",
        legendBorderColor :"#ffffff",
        "legendShadow": "0",
        "chartLeftMargin": "0",
        "chartTopMargin": "10",
        "chartRightMargin": "0",
        "chartBottomMargin":"10", 
        "drawCustomLegendIcon": "1",
        "legendIconSides": "4",
        "legendIconStartAngle": "45",
        "paletteColors": "#2057a6,#8ed8b7,#69b8f4,#82c7ed,#8fabd3"
      },
      data: data
    };
    return (
      <>
      <div>
      <ReactFusioncharts
        type="doughnut2d"
        width={window.innerWidth <=640 ? "110%":"100%"}
        height="35%"
        dataFormat="JSON"
        dataSource={dataSource}
      /></div>
      
      </>
    );
  }


export default DoughnutChart