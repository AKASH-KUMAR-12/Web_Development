import React from "react";
import FusionCharts from "fusioncharts";
import charts from "fusioncharts/fusioncharts.charts";
import ReactFusioncharts from "react-fusioncharts";
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormControl from '@mui/material/FormControl';
import './comp_style.css';

// Resolves charts dependancy
charts(FusionCharts);

const dataSource = {
  chart: {
    xaxisname:"Broker Category",
    yaxisname: "PAN Count",
    plotSpacePercent: 40,
    aligncaptionwithcanvas: "0",
    plottooltext: "<b>Average SIP Value</b>{br}<b>$value</b>",
    theme: "fusion",
    "showValues": "0",
    "showxaxisline": "1",
    "showyaxisline": "1",
    showPlotBorder :"0",
    showBorder :"0",
    "showcanvasborder": "0",
    bgColor :"#FFFFFF",
    "plotFillRatio": "100",
    "showAlternateHGridColor": "0",
    "divLineColor": "#cdd4cf",
    "paletteColors": "#69b8f4,#8ed8b7,#2057a6,#82c7ed,#8fabd3"
  },
  data: [
    {
      label: "MFD",
      value: "41"
    },
    {
      label: "ND",
      value: "50"
    },
    {
      label: "DIRECT",
      value: "30"
    },
    {
      label: "RIA",
      value: "35"
    },
    {
      label: "BANK",
      value: "32"
    }
  ]
};


const Distributor=({values})=>{
    const [value, setValue] = React.useState('female');

  const handleChange = (event) => {
    setValue(event.target.value);
  };
    return (
        <div className="distributor_content">
        <div className="distribute_top">
        <p>{values.heading}</p>
        <FormControl>
      <RadioGroup  sx={{
        '& .MuiTypography-root':{
          fontSize: '.8rem',
        }
      }}
        row
        aria-labelledby="demo-row-radio-buttons-group-label"
        name="row-radio-buttons-group" 
      >
        <FormControlLabel value="AUM" control={<Radio />} label="AUM" />
        <FormControlLabel value="PAN Count" control={<Radio />} label="PAN Count" />
      </RadioGroup>
    </FormControl>
        </div>
        <hr/>
      <ReactFusioncharts
        type="bar2d"
        width="100%"
        height={window.innerWidth <=820 ? "25%":"38%"}
        dataFormat="JSON"
        dataSource={dataSource}
      />
      </div>
    )};
  export default Distributor

