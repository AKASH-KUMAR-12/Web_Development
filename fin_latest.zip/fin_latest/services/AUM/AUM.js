import React from 'react'
import Top from './components/Top'
import Mid from './components/Mid'
import './AUM.css'
import TabContainer from './components/TabContainer'

const AUM = () => {
  return (
    <div className='container'>
      <div className='top_container'> 
      <Top />
        <div className='scroll'>
        <Mid/>
        </div>
      </div>
    </div>
    
  )
}

export default AUM