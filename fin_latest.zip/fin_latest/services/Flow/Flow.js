
import './Flow.css';
import Box from '@mui/material/Box';
import React, { Fragment } from 'react';
import side_nav from './images/side_nav.png';
import { Button, Card, Grid, TextField } from '@mui/material';
import TransactionCateogory from './component/TransactionCateogory';
import DonutChart from './component/DonutChart';
import bluebg from './images/blue-btn.png';
import footer from './images/kfin-footer.png';
import ColumnChart from './component/ColumnChart';
import { styled } from '@mui/system';
import { barChartData, pieChartData } from './DataBase';

function Flow() {

  // styled Box component with a media query
  const DateCard = styled(Card)`
    margin:40px 40px 8px;
    @media only screen and (max-width: 900px) {
      margin:8px;
      padding-inline:0px;
    }
  `;
  const ResponsiveBox = styled(Box)`
  
    width:100%;
    @media only screen and (max-width: 400px) {
      width:100vw;
      // height:100vh;
     }
    @media only screen and (max-width: 900px) {
     width:100vw;
    //  height:100vh;
    }
  `;
  const ScrollableBox = styled(Box)`
    width:97%;
    margin-inline:16px;
    height:54vh;
    @media only screen and (max-width: 900px) {
      margin-left:0px;
      height:80vh;
      text-align:center;
     
    }
    @media only screen and (max-width: 400px) {
      margin-left:0px;
      height:57vh;
      text-align:center;
     
    }
  `;
  const HeadingCard = styled(Card)`
    margin:40px;
    @media only screen and (max-width: 900px) {
      margin:8px;
     
    }
  `;


  const row1_blueCard = { height: 90, backgroundImage: `url(${bluebg})`, backgroundSize: 'cover', borderRadius: 3, marginBottom: 3, boxShadow: 3, paddingInline: 4, paddingTop: 2, fontSize: '1.2rem', color: 'white' };
  return (
    <>

      {/* <Box className="outer-box" sx={{ width: "100%", backgroundColor: '#FFFFFF' }}> */}
      {/* ########## Finstax Side Nav ###########*/}
      {/* <Box className="side-nav" sx={{ bgcolor: '#cfe8fc', height: '100vh', width: "15%" }}>
          <img src={side_nav} height={"100%"} width={'100%'} alt="" />
        </Box> */}
      {/* ######### Container Box ############### */}
      <ResponsiveBox className='container-box'>
        {/* <Box sx={{ width: '100%', height: "10%", boxShadow: "  2px 11px 13px -9px rgba(0,0,0,0.24)" }}></Box> */}
        {/* #### Dashboard Card ####### */}
        <HeadingCard sx={{
          backgroundColor: '#d5daf0', minWidth: 200, padding: 2, fontSize: '1.5rem', borderRadius: 2, borderColor: "#d5daf0",
        }} variant="outlined">
          <p style={{ fontSize: "1.2rem", fontWeight: 'bold', margin: 0 }}>
            Dashboard
          </p>
        </HeadingCard>
        {/* ############ Date Card ############# */}
        <DateCard sx={{ fontSize: '1.5rem', display: 'flex', paddingInline: 2, boxShadow: "1px 0px 14px -4px rgba(0,0,0,0.5)" }} variant="outlined">
          <Grid container>
            <Grid item xs={12} sm={6} md={6}>
              <Box >
                <h5 style={{ margin: "8px" }}>
                  Data as on 22th Aug
                </h5>
                <Box sx={{ margin: "8px" }}>
                  <Button variant='contained' sx={{ borderTopLeftRadius: "25px", borderBottomLeftRadius: "25px", width: "160px", backgroundColor: "#3759bf" }}>Amount</Button>
                  <Button variant='outlined' sx={{ borderTopRightRadius: "25px", borderBottomRightRadius: "25px", borderColor: "#3759bf", color: "#3759bf" }}>Transaction Count</Button>
                </Box>
              </Box>
            </Grid>
            <Grid item xs={12} sm={6} md={6}>
              <Box sx={{ display: "flex", flexDirection: 'row', justifyContent: "flex-end" }}>

                <Box sx={{ margin: 1 }}>
                  <p style={{ margin: 3, fontSize: ".9rem", fontWeight: 'bold' }}>Date</p>
                  <TextField
                    id="date"
                    type="date"
                    defaultValue="2017-05-24"
                    sx={{
                      width: '9.3rem', margin: 0, boxShadow: "1px 0px 14px -4px rgba(0,0,0,0.5)"
                    }}

                  />
                </Box>
                <Box sx={{ margin: 1 }}>
                  <p style={{ margin: 3, fontSize: ".9rem", fontWeight: 'bold' }}>To Date</p>
                  <TextField
                    id="date"
                    type="date"
                    defaultValue="2017-05-24"
                    sx={{ width: '9.3rem', margin: 0, boxShadow: "1px 0px 14px -4px rgba(0,0,0,0.5)" }}

                  />

                </Box>
              </Box>
            </Grid>
          </Grid>


        </DateCard>


        {/* ##### Scrollable Div ####### */}
        <ScrollableBox className="no-scrollbar" sx={{ overflow: "scroll", paddingTop: 4 }}>


          {/* ######### Row 1 ############# */}

          <Grid container spacing={2} sx={{ marginBottom: 1 }}>
            <Grid item xs={12} sm={4} md={3}>
              <Box sx={{ height: '100%', marginInline: 3, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
                <Box sx={row1_blueCard}>
                  <p style={{ margin: 0, padding: 8 }}>Gross Sales</p>
                  <p style={{ fontWeight: 'bold', fontSize: '1.4rem', margin: 0 }}>₹ 5.5K Cr</p>
                </Box>
                <Box sx={row1_blueCard}>
                  <p style={{ margin: 0, padding: 8 }}>Redemption</p>
                  <p style={{ fontWeight: 'bold', fontSize: '1.4rem', margin: 0 }}>₹ 5.5K Cr</p>
                </Box>
                <Box sx={row1_blueCard}>
                  <p style={{ margin: 0, padding: 8 }}>Net Sales</p>
                  <p style={{ fontWeight: 'bold', fontSize: '1.4rem', margin: 0 }}>₹ 5.5K Cr</p>
                </Box>
              </Box>
            </Grid>
            <Grid item xs={12} sm={8} md={9}>
              <Box sx={{ bgcolor: 'white', borderRadius: 4, boxShadow: 3, margin: 3, marginTop: 0, padding: 1, paddingInline: 2 }}>
                <p style={{ marginInline: 16, marginBlock: 6, fontWeight: 'bold' }}>Transaction Cateogory</p><hr />
                <TransactionCateogory data={barChartData[0]} />
              </Box>

            </Grid>
          </Grid>


          {/* ######### Row 2 ############# */}
          <Grid container sx={{ display: 'flex', marginBottom: 1 }}>
            <Grid item xs={12} sm={12} md={6}>
              <Box sx={{ bgcolor: 'white', borderRadius: 4, boxShadow: 3, margin: 3, padding: 1 }}>
                <p style={{ marginInline: 16, marginBlock: 6, fontWeight: 'bold' }}>Transaction Type</p><hr />
                <DonutChart data={pieChartData[0]} />
              </Box></Grid>
            <Grid item xs={12} sm={12} md={6}>
              <Box sx={{ bgcolor: 'white', borderRadius: 4, boxShadow: 3, margin: 3, padding: 1, paddingInline: 2 }}>
                <p style={{ marginInline: 16, marginBlock: 6, fontWeight: 'bold' }}>Transaction Source</p><hr />
                <TransactionCateogory data={barChartData[1]} />
              </Box>
            </Grid>
          </Grid>

          {/* ######### Row 3 ############# */}
          <Grid container sx={{ display: 'flex', marginBottom: 1 }}>
            <Grid item xs={12} sm={12} md={6}>

              <Box sx={{ bgcolor: 'white', borderRadius: 4, boxShadow: 3, margin: 3, padding: 1 }}>
                <p style={{ marginInline: 16, marginBlock: 6, fontWeight: 'bold' }}>Asset Class</p><hr />
                <DonutChart data={pieChartData[1]} />
              </Box>
            </Grid>
            <Grid item xs={12} sm={12} md={6}>
              <Box sx={{ bgcolor: 'white', borderRadius: 4, boxShadow: 3, margin: 3, padding: 1, paddingInline: 2 }}>
                <p style={{ marginInline: 16, marginBlock: 6, fontWeight: 'bold' }}>Scheme Sub Cateogory</p><hr />
                <TransactionCateogory data={barChartData[2]} />
              </Box>
            </Grid>
          </Grid>

          {/* ######### Row 4 ############# */}
          <Grid container sx={{ display: 'flex', marginBottom: 1 }}>
            <Grid item xs={12} sm={12} md={12}>
              <Box sx={{ bgcolor: 'white', borderRadius: 4, margin: 3, padding: 1, boxShadow: "1px 3px 19px -4px rgba(0,0,0,0.25)" }}>
                <p style={{ marginInline: 16, marginBlock: 6, fontWeight: 'bold' }}>Scheme Name</p><hr />
                <ColumnChart data={barChartData[3]} />

              </Box>
            </Grid>
          </Grid>
          {/* ######### Row 5 ############# */}

          {/* <Box sx={{
              display: 'flex', height: "44rem",
            }}>
              <Box sx={{ width: '95%', bgcolor: 'white', borderRadius: 4, margin: 3, marginLeft: 5, padding: 1, boxShadow: "1px 3px 19px -4px rgba(0,0,0,0.25)" }}>
                <p style={{ marginInline: 16, marginBlock: 6, fontWeight: 'bold' }}>Invertor Demography</p><hr />
                <MapChart />
              </Box>
            </Box> */}

          {/* ######### Row 6 ############# */}

          <Grid container sx={{ display: 'flex', marginBottom: 1 }}>
            <Grid item xs={12} sm={12} md={4}>
              <Box sx={{ bgcolor: 'white', borderRadius: 4, boxShadow: 3, margin: 3, padding: 1 }}>
                <p style={{ marginInline: 16, marginBlock: 6, fontWeight: 'bold' }}>Gross Sales</p><hr />
                <TransactionCateogory data={barChartData[4]} />
              </Box>
            </Grid>
            <Grid item xs={12} sm={12} md={4}>
              <Box sx={{ bgcolor: 'white', borderRadius: 4, boxShadow: 3, margin: 3, padding: 1 }}>
                <p style={{ marginInline: 16, marginBlock: 6, fontWeight: 'bold' }}>Redemption</p><hr />
                <TransactionCateogory data={barChartData[5]} />
              </Box>
            </Grid>
            <Grid item xs={12} sm={12} md={4}>
              <Box sx={{ bgcolor: 'white', borderRadius: 4, boxShadow: 3, margin: 3, padding: 1 }}>
                <p style={{ marginInline: 16, marginBlock: 6, fontWeight: 'bold' }}>Net Sales</p><hr />
                <TransactionCateogory data={barChartData[6]} />
              </Box>
            </Grid>
          </Grid>
        </ScrollableBox>
      </ResponsiveBox>
    </ >
  );
}

export default Flow;
