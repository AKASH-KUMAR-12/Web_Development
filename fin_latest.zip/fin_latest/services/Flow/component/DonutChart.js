import FusionCharts from "fusioncharts";
import charts from "fusioncharts/fusioncharts.charts";
import ReactFusioncharts from "react-fusioncharts";
import React, { useEffect, useRef } from 'react'

// Resolves charts dependancy
charts(FusionCharts);

// const colorPalette = ['#80d8b7', '#2057a6', '#06adcf'];

const DonutChart = ({ data }) => {
    const chartRef = useRef(null);
    useEffect(() => {
        if (chartRef.current && chartRef.current.parentElement) {
            // Get the width of the parent container
            const containerWidth = chartRef.current.parentElement.offsetWidth;

            // Update the chart width and render it
            FusionCharts.items[chartRef.current.id].resizeTo(containerWidth);



            // isMobile = window.innerWidth <= 768; // Adjust the breakpoint as needed
            // const chartInstance = chartRef.current.chartInstance;

            // if (chartInstance) {
            //     chartInstance.chartObj.setChartAttribute(
            //         "legendPosition",
            //         isMobile ? "bottom" : "right-bottom"
            //     );
            //     chartInstance.render();
            // }
        }
    }, []);
    const length = data.length;
    const dataSource = {
        chart: {

            theme: 'fusion',
            showBorder: "0",
            showcanvasborder: "0",
            bgColor: "#FFFFFF",
            plotBorderColor: "#FFFFFF",
            showLegend: length > 6 ? "0" : "1",
            legendNumRows: "3",
            legendPosition: window.innerWidth <= 768 ? "bottom" : "right-bottom",
            use3DLighting: "0",
            showpercentvalues: "1",
            pieRadius: window.innerWidth <= 768 ? "100" : "130",
            doughnutRadius: window.innerWidth <= 768 ? "70" : "100",
            decimals: "1",
            plottooltext: "<b>$label</b>   <b>$percentValue</b>",
            paletteColors: "#80d8b7, #2057a6, #06adcf, #5193c9, #51c985, #c951a7",
            showLabels: "0",
            drawCustomLegendIcon: "1",
            legendIconSides: "4",
            legendBgAlpha: 0,
            legendBorderAlpha: 0,
            legendShadow: "0",
            legendWidth: "150",
            legendIconScale: window.innerWidth <= 768 ? "1" : length > 3 ? "1" : "2",

        },
        data: data


    };

    return (
        <ReactFusioncharts
            type="doughnut2d"
            width="100%"
            height="40%"
            dataFormat="JSON"
            dataSource={dataSource}
            ref={chartRef} />

    )
}

export default DonutChart


