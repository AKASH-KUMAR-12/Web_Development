import FusionCharts from "fusioncharts";
import charts from "fusioncharts/fusioncharts.charts";
import ReactFusioncharts from "react-fusioncharts";
import React from 'react'


// const colorPalette = ['#80d8b7', '#2057a6', '#06adcf', '#5193c9', '#51c985', '#c951a7'];
const TransactionCateogory = ({ data }) => {
    charts(FusionCharts);
    const { chartData, chartAxis } = data;
    const dataSource = {

        "chart": {
            "theme": "fusion",
            labelFontSize: "10",
            yAxisValueFontSize: "10",
            xAxisNameFontSize: "10",
            yAxisNameFontSize: "10",
            xAxisNameFontColor: "#9aa19c",
            yAxisNameFontColor: "#9aa19c",
            plotSpacePercent: 50,
            yAxisName: `${chartAxis.yName}`,
            xAxisName: `${chartAxis.xName}`,
            alignCaptionWithCanvas: "0",
            showBorder: "0",
            showcanvasborder: "0",
            bgColor: "#FFFFFF",
            showYAxisLine: "1",
            yAxisLineColor: "#807878",
            showAlternateVGridColor: "0",
            divLineColor: "#cdd4cf",
            plotBorderColor: "#FFFFFF",
            plotFillRatio: "100",
            paletteColors: "#80d8b7, #2057a6, #06adcf, #5193c9, #51c985, #c951a7",
            // "rotateLabels": "1",
            "labelDisplay": "wrap"
            // showLabels: 0
        },
        // data: chartData.map((item, itemIndex) => ({
        //     ...item,
        //     color: colorPalette[itemIndex],

        // }))
        data: chartData
    };

    return (
        <ReactFusioncharts
            type="bar2d"
            width="100%"
            height="40%"
            dataFormat="JSON"
            dataSource={dataSource}
        />
    );
}






export default TransactionCateogory