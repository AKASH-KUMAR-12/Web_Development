import React from 'react';
import Box from '@mui/material/Box';
import { styled } from '@mui/material/styles';
import Grid from '@mui/material/Unstable_Grid2';
import Paper from '@mui/material/Paper';
const Item = styled(Paper)(({ theme }) => ({
    backgroundColor: '#E3EAF3',
    padding: theme.spacing(1),
    border: 0,
    //   textAlign: 'center',
    //   color: theme.palette.text.secondary,
}));


const BusinessBreakDown = () => {
    let data = [
        {
            "key": "Total AUM",
            "value" : "23.98CR",
            cremental :"increases",
            amount : "14cr",
            percent : "25%"
        },
        {
            "key": "Gross Sale",
            "value" : "34.98CR",
            cremental :"decreases",
            amount : "34cr",
            percent : "5%"
        },
        {
            "key": "Net Sale",
            "value" : "78.98CR",
            cremental :"increases",
            amount : "53cr",
            percent : "25%"
        },
        {
            "key": "SIP Book",
            "value" : "5678.98CR",
            cremental :"increases",
            amount : "53cr",
            percent : "25%"
        },
        {
            "key": "No. of Distributor Activated",
            "value" : "23678.98CR",
            cremental :"decreases",
            amount : "13cr",
            percent : "13%"
        },
        {
            "key": "Total SIP Count",
            "value" : "4568.98CR",
            cremental :"increases",
            amount : "53cr",
            percent : "25%"
        },
        {
            "key": "Fresh SIP Amount",
            "value" : "5678.98CR",
            cremental :"increases",
            amount : "53cr",
            percent : "25%"
        },
        {
            "key": "Fresh SIP Count",
            "value" : "28.98CR",
            cremental :"increases",
            amount : "53cr",
            percent : "25%"
        }

    ]
    
  return (
    <Box >
    <Grid container spacing={{ xs: 2, md: 3 }} columns={{ xs: 4, sm: 8, md: 12 }} sx={{ backgroundColor: "white", boxShadow: 3, margin: "2% 1% 0 0", "& .css-1ik6aa3-MuiPaper-root": { background: "#fff", height: "7rem", borderTop: 4, borderColor: 'primary.main', borderRadius: '16px' } }}>
        {data.map((res, index) => (
            <Grid xs={2} sm={4} md={4} key={index} >
                <Item>
                  <p style={{ marginTop:"1%"}}>{res.key}</p> 
                  {
                      (res.cremental == "increases") ? (<div style={{position:"relative"}}><h3 style={{color:"green",position:"absolute",marginTop:"-7%", right:"2%"}}>+{res.value}</h3> <h3 style={{color:"green",position:"absolute", marginTop:"18%", right:"2%"}}>{res.percent}</h3></div>) : (<div style={{position:"relative"}}><h3 style={{color:"red",position:"absolute", marginTop:"-7%", right:"2%"}}>-{res.value}</h3> <h3 style={{color:"red",position:"absolute", marginTop:"18%", right:"2%"}}>{res.percent}</h3></div>)
                  }
                  <p style={{ margin:"8% 0 3% 0"}}>Current Value</p> 
                  {
                    
                    (res.key == "No. of Distributor Activated" || res.key == "Total SIP Count" || res.key == "Fresh SIP Count" ) ? (<h3>{res.value}</h3>) : (<h3>&#8377;{res.value}</h3>)
                  }
                  
                  
                </Item>
            </Grid>
        ))}
    </Grid>
   </Box>
  )
}

export default BusinessBreakDown