import React from 'react';
import Box from '@mui/material/Box';
import { styled } from '@mui/material/styles';
import Grid from '@mui/material/Unstable_Grid2';
import Paper from '@mui/material/Paper';
import TrendAreaChart from '../../../newCharts/charts/TrendAreaChart';

const Item = styled(Paper)(({ theme }) => ({
    backgroundColor: '#E3EAF3',
    padding: theme.spacing(1),
    border: 0,
    //   textAlign: 'center',
    //   color: theme.palette.text.secondary,
}));


const MarketShare = () => {
  return (
    <Box>
    <Grid container spacing={2} columns={16} sx={{ margin: "2% 1% 0 0" ,"& .css-1ik6aa3-MuiPaper-root":{backgroundColor:"#fff", height:"20rem"}}}>
        <Grid xs={16} sx={{"& .css-1ik6aa3-MuiPaper-root":{boxShadow:6}}}>
            <Item>
              <h3>Market Share</h3>
              <hr/>
              <TrendAreaChart/>
            </Item>
        </Grid>
    </Grid>
</Box>
  )
}

export default MarketShare