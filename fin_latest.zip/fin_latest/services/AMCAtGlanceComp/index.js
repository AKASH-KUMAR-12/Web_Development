import Stack from '@mui/material/Stack';
import Box from '@mui/material/Box';
import { styled } from '@mui/material/styles';
import Grid from '@mui/material/Unstable_Grid2';
import Paper from '@mui/material/Paper';
import BusinessBreakDown from './Business/BusinessBreakDown';
import MarketShare from './Business/MarketShare';
import AUMGrossSale from './Business/AUMGrossSale';
const Item = styled(Paper)(({ theme }) => ({
    backgroundColor: '#E3EAF3',
    padding: theme.spacing(1),
    border: 0,
    //   textAlign: 'center',
    //   color: theme.palette.text.secondary,
}));

const AmcGlanceDashBoard = () => {
    const data = [

        {
            title: "Total AUM",


        }
    ]


    return (
        <>


            <Box sx={{ width: '100%' }}>
                <Stack spacing={2} sx={{ "& .css-1ik6aa3-MuiPaper-root": { boxShadow: "none" }, margin: "2% 1% 0 0" }}>
                    <Item>
                        <h2>Dashboard</h2>
                    </Item>
                </Stack>
            </Box>

            <Box sx={{ width: '100%' }}>
                <Stack spacing={2} sx={{ "& .css-1ik6aa3-MuiPaper-root": { boxShadow: "none" }, margin: "2% 1% 0 0", "& .css-1955l30-MuiPaper-root": { backgroundColor: "#fff", boxShadow: 3 } }}>
                    <Item sx={{ height: "5rem" }}>
                        <h2>Data as on 1st of Aug</h2>
                    </Item>
                </Stack>
            </Box>
            <Box style={{ height: "25rem", position: "relative", marginTop: "0.5rem", borderRadius: "10px" }}>
                <Box style={{ maxHeight: "100%", overflow: "auto", borderRadius: "10px" }}>
                       <BusinessBreakDown />
                        <AUMGrossSale />
                        <MarketShare />
                        {/* <Stack spacing={2} sx={{ "& .css-1ik6aa3-MuiPaper-root": { boxShadow: "none" }, marginLeft: "-1.3%", "& .css-1955l30-MuiPaper-root": { backgroundColor: "blue", boxShadow: 3 } }}>
                    <Item sx={{ height: "5rem" }}>
                        <h2>KFinTech</h2>
                    </Item>
                </Stack> */}

                </Box>
            </Box>
          

        </>
    )
}
export default AmcGlanceDashBoard;