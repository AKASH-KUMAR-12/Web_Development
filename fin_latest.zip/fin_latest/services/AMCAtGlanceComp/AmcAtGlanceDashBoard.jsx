import React from 'react'
import AmcGlanceDashBoard from './index'

const AmcAtGlanceDashBoard = () => {
  return (
    <>
     <AmcGlanceDashBoard/>
    </>
  )
}

export default AmcAtGlanceDashBoard