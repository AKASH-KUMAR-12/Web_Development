import React from 'react'
import FusionCharts from "fusioncharts";
import charts from "fusioncharts/fusioncharts.charts";
import ReactFusioncharts from "react-fusioncharts";

charts(FusionCharts);

const dataSource = {
  chart: {
    theme: "candy",
    use3DLighting:false,
    showShadow: false,
    doughnutRadius: window.innerWidth <=390 ? 40:70,
    pieRadius:window.innerWidth <=390 ? 60:100,
    bgcolor:"#ffffff",
    "showborder": "0",
  },
  data: [
    {
      label: "B30",
      value: "1000",
      showLabel:'0',
      showValue:'0',
      color:"#2057a6"
    },
    {
      label: "T30",
      value: "500",
      showLabel:'0',
      showValue:'0',
      color:"#8ed8b7"
    }  
  ]
};

const Investor=()=>
   {
    return (
      <>
      <div>
      <ReactFusioncharts
        type="doughnut2d"
        width={window.innerWidth <=390 ? "110%":"100%"}
        height="35%"
        dataFormat="JSON"
        dataSource={dataSource}
      /></div>
      
      </>
    );
  }


export default Investor