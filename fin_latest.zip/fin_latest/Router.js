import React, { useEffect } from 'react'
import { Route, Routes } from 'react-router-dom'
import SecureLS from "secure-ls";
import { useNavigate } from "react-router-dom";


import SIPBookDashBoard from './services/SIPBookComp/index'
import AmcAtGlanceDashBoard from './services/AMCAtGlanceComp/AmcAtGlanceDashBoard'
import DashBoardLayout from './layout/DashBoardLayout'
import HomePage from './auth';
import Flow from './services/Flow/Flow';
import AUM from './services/AUM/AUM';




const Router = () => {


  let ls = new SecureLS();
  let navigate = useNavigate();
  // let usertoken = ls.get('user-token')

  // useEffect(() => {
  //   if (!usertoken) {
  //     navigate("/");
  //   }else{
  //     navigate("/app/AMCAtGlance")
  //   }
  // }, [usertoken]);



  return (
    <Routes>

      <Route path='/app' element={<DashBoardLayout />} >
        <Route path='AMCAtGlance' element={<AmcAtGlanceDashBoard />} />
        <Route path='sip' element={<SIPBookDashBoard />} />
        <Route path='flow' element={<Flow />} />
        <Route path='AUM' element={<AUM />} />
        {/* <Route path = 'Flow' element = {<DashBoardLayout/>}/> */}
        <Route path='*' element={<h1>Page not found</h1>} />
      </Route>
    </Routes>
  )
}

export default Router