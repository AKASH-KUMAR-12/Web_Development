export function converter(value) {
    const val = Math.abs(value);
    if (val >= 10000000) return `${(value / 10000000).toFixed(2)} Cr`;
    if (val >= 100000) return `${(value / 100000).toFixed(2)} Lac`;
    return value;
  }